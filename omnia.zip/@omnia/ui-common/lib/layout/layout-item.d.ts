import { Type } from '@angular/core';
import { LayoutInfo } from './layout-info';
import { Widget } from '../framework/widget.interface';
import { Subject } from 'rxjs';
import { LinkedEvent } from '../framework/linked-event';
export declare class LayoutItem extends LayoutInfo {
    type?: Type<Widget>;
    subjects?: Array<Subject<LinkedEvent>>;
    isMaximized?: boolean;
}
