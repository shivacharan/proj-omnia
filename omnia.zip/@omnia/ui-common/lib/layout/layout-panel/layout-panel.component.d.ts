import { EventEmitter, OnInit, Type } from '@angular/core';
import { Control, Button } from '../../control';
import { Subject } from 'rxjs';
import { LinkedEvent } from '../../framework/linked-event';
import { LayoutItem } from '../layout-item';
export declare class LayoutPanelComponent implements OnInit {
    readonly title: string;
    readonly showHeader: boolean;
    readonly comp: Type<any>;
    private _layoutItem;
    layoutItem: LayoutItem;
    private _layoutControls;
    layoutControls: Button[];
    readonly panelItems: Array<Button>;
    private _widgetControls;
    private widgetMenuItems;
    readonly menuItems: Array<Control>;
    order: any[];
    inEvents: EventEmitter<string[]>;
    outEvents: EventEmitter<string[]>;
    linkedEvent: EventEmitter<LinkedEvent>;
    inputs: {
        config: any;
        subscriptions: Subject<LinkedEvent>[];
    };
    outputs: {
        setMenu: (items: any) => any;
        setInEvents: (eventIDs: any) => void;
        setOutEvents: (eventIDs: any) => void;
        linkedEvent: (event: any) => void;
    };
    constructor();
    private updateMenu();
    ngOnInit(): void;
}
