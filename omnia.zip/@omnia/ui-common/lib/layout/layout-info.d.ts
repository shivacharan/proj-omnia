export declare class LayoutInfo {
    x: number;
    y: number;
    rows: number;
    cols: number;
    config: {};
    comp: string;
    subscriptions?: string[];
    title?: string;
    showHeader?: boolean;
}
