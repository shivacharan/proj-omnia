import { LayoutItem } from './layout/layout-item';
export declare class Dashboard {
    id: string;
    name: string;
    showInNav: boolean;
    layout: Array<LayoutItem>;
    icon?: string;
    category?: string;
    permissions?: string[];
    children?: Dashboard[];
}
