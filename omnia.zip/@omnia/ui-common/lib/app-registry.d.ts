import { Type } from '@angular/core/src/type';
import { Dashboard } from './dashboard';
import { LayoutInfo } from './layout/layout-info';
import { Widget } from './framework/widget.interface';
import { AppContext } from './app-context';
export declare class AppRegistry {
    private appContext;
    private COMP_REGISTRY;
    private DASH_REGISTRY;
    private defaultDashboard;
    constructor(appContext: AppContext);
    registerComponent(name: string, type: Type<Widget>): void;
    getComponent(name: string): Type<Widget>;
    registerDashboard(id: string, name: string, layoutInfo: LayoutInfo[], isDefault?: boolean, addToNav?: boolean, icon?: string, category?: string, permissions?: string[], children?: Dashboard[]): void;
    getDashboard(id: string): Dashboard;
    private getDashboards();
    getDashboardsForNav(): Dashboard[];
    getDefaultDashboard(): Dashboard;
}
