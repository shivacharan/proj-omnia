import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
export declare class IconRegistry {
    private matIconRegistry;
    private domSanitizer;
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    registerCustomIcons(): void;
}
