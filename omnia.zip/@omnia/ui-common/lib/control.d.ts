export declare class Button {
    title: string;
    icon?: string;
    function?: Function;
}
export declare class Control extends Button {
    category?: string;
    value?: any;
    type?: string;
    children?: Control[];
}
