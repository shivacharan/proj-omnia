export declare class LinkedEvent {
    id: string;
    data: any;
}
