export interface Widget {
    handleLinkedEvent(id: string, data: any): any;
}
