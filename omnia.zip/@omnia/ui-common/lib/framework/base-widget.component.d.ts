import { EventEmitter, OnInit } from '@angular/core';
import { Widget } from './widget.interface';
import { Control } from '../control';
import { Subject } from 'rxjs';
import { LinkedEvent } from './linked-event';
export declare class BaseWidgetComponent implements OnInit, Widget {
    config: {};
    subscriptions: Subject<LinkedEvent>[];
    private allSubscriptions;
    setMenu: EventEmitter<Control[]>;
    setInEvents: EventEmitter<string[]>;
    setOutEvents: EventEmitter<string[]>;
    linkedEvent: EventEmitter<LinkedEvent>;
    menuItems: Control[];
    inEvents: string[];
    outEvents: string[];
    constructor();
    ngOnInit(): void;
    private unsubscribeAll();
    handleLinkedEvent(id: string, data: any): void;
}
