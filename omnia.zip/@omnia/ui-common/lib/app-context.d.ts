import { Dashboard } from './dashboard';
export declare class AppContext {
    private _currentDashboard;
    currentDashboard: Dashboard;
    private _userGroups;
    userGroups: string[];
    constructor();
    isAuthorized(permissions: string[]): boolean;
}
