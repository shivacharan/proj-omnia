export declare class ChartData {
    name: string;
    min?: number;
    max?: number;
    value: number;
}
export declare class LineData {
    name: string;
    customColor: string;
    series: ChartData[];
}
