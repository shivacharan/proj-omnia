import { EventEmitter, TemplateRef, OnInit } from '@angular/core';
import { ViewDimensions } from '../../util/view-dimensions';
import { ColorHelper } from '@swimlane/ngx-charts/release/common/color.helper';
import { BaseChartComponent } from '@swimlane/ngx-charts/release/common/base-chart.component';
import { DonutItem } from './donut-item';
export declare class DonutComponent extends BaseChartComponent implements OnInit {
    legendTitle: string;
    tooltipDisabled: boolean;
    legend: boolean;
    donutGaugeValue: {
        label: string;
        operator: string;
        inputs: Array<string>;
    };
    tooltipText: string;
    legendPosition: string;
    legendOrientation: string;
    gaugeToolTip: string;
    lineSeparator: boolean;
    results: Array<DonutItem>;
    select: EventEmitter<{}>;
    tooltipTemplate: TemplateRef<any>;
    legendTemplate: TemplateRef<any>;
    activeEntries: Array<{
        name: string;
        value: number;
        customColor: string;
    }>;
    showGaugeToolTip: boolean;
    data: any;
    dims: ViewDimensions;
    view: number[];
    domain: Array<string>;
    customColors: Array<{
        name: string;
        value: string;
    }>;
    colors: ColorHelper;
    legendWidth: number;
    margin: number[];
    legendOptions: {
        scaleType: string;
        domain: Array<string>;
        colors: ColorHelper;
        title: string;
    };
    translation: string;
    outerRadius: number;
    innerRadius: number;
    legendTranslation: string;
    donutGaugeData: {
        value: number;
        label: string;
        hidden?: boolean;
    };
    legendRight: boolean;
    legendLeft: boolean;
    legendTop: boolean;
    legendBottom: boolean;
    legendVertical: boolean;
    legendHeightFudgeFactor: number;
    segmentThickness: number;
    ngOnInit(): void;
    showTooltip(): void;
    hideTooltip(): void;
    setDonutGaugeData(): void;
    sumDonutValue(donutVal: any, donutData: any): any;
    averageDonutValue(donutVal: any, donutData: any): number;
    donutToolTipText({data}: {
        data: any;
    }): string;
    setLegendPosition(): void;
    update(): void;
    getContainerDims(): any;
    getDomain(): any[];
    getCustomColor(): any[];
    onClick(data: any): void;
    setColors(): void;
    onActivate(item: any): void;
    onDeactivate(item: any): void;
    getLegendOptions(): {
        scaleType: string;
        domain: string[];
        colors: ColorHelper;
        title: string;
    };
}
