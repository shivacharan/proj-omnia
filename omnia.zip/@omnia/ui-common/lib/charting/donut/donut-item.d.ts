export declare class DonutItem {
    name: string;
    value: number;
    customColor: string;
}
