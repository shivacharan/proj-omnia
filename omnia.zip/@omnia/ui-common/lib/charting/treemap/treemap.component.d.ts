import { ChangeDetectorRef, ElementRef, NgZone, OnInit, TemplateRef } from '@angular/core';
import { TreeMapComponent } from '@swimlane/ngx-charts';
export declare class TreemapComponent extends TreeMapComponent implements OnInit {
    data: any;
    private _data;
    showDefaultLegend: boolean;
    legendTitle: string;
    private _legendPosition;
    legendPosition: string;
    legendOrientation: string;
    legendStyle: string;
    lineSeparator: boolean;
    legendTemplate: TemplateRef<any>;
    legendWidth: number;
    legendHeight: number;
    legendRight: boolean;
    legendLeft: boolean;
    legendTop: boolean;
    legendBottom: boolean;
    constructor(chartElement: ElementRef, zone: NgZone, cd: ChangeDetectorRef);
    ngOnInit(): void;
    update(): void;
    getCustomColor(): any[];
    getContainerDims(): any;
    setLegendPosition(position: string): void;
}
