import { AfterViewInit, ElementRef, EventEmitter, Renderer2, TemplateRef } from '@angular/core';
export declare class LegendComponent implements AfterViewInit {
    private el;
    private renderer;
    title: string;
    height: number;
    width: number;
    private _legendData;
    legendData: [any];
    template: TemplateRef<any>;
    activeEntries: any;
    legendOrientation: string;
    legendTranslation: string;
    showSeparator: boolean;
    legendStyle: string;
    removable: boolean;
    click: EventEmitter<any>;
    activate: EventEmitter<any>;
    deactivate: EventEmitter<any>;
    constructor(el: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    addMouseEvents(): void;
    isActive(entry: any): boolean;
    trackBy(index: any, item: any): string;
    handleActivate(item: any): void;
    handleDeactivate(item: any): void;
    handleClick(item: any): void;
}
