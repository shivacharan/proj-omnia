import { OnInit } from '@angular/core';
import { Control } from '../../control';
export declare class ControlMenuItemComponent implements OnInit {
    menuItems: Control[];
    isSubMenu: boolean;
    order: any[];
    divider?: boolean;
    menu: any;
    constructor();
    ngOnInit(): void;
}
