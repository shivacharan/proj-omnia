export declare class UiCommonModule {
}
