import { ElementRef, NgZone, ChangeDetectorRef } from '@angular/core';
import { BaseWidgetComponent } from '@omnia/ui-common';
import { CommonUtilsService } from '../services/common-utils.service';
import { NavService } from '../services/nav-service.service';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
export declare class PositionFundSummaryComponent extends BaseWidgetComponent {
    commonUtils: CommonUtilsService;
    private navService;
    private shareInforBewteenComponents;
    dateNow: Date;
    summaryAssetsValue: {
        title: string;
        value: number;
    }[];
    threeDayTrendData: any[];
    results: any[];
    height: number;
    width: number;
    margin: any[];
    colorDomain: any[];
    tickValues: any[];
    xScaleMin: any;
    xScaleMax: any;
    constructor(chartElement: ElementRef, zone: NgZone, cd: ChangeDetectorRef, commonUtils: CommonUtilsService, navService: NavService, shareInforBewteenComponents: ShareInfoBeweenComponentsService);
    ngOnInit(): void;
    setColorForSelectedFund(): any[];
    filterFundData(data: any[]): any[];
    createSeries(data: any): any[];
    xAxisTickFormatting(v: any): string;
    getValueSty(value: any): string;
    ngOnDestroy(): void;
    resizingSingleLineChart(event: any): void;
}
