export declare const singleLineTicksValue: number[];
