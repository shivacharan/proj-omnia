import { OnInit, EventEmitter } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { CommonUtilsService } from '../services/common-utils.service';
export declare class AddFundModalComponent implements OnInit {
    private commonUtils;
    dialogRef: MatDialogRef<AddFundModalComponent>;
    data: any;
    fundList: any[];
    selectedFundChange: EventEmitter<any>;
    constructor(commonUtils: CommonUtilsService, dialogRef: MatDialogRef<AddFundModalComponent>, data: any);
    ngOnInit(): void;
    handleSelectFund(fund: any): void;
    handleClickSelectBtn(): void;
    updateVariableFundList(fund: any): void;
    onNoClick(): void;
}
