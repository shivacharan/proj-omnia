import { EventEmitter, TemplateRef } from '@angular/core';
import { BaseChartComponent, ColorHelper } from '@swimlane/ngx-charts';
export declare class HeatMapComponent extends BaseChartComponent {
    syncResults: any;
    tooltipDisabled: boolean;
    valueFormatting: any;
    labelFormatting: any;
    gradient: boolean;
    height: number;
    width: number;
    scheme: any;
    margin: any[];
    animations: boolean;
    select: EventEmitter<{}>;
    tooltipTemplate: TemplateRef<any>;
    dims: any;
    domain: any;
    transform: any;
    colors: ColorHelper;
    treemap: any;
    data: any;
    customColors: any;
    update(): void;
    setCustomColors(): any[];
    getDomain(): any[];
    onClick(data: any): void;
    setColors(): void;
}
