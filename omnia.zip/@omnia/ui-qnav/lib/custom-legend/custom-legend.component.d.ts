import { OnInit } from '@angular/core';
import { CommonUtilsService } from '../services/common-utils.service';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
export declare class CustomLegendComponent implements OnInit {
    private shareInforBewteenComponents;
    private commonUtils;
    results: any;
    selectable: any;
    removable: any;
    colorDomain: any;
    index: any;
    selectedFundChange: any;
    constructor(shareInforBewteenComponents: ShareInfoBeweenComponentsService, commonUtils: CommonUtilsService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getShowLegendAndConsistent(fund: any): boolean;
    getFundRelatedColor(fund: any): string;
    remove(fund: any): void;
}
