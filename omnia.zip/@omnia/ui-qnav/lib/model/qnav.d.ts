export declare enum Action {
    REGISTER = "register",
    SENDTO = "sendTo",
    STOPWATCHFUND = "stopWatchFund",
    WATCHFUND = "watchFund",
}
export interface Request {
    action?: Action;
    sessionId?: any;
    fundId?: any;
    timeZoneOffset?: any;
}
export interface Series {
    name: any;
    value: any;
}
export interface Nav {
    cusip?: any;
    exchangeRate?: number;
    fundid: any;
    parShare: number;
    fundmv: number;
    fundmvChange?: number;
    fundmvChangePercent?: number;
    mv?: number;
    mvChange?: number;
    nav?: number;
    navChange?: number;
    navChangePercent?: number;
    previousPrice?: number;
    price?: number;
    sodmv?: number;
    updatetime?: number;
    pricetime?: number;
}
export interface NavEvent {
    eventType?: any;
    eventData?: Nav;
}
