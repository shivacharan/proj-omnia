export declare const dataVisualFundColorMap: {
    fundID: any;
    color: string;
}[];
export declare const dataVisualColor: string[];
export declare const heatMapColorSetting: {
    value: number;
    color: string;
}[];
export declare const heatMapColorScheme: {
    domain: string[];
};
