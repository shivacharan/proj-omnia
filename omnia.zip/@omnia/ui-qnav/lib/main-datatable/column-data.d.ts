export declare const customColumn: {
    type: string;
    details: string;
}[];
export declare const normalColumn: ({
    prop: string;
    name: string;
    width: number;
    draggable: boolean;
    canAutoResize: boolean;
    columnSetting: boolean;
    cellTemplate: string;
    headerClassFormat: string;
    cellClassFormat: string;
    treeToggleTemplate: string;
    frozenLeft: boolean;
    sortColumnAscOrDesc: string;
} | {
    prop: string;
    name: string;
    width: string;
    draggable: boolean;
    canAutoResize: boolean;
    columnSetting: boolean;
    cellTemplate: string;
    headerClassFormat: string;
    cellClassFormat: string;
    treeToggleTemplate: string;
    frozenLeft: boolean;
    sortColumnAscOrDesc: string;
})[];
export declare const columnMenuDropDownSetting: {
    name: string;
    type: string;
    hasSubMenu: boolean;
}[];
