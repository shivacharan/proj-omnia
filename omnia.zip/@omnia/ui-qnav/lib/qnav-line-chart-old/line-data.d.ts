export declare const defaultFundList: {
    "name": string;
    "series": {
        "name": string;
        "value": number;
        "nav": string;
        "marketval": string;
    }[];
}[];
export declare const ticksValue: number[];
