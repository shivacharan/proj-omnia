import { ElementRef, NgZone, ChangeDetectorRef } from '@angular/core';
import { BaseWidgetComponent } from '@omnia/ui-common';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import { NavService } from '../services/nav-service.service';
import { NavSocketService } from '../services/nav-socket.service';
import { CommonUtilsService } from '../services/common-utils.service';
import { ResourceManagerService } from '../services/resource-manager.service';
export declare class PositionHeatMapComponent extends BaseWidgetComponent {
    private navSocketService;
    private shareInfoBeweenComponentsService;
    private commonUtils;
    private navService;
    private resourceManger;
    private subs;
    syncResults: any[];
    topFiveResults: any[];
    height: number;
    width: number;
    margin: number[];
    isDataAvailable: boolean;
    heatMapColorSetting: any[];
    dateNow: Date;
    colorScheme: {
        domain: string[];
    };
    fundInfo: any;
    constructor(chartElement: ElementRef, zone: NgZone, cd: ChangeDetectorRef, navSocketService: NavSocketService, shareInfoBeweenComponentsService: ShareInfoBeweenComponentsService, commonUtils: CommonUtilsService, navService: NavService, resourceManger: ResourceManagerService);
    ngOnInit(): void;
    renderPositionMap(): void;
    filterHoldingsToHeatMap(data: any): any[];
    filterHoldingsToTopFive(data: any): any[];
    updateHeatMap(data: any): void;
    resizingHeatMap(event: any): void;
    heatMapValueFormatting(value: any): void;
    heatMapLabelFormatting(obj: any): string;
    ngOnDestroy(): void;
}
