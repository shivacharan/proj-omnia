import { AppRegistry } from '@omnia/ui-common';
export declare class UiQNavModule {
    private appRegistry;
    static forRoot(environment: any): {
        ngModule: typeof UiQNavModule;
        providers: {
            provide: string;
            useValue: any;
        }[];
    };
    permissions: string[];
    constructor(appRegistry: AppRegistry);
}
