import { Observable } from 'rxjs';
import { Request, NavEvent } from '../model/qnav';
export declare class NavSocketService {
    private subject;
    private nav;
    constructor();
    initSocket(): void;
    getNav(): Observable<NavEvent>;
    send(request: Request): void;
    registerFunds(funds: any[]): void;
    unRegisterFunds(funds: any[]): void;
    registerService(): void;
}
