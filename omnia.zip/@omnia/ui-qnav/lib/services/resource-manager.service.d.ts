export declare class ResourceManagerService {
    constructor();
    private intervalInstances;
    private intervalFuncs;
    private deactive(event);
    private doDeactive();
    private active(event);
    registInterval(intervalFunc: any, interval: number): void;
    cleanResources(): void;
}
