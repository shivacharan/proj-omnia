import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
export declare class CommonUtilsService {
    private shareInforBewteenComponents;
    startTime: Date;
    endTime: Date;
    timeDivision: Date;
    liveTime: Date;
    isAfterMarketClose: boolean;
    constructor(shareInforBewteenComponents: ShareInfoBeweenComponentsService);
    isAfterMarketColse(time: Date): boolean;
    isBeforeMarketOpen(time: Date): boolean;
    isValidTime(time: Date): boolean;
    isBeyondDivision(time: Date): boolean;
    getRandomColor(): string;
    getColorForFund(fundid: String): any;
    resetColorForFund(fundid: String): void;
    updateFundStatus(fundid: String, isChecked: boolean): void;
    formatTime(time: Date): string;
    formatDateTime(time: any): Date;
    validateUser(): boolean;
    extractFundLevelData(data: any): any[];
    extractClassLevelData(data: any): any[];
    extractWSData(data: any, childOrNot: any): any[];
    sortColumnByProp(rows: any, childRows: any, expandCollapseIconMap: any, prop: any, ascFlag: any): any[];
    private sortCompareAsc(prop);
    private sortCompareDesc(prop);
}
