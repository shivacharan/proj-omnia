import { EventEmitter } from '@angular/core';
export declare class ShareInfoBeweenComponentsService {
    accessToken: any;
    fundInfo: any;
    private variableFundList;
    colorSchema: any[];
    highLightActiveEntries: EventEmitter<any>;
    clickedOutSide: EventEmitter<any>;
    hyperLinkNavigate: EventEmitter<any>;
    openModalData: EventEmitter<any>;
    sortDatatableColumn: EventEmitter<any>;
    constructor();
    savePositionDetailsFundInfo(fundInfo: any): void;
    setVariableFundList(data: any): void;
    setColorSchema(colorSchema: any[]): void;
    getFundList(): any[];
    reset(): void;
}
