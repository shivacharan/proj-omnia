import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export declare class NavService {
    private http;
    private data;
    constructor(http: HttpClient);
    getTodayNav(funds: any): Observable<any[]>;
    fetchFundList(): void;
    getFundList(): Observable<any[]>;
    getPositionDetails(fund: string): Observable<any[]>;
}
