import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { CommonUtilsService } from '../services/common-utils.service';
export declare class CustomAlertModalComponent implements OnInit {
    private commonUtils;
    dialogRef: MatDialogRef<CustomAlertModalComponent>;
    data: any;
    alertData: any[];
    constructor(commonUtils: CommonUtilsService, dialogRef: MatDialogRef<CustomAlertModalComponent>, data: any);
    ngOnInit(): void;
    onNoClick(): void;
}
