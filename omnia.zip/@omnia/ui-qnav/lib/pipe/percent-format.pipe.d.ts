import { PipeTransform } from '@angular/core';
export declare class PercentFormatPipe implements PipeTransform {
    transform(value: any): any;
}
