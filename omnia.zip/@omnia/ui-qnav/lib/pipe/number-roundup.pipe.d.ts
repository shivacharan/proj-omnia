import { PipeTransform } from '@angular/core';
export declare class NumberRoundUpPipe implements PipeTransform {
    transform(value: any, maxFractionDigits: number): any;
}
