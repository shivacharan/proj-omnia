(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('lodash'), require('@angular/animations'), require('@angular/common'), require('d3-scale'), require('d3-shape'), require('@swimlane/ngx-charts/release/utils'), require('@swimlane/ngx-charts/release/common/domain.helper'), require('@swimlane/ngx-charts'), require('@angular/common/http'), require('rxjs'), require('rxjs/webSocket'), require('@omnia/ui-common'), require('@angular/material'), require('d3-hierarchy'), require('ng-dynamic-component'), require('@swimlane/ngx-datatable'), require('@angular/material/chips'), require('@angular/material/menu'), require('@angular/platform-browser/animations'), require('ng-click-outside'), require('@angular/material/dialog')) :
    typeof define === 'function' && define.amd ? define('@omnia/ui-qnav', ['exports', '@angular/core', 'lodash', '@angular/animations', '@angular/common', 'd3-scale', 'd3-shape', '@swimlane/ngx-charts/release/utils', '@swimlane/ngx-charts/release/common/domain.helper', '@swimlane/ngx-charts', '@angular/common/http', 'rxjs', 'rxjs/webSocket', '@omnia/ui-common', '@angular/material', 'd3-hierarchy', 'ng-dynamic-component', '@swimlane/ngx-datatable', '@angular/material/chips', '@angular/material/menu', '@angular/platform-browser/animations', 'ng-click-outside', '@angular/material/dialog'], factory) :
    (factory((global.omnia = global.omnia || {}, global.omnia['ui-qnav'] = {}),global.ng.core,null,global.ng.animations,global.ng.common,null,null,null,null,null,global.ng.common.http,global.rxjs,global.rxjs.webSocket,null,global.ng.material,null,null,null,global.ng.material.chips,global.ng.material.menu,global.ng.platformBrowser.animations,null,global.ng.material.dialog));
}(this, (function (exports,i0,_,animations,common,d3Scale,d3Shape,utils,domain_helper,ngxCharts,i1,rxjs,webSocket,uiCommon,material,d3Hierarchy,ngDynamicComponent,ngxDatatable,chips,menu,animations$1,ngClickOutside,dialog) { 'use strict';

    _ = _ && _.hasOwnProperty('default') ? _['default'] : _;

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (b.hasOwnProperty(p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m)
            return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length)
                    o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var ShareInfoBeweenComponentsService = (function () {
        function ShareInfoBeweenComponentsService() {
            this.fundInfo = [];
            this.variableFundList = [];
            this.colorSchema = [];
            this.highLightActiveEntries = new i0.EventEmitter();
            this.clickedOutSide = new i0.EventEmitter();
            // data-table components data communication
            this.hyperLinkNavigate = new i0.EventEmitter();
            this.openModalData = new i0.EventEmitter();
            this.sortDatatableColumn = new i0.EventEmitter();
        }
        /**
         * @param {?} fundInfo
         * @return {?}
         */
        ShareInfoBeweenComponentsService.prototype.savePositionDetailsFundInfo = /**
         * @param {?} fundInfo
         * @return {?}
         */
            function (fundInfo) {
                this.fundInfo = fundInfo;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        ShareInfoBeweenComponentsService.prototype.setVariableFundList = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                this.variableFundList = data;
            };
        /**
         * @param {?} colorSchema
         * @return {?}
         */
        ShareInfoBeweenComponentsService.prototype.setColorSchema = /**
         * @param {?} colorSchema
         * @return {?}
         */
            function (colorSchema) {
                this.colorSchema = colorSchema;
            };
        /**
         * @return {?}
         */
        ShareInfoBeweenComponentsService.prototype.getFundList = /**
         * @return {?}
         */
            function () {
                return this.variableFundList;
            };
        /**
         * @return {?}
         */
        ShareInfoBeweenComponentsService.prototype.reset = /**
         * @return {?}
         */
            function () {
                this.fundInfo = [];
                this.variableFundList = [];
                this.colorSchema = [];
                this.highLightActiveEntries = new i0.EventEmitter();
                this.hyperLinkNavigate = new i0.EventEmitter();
                this.openModalData = new i0.EventEmitter();
                this.sortDatatableColumn = new i0.EventEmitter();
            };
        ShareInfoBeweenComponentsService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        ShareInfoBeweenComponentsService.ctorParameters = function () { return []; };
        /** @nocollapse */ ShareInfoBeweenComponentsService.ngInjectableDef = i0.defineInjectable({ factory: function ShareInfoBeweenComponentsService_Factory() { return new ShareInfoBeweenComponentsService(); }, token: ShareInfoBeweenComponentsService, providedIn: "root" });
        return ShareInfoBeweenComponentsService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CommonUtilsService = (function () {
        function CommonUtilsService(shareInforBewteenComponents) {
            var _this = this;
            this.shareInforBewteenComponents = shareInforBewteenComponents;
            this.startTime = new Date();
            this.endTime = new Date();
            this.timeDivision = new Date();
            this.liveTime = new Date();
            this.isAfterMarketClose = false;
            this.startTime.setHours(9, 30, 0, 0);
            this.endTime.setHours(16, 30, 0, 0);
            this.timeDivision.setHours(15, 30, 0, 0);
            /** @type {?} */
            var instance = setInterval(function () {
                if (new Date() < _this.endTime) {
                    _this.liveTime = new Date();
                }
                else {
                    _this.liveTime = _this.endTime;
                    clearInterval(instance);
                }
            }, 1000);
            this.isAfterMarketClose = this.isAfterMarketColse(this.liveTime);
        }
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.isAfterMarketColse = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                if (time <= this.endTime) {
                    return false;
                }
                return true;
            };
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.isBeforeMarketOpen = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                if (time >= this.startTime) {
                    return false;
                }
                return true;
            };
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.isValidTime = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                if (time >= this.startTime && time <= this.endTime) {
                    return true;
                }
                return false;
            };
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.isBeyondDivision = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                if (time >= this.timeDivision) {
                    return true;
                }
                return false;
            };
        /**
         * @return {?}
         */
        CommonUtilsService.prototype.getRandomColor = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var letters = '0123456789ABCDEF';
                /** @type {?} */
                var color = '#';
                for (var i = 0; i < 6; i++) {
                    color += letters[Math.floor(Math.random() * 16)];
                }
                return color;
            };
        /**
         * @param {?} fundid
         * @return {?}
         */
        CommonUtilsService.prototype.getColorForFund = /**
         * @param {?} fundid
         * @return {?}
         */
            function (fundid) {
                this.resetColorForFund(fundid);
                try {
                    for (var _a = __values(this.shareInforBewteenComponents.colorSchema), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var item = _b.value;
                        if (item['fundid'] === undefined) {
                            item['fundid'] = fundid;
                            return item['color'];
                        }
                    }
                }
                catch (e_1_1) {
                    e_1 = { error: e_1_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return))
                            _c.call(_a);
                    }
                    finally {
                        if (e_1)
                            throw e_1.error;
                    }
                }
                return this.getRandomColor();
                var e_1, _c;
            };
        /**
         * @param {?} fundid
         * @return {?}
         */
        CommonUtilsService.prototype.resetColorForFund = /**
         * @param {?} fundid
         * @return {?}
         */
            function (fundid) {
                try {
                    for (var _a = __values(this.shareInforBewteenComponents.colorSchema), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var item = _b.value;
                        if (item['fundid'] === fundid) {
                            item['fundid'] = undefined;
                        }
                    }
                }
                catch (e_2_1) {
                    e_2 = { error: e_2_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return))
                            _c.call(_a);
                    }
                    finally {
                        if (e_2)
                            throw e_2.error;
                    }
                }
                var e_2, _c;
            };
        /**
         * @param {?} fundid
         * @param {?} isChecked
         * @return {?}
         */
        CommonUtilsService.prototype.updateFundStatus = /**
         * @param {?} fundid
         * @param {?} isChecked
         * @return {?}
         */
            function (fundid, isChecked) {
                /** @type {?} */
                var index = this.shareInforBewteenComponents.getFundList().findIndex(function (element) { return element.fundID === fundid; });
                if (isChecked === this.shareInforBewteenComponents.getFundList()[index]['checked']) {
                    return;
                }
                this.shareInforBewteenComponents.getFundList()[index]['checked'] = isChecked;
                //remove the color for the fund as well
                if (isChecked === false) {
                    this.resetColorForFund(fundid);
                }
                else {
                    this.getColorForFund(fundid);
                }
            };
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.formatTime = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                /** @type {?} */
                var t = new Date(time);
                /** @type {?} */
                var second = '00';
                if (t.getSeconds() <= 20) {
                    second = '00';
                }
                else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
                    second = '20';
                }
                else {
                    second = '40';
                }
                return ("0" + t.getHours()).slice(-2) + ':' + ("0" + t.getMinutes()).slice(-2) + ':' + second;
            };
        /**
         * @param {?} time
         * @return {?}
         */
        CommonUtilsService.prototype.formatDateTime = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                /** @type {?} */
                var t = new Date(time);
                if (t.getSeconds() <= 20) {
                    t.setSeconds(0);
                    t.setMilliseconds(0);
                }
                else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
                    t.setSeconds(20);
                    t.setMilliseconds(0);
                }
                else {
                    t.setSeconds(40);
                    t.setMilliseconds(0);
                }
                return t;
            };
        //rest component shared information if login user/authorized token changed
        //rest component shared information if login user/authorized token changed
        /**
         * @return {?}
         */
        CommonUtilsService.prototype.validateUser =
            //rest component shared information if login user/authorized token changed
            /**
             * @return {?}
             */
            function () {
                if (this.shareInforBewteenComponents.accessToken) {
                    if (sessionStorage.getItem('access_token') === this.shareInforBewteenComponents.accessToken) {
                        return true;
                    }
                }
                this.shareInforBewteenComponents.reset();
                this.shareInforBewteenComponents.accessToken = sessionStorage.getItem('access_token');
                return false;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        CommonUtilsService.prototype.extractFundLevelData = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var fundLevelData = (((data))).map(function (d) {
                    /** @type {?} */
                    var rowTemp = {
                        //fundid: d.fundid,
                        fundid: d.fundid,
                        maskedId: d.maskedId,
                        name: d.name,
                        classID: "A",
                        child: "parent",
                    };
                    /** @type {?} */
                    var multiClassData = d.classLevelTrialData;
                    /** @type {?} */
                    var row = Object.assign(rowTemp, multiClassData.A);
                    return row;
                });
                return fundLevelData;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        CommonUtilsService.prototype.extractClassLevelData = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var classLevelData = [];
                (((data))).forEach(function (d) {
                    /** @type {?} */
                    var rowTemp = {
                        //fundid: d.fundid,
                        fundid: d.fundid,
                        maskedId: d.maskedId,
                        name: d.name,
                        child: "child",
                    };
                    /** @type {?} */
                    var multiClassData = d.classLevelTrialData;
                    for (var key in multiClassData) {
                        if (key !== "A") {
                            /** @type {?} */
                            var childRow = Object.assign(rowTemp, multiClassData[key], { classID: key });
                            classLevelData.push(_.cloneDeep(childRow));
                        }
                    }
                });
                return classLevelData.reverse();
            };
        /**
         * @param {?} data
         * @param {?} childOrNot
         * @return {?}
         */
        CommonUtilsService.prototype.extractWSData = /**
         * @param {?} data
         * @param {?} childOrNot
         * @return {?}
         */
            function (data, childOrNot) {
                /** @type {?} */
                var returnData = [];
                /** @type {?} */
                var temp = {
                    cusip: data.cusip,
                    exchangeRate: data.exchangeRate,
                    //fundid: data.fundid,
                    fundid: data.fundid,
                    longShortIndicator: data.longShortIndicator,
                    mv: data.mv,
                    mvChange: data.mvChange,
                    navImpact: data.navImpact,
                    price: data.price,
                    priceChangePercent: data.priceChangePercent,
                    sodMv: data.sodMv,
                    sodPrice: data.sodPrice,
                    updatetime: data.updatetime
                };
                if (childOrNot) {
                    for (var key in data) {
                        if (Number(key)) {
                            /** @type {?} */
                            var row = Object.assign(temp, data[key], { classID: key });
                            returnData.push(_.cloneDeep(row));
                        }
                    }
                }
                else {
                    returnData = data["A"];
                    returnData = Object.assign(temp, returnData, { classID: "A" });
                }
                return returnData;
            };
        /**
         * @param {?} rows
         * @param {?} childRows
         * @param {?} expandCollapseIconMap
         * @param {?} prop
         * @param {?} ascFlag
         * @return {?}
         */
        CommonUtilsService.prototype.sortColumnByProp = /**
         * @param {?} rows
         * @param {?} childRows
         * @param {?} expandCollapseIconMap
         * @param {?} prop
         * @param {?} ascFlag
         * @return {?}
         */
            function (rows, childRows, expandCollapseIconMap, prop, ascFlag) {
                /** @type {?} */
                var pRows = [];
                rows.forEach(function (item) {
                    if (item.classID === "A")
                        pRows.push(item);
                    if (childRows.length === 0)
                        pRows.push(item);
                });
                ascFlag ? pRows.sort(this.sortCompareAsc(prop)) : pRows.sort(this.sortCompareDesc(prop));
                childRows.forEach(function (item) {
                    /** @type {?} */
                    var fundid = item.fundid;
                    expandCollapseIconMap.forEach(function (expandItem) {
                        if (expandItem.fundid === fundid && expandItem.expand) {
                            /** @type {?} */
                            var index = pRows.findIndex(function (pitem) { return pitem.fundid === fundid; });
                            pRows.splice(index + 1, 0, item);
                        }
                    });
                });
                return pRows;
            };
        /**
         * @param {?} prop
         * @return {?}
         */
        CommonUtilsService.prototype.sortCompareAsc = /**
         * @param {?} prop
         * @return {?}
         */
            function (prop) {
                return function (obj1, obj2) {
                    /** @type {?} */
                    var v1 = obj1[prop];
                    /** @type {?} */
                    var v2 = obj2[prop];
                    if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
                        v1 = Number(v1);
                        v2 = Number(v2);
                    }
                    if (v1 === undefined || v1 < v2) {
                        return -1;
                    }
                    else if (v2 === undefined || v1 > v2) {
                        return 1;
                    }
                    else {
                        return 0;
                    }
                };
            };
        /**
         * @param {?} prop
         * @return {?}
         */
        CommonUtilsService.prototype.sortCompareDesc = /**
         * @param {?} prop
         * @return {?}
         */
            function (prop) {
                return function (obj1, obj2) {
                    /** @type {?} */
                    var v1 = obj1[prop];
                    /** @type {?} */
                    var v2 = obj2[prop];
                    if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
                        v1 = Number(v1);
                        v2 = Number(v2);
                    }
                    if (v1 === undefined || v1 < v2) {
                        return 1;
                    }
                    else if (v2 === undefined || v1 > v2) {
                        return -1;
                    }
                    else {
                        return 0;
                    }
                };
            };
        CommonUtilsService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        CommonUtilsService.ctorParameters = function () {
            return [
                { type: ShareInfoBeweenComponentsService }
            ];
        };
        /** @nocollapse */ CommonUtilsService.ngInjectableDef = i0.defineInjectable({ factory: function CommonUtilsService_Factory() { return new CommonUtilsService(i0.inject(ShareInfoBeweenComponentsService)); }, token: CommonUtilsService, providedIn: "root" });
        return CommonUtilsService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var LineChartComponent = (function (_super) {
        __extends(LineChartComponent, _super);
        function LineChartComponent(chartElement, zone, cd, commonUtils, datePipe) {
            var _this = _super.call(this, chartElement, zone, cd) || this;
            _this.commonUtils = commonUtils;
            _this.datePipe = datePipe;
            _this.legendTitle = 'Legend';
            _this.showGridLines = true;
            _this.curve = d3Shape.curveLinear;
            _this.roundDomains = false;
            _this.tooltipDisabled = false;
            _this.showRefLines = false; // if don't show grid line in x-axis level we can use refLine to customize x-axis level lines..
            _this.referenceLines = []; //[{ value: 0.1, name: 'Maximum' }, { value: 0.0, name: 'Average' }, { value: -0.1, name: 'Minimum' }];
            _this.showRefLabels = false;
            _this.colorDomain = [];
            _this.circleData = [];
            _this.tickValues = [];
            _this.activeEntries = [];
            _this.highLightActiveEntries = [];
            _this.activate = new i0.EventEmitter();
            _this.deactivate = new i0.EventEmitter();
            _this.xAxisHeight = 0;
            _this.yAxisWidth = 0;
            _this.timelineHeight = 50;
            _this.timelinePadding = 10;
            _this.circleRadius = 5;
            _this.tooltipObj = {};
            _this.showAlertDetailsMap = [];
            return _this;
        }
        /**
         * @return {?}
         */
        LineChartComponent.prototype.update = /**
         * @return {?}
         */
            function () {
                this.dims = ngxCharts.calculateViewDimensions({
                    width: this.width,
                    height: this.height,
                    margins: this.margin,
                    xAxisHeight: this.xAxisHeight,
                    yAxisWidth: this.yAxisWidth,
                    showXLabel: this.showXAxisLabel,
                    showYLabel: this.showYAxisLabel,
                    showLegend: this.legend,
                    legendType: this.schemeType,
                });
                if (this.timeline) {
                    this.dims.height -= (this.timelineHeight + this.margin[2] + this.timelinePadding);
                }
                this.xDomain = this.getXDomain();
                if (this.filteredDomain) {
                    this.xDomain = this.filteredDomain;
                }
                this.yDomain = this.getYDomain();
                this.seriesDomain = this.getSeriesDomain();
                this.xScale = this.getXScale(this.xDomain, this.dims.width);
                this.yScale = this.getYScale(this.yDomain, this.dims.height);
                this.customColors = this.setCustomcolors();
                this.setColors();
                this.legendOptions = this.getLegendOptions();
                this.transform = "translate(" + this.dims.xOffset + " , " + this.margin[0] + ")";
                this.clipPathId = 'clip' + utils.id().toString();
                this.clipPath = "url(#" + this.clipPathId + ")";
                //map circle
                this.circleSeries = this.mapCircle(this.circleData);
                this.lastDataX = this.xScale(this.currentLineTime);
            };
        /**
         * @param {?} circleData
         * @return {?}
         */
        LineChartComponent.prototype.mapCircle = /**
         * @param {?} circleData
         * @return {?}
         */
            function (circleData) {
                var _this = this;
                /** @type {?} */
                var xscale = this.xScale;
                /** @type {?} */
                var yscale = this.yScale;
                /** @type {?} */
                var arr = [];
                circleData.forEach(function (item, index) {
                    /** @type {?} */
                    var obj = {
                        x: xscale(item.x),
                        time: _this.datePipe.transform(item.pricetime, "hh:mm:ss aaaaa'm'"),
                        value: yscale(item.value),
                        name: item.name,
                        fill: item.alertType == 1 ? ['#ffbc06'] : ['#b91224'],
                        alertType: item.alertType,
                        navChange: item.value,
                        mvChange: item.fundmvChangePercent,
                        pricetime: item.pricetime,
                    };
                    arr.push(obj);
                });
                return arr;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.setCustomcolors = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var arr = [];
                this.results.forEach(function (item) {
                    _this.colorDomain.forEach(function (color) {
                        if (item['name'] === color['fundid']) {
                            /** @type {?} */
                            var obj = {
                                name: color.fundid,
                                value: color.color
                            };
                            arr.push(obj);
                        }
                    });
                });
                return arr;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.getXDomain = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var values = domain_helper.getUniqueXDomainValues(this.results);
                this.scaleType = this.getScaleType(values);
                /** @type {?} */
                var domain = [];
                if (this.scaleType === 'linear') {
                    values = values.map(function (v) { return Number(v); });
                }
                /** @type {?} */
                var min;
                /** @type {?} */
                var max;
                if (this.scaleType === 'time' || this.scaleType === 'linear') {
                    min = this.xScaleMin
                        ? this.xScaleMin
                        : Math.min.apply(Math, __spread(values));
                    max = this.xScaleMax
                        ? this.xScaleMax
                        : Math.max.apply(Math, __spread(values));
                }
                if (this.scaleType === 'time') {
                    domain = [new Date(min), new Date(max)];
                    this.xSet = __spread(values).sort(function (a, b) {
                        /** @type {?} */
                        var aDate = a.getTime();
                        /** @type {?} */
                        var bDate = b.getTime();
                        if (aDate > bDate)
                            return 1;
                        if (bDate > aDate)
                            return -1;
                        return 0;
                    });
                }
                else if (this.scaleType === 'linear') {
                    domain = [min, max];
                    // Use compare function to sort numbers numerically
                    this.xSet = __spread(values).sort(function (a, b) { return (a - b); });
                }
                else {
                    domain = values;
                    this.xSet = values;
                }
                return domain;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.getYDomain = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var domain = [];
                try {
                    for (var _a = __values(this.results), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var results = _b.value;
                        try {
                            for (var _c = __values(results.series), _d = _c.next(); !_d.done; _d = _c.next()) {
                                var d = _d.value;
                                if (d.value && domain.indexOf(d.value) < 0) {
                                    domain.push(d.value);
                                }
                                if (d.min !== undefined) {
                                    this.hasRange = true;
                                    if (domain.indexOf(d.min) < 0) {
                                        domain.push(d.min);
                                    }
                                }
                                if (d.max !== undefined) {
                                    this.hasRange = true;
                                    if (domain.indexOf(d.max) < 0) {
                                        domain.push(d.max);
                                    }
                                }
                            }
                        }
                        catch (e_1_1) {
                            e_1 = { error: e_1_1 };
                        }
                        finally {
                            try {
                                if (_d && !_d.done && (_e = _c.return))
                                    _e.call(_c);
                            }
                            finally {
                                if (e_1)
                                    throw e_1.error;
                            }
                        }
                    }
                }
                catch (e_2_1) {
                    e_2 = { error: e_2_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_f = _a.return))
                            _f.call(_a);
                    }
                    finally {
                        if (e_2)
                            throw e_2.error;
                    }
                }
                /** @type {?} */
                var values = __spread(domain);
                if (!this.autoScale) {
                    values.push(0);
                }
                /** @type {?} */
                var min = this.yScaleMin
                    ? this.yScaleMin
                    : Math.min.apply(Math, __spread(values));
                /** @type {?} */
                var max = this.yScaleMax
                    ? this.yScaleMax
                    : Math.max.apply(Math, __spread(values));
                if (min !== undefined && max !== undefined) {
                    return [min, max];
                }
                else {
                    return [-0.1, 0.1];
                }
                var e_2, _f, e_1, _e;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.getSeriesDomain = /**
         * @return {?}
         */
            function () {
                return this.results.map(function (d) { return d.name; });
            };
        /**
         * @param {?} domain
         * @param {?} width
         * @return {?}
         */
        LineChartComponent.prototype.getXScale = /**
         * @param {?} domain
         * @param {?} width
         * @return {?}
         */
            function (domain, width) {
                /** @type {?} */
                var scale;
                if (this.scaleType === 'time') {
                    scale = d3Scale.scaleTime()
                        .range([0, width])
                        .domain(domain);
                }
                else if (this.scaleType === 'linear') {
                    scale = d3Scale.scaleLinear()
                        .range([0, width])
                        .domain(domain);
                    if (this.roundDomains) {
                        scale = scale.nice();
                    }
                }
                else if (this.scaleType === 'ordinal') {
                    scale = d3Scale.scalePoint()
                        .range([0, width])
                        .padding(0.1)
                        .domain(domain);
                }
                return scale;
            };
        /**
         * @param {?} domain
         * @param {?} height
         * @return {?}
         */
        LineChartComponent.prototype.getYScale = /**
         * @param {?} domain
         * @param {?} height
         * @return {?}
         */
            function (domain, height) {
                /** @type {?} */
                var scale = d3Scale.scaleLinear()
                    .range([height, 0])
                    .domain(domain);
                return this.roundDomains ? scale.nice() : scale;
            };
        /**
         * @param {?} values
         * @return {?}
         */
        LineChartComponent.prototype.getScaleType = /**
         * @param {?} values
         * @return {?}
         */
            function (values) {
                /** @type {?} */
                var date = true;
                /** @type {?} */
                var num = true;
                try {
                    for (var values_1 = __values(values), values_1_1 = values_1.next(); !values_1_1.done; values_1_1 = values_1.next()) {
                        var value = values_1_1.value;
                        if (!this.isDate(value)) {
                            date = false;
                        }
                        if (typeof value !== 'number') {
                            num = false;
                        }
                    }
                }
                catch (e_3_1) {
                    e_3 = { error: e_3_1 };
                }
                finally {
                    try {
                        if (values_1_1 && !values_1_1.done && (_a = values_1.return))
                            _a.call(values_1);
                    }
                    finally {
                        if (e_3)
                            throw e_3.error;
                    }
                }
                if (date)
                    return 'time';
                if (num)
                    return 'linear';
                return 'ordinal';
                var e_3, _a;
            };
        /**
         * @param {?} value
         * @return {?}
         */
        LineChartComponent.prototype.isDate = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                if (value instanceof Date) {
                    return true;
                }
                return false;
            };
        /**
         * @param {?} __0
         * @return {?}
         */
        LineChartComponent.prototype.updateYAxisWidth = /**
         * @param {?} __0
         * @return {?}
         */
            function (_a) {
                var width = _a.width;
                this.yAxisWidth = width;
                this.update();
            };
        /**
         * @param {?} __0
         * @return {?}
         */
        LineChartComponent.prototype.updateXAxisHeight = /**
         * @param {?} __0
         * @return {?}
         */
            function (_a) {
                var height = _a.height;
                this.xAxisHeight = height;
                this.update();
            };
        /**
         * @param {?} item
         * @return {?}
         */
        LineChartComponent.prototype.updateHoveredVertical = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                this.tooltipObj = Object.assign(this.tooltipObj, item);
                this.hoveredVertical = item.value;
                this.deactivateAll();
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.hideCircles = /**
         * @return {?}
         */
            function () {
                this.hoveredVertical = null;
                this.deactivateAll();
                this.activeEntries = this.highLightActiveEntries;
            };
        /**
         * @param {?} series
         * @return {?}
         */
        LineChartComponent.prototype.onMouseEnter = /**
         * @param {?} series
         * @return {?}
         */
            function (series) {
                this.activate.emit(series);
            };
        /**
         * @param {?} series
         * @return {?}
         */
        LineChartComponent.prototype.onMouseLeave = /**
         * @param {?} series
         * @return {?}
         */
            function (series) {
                this.deactivate.emit(series);
            };
        /**
         * @param {?} data
         * @param {?=} series
         * @return {?}
         */
        LineChartComponent.prototype.onClick = /**
         * @param {?} data
         * @param {?=} series
         * @return {?}
         */
            function (data, series) {
                if (series) {
                    data.series = series.name;
                }
                this.select.emit(data);
            };
        /**
         * @param {?} index
         * @param {?} item
         * @return {?}
         */
        LineChartComponent.prototype.trackBy = /**
         * @param {?} index
         * @param {?} item
         * @return {?}
         */
            function (index, item) {
                return item.name;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.setColors = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var domain;
                if (this.schemeType === 'ordinal') {
                    domain = this.seriesDomain;
                }
                else {
                    domain = this.yDomain;
                }
                this.colors = new ngxCharts.ColorHelper(this.scheme, this.schemeType, domain, this.customColors);
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.getLegendOptions = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var opts = {
                    scaleType: this.schemeType,
                    colors: undefined,
                    domain: [],
                    title: undefined
                };
                if (opts.scaleType === 'ordinal') {
                    opts.domain = this.seriesDomain;
                    opts.colors = this.colors;
                    opts.title = this.legendTitle;
                }
                else {
                    opts.domain = this.yDomain;
                    opts.colors = this.colors.scale;
                }
                return opts;
            };
        /**
         * @param {?} item
         * @return {?}
         */
        LineChartComponent.prototype.onActivate = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                this.deactivateAll();
                /** @type {?} */
                var idx = this.activeEntries.findIndex(function (d) {
                    return d.name === item.name && d.value === item.value;
                });
                if (idx > -1) {
                    return;
                }
                this.activeEntries = [item];
                this.activate.emit({ value: item, entries: this.activeEntries });
                this.tooltipObj = Object.assign(this.tooltipObj, item);
                this.findOtherProperty();
                this.setCustomClass();
            };
        /**
         * @param {?} item
         * @return {?}
         */
        LineChartComponent.prototype.onDeactivate = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                /** @type {?} */
                var idx = this.activeEntries.findIndex(function (d) {
                    return d.name === item.name && d.value === item.value;
                });
                this.activeEntries.splice(idx, 1);
                this.activeEntries = __spread(this.activeEntries);
                this.deactivate.emit({ value: item, entries: this.activeEntries });
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.deactivateAll = /**
         * @return {?}
         */
            function () {
                this.activeEntries = __spread(this.activeEntries);
                try {
                    for (var _a = __values(this.activeEntries), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var entry = _b.value;
                        this.deactivate.emit({ value: entry, entries: [] });
                    }
                }
                catch (e_4_1) {
                    e_4 = { error: e_4_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return))
                            _c.call(_a);
                    }
                    finally {
                        if (e_4)
                            throw e_4.error;
                    }
                }
                this.activeEntries = [];
                var e_4, _c;
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.setCustomClass = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var alertType = this.tooltipObj["alertType"];
                if (alertType) {
                    if (alertType == 1) {
                        this.customTooltipClass = 'alert1';
                    }
                    else {
                        this.customTooltipClass = 'alert2';
                    }
                }
            };
        /**
         * @return {?}
         */
        LineChartComponent.prototype.findOtherProperty = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var arr = this.results;
                /** @type {?} */
                var fundName = this.tooltipObj["name"];
                /** @type {?} */
                var timeName = this.tooltipObj["value"];
                /** @type {?} */
                var findSeries = {};
                /** @type {?} */
                var obj;
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i]["name"] === fundName) {
                        findSeries = Object.assign(findSeries, arr[i]);
                        break;
                    }
                }
                /** @type {?} */
                var series = findSeries["series"];
                for (var j = 0; j < series.length; j++) {
                    if (series[j]["name"] === timeName) {
                        obj = {
                            "nav": series[j]["nav"],
                            "marketval": series[j]["marketval"]
                        };
                        this.tooltipObj = Object.assign(this.tooltipObj, obj);
                        break;
                    }
                }
            };
        // below is for custom alert details rect logic
        // below is for custom alert details rect logic
        /**
         * @param {?} data
         * @return {?}
         */
        LineChartComponent.prototype.onClickAlertCircle =
            // below is for custom alert details rect logic
            /**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                if (data) {
                    /** @type {?} */
                    var alreadyInShowMap_1 = false;
                    this.showAlertDetailsMap.forEach(function (item) {
                        if (data.x === item.x && data.name === item.name) {
                            alreadyInShowMap_1 = true;
                            item.show = !item.show;
                        }
                        else {
                            item.show = false;
                        }
                    });
                    if (!alreadyInShowMap_1) {
                        /** @type {?} */
                        var obj = {
                            x: data.x,
                            name: data.name,
                            show: data['show'] ? !data['show'] : true
                        };
                        this.showAlertDetailsMap.push(obj);
                    }
                }
            };
        /**
         * @param {?} data
         * @return {?}
         */
        LineChartComponent.prototype.getShowAlertDetails = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var showOrNot = false;
                this.showAlertDetailsMap.forEach(function (item) {
                    if (data.x === item.x && data.name === item.name) {
                        showOrNot = item.show;
                    }
                });
                return showOrNot;
            };
        /**
         * @param {?} circle
         * @return {?}
         */
        LineChartComponent.prototype.getRectLoactionX = /**
         * @param {?} circle
         * @return {?}
         */
            function (circle) {
                /** @type {?} */
                var xLocation = 0;
                if (this.commonUtils.isBeyondDivision(new Date(circle.pricetime))) {
                    xLocation = circle.x - 220;
                }
                else {
                    xLocation = circle.x + 10;
                }
                return xLocation;
            };
        /**
         * @param {?} circle
         * @return {?}
         */
        LineChartComponent.prototype.getRectLoactionY = /**
         * @param {?} circle
         * @return {?}
         */
            function (circle) {
                /** @type {?} */
                var yLocation = 0;
                if (circle.navChange >= 0) {
                    yLocation = circle.value + 10;
                }
                else {
                    yLocation = circle.value - 110;
                }
                return yLocation;
            };
        LineChartComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-fine-line-chart',
                        template: "<div class=\"custom-chart\">\n  <ngx-charts-chart \n      [view]=\"[width, height]\"\n      [showLegend]=\"false\"\n      [legendOptions]=\"legendOptions\"\n      [activeEntries]=\"activeEntries\"\n      [animations]=\"animations\"\n      (legendLabelClick)=\"onClick($event)\"\n      (legendLabelActivate)=\"onActivate($event)\"\n      (legendLabelDeactivate)=\"onDeactivate($event)\">\n      <svg:defs>\n        <svg:clipPath [attr.id]=\"clipPathId\">\n          <svg:rect\n            [attr.width]=\"dims.width + 10\"\n            [attr.height]=\"dims.height + 10\"\n            [attr.transform]=\"'translate(-5, -5)'\"/>\n        </svg:clipPath>\n      </svg:defs>\n      <svg:g [attr.transform]=\"transform\" class=\"line-chart chart\">\n        <svg:g ngx-charts-x-axis \n          [xScale]=\"xScale\"\n          [dims]=\"dims\"\n          [showLabel]=\"showXAxisLabel\"\n          [showGridLines]=\"showGridLines\"\n          [labelText]=\"xAxisLabel\"\n          [ticks]=\"tickValues\"\n          [tickFormatting]=\"xAxisTickFormatting\"\n          (dimensionsChanged)=\"updateXAxisHeight($event)\">\n        </svg:g>\n        <svg:g ngx-charts-y-axis\n          [yScale]=\"yScale\"\n          [dims]=\"dims\"\n          [showLabel]=\"showYAxisLabel\"\n          [labelText]=\"yAxisLabel\"\n          [referenceLines]=\"referenceLines\"\n          [showRefLines]=\"showRefLines\"\n          [showGridLines]=\"showGridLines\"\n          [showRefLabels]=\"showRefLabels\"\n          (dimensionsChanged)=\"updateYAxisWidth($event)\">\n        </svg:g>\n        <svg:line\n        [attr.x1]=\"lastDataX\"\n        [attr.y1]=\"0\"\n        [attr.x2]=\"lastDataX\"\n        [attr.y2]=\"height\"\n        [attr.class]=\"'end-line'\"\n      />\n      <svg:foreignObject\n        [attr.x]=\"lastDataX - 40\"\n        [attr.y]=\"height - 15\"\n        [attr.width]=\"80 + 'px'\"\n        [attr.height]=\"30 + 'px'\"\n        [style.pointer-events]=\"'none'\">\n        <xhtml:div\n          class='last-time'\n          [style.width]=\"80 + 'px'\"\n          [style.height]=\"20 + 'px'\"\n          >\n          <xhtml:span> {{displayLiveTime | date: \"h:mm:ss aaaaa'm'\"}}\n          </xhtml:span>\n        </xhtml:div>\n      </svg:foreignObject>\n        <svg:g [attr.clip-path]=\"clipPath\">\n          <svg:g *ngFor=\"let series of results; trackBy:trackBy\" [@animationState]=\"'active'\">\n            <svg:g ngx-charts-line-series\n              [xScale]=\"xScale\"\n              [yScale]=\"yScale\"\n              [colors]=\"colors\"\n              [data]=\"series\"\n              [activeEntries]=\"activeEntries\"\n              [scaleType]=\"scaleType\"\n              [curve]=\"curve\"\n              [rangeFillOpacity]=\"rangeFillOpacity\"\n              [hasRange]=\"hasRange\"\n              [animations]=\"animations\"\n            />\n          </svg:g>\n          <svg:g *ngIf=\"!tooltipDisabled\" (mouseleave)=\"hideCircles()\">\n            <svg:g ngx-charts-tooltip-area\n              [dims]=\"dims\"\n              [xSet]=\"xSet\"\n              [xScale]=\"xScale\"\n              [yScale]=\"yScale\"\n              [results]=\"results\"\n              [colors]=\"colors\"\n              [tooltipDisabled]=\"!tooltipDisabled\"\n              (hover)=\"updateHoveredVertical($event)\"\n            />\n          \n            <svg:g *ngFor=\"let series of results\">\n              <svg:g ngx-charts-circle-series\n                [xScale]=\"xScale\"\n                [yScale]=\"yScale\"\n                [colors]=\"colors\"\n                [data]=\"series\"\n                [scaleType]=\"scaleType\"\n                [visibleValue]=\"hoveredVertical\"\n                [activeEntries]=\"activeEntries\"\n                (select)=\"onClick($event, series)\"\n                (activate)=\"onActivate($event)\"\n                (deactivate)=\"onDeactivate($event)\"\n                [tooltipTemplate]=\"tooltipTemplate\"\n              />\n            </svg:g>\n            \n            <svg:g *ngFor=\"let circle of circleSeries\">\n                <svg:g ngx-charts-circle\n                  [cx]=\"circle.x\"\n                  [cy]=\"circle.value\"\n                  [r]=\"circleRadius\"\n                  [data]=\"circle\"\n                  [fill]=\"circle.fill\"\n                  (select)=\"onClickAlertCircle($event)\"\n                />\n            </svg:g>\n          </svg:g>\n        </svg:g>\n        <svg:g *ngFor=\"let circle of circleSeries\">\n            <svg:foreignObject\n                  *ngIf=\"getShowAlertDetails(circle)\"\n                  [attr.x]=\"getRectLoactionX(circle)\"\n                  [attr.y]=\"getRectLoactionY(circle)\"\n                  [attr.width]=\"210 + 'px'\"\n                  [attr.height]=\"140 + 'px'\"\n                  [style.pointer-events]=\"'none'\">\n                    <xhtml:div\n                      class='alert-details-sty'\n                      [style.border-color]=\"circle.fill\"\n                      >\n                      <xhtml:span> {{circle.name}}\n                      </xhtml:span>\n                      <xhtml:span> {{circle.time}}\n                      </xhtml:span>\n                       <xhtml:label> \n                          NAV diverging from market value\n                      </xhtml:label>\n                      <xhtml:table>\n                        <xhtml:tr>NAV Change:<xhtml:td>{{circle.navChange | percent: '1.2-2'}}</xhtml:td>\n                        </xhtml:tr>\n                        <xhtml:tr>MV Change:<xhtml:td>{{circle.mvChange | percent: '1.2-2'}}</xhtml:td>\n                        </xhtml:tr>\n                      </xhtml:table>\n                    </xhtml:div>\n                </svg:foreignObject>\n        </svg:g>\n      </svg:g>\n  </ngx-charts-chart>\n  <ng-template #tooltipTemplate>\n      <div class=\"line-tooltip\">\n          <div class=\"top\">\n              <span class=\"fund-name\">{{tooltipObj.name}} </span>\n              <span> - </span>\n              <span class=\"time\">{{tooltipObj.value | date: \"h:mm:ss aaaaa'm'\"}}</span>\n          </div>\n          <table>\n            <tr align='right'>NAV<td>{{tooltipObj.nav | number: '1.2-2'}}</td></tr>\n            <tr align='right'>MV Amt Base<td>{{tooltipObj.marketval | number: '1.2-2'}}</td></tr>\n          </table>\n      </div>\n  </ng-template>\n</div>",
                        styles: [".custom-chart{position:relative}.custom-chart .custom-tooltip{background-color:#ddd;border:2px solid grey;position:absolute;z-index:99}.custom-chart .custom-tooltip table{border-spacing:0;border-collapse:collapse;width:100%}.custom-chart .ngx-charts{float:left;overflow:visible}.custom-chart .ngx-charts .custom-axis-line{stroke:#eee;stroke-width:2}.custom-chart .ngx-charts .end-line{stroke:#6c757d;stroke-width:1}.custom-chart .ngx-charts .last-time{background-color:#eee;box-shadow:0 0 2px 0 rgba(0,0,0,.15);display:flex;justify-content:center;align-items:center;font-weight:700;font-size:14px;border-radius:5px}.custom-chart .ngx-charts .alert-details-sty{color:#6c757d;border:2px solid;background-color:rgba(255,255,255,.9);width:200px;height:95px;padding-left:5px}.custom-chart .ngx-charts .alert-details-sty span{text-align:center;display:inline-flex;width:80px;font-size:14px;font-weight:700}.custom-chart .ngx-charts .alert-details-sty label{display:inline-block;font-size:12px;padding:5px 0 5px 2px}.custom-chart .ngx-charts .alert-details-sty table{font-size:12px}.custom-chart .ngx-charts .arc,.custom-chart .ngx-charts .bar,.custom-chart .ngx-charts .circle{cursor:pointer}.custom-chart .ngx-charts .arc.active,.custom-chart .ngx-charts .arc:hover,.custom-chart .ngx-charts .bar.active,.custom-chart .ngx-charts .bar:hover,.custom-chart .ngx-charts .card.active,.custom-chart .ngx-charts .card:hover,.custom-chart .ngx-charts .cell.active,.custom-chart .ngx-charts .cell:hover{opacity:.8;transition:opacity .1s ease-in-out}.custom-chart .ngx-charts .arc:focus,.custom-chart .ngx-charts .bar:focus,.custom-chart .ngx-charts .card:focus,.custom-chart .ngx-charts .cell:focus,.custom-chart .ngx-charts g:focus{outline:0}.custom-chart .ngx-charts .area-series.inactive,.custom-chart .ngx-charts .line-series-range.inactive,.custom-chart .ngx-charts .line-series.inactive,.custom-chart .ngx-charts .polar-series-area.inactive,.custom-chart .ngx-charts .polar-series-path.inactive{transition:opacity .1s ease-in-out;opacity:.2}.custom-chart .ngx-charts .line-highlight{display:none}.custom-chart .ngx-charts .line-highlight.active{display:block}.custom-chart .ngx-charts .area{opacity:.6}.custom-chart .ngx-charts .circle:hover{cursor:pointer}.custom-chart .ngx-charts .label{font-size:18px;font-weight:400}.custom-chart .ngx-charts .tooltip-anchor{fill:#000}.custom-chart .ngx-charts .gridline-path{stroke:#ddd;stroke-width:1;fill:none}.custom-chart .ngx-charts .refline-path{stroke:#a8b2c7;stroke-width:1;stroke-dasharray:5;stroke-dashoffset:5}.custom-chart .ngx-charts .refline-label{font-size:9px}.custom-chart .ngx-charts .reference-area{fill-opacity:.05;fill:#000}.custom-chart .ngx-charts .gridline-path-dotted{stroke:#ddd;stroke-width:1;fill:none;stroke-dasharray:1,20;stroke-dashoffset:3}.custom-chart .ngx-charts .grid-panel rect{fill:none}.custom-chart .ngx-charts .grid-panel.odd rect{fill:rgba(170,35,35,.05)}.type-tooltip.ngx-charts-tooltip-content{position:fixed;border-radius:3px;z-index:5000;display:block;font-weight:400;opacity:0;pointer-events:none!important;font-size:14px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top{border-bottom:1px solid grey;padding-bottom:5px;margin-bottom:0;overflow:auto}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top .fund-name{float:left;font-weight:700}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top .time{float:right;font-weight:700}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .description{clear:both;font-size:14px;margin-top:10px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip td{padding:2px 20px;text-align:right}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .bth-group{float:right;margin-right:-10px;margin-top:15px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .bth-group button{background-color:#fff;padding:8px;border:2px solid #ddd;width:85px;font-size:12px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip{color:#000;background:#eee;font-size:14px;padding:15px 18px;text-align:left;pointer-events:auto;width:220px;height:115px;border:2px solid #ddd}.type-tooltip.ngx-charts-tooltip-content.type-tooltip.alert1{border:2px solid #ffbc06;height:150px;width:249px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip.alert2{border:2px solid #b91224;height:150px;width:249px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-left{border-top:7px solid transparent;border-bottom:7px solid transparent;border-left:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-top{border-left:7px solid transparent;border-right:7px solid transparent;border-top:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-right{border-top:7px solid transparent;border-bottom:7px solid transparent;border-right:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-bottom{border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content .tooltip-caret{position:absolute;z-index:5001;width:0;height:0}.type-tooltip.ngx-charts-tooltip-content.position-right{-webkit-transform:translate3d(10px,0,0);transform:translate3d(10px,0,0)}.type-tooltip.ngx-charts-tooltip-content.position-left{-webkit-transform:translate3d(-10px,0,0);transform:translate3d(-10px,0,0)}.type-tooltip.ngx-charts-tooltip-content.position-top{-webkit-transform:translate3d(0,-10px,0);transform:translate3d(0,-10px,0)}.type-tooltip.ngx-charts-tooltip-content.position-bottom{-webkit-transform:translate3d(0,10px,0);transform:translate3d(0,10px,0)}.type-tooltip.ngx-charts-tooltip-content.animate{opacity:1;transition:opacity .3s,transform .3s,-webkit-transform .3s;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);pointer-events:auto}.area-tooltip-container{padding:5px 0;pointer-events:none}.tooltip-item{text-align:left;line-height:1.2em;padding:5px 0}.tooltip-item .tooltip-item-color{display:inline-block;height:12px;width:12px;margin-right:5px;color:#5b646b;border-radius:3px}"],
                        encapsulation: i0.ViewEncapsulation.ShadowDom,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        animations: [
                            animations.trigger('animationState', [
                                animations.transition(':leave', [
                                    animations.style({
                                        opacity: 1,
                                    }),
                                    animations.animate(500, animations.style({
                                        opacity: 0
                                    }))
                                ])
                            ])
                        ]
                    },] },
        ];
        LineChartComponent.ctorParameters = function () {
            return [
                { type: i0.ElementRef },
                { type: i0.NgZone },
                { type: i0.ChangeDetectorRef },
                { type: CommonUtilsService },
                { type: common.DatePipe }
            ];
        };
        LineChartComponent.propDecorators = {
            legend: [{ type: i0.Input }],
            legendTitle: [{ type: i0.Input }],
            showXAxisLabel: [{ type: i0.Input }],
            showYAxisLabel: [{ type: i0.Input }],
            xAxisLabel: [{ type: i0.Input }],
            yAxisLabel: [{ type: i0.Input }],
            autoScale: [{ type: i0.Input }],
            timeline: [{ type: i0.Input }],
            gradient: [{ type: i0.Input }],
            showGridLines: [{ type: i0.Input }],
            curve: [{ type: i0.Input }],
            schemeType: [{ type: i0.Input }],
            rangeFillOpacity: [{ type: i0.Input }],
            xAxisTickFormatting: [{ type: i0.Input }],
            yAxisTickFormatting: [{ type: i0.Input }],
            xAxisTicks: [{ type: i0.Input }],
            yAxisTicks: [{ type: i0.Input }],
            roundDomains: [{ type: i0.Input }],
            tooltipDisabled: [{ type: i0.Input }],
            showRefLines: [{ type: i0.Input }],
            referenceLines: [{ type: i0.Input }],
            showRefLabels: [{ type: i0.Input }],
            xScaleMin: [{ type: i0.Input }],
            xScaleMax: [{ type: i0.Input }],
            yScaleMin: [{ type: i0.Input }],
            yScaleMax: [{ type: i0.Input }],
            selectable: [{ type: i0.Input }],
            height: [{ type: i0.Input }],
            width: [{ type: i0.Input }],
            margin: [{ type: i0.Input }],
            colorDomain: [{ type: i0.Input }],
            results: [{ type: i0.Input }],
            circleData: [{ type: i0.Input }],
            currentLineTime: [{ type: i0.Input }],
            tickValues: [{ type: i0.Input }],
            displayLiveTime: [{ type: i0.Input }],
            activeEntries: [{ type: i0.Input }],
            highLightActiveEntries: [{ type: i0.Input }],
            activate: [{ type: i0.Output }],
            deactivate: [{ type: i0.Output }],
            tooltipTemplate: [{ type: i0.ContentChild, args: ['tooltipTemplate',] }],
            seriesTooltipTemplate: [{ type: i0.ContentChild, args: ['seriesTooltipTemplate',] }],
            hideCircles: [{ type: i0.HostListener, args: ['mouseleave',] }],
            onMouseEnter: [{ type: i0.HostListener, args: ['mouseenter', ["series"],] }],
            onMouseLeave: [{ type: i0.HostListener, args: ['mouseleave', ["$event"],] }]
        };
        return LineChartComponent;
    }(ngxCharts.BaseChartComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CustomLegendComponent = (function () {
        function CustomLegendComponent(shareInforBewteenComponents, commonUtils) {
            this.shareInforBewteenComponents = shareInforBewteenComponents;
            this.commonUtils = commonUtils;
        }
        /**
         * @return {?}
         */
        CustomLegendComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @return {?}
         */
        CustomLegendComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        CustomLegendComponent.prototype.getShowLegendAndConsistent = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                if (fund.name === "") {
                    return false;
                }
                else {
                    /** @type {?} */
                    var list = this.shareInforBewteenComponents.getFundList();
                    /** @type {?} */
                    var show_1 = false;
                    list.forEach(function (item) {
                        if (item.fundID === fund.name && item.checked) {
                            show_1 = true;
                        }
                    });
                    return show_1;
                }
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        CustomLegendComponent.prototype.getFundRelatedColor = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                /** @type {?} */
                var colorStr = '';
                this.colorDomain.forEach(function (item) {
                    if (item['fundid'] === fund['name']) {
                        colorStr = item['color'];
                    }
                });
                return colorStr;
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        CustomLegendComponent.prototype.remove = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                this.commonUtils.updateFundStatus(fund['fundID'], false);
                /** @type {?} */
                var fundIndex = -1;
                this.results.forEach(function (item, index) {
                    if (item['name'] === fund['name']) {
                        fundIndex = index;
                    }
                });
                if (fundIndex >= 0) {
                    this.results.splice(fundIndex, 1);
                }
                this.selectedFundChange.emit(fund);
            };
        CustomLegendComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'app-custom-legend',
                        template: "<mat-chip-list class=\"mat-chip-list\">\n  <ng-container\n  *ngFor=\"let fund of results;let i=index;trackBy:index\" \n  >\n     <mat-basic-chip\n      *ngIf=\"getShowLegendAndConsistent(fund)\"\n      [selectable]=\"selectable\" \n      [removable]=\"removable\" \n      [style.borderColor]=\"getFundRelatedColor(fund)\"\n      disableRipple>\n        {{fund.fundTicker ? fund.fundTicker : fund.fundID }}\n         <mat-icon class=\"removeIcon\" svgIcon=\"close\" matChipRemove (click)=\"remove(fund)\"></mat-icon> \n  </mat-basic-chip>\n  </ng-container>\n</mat-chip-list>",
                        styles: [".mat-basic-chip{margin:10px 10px 15px;border-top:1px solid;border-bottom:1px solid;border-right:1px solid;border-left:5px solid;display:inline-flex;padding:3px 0 0 10px;font-size:14px}.mat-basic-chip .removeIcon{width:10px!important;height:10px!important;margin:0 8px;cursor:pointer;min-height:10px!important;min-width:10px!important}"]
                    },] },
        ];
        CustomLegendComponent.ctorParameters = function () {
            return [
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService }
            ];
        };
        CustomLegendComponent.propDecorators = {
            results: [{ type: i0.Input }],
            selectable: [{ type: i0.Input }],
            removable: [{ type: i0.Input }],
            colorDomain: [{ type: i0.Input }],
            index: [{ type: i0.Input }],
            selectedFundChange: [{ type: i0.Input }]
        };
        return CustomLegendComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    //import { dev, prod } from '../lib-env';
    var NavService = (function () {
        //baseUrl = this.env.production? prod.service_base_url: dev.service_base_url;
        //constructor(private http: HttpClient, @Inject('env') private env) { }
        function NavService(http) {
            this.http = http;
            this.data = new rxjs.BehaviorSubject((([])));
        }
        /**
         * @param {?} funds
         * @return {?}
         */
        NavService.prototype.getTodayNav = /**
         * @param {?} funds
         * @return {?}
         */
            function (funds) {
                return this.http.get('/api/today'); // demo api, can be removed after merge qnav-line-chart
            };
        // call this one from chart component only to avoid multiple call request by different component
        // call this one from chart component only to avoid multiple call request by different component
        /**
         * @return {?}
         */
        NavService.prototype.fetchFundList =
            // call this one from chart component only to avoid multiple call request by different component
            /**
             * @return {?}
             */
            function () {
                var _this = this;
                //return this.http.get<any[]>('/api/fundList').subscribe(d => this.data.next(d as any[]));
                this.data = new rxjs.BehaviorSubject((([]))); //reset data as the getFundList subcription may still get the old data if new call hasn't returned yet.
                this.http.get('/qnav-web-multiclass/data/fundlist?timeZoneOffset=' + new Date().getTimezoneOffset() * (-1))
                    .subscribe(function (d) {
                    _this.data.next(((d)));
                }, function (error) {
                    console.log(error);
                });
            };
        // call this one for all components to get fundlist if it's already fetched.
        // call this one for all components to get fundlist if it's already fetched.
        /**
         * @return {?}
         */
        NavService.prototype.getFundList =
            // call this one for all components to get fundlist if it's already fetched.
            /**
             * @return {?}
             */
            function () {
                return this.data.asObservable();
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        NavService.prototype.getPositionDetails = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                //return this.http.get('api/positionDetails')
                return this.http.get('/qnav-web-multiclass/data/fundDetail?fundId=' + fund);
            };
        NavService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        NavService.ctorParameters = function () {
            return [
                { type: i1.HttpClient }
            ];
        };
        /** @nocollapse */ NavService.ngInjectableDef = i0.defineInjectable({ factory: function NavService_Factory() { return new NavService(i0.inject(i1.HttpClient)); }, token: NavService, providedIn: "root" });
        return NavService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @enum {string} */
    var Action = {
        REGISTER: "register",
        SENDTO: "sendTo",
        STOPWATCHFUND: "stopWatchFund",
        WATCHFUND: "watchFund",
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    //import { dev, prod } from '../lib-env';
    var NavSocketService = (function () {
        // constructor(@Inject('env') private env) {
        //     this.initSocket();
        //     this.registerService();
        // }
        function NavSocketService() {
            this.nav = new rxjs.BehaviorSubject((({})));
            this.initSocket();
            this.registerService();
        }
        /**
         * @return {?}
         */
        NavSocketService.prototype.initSocket = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.subject = webSocket.webSocket('wss://' + window.location.hostname + ":" + window.location.port + '/qnav-web-multiclass/conn'); //  proxy won't be able to function if the port not match with start port
                //return this.subject;
                this.subject.subscribe(function (msg) { _this.nav.next(((msg))); }, function (err) { return console.log("ERROR!!!!" + err); }, function () { return console.log("NAV Socket COMPLETED....."); });
                // console.log(new Date(1524823809200431));
            };
        /**
         * @return {?}
         */
        NavSocketService.prototype.getNav = /**
         * @return {?}
         */
            function () {
                return this.nav.asObservable();
            };
        /**
         * @param {?} request
         * @return {?}
         */
        NavSocketService.prototype.send = /**
         * @param {?} request
         * @return {?}
         */
            function (request) {
                this.subject.next(request);
            };
        /**
         * @param {?} funds
         * @return {?}
         */
        NavSocketService.prototype.registerFunds = /**
         * @param {?} funds
         * @return {?}
         */
            function (funds) {
                var _this = this;
                funds.forEach(function (fund) {
                    _this.send({ "action": Action.WATCHFUND, "fundId": fund });
                });
            };
        /**
         * @param {?} funds
         * @return {?}
         */
        NavSocketService.prototype.unRegisterFunds = /**
         * @param {?} funds
         * @return {?}
         */
            function (funds) {
                var _this = this;
                funds.forEach(function (fund) {
                    _this.send({ "action": Action.STOPWATCHFUND, "fundId": fund });
                });
            };
        /**
         * @return {?}
         */
        NavSocketService.prototype.registerService = /**
         * @return {?}
         */
            function () {
                this.send({ action: Action.REGISTER, sessionId: new Date().valueOf() + '', timeZoneOffset: new Date().getTimezoneOffset() * (-1) });
            };
        NavSocketService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        NavSocketService.ctorParameters = function () { return []; };
        /** @nocollapse */ NavSocketService.ngInjectableDef = i0.defineInjectable({ factory: function NavSocketService_Factory() { return new NavSocketService(); }, token: NavSocketService, providedIn: "root" });
        return NavSocketService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var ResourceManagerService = (function () {
        function ResourceManagerService() {
            var _this = this;
            this.intervalInstances = [];
            this.intervalFuncs = [];
            //window.addEventListener('blur',(event)=>{this.deactive(event)});
            //window.addEventListener('focus',(event)=>{this.active(event)});
            window.addEventListener('visibilitychange', function (event) {
                if (document.hidden) {
                    _this.deactive(event);
                }
                else {
                    _this.active(event);
                }
            });
        }
        /**
         * @param {?} event
         * @return {?}
         */
        ResourceManagerService.prototype.deactive = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                //console.log(event);
                this.doDeactive();
            };
        /**
         * @return {?}
         */
        ResourceManagerService.prototype.doDeactive = /**
         * @return {?}
         */
            function () {
                this.intervalInstances.forEach(function (item) {
                    /** @type {?} */
                    var time = new Date();
                    console.log("clear the setinterval for component: " + item + ", " + time);
                    clearInterval(item);
                });
            };
        /**
         * @param {?} event
         * @return {?}
         */
        ResourceManagerService.prototype.active = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                var _this = this;
                //console.log(event);
                this.intervalFuncs.forEach(function (item) {
                    //console.log(`active the setinterval for component: ${item['func']}, interval:${item['interval']}, ${time}`);
                    _this.intervalInstances.push(setInterval(item['func'], item['interval']));
                });
            };
        /**
         * @param {?} intervalFunc
         * @param {?} interval
         * @return {?}
         */
        ResourceManagerService.prototype.registInterval = /**
         * @param {?} intervalFunc
         * @param {?} interval
         * @return {?}
         */
            function (intervalFunc, interval) {
                /** @type {?} */
                var instance = setInterval(intervalFunc, interval);
                this.intervalInstances.push(instance);
                this.intervalFuncs.push({ 'func': intervalFunc, 'interval': interval });
            };
        //need call in component ngOnDestroy() to clear resources for current component
        //need call in component ngOnDestroy() to clear resources for current component
        /**
         * @return {?}
         */
        ResourceManagerService.prototype.cleanResources =
            //need call in component ngOnDestroy() to clear resources for current component
            /**
             * @return {?}
             */
            function () {
                this.doDeactive();
                this.intervalInstances = [];
                this.intervalFuncs = [];
            };
        ResourceManagerService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        ResourceManagerService.ctorParameters = function () { return []; };
        /** @nocollapse */ ResourceManagerService.ngInjectableDef = i0.defineInjectable({ factory: function ResourceManagerService_Factory() { return new ResourceManagerService(); }, token: ResourceManagerService, providedIn: "root" });
        return ResourceManagerService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @type {?} */
    var customColumn = [];
    /** @type {?} */
    var normalColumn = [
        {
            prop: 'cusip',
            name: 'Instrument Id Ref',
            width: '',
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'default',
            headerClassFormat: 'headerLeft',
            cellClassFormat: 'cellLeft',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'longShortIndicator',
            name: 'Long/Short',
            width: '',
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'default',
            headerClassFormat: 'headerLeft',
            cellClassFormat: 'cellLeft',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'parShare',
            name: 'Units',
            width: '',
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'sodPrice',
            name: 'Price Previous',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'price',
            name: 'Price Current',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'mv',
            name: 'Market Value',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'priceChangePercent',
            name: 'Price % Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'percentFormat',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'navImpact',
            name: 'NAV Impact',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatLong',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        }
    ];
    /** @type {?} */
    var columnMenuDropDownSetting = [
        // {
        //   name: "Resize to Fit",
        //   type: "resizeToFit",
        //   hasSubMenu: false,
        // },
        {
            name: "Freeze Column",
            type: "freezeColumn",
            hasSubMenu: false,
        },
        {
            name: "Sort Column",
            type: "sortColumn",
            hasSubMenu: false,
        },
    ];

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var QnavPositionComponent = (function (_super) {
        __extends(QnavPositionComponent, _super);
        function QnavPositionComponent(navService, appContext, navSocketService, shareInfoBeweenComponentsService, commonUtils, resourceManger) {
            var _this = _super.call(this) || this;
            _this.navService = navService;
            _this.appContext = appContext;
            _this.navSocketService = navSocketService;
            _this.shareInfoBeweenComponentsService = shareInfoBeweenComponentsService;
            _this.commonUtils = commonUtils;
            _this.resourceManger = resourceManger;
            _this.rows = [];
            _this.childRows = [];
            _this.isDataAvailable = false;
            _this.rowHeight = 50;
            _this.alertData = [];
            _this.allRowsSelected = false;
            _this.isSelectedMap = [];
            _this.headerSetting = true;
            _this.headerHeight = 50;
            // temp data structure
            _this.isDataTablePaused = false;
            _this.customColumn = customColumn;
            _this.normalColumn = normalColumn;
            _this.columnMenuDropDownSetting = columnMenuDropDownSetting;
            _this.limit = 5;
            _this.footerHeight = 50;
            _this.headerCheckBox = false;
            _this.fundInfo = [];
            return _this;
        }
        /**
         * @return {?}
         */
        QnavPositionComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                //reset component data and user validation;
                this.commonUtils.validateUser();
                this.rows = [];
                this.subs = [];
                this.isDataAvailable = false;
                this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
                if (this.fundInfo.length > 0) {
                    this.renderPositionDetails();
                }
                else {
                    //this.navService.fetchFundList();
                    this.navService.getFundList().subscribe(function (data) {
                        if (data.length > 0) {
                            /** @type {?} */
                            var fundInfo = [];
                            fundInfo.push(data[0].fundid);
                            fundInfo.push(data[0].name);
                            fundInfo.push(data[0].fundTicker);
                            _this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
                            _this.renderPositionDetails();
                        }
                    });
                }
                this.shareInfoBeweenComponentsService.sortDatatableColumn.subscribe(function (data) {
                    console.log(__spread(_this.commonUtils.sortColumnByProp(_this.rows, _this.childRows, data.map, data.prop, data.ascFlag)));
                    _this.rows = __spread(_this.commonUtils.sortColumnByProp(_this.rows, _this.childRows, data.map, data.prop, data.ascFlag));
                });
            };
        /**
         * @return {?}
         */
        QnavPositionComponent.prototype.renderPositionDetails = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
                if (this.fundInfo.length > 0) {
                    this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(function (data) {
                        _this.isDataAvailable = true;
                        _this.rows = data["holdings"];
                        _this.rows = __spread(_this.rows);
                    }));
                    this.subs.push(this.navSocketService.getNav().subscribe(function (data) {
                        if (data['eventType'] === 'fundChange') {
                            /** @type {?} */
                            var fundLevelRow = _this.commonUtils.extractWSData(data["eventData"], false);
                            _this.updateRow(fundLevelRow);
                        }
                        else {
                            _this.updateRow(data);
                        }
                    }));
                    this.navSocketService.registerFunds([this.fundInfo[0]]);
                    this.resourceManger.registInterval(function () { _this.rows = __spread(_this.rows); }, 300);
                }
            };
        /**
         * @return {?}
         */
        QnavPositionComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                if (this.fundInfo.length > 0) {
                    this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
                    this.subs.forEach(function (sub) { return sub.unsubscribe(); });
                }
                this.resourceManger.cleanResources();
            };
        /**
         * @param {?} data
         * @return {?}
         */
        QnavPositionComponent.prototype.updateRow = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
                    if (this.rows.length && data) {
                        /** @type {?} */
                        var fundid_1 = data['fundid'];
                        /** @type {?} */
                        var cusip_1 = data['cusip'];
                        /** @type {?} */
                        var longShortIndicator_1 = data['longShortIndicator'];
                        this.rows.forEach(function (item) {
                            if (_this.fundInfo[0] === fundid_1 && item['cusip'] === cusip_1 && item['longShortIndicator'] === longShortIndicator_1) {
                                _this.normalColumn.forEach(function (colItem) {
                                    if (null != data[colItem.prop]) {
                                        item[colItem.prop] = data[colItem.prop];
                                    }
                                });
                            }
                        });
                    }
                }
                if (data && data['eventType'] === 'sodChange') {
                    this.navService.getPositionDetails(this.fundInfo[0]).subscribe(function (data) {
                        _this.rows = data["holdings"];
                        _this.rows = __spread(_this.rows);
                    });
                }
            };
        // returnBack(): any {
        //   this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-001');
        // }
        // returnBack(): any {
        //   this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-001');
        // }
        /**
         * @return {?}
         */
        QnavPositionComponent.prototype.togglePauseFlag =
            // returnBack(): any {
            //   this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-001');
            // }
            /**
             * @return {?}
             */
            function () {
                this.isDataTablePaused = !this.isDataTablePaused;
            };
        QnavPositionComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-qnav-position',
                        template: "<div class=\"qnav-position-container\" *ngIf=\"isDataAvailable\">\n    <!-- <div class=\"returnBack\" (click)=\"returnBack()\">\n        <mat-icon class=\"home\" svgIcon=\"home\"></mat-icon>\n    </div> -->\n    <div class=\"fundDetails\">\n        <ul>\n            <li>Position Details for</li>\n            <li>\n                <label>Entity Ticker: </label> {{fundInfo[2]}}\n            </li>\n             <li>\n                <label>Entity Name: </label> {{fundInfo[1]}}\n            </li>\n        </ul>\n    </div>\n<lib-common-data-table\n    [headerSetting]=\"headerSetting\"\n    [headerHeight]=\"headerHeight\"\n    [rows]=\"rows\"\n    [childRows]=\"childRows\"\n    [alertData]=\"alertData\"\n    [rowHeight]=\"rowHeight\"\n    [customColumn]=\"customColumn\"\n    [normalColumn]=\"normalColumn\"\n    [limit]=\"limit\"\n    [footerHeight]=\"footerHeight\"\n    [headerCheckBox]=\"headerCheckBox\"\n    [isDataTablePaused]=\"isDataTablePaused\"\n    [columnMenuDropDownSetting]=\"columnMenuDropDownSetting\"\n    [defaultSortCol]=\"'cusip'\"\n    (togglePauseFlagEvent)=\"togglePauseFlag()\"\n>\n</lib-common-data-table>\n</div>",
                        styles: [".ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:\" \";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:\"\";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:\"\";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}", ".ngx-datatable.material{display:unset}.ngx-datatable .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .columnHeader{color:#000}.returnBack{width:20px;height:20px;position:absolute;top:14px;right:60px;cursor:pointer}.qnav-position-container{width:100%;height:100%}.fundDetails{color:#464646;font-size:16px;position:absolute;top:0;left:-15px;font-family:DINNextLTPro-Medium}ul{list-style:none;display:inline-flex}li{margin-right:5px}"],
                    },] },
        ];
        QnavPositionComponent.ctorParameters = function () {
            return [
                { type: NavService },
                { type: uiCommon.AppContext },
                { type: NavSocketService },
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService },
                { type: ResourceManagerService }
            ];
        };
        return QnavPositionComponent;
    }(uiCommon.BaseWidgetComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var AddFundModalComponent = (function () {
        function AddFundModalComponent(commonUtils, dialogRef, data) {
            this.commonUtils = commonUtils;
            this.dialogRef = dialogRef;
            this.data = data;
            this.fundList = _.cloneDeep(data['fundList']);
            this.selectedFundChange = data.dataChange;
        }
        /**
         * @return {?}
         */
        AddFundModalComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        AddFundModalComponent.prototype.handleSelectFund = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                /** @type {?} */
                var index = this.fundList.indexOf(fund);
                this.fundList[index]['checked'] = !this.fundList[index]['checked'];
            };
        /**
         * @return {?}
         */
        AddFundModalComponent.prototype.handleClickSelectBtn = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var removeFundList = this.fundList.filter(function (item) { return item.checked === false; });
                /** @type {?} */
                var addFundlist = this.fundList.filter(function (item) { return item.checked === true; });
                removeFundList.forEach(function (item) {
                    _this.updateVariableFundList(item);
                });
                addFundlist.forEach(function (item) {
                    _this.updateVariableFundList(item);
                });
                this.selectedFundChange.emit(addFundlist);
                this.onNoClick();
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        AddFundModalComponent.prototype.updateVariableFundList = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                this.commonUtils.updateFundStatus(fund['fundID'], fund['checked']);
            };
        /**
         * @return {?}
         */
        AddFundModalComponent.prototype.onNoClick = /**
         * @return {?}
         */
            function () {
                this.dialogRef.close();
            };
        AddFundModalComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-add-fund-modal',
                        template: "<div class=\"modal-header\">\n\t<h1 mat-dialog-title>Add Entity to Chart</h1>\n  <span class=\"alert-close\" (click)=\"onNoClick()\">\u00D7</span>\n</div>\n<div mat-dialog-content>\n <div class=\"form-group\">\n\t<div \n  *ngFor=\"let fund of fundList\"\n\tclass=\"fund-list-item\"\n   >\n\t\t<div class=\"checkbox\">\n\t\t\t<label>\n\t\t\t\t <ng-container\n\t\t\t\t *ngIf=\"fund.checked\">\n\t\t\t\t\t <input type=\"checkbox\" (click)=\"handleSelectFund(fund)\" checked> {{fund.fundTicker ? fund.fundTicker : fund.fundID }}\n\t\t\t\t </ng-container>\n\t\t\t\t <ng-container\n\t\t\t\t *ngIf=\"!fund.checked\">\n\t\t\t\t\t <input type=\"checkbox\" (click)=\"handleSelectFund(fund)\"> {{fund.fundTicker ? fund.fundTicker : fund.fundID }}\n\t\t\t\t </ng-container>\n     \t\t</label>\n\t\t</div>\n\t</div>\n</div>\n</div>\n<div mat-dialog-actions align=\"end\">\n  <button mat-button (click)=\"onNoClick()\" cdkFocusInitial>Cancel</button>\n  <button mat-button (click)=\"handleClickSelectBtn()\" class=\"primary-btn\">Select</button>\n</div>",
                        styles: [".modal-header{position:relative}.mat-dialog-title{color:#464646;margin:-10px 0 20px}.alert-close{position:absolute;top:-6px;right:-6px;color:rgba(105,105,105,.78);cursor:pointer;font-size:40px}.mat-dialog-content{color:#464646;font-size:16px;border-bottom:2px solid rgba(0,0,0,.15)}.form-group{margin-bottom:1em}.fund-list-item{margin:0 0 15px}.primary-btn{background:#2f749a;color:#fff}"]
                    },] },
        ];
        AddFundModalComponent.ctorParameters = function () {
            return [
                { type: CommonUtilsService },
                { type: material.MatDialogRef },
                { type: undefined, decorators: [{ type: i0.Inject, args: [material.MAT_DIALOG_DATA,] }] }
            ];
        };
        return AddFundModalComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    // fund color map, need set color for each fund if add more funds
    /** @type {?} */
    var dataVisualFundColorMap = [
        {
            fundID: undefined,
            color: '#86BBD1',
        },
        {
            fundID: undefined,
            color: '#FC7C42'
        },
        {
            fundID: undefined,
            color: '#008198'
        },
        {
            fundID: undefined,
            color: '#CDDC39'
        }
    ];
    // for heatmap component color setting
    /** @type {?} */
    var heatMapColorSetting = [
        {
            value: -3,
            color: '#B91224',
        },
        {
            value: -2,
            color: '#EAB7BD',
        },
        {
            value: -1,
            color: '#F5DCDE',
        },
        {
            value: 1,
            color: '#DFEAE2',
        },
        {
            value: 2,
            color: '#BED5C5',
        },
        {
            value: 3,
            color: '#28743E',
        }
    ];
    /** @type {?} */
    var heatMapColorScheme = {
        domain: ['#B91224', '#EAB7BD', '#F5DCDE', '#DFEAE2', '#BED5C5', '#28743E']
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @type {?} */
    var defaultFundList = [
        {
            "name": "",
            "series": [
                {
                    "name": "09:30:00",
                    "value": 0.0,
                    "nav": "0.0",
                    "marketval": "0.0"
                }
            ]
        }
    ];
    /** @type {?} */
    var ticksValue = [
        new Date().setHours(9, 30, 0),
        new Date().setHours(10, 30, 0),
        new Date().setHours(11, 30, 0),
        new Date().setHours(12, 30, 0),
        new Date().setHours(13, 30, 0),
        new Date().setHours(14, 30, 0),
        new Date().setHours(15, 30, 0),
        new Date().setHours(16, 30, 0)
    ];

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var QnavLineChartComponent = (function (_super) {
        __extends(QnavLineChartComponent, _super);
        function QnavLineChartComponent(chartElement, zone, cd, navService, navSocketService, dialog$$1, viewContainer, shareInforBewteenComponents, commonUtils, resourceManger) {
            var _this = _super.call(this) || this;
            _this.navService = navService;
            _this.navSocketService = navSocketService;
            _this.dialog = dialog$$1;
            _this.viewContainer = viewContainer;
            _this.shareInforBewteenComponents = shareInforBewteenComponents;
            _this.commonUtils = commonUtils;
            _this.resourceManger = resourceManger;
            _this.removable = true;
            _this.selectable = false;
            _this.results = [];
            _this.permanentResults = [];
            _this.isDataAvailable = false;
            _this.height = 240;
            _this.margin = [20, 100, 30, 100];
            _this.colorDomain = [];
            _this.tickValues = ticksValue;
            _this.circleData = [];
            _this.permanentCircleData = [];
            _this.showYAxisLabel = true;
            _this.yAxisLabel = 'Nav % Change';
            _this.previousTime = new Date();
            _this.activeEntries = [];
            _this.highLightActiveEntries = [];
            _this.fundChange = new i0.EventEmitter();
            _this.removeIndexs = [];
            _this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width - 100;
            _this.xScaleMin = commonUtils.startTime;
            _this.xScaleMax = commonUtils.endTime;
            _this.currentLineTime = commonUtils.startTime;
            _this.resourceManger.registInterval(function () {
                if (new Date() < commonUtils.endTime) {
                    _this.displayLiveTime = new Date();
                }
                else {
                    _this.displayLiveTime = commonUtils.endTime;
                }
            }, 1000);
            return _this;
        }
        /**
         * @return {?}
         */
        QnavLineChartComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                //need to reset value here when switch back from other dashboard like position or when switch users
                this.commonUtils.validateUser();
                //initialize the  colorDomain with predefined colors.
                this.shareInforBewteenComponents.setColorSchema(dataVisualFundColorMap);
                this.isDataAvailable = false;
                this.subs = [];
                this.results = [];
                this.permanentResults = [];
                this.colorDomain = [];
                this.circleData = [];
                this.permanentCircleData = [];
                this.previousTimeMap = null;
                //reset done
                this.navService.fetchFundList();
                this.subs.push(this.navService.getFundList().subscribe(function (data) {
                    if (data.length > 0) {
                        /** @type {?} */
                        var fundLevelData = _this.commonUtils.extractFundLevelData(data);
                        _this.permanentResults = __spread(_this.convertToResults(fundLevelData));
                        _this.permanentCircleData = __spread(_this.updateCircleData(fundLevelData));
                        _this.colorDomain = __spread(_this.setFundColorMap(fundLevelData));
                        _this.shareInforBewteenComponents.setColorSchema(_this.colorDomain);
                        _this.isDataAvailable = true;
                        _this.previousTimeMap = new Map();
                        _this.permanentResults.forEach(function (f) {
                            /** @type {?} */
                            var series = f['series'];
                            _this.previousTimeMap.set(f['name'], series[series.length - 1]['pricetime']);
                            _this.currentLineTime = new Date(_this.previousTimeMap.get(f['name']));
                        });
                        _this.results = _this.filterResults(_this.permanentResults);
                        _this.circleData = _this.filterCircleDate(_this.permanentCircleData);
                    }
                }));
                this.subs.push(this.navSocketService.getNav().subscribe(function (data) {
                    if (data && data["eventData"]) {
                        /** @type {?} */
                        var fundLevelUpdateData = _this.commonUtils.extractWSData(data["eventData"], false);
                        _this.updateChart(fundLevelUpdateData);
                    }
                }));
                this.shareInforBewteenComponents.highLightActiveEntries.subscribe(function (data) {
                    /** @type {?} */
                    var filteredActiveData = [];
                    /** @type {?} */
                    var lists = _this.shareInforBewteenComponents.getFundList();
                    data.forEach(function (item) {
                        if (lists.find(function (list) { return (list.fundID === item.name && list.checked); })) {
                            filteredActiveData.push(item);
                        }
                    });
                    _this.highLightActiveEntries = filteredActiveData;
                    _this.activeEntries = filteredActiveData;
                });
                this.fundChange.subscribe(function (data) {
                    _this.shareInforBewteenComponents.highLightActiveEntries.emit(_this.highLightActiveEntries);
                    _this.results = [];
                    _this.circleData = [];
                    _this.shareInforBewteenComponents.getFundList().forEach(function (fund) {
                        _this.permanentResults.forEach(function (result) {
                            if (fund['fundID'] === result['name'] && fund['checked']) {
                                _this.results.push(result);
                            }
                        });
                        _this.permanentCircleData.forEach(function (circle) {
                            if (fund['fundID'] === circle['name'] && fund['checked']) {
                                _this.circleData.push(circle);
                            }
                        });
                    });
                });
            };
        /**
         * @param {?} permnantResult
         * @return {?}
         */
        QnavLineChartComponent.prototype.filterResults = /**
         * @param {?} permnantResult
         * @return {?}
         */
            function (permnantResult) {
                var _this = this;
                /** @type {?} */
                var filteredResults = [];
                permnantResult.forEach(function (result) {
                    _this.shareInforBewteenComponents.getFundList().forEach(function (item) {
                        if (result.name === item.fundID && item.checked) {
                            filteredResults.push(result);
                        }
                    });
                });
                return filteredResults;
            };
        /**
         * @param {?} permanentCircleData
         * @return {?}
         */
        QnavLineChartComponent.prototype.filterCircleDate = /**
         * @param {?} permanentCircleData
         * @return {?}
         */
            function (permanentCircleData) {
                var _this = this;
                /** @type {?} */
                var filteredCircleData = [];
                permanentCircleData.forEach(function (result) {
                    _this.shareInforBewteenComponents.getFundList().forEach(function (item) {
                        if (result.name === item.fundID && item.checked) {
                            filteredCircleData.push(result);
                        }
                    });
                });
                return filteredCircleData;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.setFundColorMap = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                /** @type {?} */
                var temp = [];
                /** @type {?} */
                var lists = this.shareInforBewteenComponents.getFundList();
                data.forEach(function (item) {
                    /** @type {?} */
                    var setColor = false;
                    lists.forEach(function (list) {
                        if (item.fundid === list.fundID && list.checked)
                            setColor = true;
                    });
                    if (setColor) {
                        /** @type {?} */
                        var obj = {
                            fundid: item.fundid,
                            color: _this.commonUtils.getColorForFund(item.fundid)
                        };
                        temp.push(obj);
                    }
                    else {
                        /** @type {?} */
                        var obj = {
                            fundid: undefined,
                            color: _this.commonUtils.getColorForFund(item.fundid)
                        };
                        temp.push(obj);
                    }
                });
                return temp;
            };
        //need to unsubscribe to avoid potential memory leak.
        //need to unsubscribe to avoid potential memory leak.
        /**
         * @return {?}
         */
        QnavLineChartComponent.prototype.ngOnDestroy =
            //need to unsubscribe to avoid potential memory leak.
            /**
             * @return {?}
             */
            function () {
                this.subs.forEach(function (sub) { return sub.unsubscribe(); });
                this.colorDomain = [];
                this.resourceManger.cleanResources();
            };
        /**
         * @param {?} event
         * @return {?}
         */
        QnavLineChartComponent.prototype.resizingChart = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                this.width = event.target.innerWidth - 100;
            };
        /**
         * @param {?} results
         * @return {?}
         */
        QnavLineChartComponent.prototype.getResults = /**
         * @param {?} results
         * @return {?}
         */
            function (results) {
                if (results.length === 0) {
                    return defaultFundList;
                }
                else {
                    return results;
                }
            };
        /**
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.updateChart = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                if (data) {
                    /** @type {?} */
                    var fundid_1 = data['fundid'];
                    /** @type {?} */
                    var time_1;
                    /** @type {?} */
                    var currentTime_1;
                    if (data['pricetime']) {
                        currentTime_1 = new Date(data['pricetime']);
                        if (this.commonUtils.isValidTime(currentTime_1)) {
                            time_1 = currentTime_1;
                        }
                    }
                    if (currentTime_1 > this.commonUtils.endTime) {
                        this.currentLineTime = this.commonUtils.endTime;
                    }
                    //for adding alert data if any.
                    if (this.commonUtils.isValidTime(new Date(data['pricetime'])) && data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
                        /** @type {?} */
                        var alertObj = {
                            "name": fundid_1,
                            "x": new Date(data['pricetime']),
                            "alertType": data['alertType'],
                            "value": data['navChangePercent'],
                            "fundmvChangePercent": data['fundmvChangePercent'],
                            "nav": data['nav'],
                            "marketval": data['fundmv'],
                            "pricetime": data['pricetime']
                        };
                        this.permanentCircleData.push(alertObj);
                        //this.permanentCircleData = [...this.permanentCircleData];
                        this.circleData = __spread(this.filterCircleDate(this.permanentCircleData));
                    }
                    this.permanentResults.forEach(function (item) {
                        if (item['name'] === fundid_1) {
                            //only shows data between 9:30AM to 4:30PM
                            if (time_1) {
                                if (currentTime_1.getTime() - new Date(_this.previousTimeMap.get(fundid_1)).getTime() >= 20000) {
                                    _this.currentLineTime = new Date(data['pricetime']);
                                    /** @type {?} */
                                    var obj = {
                                        'marketval': data['fundmv'],
                                        // fund market value
                                        'name': _this.nextTimeForFund(_this.previousTimeMap, fundid_1, data['pricetime']),
                                        'nav': data['nav'],
                                        'value': data['navChangePercent'],
                                        'pricetime': data['pricetime']
                                    };
                                    item['series'].push(obj);
                                }
                                else if (currentTime_1.getTime() - _this.previousTime.getTime() >= 2000) {
                                    _this.previousTime = currentTime_1;
                                    //this.currentLineTime = new Date(this.previousTimeMap.get(fundTicker)); //this will cause component re-render whenever this is ws data coming
                                    /** @type {?} */
                                    var obj = {
                                        'marketval': data['fundmv'],
                                        'name': new Date(_this.previousTimeMap.get(fundid_1)),
                                        'nav': data['nav'],
                                        'value': data['navChangePercent'],
                                        'pricetime': data['pricetime']
                                    };
                                    //this will increase cpu usage as well, need to find better way to update results
                                    item['series'].pop();
                                    item['series'].push(obj);
                                }
                            }
                        }
                    });
                }
            };
        // the get fund list service will return the history chart data, using below functions to covert the data to expected result set
        // the get fund list service will return the history chart data, using below functions to covert the data to expected result set
        /**
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.convertToResults =
            // the get fund list service will return the history chart data, using below functions to covert the data to expected result set
            /**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                var _this = this;
                /** @type {?} */
                var results = [];
                /** @type {?} */
                var variableFundList = this.shareInforBewteenComponents.getFundList();
                data.forEach(function (item) {
                    // for persistent user selected funds in legend.
                    if (variableFundList.findIndex(function (list) { return list.fundID === item.fundid; }) === -1) {
                        variableFundList.push({
                            'fundID': item['fundid'],
                            'fundTicker': item['fundTicker'],
                            'checked': true
                        });
                    }
                    /** @type {?} */
                    var obj = {
                        'name': item['fundid'],
                        'fundID': item['fundid'],
                        'fundTicker': item['fundTicker'],
                        'series': _this.createSeries(item)
                    };
                    results.push(obj);
                });
                this.shareInforBewteenComponents.setVariableFundList(variableFundList);
                return results;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.createSeries = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                /** @type {?} */
                var series = [];
                data['priceChanges'].forEach(function (item) {
                    if (_this.commonUtils.isValidTime(new Date(item['pricetime']))) {
                        /** @type {?} */
                        var obj = {
                            'marketval': item['fundmv'],
                            //fund market value from history data
                            'name': new Date(item['pricetime']),
                            'nav': item['nav'],
                            'value': item['navChangePercent'],
                            'pricetime': item['pricetime']
                        };
                        series.push(obj);
                    }
                });
                if (series.length == 0) {
                    /** @type {?} */
                    var obj = {
                        'marketval': data['fundmv'],
                        //fund market value from history data
                        'name': this.xScaleMin,
                        'nav': data['nav'],
                        'value': 0,
                        'pricetime': this.commonUtils.startTime
                    };
                    series.push(obj);
                }
                return series;
            };
        // for collecting historic alert data
        // for collecting historic alert data
        /**
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.updateCircleData =
            // for collecting historic alert data
            /**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                var _this = this;
                /** @type {?} */
                var CricleData = [];
                data.forEach(function (item) {
                    CricleData = CricleData.concat(_this.filterAlertData(item['fundid'], item['priceChanges']));
                });
                return CricleData;
            };
        /**
         * @param {?} fundid
         * @param {?} data
         * @return {?}
         */
        QnavLineChartComponent.prototype.filterAlertData = /**
         * @param {?} fundid
         * @param {?} data
         * @return {?}
         */
            function (fundid, data) {
                var _this = this;
                /** @type {?} */
                var tempAlertCricleData = [];
                data.forEach(function (item) {
                    if (_this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                        /** @type {?} */
                        var alertObj = {
                            "name": fundid,
                            "x": new Date(item['pricetime']),
                            "alertType": item['alertType'],
                            "value": item['navChangePercent'],
                            "nav": item['nav'],
                            "fundmvChangePercent": item['fundmvChangePercent'],
                            "marketval": item['fundmv'],
                            "pricetime": item['pricetime'],
                        };
                        tempAlertCricleData.push(alertObj);
                    }
                });
                return tempAlertCricleData;
            };
        // this method will return the next time and set the new time to the previous time map for the given fund
        // this method will return the next time and set the new time to the previous time map for the given fund
        /**
         * @param {?} previousTimeMap
         * @param {?} fundid
         * @param {?} time
         * @return {?}
         */
        QnavLineChartComponent.prototype.nextTimeForFund =
            // this method will return the next time and set the new time to the previous time map for the given fund
            /**
             * @param {?} previousTimeMap
             * @param {?} fundid
             * @param {?} time
             * @return {?}
             */
            function (previousTimeMap, fundid, time) {
                previousTimeMap.set(fundid, time); // set back to the map
                return new Date(time);
            };
        /**
         * @param {?} event
         * @return {?}
         */
        QnavLineChartComponent.prototype.openAddFundModal = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                /** @type {?} */
                var dialogRef = this.dialog.open(AddFundModalComponent, {
                    width: '300px',
                    data: {
                        'fundList': this.shareInforBewteenComponents.getFundList(),
                        'dataChange': this.fundChange //create eventemitter ourself as closeDialogSubject is not working
                    },
                });
                dialogRef.afterClosed().subscribe(function (result) {
                    console.log('The dialog was closed');
                });
            };
        /**
         * @param {?} v
         * @return {?}
         */
        QnavLineChartComponent.prototype.xAxisTickFormatting = /**
         * @param {?} v
         * @return {?}
         */
            function (v) {
                /** @type {?} */
                var tempDate = new Date(v);
                return common.formatDate(tempDate, "h:mm aaaaa'm'", 'en-US');
            };
        QnavLineChartComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-qnav-line-chart',
                        template: "<div  class=\"qnav-container\" *ngIf=\"isDataAvailable\" (window:resize)=\"resizingChart($event)\">\n    <div class=\"live-time-for-title\">\n        <p *ngIf=\"commonUtils.isAfterMarketClose else elseBlock\">Change in NAV per share for {{commonUtils.liveTime | date:'EEEE'}}, {{commonUtils.liveTime | date:'MM/dd/yyyy'}}, as of Market Close: {{commonUtils.liveTime | date:\"h:mm aaaaa'm'\"}}</p>\n        <ng-template #elseBlock><p>Change in NAV per share for {{commonUtils.liveTime | date:'EEEE'}}, {{commonUtils.liveTime | date:'MM/dd/yyyy'}}, Real Time: {{commonUtils.liveTime | date:\"h:mm aaaaa'm'\"}}</p></ng-template>\n    </div>\n    <div class=\"custom-legend\">\n    <app-custom-legend\n      [results]=\"results\"\n      [selectable]=\"selectable\"\n      [removable]=\"removable\"\n      [colorDomain]='colorDomain'\n      [selectedFundChange]=\"fundChange\"\n    >\n    </app-custom-legend>\n    <div class=\"addChunk\">\n      <mat-icon class=\"addFundIcon\" svgIcon=\"circle_plus\"  (click)=\"openAddFundModal($event)\"></mat-icon>\n      <span class=\"addContent\">Add Entity</span>\n    </div>\n  </div>\n  <lib-fine-line-chart\n  [results]='results'\n  [height]='height'\n  [width]='width'\n  [margin]='margin'\n  [colorDomain]='colorDomain'\n  [circleData]='circleData'\n  [currentLineTime]='currentLineTime'\n  [displayLiveTime]='displayLiveTime'\n  [tickValues]='tickValues'\n  [xAxisTickFormatting]='xAxisTickFormatting'\n  [xScaleMin]='xScaleMin'\n  [xScaleMax]='xScaleMax'\n  [showYAxisLabel]='showYAxisLabel'\n  [yAxisLabel]='yAxisLabel'\n  [activeEntries]='activeEntries'\n  [highLightActiveEntries]='highLightActiveEntries'\n  >\n  </lib-fine-line-chart>\n</div>\n",
                        styles: [".ngx-chart.material{display:unset}.qnav-container{width:100%;height:100%}.custom-legend{display:inline-flex;width:98%;align-items:center;margin-top:5px;padding:0 12px;min-height:40px}.addChunk{position:relative;display:inline-block;min-height:30px;min-width:150px}.addChunk .addFundIcon{position:absolute;top:6px;margin-right:5px;width:15px!important;height:15px!important;margin-left:20px;cursor:pointer;min-height:15px!important;min-width:15px!important}.addChunk .addContent{position:absolute;top:6px;left:40px}.live-time-for-title{position:absolute;top:0;left:15px;font-size:16px;font-family:DINNextLTPro-Medium;color:#464646}"]
                    },] },
        ];
        QnavLineChartComponent.ctorParameters = function () {
            return [
                { type: i0.ElementRef },
                { type: i0.NgZone },
                { type: i0.ChangeDetectorRef },
                { type: NavService },
                { type: NavSocketService },
                { type: material.MatDialog },
                { type: i0.ViewContainerRef },
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService },
                { type: ResourceManagerService }
            ];
        };
        return QnavLineChartComponent;
    }(uiCommon.BaseWidgetComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var PercentFormatPipe = (function () {
        function PercentFormatPipe() {
        }
        /**
         * @param {?} value
         * @return {?}
         */
        PercentFormatPipe.prototype.transform = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                if (value != 0) {
                    if (value.toString().indexOf('-') === 0) {
                        return value;
                    }
                    else {
                        return '+' + value;
                    }
                }
                else {
                    return "0.000%";
                }
            };
        PercentFormatPipe.decorators = [
            { type: i0.Pipe, args: [{
                        name: 'percentFormat'
                    },] },
        ];
        return PercentFormatPipe;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var NumberRoundUpPipe = (function () {
        function NumberRoundUpPipe() {
        }
        /**
         * @param {?} value
         * @param {?} maxFractionDigits
         * @return {?}
         */
        NumberRoundUpPipe.prototype.transform = /**
         * @param {?} value
         * @param {?} maxFractionDigits
         * @return {?}
         */
            function (value, maxFractionDigits) {
                return Math.round(Math.pow(10, maxFractionDigits) * value) / Math.pow(10, maxFractionDigits);
            };
        NumberRoundUpPipe.decorators = [
            { type: i0.Pipe, args: [{
                        name: 'numberRoundUp'
                    },] },
        ];
        return NumberRoundUpPipe;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CustomAlertModalComponent = (function () {
        function CustomAlertModalComponent(commonUtils, dialogRef, data) {
            this.commonUtils = commonUtils;
            this.dialogRef = dialogRef;
            this.data = data;
            this.alertData = [];
            this.alertData = data['alertData'];
        }
        /**
         * @return {?}
         */
        CustomAlertModalComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @return {?}
         */
        CustomAlertModalComponent.prototype.onNoClick = /**
         * @return {?}
         */
            function () {
                this.dialogRef.close();
            };
        CustomAlertModalComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-custom-alert-modal',
                        template: "<div class=\"modal-header\">\n  <h1 mat-dialog-title>{{data.title}} {{data.type}} Alerts for {{data.now | date: \"EEEE, M/d, h:mm aaaaa'm'\"}}</h1>\n  <span class=\"alert-close\" (click)=\"onNoClick()\" >\u00D7</span>\n</div>\n<div mat-dialog-content>\n  <div class=\"container custom-alert-sty\" *ngFor=\"let data of alertData\">\n    <div class=\"alert-details-item-container\">\n      <div class=\"top-line\">\n        <div class=\"top-line-item\">\n        {{data.pricetime | date: \"h:mm:ss aaaaa'm'\"}}\n        </div>\n        <div class=\"top-line-item\">\n          NAV Diverging from Market Value\n        </div>\n      </div>\n      <div class=\"button-line\">\n        <div>\n           <div class=\"button-line-item\">\n             NAV % Change:\n          </div>\n          <div class=\"button-line-item\">\n            {{data.value | percent: '1.2-2'}}\n          </div>\n        </div>\n        <div>\n         <div class=\"button-line-item\">\n             MV % Change:\n          </div>\n          <div class=\"button-line-item\">\n            {{data.fundmvChangePercent | percent: '1.2-2'}}\n          </div>\n        </div>\n     </div>\n    </div>\n    </div>\n</div>\n<div mat-dialog-actions align=\"end\">\n  <!-- <button mat-button (click)=\"onNoClick()\" cdkFocusInitial>Cancel</button> -->\n  <button mat-button (click)=\"onNoClick()\" class=\"primary-btn\">OK</button>\n</div>",
                        styles: [".modal-header{position:relative}.mat-dialog-title{color:#464646;margin:-10px 0 20px}.alert-close{position:absolute;top:-6px;right:-6px;color:rgba(105,105,105,.78);cursor:pointer;font-size:40px}.mat-dialog-content{border-bottom:2px solid rgba(0,0,0,.15);height:250px;overflow:auto}.custom-alert-sty{color:#464646;font-size:16px;padding-left:0!important;margin-bottom:20px}.alert-details-item-container{padding:0 0 10px}.top-line{display:inline-flex}.top-line-item{margin-right:15px}.button-line{margin-top:5px;margin-left:90px}.button-line-item{display:inline-flex;width:150px}.primary-btn{background:#2f749a;color:#fff}"]
                    },] },
        ];
        CustomAlertModalComponent.ctorParameters = function () {
            return [
                { type: CommonUtilsService },
                { type: material.MatDialogRef },
                { type: undefined, decorators: [{ type: i0.Inject, args: [material.MAT_DIALOG_DATA,] }] }
            ];
        };
        return CustomAlertModalComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var PositionHeatMapComponent = (function (_super) {
        __extends(PositionHeatMapComponent, _super);
        function PositionHeatMapComponent(chartElement, zone, cd, navSocketService, shareInfoBeweenComponentsService, commonUtils, navService, resourceManger) {
            var _this = _super.call(this) || this;
            _this.navSocketService = navSocketService;
            _this.shareInfoBeweenComponentsService = shareInfoBeweenComponentsService;
            _this.commonUtils = commonUtils;
            _this.navService = navService;
            _this.resourceManger = resourceManger;
            _this.syncResults = []; // it's results,  change name to syncResults
            _this.topFiveResults = [];
            _this.height = 260;
            _this.margin = [20, 10, 10, 10];
            _this.isDataAvailable = false;
            _this.heatMapColorSetting = heatMapColorSetting;
            _this.dateNow = new Date();
            _this.colorScheme = heatMapColorScheme;
            _this.fundInfo = [];
            _this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.7;
            return _this;
        }
        /**
         * @return {?}
         */
        PositionHeatMapComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.syncResults = [];
                this.topFiveResults = [];
                this.subs = [];
                this.isDataAvailable = false;
                this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
                if (this.fundInfo.length > 0) {
                    this.renderPositionMap();
                }
                else {
                    this.navService.fetchFundList();
                    this.navService.getFundList().subscribe(function (data) {
                        console.log("data");
                        if (data.length > 0) {
                            console.log(data);
                            /** @type {?} */
                            var fundInfo = [];
                            fundInfo.push(data[0].fundid);
                            fundInfo.push(data[0].name);
                            fundInfo.push(data[0].fundTicker);
                            _this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
                            _this.renderPositionMap();
                        }
                    });
                }
            };
        /**
         * @return {?}
         */
        PositionHeatMapComponent.prototype.renderPositionMap = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
                if (this.fundInfo.length > 0) {
                    this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(function (data) {
                        _this.isDataAvailable = true;
                        _this.syncResults = _this.filterHoldingsToHeatMap(data['holdings']);
                        _this.topFiveResults = _this.filterHoldingsToTopFive(data['holdings']);
                    }));
                    this.subs.push(this.navSocketService.getNav().subscribe(function (data) {
                        _this.updateHeatMap(data.eventData);
                    }));
                    this.navSocketService.registerFunds([this.fundInfo[0]]);
                    this.resourceManger.registInterval(function () { _this.syncResults = __spread(_this.syncResults); }, 400); // set interval time for 0.4 seconds temporarily
                }
            };
        /**
         * @param {?} data
         * @return {?}
         */
        PositionHeatMapComponent.prototype.filterHoldingsToHeatMap = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var tempResults = [];
                data.forEach(function (item) {
                    /** @type {?} */
                    var obj = {
                        "name": item.cusip,
                        "value": Math.abs(item.navImpact),
                        "navImpact": item.navImpact
                    };
                    tempResults.push(obj);
                });
                return tempResults;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        PositionHeatMapComponent.prototype.filterHoldingsToTopFive = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var tempTopFive = [];
                data.sort(function (itema, itemb) {
                    return itemb.navImpact - itema.navImpact;
                    // return Math.abs(itemb.navImpact)  - Math.abs(itema.navImpact); TBC...  if we sort it using real value not absolute value, will make confusion between top five records and heat map chart.
                });
                data.forEach(function (item) {
                    if (tempTopFive.length < 5) {
                        /** @type {?} */
                        var obj = {
                            "name": item.cusip ? item.cusip : item.name,
                            "value": common.formatNumber(item.navImpact, 'en-US', '1.5-5')
                        };
                        tempTopFive.push(obj);
                    }
                });
                return tempTopFive;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        PositionHeatMapComponent.prototype.updateHeatMap = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                if (data && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
                    this.syncResults.forEach(function (item) {
                        if (item.name === data.cusip) {
                            item.value = Math.abs(data.navImpact);
                            item.navImpact = data.navImpact;
                        }
                    });
                }
            };
        /**
         * @param {?} event
         * @return {?}
         */
        PositionHeatMapComponent.prototype.resizingHeatMap = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                this.width = event.target.innerWidth * 0.7;
            };
        // needs more analyze here
        // needs more analyze here
        /**
         * @param {?} value
         * @return {?}
         */
        PositionHeatMapComponent.prototype.heatMapValueFormatting =
            // needs more analyze here
            /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                // const formatValue =  formatNumber(value, 'en-US', '1.5-5');
                // return formatValue;
                return;
            };
        /**
         * @param {?} obj
         * @return {?}
         */
        PositionHeatMapComponent.prototype.heatMapLabelFormatting = /**
         * @param {?} obj
         * @return {?}
         */
            function (obj) {
                /** @type {?} */
                var formatValue = common.formatNumber(obj.value, 'en-US', '1.5-5');
                return obj.label + "<br/><small>" + (formatValue + "</small>");
                // return `${obj.label}<br/><small>Instrument Id Ref</small>`;
            };
        /**
         * @return {?}
         */
        PositionHeatMapComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                if (this.fundInfo.length > 0) {
                    this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
                    this.subs.forEach(function (sub) { return sub.unsubscribe(); });
                }
                this.resourceManger.cleanResources();
            };
        PositionHeatMapComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-position-heat-map',
                        template: "<div class=\"position-heat-map-container\" *ngIf=\"isDataAvailable\" (window:resize)=\"resizingHeatMap($event)\">\n\n  <div class=\"heat-map-title\">\n    <p>Postion | NAV Impact T + 1</p>\n  </div> <!-- title-->\n\n  <div class=\"left-side-panel\">\n    <p class=\"panel-title\">T + 1 View</p>\n    <div  class=\"date-details\">\n      <p class=\"day\">{{dateNow | date : 'dd'}}</p>\n      <div class=\"date-items\">\n        <p>{{dateNow | date : 'EEEE'}}</p>\n        <p>{{dateNow | date : 'LLLL'}}</p>\n        <p>{{dateNow | date : 'yyyy'}}</p>\n      </div>\n   </div>\n   <ul>\n     <li\n     *ngFor=\"let item of topFiveResults; let i = index;\"\n     >\n     <p class=\"left-name\">{{item.name}}</p>\n     <p class=\"right-value\">{{item.value}}</p>\n     </li>\n   </ul>\n   <div class=\"btn-wrapper\">\n     <a class=\"view-all-btn\">View All Positions</a>\n   </div>\n  </div> <!-- left side panel-->\n\n  <div class=\"heat-map-container\">\n    <position-heat-map-chart\n    [syncResults]=\"syncResults\"\n    [height]='height'\n    [width]='width'\n    [margin]='margin'\n    [tooltipDisabled]=\"false\"\n    [scheme]=\"colorScheme\"\n    [valueFormatting]=\"heatMapValueFormatting\"\n    [labelFormatting]=\"heatMapLabelFormatting\"\n    >\n    </position-heat-map-chart>\n\n    <div class=\"bottom\">\n    <p>Size represents market cap</p>\n    <ul>\n      <li\n      *ngFor=\"let item of heatMapColorSetting; let i=index;\"\n      [style.background]=\"item.color\"\n      >{{item.value}}%</li>\n    </ul>\n  </div>\n  </div> <!-- heat map -->\n\n</div>\n",
                        styles: [".position-heat-map-container{height:100%;color:#464646!important}.position-heat-map-container .heat-map-title{position:absolute;top:0;left:15px;font-size:16px}.position-heat-map-container .left-side-panel{display:inline-block;border-right:1px solid #eee;text-align:center;padding:0 20px;width:15%}.position-heat-map-container .left-side-panel .panel-title{margin:10px 0 0;font-size:15px;opacity:.6;text-align:left}.position-heat-map-container .left-side-panel .date-details .day{display:inline-block;font-size:60px;padding:0;margin:0 20px 0 0}.position-heat-map-container .left-side-panel .date-details .date-items{display:inline-block}.position-heat-map-container .left-side-panel .date-details .date-items p{margin:0;padding:0 0 2px;font-size:14px;text-align:left}.position-heat-map-container .left-side-panel ul{list-style-type:none;padding:0}.position-heat-map-container .left-side-panel ul li{margin:12px 0;display:block}.position-heat-map-container .left-side-panel ul li p{display:inline-block;margin:0;width:45%}.position-heat-map-container .left-side-panel ul li .left-name{font-size:16px;text-align:left}.position-heat-map-container .left-side-panel ul li .right-value{font-size:12px;opacity:.9;text-align:right}.position-heat-map-container .left-side-panel .btn-wrapper{padding:10px 0 0}.position-heat-map-container .left-side-panel .btn-wrapper .view-all-btn{border:1px solid rgba(0,0,0,.3);cursor:pointer;border-radius:3px;padding:3px 5px}.position-heat-map-container .heat-map-container{width:70%;display:inline-block;margin-left:25px}.position-heat-map-container .heat-map-container .bottom{text-align:right;font-size:14px}.position-heat-map-container .heat-map-container .bottom p{display:inline-flex;font-style:italic}.position-heat-map-container .heat-map-container .bottom ul{display:inline-flex}.position-heat-map-container .heat-map-container .bottom li{display:inline-flex;padding:0 10px}"]
                    },] },
        ];
        PositionHeatMapComponent.ctorParameters = function () {
            return [
                { type: i0.ElementRef },
                { type: i0.NgZone },
                { type: i0.ChangeDetectorRef },
                { type: NavSocketService },
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService },
                { type: NavService },
                { type: ResourceManagerService }
            ];
        };
        return PositionHeatMapComponent;
    }(uiCommon.BaseWidgetComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var HeatMapComponent = (function (_super) {
        __extends(HeatMapComponent, _super);
        function HeatMapComponent() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.tooltipDisabled = false;
            _this.gradient = false;
            _this.scheme = {};
            _this.animations = true;
            _this.select = new i0.EventEmitter();
            return _this;
        }
        /**
         * @return {?}
         */
        HeatMapComponent.prototype.update = /**
         * @return {?}
         */
            function () {
                _super.prototype.update.call(this);
                this.dims = ngxCharts.calculateViewDimensions({
                    width: this.width,
                    height: 260,
                    margins: this.margin
                });
                this.height = 260;
                this.domain = this.getDomain();
                this.treemap = d3Hierarchy.treemap()
                    .size([this.dims.width, this.dims.height]);
                /** @type {?} */
                var rootNode = {
                    name: 'root',
                    value: 0,
                    isRoot: true
                };
                /** @type {?} */
                var root = d3Hierarchy.stratify()
                    .id(function (d) {
                    /** @type {?} */
                    var label = d.name;
                    if (label.constructor.name === 'Date') {
                        label = label.toLocaleDateString();
                    }
                    else {
                        label = label.toLocaleString();
                    }
                    return label;
                })
                    .parentId(function (d) { return d.isRoot ? null : 'root'; })(__spread([rootNode], this.syncResults))
                    .sum(function (d) { return d.value; });
                this.data = this.treemap(root);
                this.customColors = this.setCustomColors();
                this.setColors();
                this.transform = "translate(" + this.dims.xOffset + " , " + this.margin[0] + ")";
            };
        /**
         * @return {?}
         */
        HeatMapComponent.prototype.setCustomColors = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var arr = [];
                this.syncResults.forEach(function (item) {
                    /** @type {?} */
                    var color = '';
                    if (item.navImpact <= -3) {
                        color = '#B91224';
                    }
                    else if (item.navImpact > -3 && item.navImpact <= -2) {
                        color = '#EAB7BD';
                    }
                    else if (item.navImpact > -2 && item.navImpact <= 0) {
                        color = '#F5DCDE';
                    }
                    else if (item.navImpact >= 0 && item.navImpact < 2) {
                        color = '#DFEAE2';
                    }
                    else if (item.navImpact >= 2 && item.navImpact < 3) {
                        color = '#BED5C5';
                    }
                    else if (item.navImpact >= 3) {
                        color = '#28743E';
                    }
                    else {
                        color = '';
                    }
                    /** @type {?} */
                    var obj = {
                        name: item.name,
                        value: color
                    };
                    arr.push(obj);
                });
                return arr;
            };
        /**
         * @return {?}
         */
        HeatMapComponent.prototype.getDomain = /**
         * @return {?}
         */
            function () {
                return this.syncResults.map(function (d) { return d.name; });
            };
        /**
         * @param {?} data
         * @return {?}
         */
        HeatMapComponent.prototype.onClick = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                this.select.emit(data);
            };
        /**
         * @return {?}
         */
        HeatMapComponent.prototype.setColors = /**
         * @return {?}
         */
            function () {
                this.colors = new ngxCharts.ColorHelper(this.scheme, 'ordinal', this.domain, this.customColors);
            };
        HeatMapComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'position-heat-map-chart',
                        template: "<ngx-charts-chart\n      [view]=\"[width, height]\"\n      [showLegend]=\"false\"\n      [animations]=\"animations\">\n      <svg:g [attr.transform]=\"transform\" class=\"tree-map chart\">\n        <svg:g ngx-charts-tree-map-cell-series\n          [colors]=\"colors\"\n          [data]=\"data\"\n          [dims]=\"dims\"\n          [tooltipDisabled]=\"tooltipDisabled\"\n          [tooltipTemplate]=\"tooltipTemplate\"\n          [valueFormatting]=\"valueFormatting\"\n          [labelFormatting]=\"labelFormatting\"\n          [gradient]=\"gradient\"\n          [animations]=\"animations\"\n          (select)=\"onClick($event)\"\n        />\n      </svg:g>\n    </ngx-charts-chart>",
                        styles: [".tree-map .treemap-val{font-size:1.3em;padding-top:5px;display:inline-block}.tree-map .label p{display:table-cell;text-align:center;line-height:1.2em;vertical-align:middle}"],
                        encapsulation: i0.ViewEncapsulation.None,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush
                    },] },
        ];
        HeatMapComponent.propDecorators = {
            syncResults: [{ type: i0.Input }],
            tooltipDisabled: [{ type: i0.Input }],
            valueFormatting: [{ type: i0.Input }],
            labelFormatting: [{ type: i0.Input }],
            gradient: [{ type: i0.Input }],
            height: [{ type: i0.Input }],
            width: [{ type: i0.Input }],
            scheme: [{ type: i0.Input }],
            margin: [{ type: i0.Input }],
            animations: [{ type: i0.Input }],
            select: [{ type: i0.Output }],
            tooltipTemplate: [{ type: i0.ContentChild, args: ['tooltipTemplate',] }]
        };
        return HeatMapComponent;
    }(ngxCharts.BaseChartComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @type {?} */
    var singleLineTicksValue = [
        new Date().setHours(9, 30, 0),
        new Date().setHours(12, 0, 0),
        new Date().setHours(14, 0, 0),
        new Date().setHours(16, 0, 0)
    ];

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var PositionFundSummaryComponent = (function (_super) {
        __extends(PositionFundSummaryComponent, _super);
        function PositionFundSummaryComponent(chartElement, zone, cd, commonUtils, navService, shareInforBewteenComponents) {
            var _this = _super.call(this) || this;
            _this.commonUtils = commonUtils;
            _this.navService = navService;
            _this.shareInforBewteenComponents = shareInforBewteenComponents;
            _this.dateNow = new Date();
            // temp mock data
            _this.summaryAssetsValue = [
                {
                    title: 'Total Net Assets: USD',
                    value: 5000000
                },
                {
                    title: 'Market Value: USD',
                    value: 4400000
                }
            ];
            _this.threeDayTrendData = [
                {
                    day: new Date(),
                    details: [
                        {
                            title: 'NAV Price',
                            value: 9.91
                        },
                        {
                            title: 'Market Value',
                            value: '4.3M'
                        },
                        {
                            title: 'NAV Change',
                            value: '-2.05%'
                        }
                    ],
                    color: ''
                },
                {
                    day: new Date(),
                    details: [
                        {
                            title: 'NAV Price',
                            value: 10.11
                        },
                        {
                            title: 'Market Value',
                            value: '4.25M'
                        },
                        {
                            title: 'NAV Change',
                            value: '-1.19%'
                        }
                    ],
                    color: '#DFEAE2'
                },
                {
                    day: new Date(),
                    details: [
                        {
                            title: 'NAV Price',
                            value: 10.23
                        },
                        {
                            title: 'Market Value',
                            value: '4.05M'
                        },
                        {
                            title: 'NAV Change',
                            value: '1.81%'
                        }
                    ],
                    color: '#BED5C5'
                }
            ];
            _this.results = [];
            _this.height = 240;
            _this.margin = [20, 100, 30, 50];
            _this.colorDomain = [];
            _this.tickValues = singleLineTicksValue;
            _this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.55;
            _this.xScaleMin = commonUtils.startTime;
            _this.xScaleMax = commonUtils.endTime;
            return _this;
        }
        /**
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.navService.getFundList().subscribe(function (data) {
                    if (data.length > 0) {
                        _this.results = __spread(_this.filterFundData(data));
                    }
                });
                this.colorDomain = this.setColorForSelectedFund();
            };
        /**
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.setColorForSelectedFund = /**
         * @return {?}
         */
            function () {
                // need enhancemen here: if the line color should be as same as previous live-line-chart? Temporarily set the color #28743E.
                /** @type {?} */
                var color = [];
                /** @type {?} */
                var selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
                /** @type {?} */
                var obj = {
                    fundTicker: selectedFundTicker,
                    color: "#28743E"
                };
                color.push(obj);
                return color;
            };
        // below function is duplicated with qnav-line-chart needs extract to a common class.
        // below function is duplicated with qnav-line-chart needs extract to a common class.
        /**
         * @param {?} data
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.filterFundData =
            // below function is duplicated with qnav-line-chart needs extract to a common class.
            /**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                var _this = this;
                /** @type {?} */
                var results = [];
                /** @type {?} */
                var selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
                data.forEach(function (item) {
                    if (item['fundTicker'] === selectedFundTicker) {
                        /** @type {?} */
                        var obj = {
                            'name': item['fundTicker'],
                            'fundID': item['fundid'],
                            'series': _this.createSeries(item)
                        };
                        results.push(obj);
                    }
                });
                return results;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.createSeries = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                /** @type {?} */
                var series = [];
                data['priceChanges'].forEach(function (item) {
                    if (_this.commonUtils.isValidTime(new Date(item['pricetime']))) {
                        /** @type {?} */
                        var obj = {
                            'marketval': item['fundmv'],
                            'name': new Date(item['pricetime']),
                            'nav': item['nav'],
                            'value': item['navChangePercent'],
                            'pricetime': item['pricetime']
                        };
                        series.push(obj);
                    }
                });
                if (series.length == 0) {
                    /** @type {?} */
                    var obj = {
                        'marketval': data['fundmv'],
                        'name': this.xScaleMin,
                        'nav': data['nav'],
                        'value': 0,
                        'pricetime': this.commonUtils.startTime
                    };
                    series.push(obj);
                }
                return series;
            };
        /**
         * @param {?} v
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.xAxisTickFormatting = /**
         * @param {?} v
         * @return {?}
         */
            function (v) {
                /** @type {?} */
                var tempDate = new Date(v);
                return common.formatDate(tempDate, "h:mm aaaaa'm'", 'en-US');
            };
        /**
         * @param {?} value
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.getValueSty = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                /** @type {?} */
                var color = '';
                if (value.toString().indexOf('%') !== -1) {
                    if (value.toString().indexOf('-')) {
                        color = '#28743E';
                    }
                    else {
                        color = '#B91224';
                    }
                }
                return color;
            };
        /**
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                this.colorDomain = [];
            };
        /**
         * @param {?} event
         * @return {?}
         */
        PositionFundSummaryComponent.prototype.resizingSingleLineChart = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                this.width = event.target.innerWidth * 0.55;
            };
        PositionFundSummaryComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-position-fund-summary',
                        template: "<div class=\"position-fund-summary-container\" (window:resize)=\"resizingSingleLineChart($event)\">\n\n  <div class=\"fund-summary-title\">\n    <p>Fund Summary | {{dateNow | date : 'longDate'}}</p>\n  </div> <!-- title-->\n\n  <div class=\"main-body-wrapper\">\n\n    <div class=\"top-search\">\n      <input type=\"text\" placeholder=\"Search Mutual Fund Name\"/>\n      <mat-icon svgIcon=\"search\" ></mat-icon>\n    </div> <!--If need use angular search component ?-->\n\n    <div class=\"left-side-panel-wrapper\">\n      <div class=\"left-side-panel\"\n      *ngFor=\"let item of summaryAssetsValue; let i = index;\"\n      >\n        <p>{{item.value | currency : 'USD': '' : '5.0-0'}}</p>\n        <label>{{item.title}}</label>\n    </div>\n    </div>\n\n   <div class=\"single-line-chart\">\n\n     <div class=\"floating-rect-wrapper\">\n       <div class=\"top-left-info\">\n         <p class=\"top-left-info-v\">500,000</p>\n         <label>Shares Outstanding</label>\n       </div>\n       <div class=\"top-rightt-info\">\n         <label>Market Value Change: Today</label>\n         <p class=\"top-rightt-info-v\">+100,000</p>\n         <p class=\"top-rightt-info-v\">+0.03%</p>\n       </div>\n       <div class=\"middle-info\">\n         4,400,000\n       </div>\n       <div class=\"bottom-info\">\n         4,300,000\n       </div>\n     </div>\n\n    <lib-single-line-chart\n      [results]='results'\n      [height]='height'\n      [width]='width'\n      [margin]='margin'\n      [colorDomain]='colorDomain'\n      [tickValues]='tickValues'\n      [xAxisTickFormatting]='xAxisTickFormatting'\n      [xScaleMin]='xScaleMin'\n      [xScaleMax]='xScaleMax'\n      >\n    </lib-single-line-chart>\n   </div>\n\n   <div class=\"right-side-grid-wrapper\">\n     <h4>Your Three Day Trend</h4>\n       <div\n       *ngFor=\"let oneDayData of threeDayTrendData; let i = index;\"\n       [style.background]=\"oneDayData.color\"\n       class=\"three-day-data-details-item\"\n       >\n         <label class=\"detail-item-date\">{{oneDayData.day | date : 'longDate'}}</label>\n         <ul>\n           <li\n           *ngFor=\"let item of oneDayData.details;\"\n           >\n             <p\n             [style.color]=\"getValueSty(item.value)\"\n             >{{item.value}}</p>\n             <label>{{item.title}}</label>\n           </li>\n         </ul>\n       </div>\n     </div>\n\n  </div><!-- main-->\n</div>",
                        styles: [".position-fund-summary-container{font-family:DINNextLTPro-Medium;color:#464646}.position-fund-summary-container .fund-summary-title{position:absolute;top:0;left:15px;font-size:16px}.position-fund-summary-container .main-body-wrapper .top-search{position:absolute;top:60px;left:20px}.position-fund-summary-container .main-body-wrapper .top-search input{width:160px;padding:8px 20px;display:inline-block}.position-fund-summary-container .main-body-wrapper .top-search mat-icon{position:absolute;top:0;left:200px;background-color:#86bbd1;padding:5px 5px 6px 8px;cursor:pointer}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper{display:inline-block;margin-left:20px;padding-top:40px}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper .left-side-panel p{font-size:40px;margin:10px 0;padding:0}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper .left-side-panel label{font-size:14px;margin:0;padding:0}.position-fund-summary-container .main-body-wrapper .single-line-chart{display:inline-block;height:250px;margin:0 20px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper{position:relative}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper div{position:absolute}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper p{margin:0}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper label{display:block;font-size:12px;text-align:right}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-left-info{top:-65px;right:250px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-left-info .top-left-info-v{text-align:right;font-size:25px;margin-bottom:6px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-rightt-info{top:-70px;right:10px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-rightt-info .top-rightt-info-v{display:inline-block;background-color:#28743e;color:#faebd7;padding:5px 16px;font-size:18px;margin-top:6px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .middle-info{top:25px;right:10px;background-color:#28743e;color:#faebd7;font-size:16px;padding:2px 15px 2px 5px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .bottom-info{top:80px;right:10px;background-color:#727272;color:#faebd7;font-size:16px;padding:2px 15px 2px 5px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper{display:inline-block}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item{padding:10px 0}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item .detail-item-date{margin-left:10px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item label{font-size:12px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul{list-style-type:none;margin:0;padding:0}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul li{display:inline-block;margin:10px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul li p{margin:0}"]
                    },] },
        ];
        PositionFundSummaryComponent.ctorParameters = function () {
            return [
                { type: i0.ElementRef },
                { type: i0.NgZone },
                { type: i0.ChangeDetectorRef },
                { type: CommonUtilsService },
                { type: NavService },
                { type: ShareInfoBeweenComponentsService }
            ];
        };
        return PositionFundSummaryComponent;
    }(uiCommon.BaseWidgetComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var SingleLineChartComponent = (function (_super) {
        __extends(SingleLineChartComponent, _super);
        function SingleLineChartComponent(chartElement, zone, cd, commonUtils, datePipe) {
            var _this = _super.call(this, chartElement, zone, cd) || this;
            _this.commonUtils = commonUtils;
            _this.datePipe = datePipe;
            _this.legendTitle = 'Legend';
            _this.showGridLines = true;
            _this.curve = d3Shape.curveLinear;
            _this.roundDomains = false;
            _this.tooltipDisabled = true; // if need tooltip then set tooltipObj
            _this.showRefLines = false;
            _this.showRefLabels = false;
            _this.colorDomain = [];
            _this.tickValues = [];
            _this.activeEntries = [];
            _this.activate = new i0.EventEmitter();
            _this.deactivate = new i0.EventEmitter();
            _this.xAxisHeight = 0;
            _this.yAxisWidth = 0;
            _this.timelineHeight = 50;
            _this.timelinePadding = 10;
            _this.tooltipObj = {};
            return _this;
        }
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.update = /**
         * @return {?}
         */
            function () {
                this.dims = ngxCharts.calculateViewDimensions({
                    width: this.width,
                    height: this.height,
                    margins: this.margin,
                    xAxisHeight: this.xAxisHeight,
                    yAxisWidth: this.yAxisWidth,
                    showXLabel: this.showXAxisLabel,
                    showYLabel: this.showYAxisLabel,
                    showLegend: this.legend,
                    legendType: this.schemeType,
                });
                if (this.timeline) {
                    this.dims.height -= (this.timelineHeight + this.margin[2] + this.timelinePadding);
                }
                this.xDomain = this.getXDomain();
                if (this.filteredDomain) {
                    this.xDomain = this.filteredDomain;
                }
                this.yDomain = this.getYDomain();
                this.seriesDomain = this.getSeriesDomain();
                this.xScale = this.getXScale(this.xDomain, this.dims.width);
                this.yScale = this.getYScale(this.yDomain, this.dims.height);
                this.customColors = this.setCustomcolors();
                this.setColors();
                this.legendOptions = this.getLegendOptions();
                this.transform = "translate(" + this.dims.xOffset + " , " + this.margin[0] + ")";
                this.clipPathId = 'clip' + utils.id().toString();
                this.clipPath = "url(#" + this.clipPathId + ")";
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.setCustomcolors = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var arr = [];
                this.results.forEach(function (item) {
                    _this.colorDomain.forEach(function (color) {
                        if (item['name'] === color['fundTicker']) {
                            /** @type {?} */
                            var obj = {
                                name: color.fundTicker,
                                value: color.color
                            };
                            arr.push(obj);
                        }
                    });
                });
                return arr;
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.getXDomain = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var values = domain_helper.getUniqueXDomainValues(this.results);
                this.scaleType = this.getScaleType(values);
                /** @type {?} */
                var domain = [];
                if (this.scaleType === 'linear') {
                    values = values.map(function (v) { return Number(v); });
                }
                /** @type {?} */
                var min;
                /** @type {?} */
                var max;
                if (this.scaleType === 'time' || this.scaleType === 'linear') {
                    min = this.xScaleMin
                        ? this.xScaleMin
                        : Math.min.apply(Math, __spread(values));
                    max = this.xScaleMax
                        ? this.xScaleMax
                        : Math.max.apply(Math, __spread(values));
                }
                if (this.scaleType === 'time') {
                    domain = [new Date(min), new Date(max)];
                    this.xSet = __spread(values).sort(function (a, b) {
                        /** @type {?} */
                        var aDate = a.getTime();
                        /** @type {?} */
                        var bDate = b.getTime();
                        if (aDate > bDate)
                            return 1;
                        if (bDate > aDate)
                            return -1;
                        return 0;
                    });
                }
                else if (this.scaleType === 'linear') {
                    domain = [min, max];
                    // Use compare function to sort numbers numerically
                    this.xSet = __spread(values).sort(function (a, b) { return (a - b); });
                }
                else {
                    domain = values;
                    this.xSet = values;
                }
                return domain;
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.getYDomain = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var domain = [];
                try {
                    for (var _a = __values(this.results), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var results = _b.value;
                        try {
                            for (var _c = __values(results.series), _d = _c.next(); !_d.done; _d = _c.next()) {
                                var d = _d.value;
                                if (d.value && domain.indexOf(d.value) < 0) {
                                    domain.push(d.value);
                                }
                                if (d.min !== undefined) {
                                    this.hasRange = true;
                                    if (domain.indexOf(d.min) < 0) {
                                        domain.push(d.min);
                                    }
                                }
                                if (d.max !== undefined) {
                                    this.hasRange = true;
                                    if (domain.indexOf(d.max) < 0) {
                                        domain.push(d.max);
                                    }
                                }
                            }
                        }
                        catch (e_1_1) {
                            e_1 = { error: e_1_1 };
                        }
                        finally {
                            try {
                                if (_d && !_d.done && (_e = _c.return))
                                    _e.call(_c);
                            }
                            finally {
                                if (e_1)
                                    throw e_1.error;
                            }
                        }
                    }
                }
                catch (e_2_1) {
                    e_2 = { error: e_2_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_f = _a.return))
                            _f.call(_a);
                    }
                    finally {
                        if (e_2)
                            throw e_2.error;
                    }
                }
                /** @type {?} */
                var values = __spread(domain);
                if (!this.autoScale) {
                    values.push(0);
                }
                /** @type {?} */
                var min = this.yScaleMin
                    ? this.yScaleMin
                    : Math.min.apply(Math, __spread(values));
                /** @type {?} */
                var max = this.yScaleMax
                    ? this.yScaleMax
                    : Math.max.apply(Math, __spread(values));
                if (min && max) {
                    return [min, max];
                }
                else {
                    return [-0.1, 0.1];
                }
                var e_2, _f, e_1, _e;
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.getSeriesDomain = /**
         * @return {?}
         */
            function () {
                return this.results.map(function (d) { return d.name; });
            };
        /**
         * @param {?} domain
         * @param {?} width
         * @return {?}
         */
        SingleLineChartComponent.prototype.getXScale = /**
         * @param {?} domain
         * @param {?} width
         * @return {?}
         */
            function (domain, width) {
                /** @type {?} */
                var scale;
                if (this.scaleType === 'time') {
                    scale = d3Scale.scaleTime()
                        .range([0, width])
                        .domain(domain);
                }
                else if (this.scaleType === 'linear') {
                    scale = d3Scale.scaleLinear()
                        .range([0, width])
                        .domain(domain);
                    if (this.roundDomains) {
                        scale = scale.nice();
                    }
                }
                else if (this.scaleType === 'ordinal') {
                    scale = d3Scale.scalePoint()
                        .range([0, width])
                        .padding(0.1)
                        .domain(domain);
                }
                return scale;
            };
        /**
         * @param {?} domain
         * @param {?} height
         * @return {?}
         */
        SingleLineChartComponent.prototype.getYScale = /**
         * @param {?} domain
         * @param {?} height
         * @return {?}
         */
            function (domain, height) {
                /** @type {?} */
                var scale = d3Scale.scaleLinear()
                    .range([height, 0])
                    .domain(domain);
                return this.roundDomains ? scale.nice() : scale;
            };
        /**
         * @param {?} values
         * @return {?}
         */
        SingleLineChartComponent.prototype.getScaleType = /**
         * @param {?} values
         * @return {?}
         */
            function (values) {
                /** @type {?} */
                var date = true;
                /** @type {?} */
                var num = true;
                try {
                    for (var values_1 = __values(values), values_1_1 = values_1.next(); !values_1_1.done; values_1_1 = values_1.next()) {
                        var value = values_1_1.value;
                        if (!this.isDate(value)) {
                            date = false;
                        }
                        if (typeof value !== 'number') {
                            num = false;
                        }
                    }
                }
                catch (e_3_1) {
                    e_3 = { error: e_3_1 };
                }
                finally {
                    try {
                        if (values_1_1 && !values_1_1.done && (_a = values_1.return))
                            _a.call(values_1);
                    }
                    finally {
                        if (e_3)
                            throw e_3.error;
                    }
                }
                if (date)
                    return 'time';
                if (num)
                    return 'linear';
                return 'ordinal';
                var e_3, _a;
            };
        /**
         * @param {?} value
         * @return {?}
         */
        SingleLineChartComponent.prototype.isDate = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                if (value instanceof Date) {
                    return true;
                }
                return false;
            };
        /**
         * @param {?} __0
         * @return {?}
         */
        SingleLineChartComponent.prototype.updateYAxisWidth = /**
         * @param {?} __0
         * @return {?}
         */
            function (_a) {
                var width = _a.width;
                this.yAxisWidth = width;
                this.update();
            };
        /**
         * @param {?} __0
         * @return {?}
         */
        SingleLineChartComponent.prototype.updateXAxisHeight = /**
         * @param {?} __0
         * @return {?}
         */
            function (_a) {
                var height = _a.height;
                this.xAxisHeight = height;
                this.update();
            };
        /**
         * @param {?} item
         * @return {?}
         */
        SingleLineChartComponent.prototype.updateHoveredVertical = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                this.hoveredVertical = item.value;
                this.deactivateAll();
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.hideCircles = /**
         * @return {?}
         */
            function () {
                this.hoveredVertical = null;
                this.deactivateAll();
            };
        /**
         * @param {?} series
         * @return {?}
         */
        SingleLineChartComponent.prototype.onMouseEnter = /**
         * @param {?} series
         * @return {?}
         */
            function (series) {
                this.activate.emit(series);
            };
        /**
         * @param {?} series
         * @return {?}
         */
        SingleLineChartComponent.prototype.onMouseLeave = /**
         * @param {?} series
         * @return {?}
         */
            function (series) {
                this.deactivate.emit(series);
            };
        /**
         * @param {?} data
         * @param {?=} series
         * @return {?}
         */
        SingleLineChartComponent.prototype.onClick = /**
         * @param {?} data
         * @param {?=} series
         * @return {?}
         */
            function (data, series) {
                if (series) {
                    data.series = series.name;
                }
                this.select.emit(data);
            };
        /**
         * @param {?} index
         * @param {?} item
         * @return {?}
         */
        SingleLineChartComponent.prototype.trackBy = /**
         * @param {?} index
         * @param {?} item
         * @return {?}
         */
            function (index, item) {
                return item.name;
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.setColors = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var domain;
                if (this.schemeType === 'ordinal') {
                    domain = this.seriesDomain;
                }
                else {
                    domain = this.yDomain;
                }
                this.colors = new ngxCharts.ColorHelper(this.scheme, this.schemeType, domain, this.customColors);
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.getLegendOptions = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var opts = {
                    scaleType: this.schemeType,
                    colors: undefined,
                    domain: [],
                    title: undefined
                };
                if (opts.scaleType === 'ordinal') {
                    opts.domain = this.seriesDomain;
                    opts.colors = this.colors;
                    opts.title = this.legendTitle;
                }
                else {
                    opts.domain = this.yDomain;
                    opts.colors = this.colors.scale;
                }
                return opts;
            };
        /**
         * @param {?} item
         * @return {?}
         */
        SingleLineChartComponent.prototype.onActivate = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                this.deactivateAll();
                /** @type {?} */
                var idx = this.activeEntries.findIndex(function (d) {
                    return d.name === item.name && d.value === item.value;
                });
                if (idx > -1) {
                    return;
                }
                this.activeEntries = [item];
                this.activate.emit({ value: item, entries: this.activeEntries });
            };
        /**
         * @param {?} item
         * @return {?}
         */
        SingleLineChartComponent.prototype.onDeactivate = /**
         * @param {?} item
         * @return {?}
         */
            function (item) {
                /** @type {?} */
                var idx = this.activeEntries.findIndex(function (d) {
                    return d.name === item.name && d.value === item.value;
                });
                this.activeEntries.splice(idx, 1);
                this.activeEntries = __spread(this.activeEntries);
                this.deactivate.emit({ value: item, entries: this.activeEntries });
            };
        /**
         * @return {?}
         */
        SingleLineChartComponent.prototype.deactivateAll = /**
         * @return {?}
         */
            function () {
                this.activeEntries = __spread(this.activeEntries);
                try {
                    for (var _a = __values(this.activeEntries), _b = _a.next(); !_b.done; _b = _a.next()) {
                        var entry = _b.value;
                        this.deactivate.emit({ value: entry, entries: [] });
                    }
                }
                catch (e_4_1) {
                    e_4 = { error: e_4_1 };
                }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return))
                            _c.call(_a);
                    }
                    finally {
                        if (e_4)
                            throw e_4.error;
                    }
                }
                this.activeEntries = [];
                var e_4, _c;
            };
        SingleLineChartComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-single-line-chart',
                        template: "<div class=\"custom-chart\">\n  <ngx-charts-chart \n      [view]=\"[width, height]\"\n      [showLegend]=\"false\"\n      [legendOptions]=\"legendOptions\"\n      [activeEntries]=\"activeEntries\"\n      [animations]=\"animations\"\n      (legendLabelClick)=\"onClick($event)\"\n      (legendLabelActivate)=\"onActivate($event)\"\n      (legendLabelDeactivate)=\"onDeactivate($event)\">\n      <svg:defs>\n        <svg:clipPath [attr.id]=\"clipPathId\">\n          <svg:rect\n            [attr.width]=\"dims.width + 10\"\n            [attr.height]=\"dims.height + 10\"\n            [attr.transform]=\"'translate(-5, -5)'\"/>\n        </svg:clipPath>\n      </svg:defs>\n      <svg:g [attr.transform]=\"transform\" class=\"line-chart chart\">\n        <svg:g ngx-charts-x-axis \n          [xScale]=\"xScale\"\n          [dims]=\"dims\"\n          [showLabel]=\"showXAxisLabel\"\n          [showGridLines]=\"showGridLines\"\n          [labelText]=\"xAxisLabel\"\n          [ticks]=\"tickValues\"\n          [tickFormatting]=\"xAxisTickFormatting\"\n          (dimensionsChanged)=\"updateXAxisHeight($event)\">\n        </svg:g>\n        <svg:g ngx-charts-y-axis\n          [yScale]=\"yScale\"\n          [dims]=\"dims\"\n          [showLabel]=\"showYAxisLabel\"\n          [labelText]=\"yAxisLabel\"\n          [referenceLines]=\"referenceLines\"\n          [showRefLines]=\"showRefLines\"\n          [showGridLines]=\"showGridLines\"\n          [showRefLabels]=\"showRefLabels\"\n          (dimensionsChanged)=\"updateYAxisWidth($event)\">\n        </svg:g>\n\n        <svg:g [attr.clip-path]=\"clipPath\">\n          <svg:g *ngFor=\"let series of results; trackBy:trackBy\" [@animationState]=\"'active'\">\n            <svg:g ngx-charts-line-series\n              [xScale]=\"xScale\"\n              [yScale]=\"yScale\"\n              [colors]=\"colors\"\n              [data]=\"series\"\n              [activeEntries]=\"activeEntries\"\n              [scaleType]=\"scaleType\"\n              [curve]=\"curve\"\n              [rangeFillOpacity]=\"rangeFillOpacity\"\n              [hasRange]=\"hasRange\"\n              [animations]=\"animations\"\n            />\n          </svg:g>\n          <svg:g *ngIf=\"!tooltipDisabled\" (mouseleave)=\"hideCircles()\">\n            <svg:g ngx-charts-tooltip-area\n              [dims]=\"dims\"\n              [xSet]=\"xSet\"\n              [xScale]=\"xScale\"\n              [yScale]=\"yScale\"\n              [results]=\"results\"\n              [colors]=\"colors\"\n              [tooltipDisabled]=\"!tooltipDisabled\"\n              (hover)=\"updateHoveredVertical($event)\"\n            />\n\n            <svg:g *ngFor=\"let series of results\">\n              <svg:g ngx-charts-circle-series\n                [xScale]=\"xScale\"\n                [yScale]=\"yScale\"\n                [colors]=\"colors\"\n                [data]=\"series\"\n                [scaleType]=\"scaleType\"\n                [visibleValue]=\"hoveredVertical\"\n                [activeEntries]=\"activeEntries\"\n                (select)=\"onClick($event, series)\"\n                (activate)=\"onActivate($event)\"\n                (deactivate)=\"onDeactivate($event)\"\n                [tooltipTemplate]=\"tooltipTemplate\"\n              />\n            </svg:g>\n        \n          </svg:g>\n        </svg:g>\n      </svg:g>\n  </ngx-charts-chart>\n  <ng-template #tooltipTemplate>\n    <div class=\"single-tooltip\">\n    </div>\n  </ng-template>\n</div>",
                        styles: [""],
                        encapsulation: i0.ViewEncapsulation.ShadowDom,
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        animations: [
                            animations.trigger('animationState', [
                                animations.transition(':leave', [
                                    animations.style({
                                        opacity: 1,
                                    }),
                                    animations.animate(500, animations.style({
                                        opacity: 0
                                    }))
                                ])
                            ])
                        ]
                    },] },
        ];
        SingleLineChartComponent.ctorParameters = function () {
            return [
                { type: i0.ElementRef },
                { type: i0.NgZone },
                { type: i0.ChangeDetectorRef },
                { type: CommonUtilsService },
                { type: common.DatePipe }
            ];
        };
        SingleLineChartComponent.propDecorators = {
            legend: [{ type: i0.Input }],
            legendTitle: [{ type: i0.Input }],
            showXAxisLabel: [{ type: i0.Input }],
            showYAxisLabel: [{ type: i0.Input }],
            xAxisLabel: [{ type: i0.Input }],
            yAxisLabel: [{ type: i0.Input }],
            autoScale: [{ type: i0.Input }],
            timeline: [{ type: i0.Input }],
            gradient: [{ type: i0.Input }],
            showGridLines: [{ type: i0.Input }],
            curve: [{ type: i0.Input }],
            schemeType: [{ type: i0.Input }],
            rangeFillOpacity: [{ type: i0.Input }],
            xAxisTickFormatting: [{ type: i0.Input }],
            yAxisTickFormatting: [{ type: i0.Input }],
            xAxisTicks: [{ type: i0.Input }],
            yAxisTicks: [{ type: i0.Input }],
            roundDomains: [{ type: i0.Input }],
            tooltipDisabled: [{ type: i0.Input }],
            showRefLines: [{ type: i0.Input }],
            referenceLines: [{ type: i0.Input }],
            showRefLabels: [{ type: i0.Input }],
            xScaleMin: [{ type: i0.Input }],
            xScaleMax: [{ type: i0.Input }],
            yScaleMin: [{ type: i0.Input }],
            yScaleMax: [{ type: i0.Input }],
            selectable: [{ type: i0.Input }],
            height: [{ type: i0.Input }],
            width: [{ type: i0.Input }],
            margin: [{ type: i0.Input }],
            colorDomain: [{ type: i0.Input }],
            results: [{ type: i0.Input }],
            tickValues: [{ type: i0.Input }],
            activeEntries: [{ type: i0.Input }],
            activate: [{ type: i0.Output }],
            deactivate: [{ type: i0.Output }],
            tooltipTemplate: [{ type: i0.ContentChild, args: ['tooltipTemplate',] }],
            hideCircles: [{ type: i0.HostListener, args: ['mouseleave',] }],
            onMouseEnter: [{ type: i0.HostListener, args: ['mouseenter', ["series"],] }],
            onMouseLeave: [{ type: i0.HostListener, args: ['mouseleave', ["$event"],] }]
        };
        return SingleLineChartComponent;
    }(ngxCharts.BaseChartComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var CommonDataTableComponent = (function () {
        function CommonDataTableComponent(cd, viewContainer, shareInforBewteenComponents, commonUtils) {
            this.cd = cd;
            this.viewContainer = viewContainer;
            this.shareInforBewteenComponents = shareInforBewteenComponents;
            this.commonUtils = commonUtils;
            // data
            this.headerSetting = true;
            this.headerHeight = 50;
            this.isDataTablePaused = false;
            this.rows = [];
            this.childRows = [];
            this.alertData = [];
            this.rowHeight = 50;
            this.customColumn = []; //type No. Details
            this.normalColumn = []; // width, draggable, canAutoResize  prop headerClass cellClass headerTemplate cellTemplate columnSetting etc.
            this.limit = 5;
            this.footerHeight = 50;
            this.headerCheckBox = false;
            this.columnMenuDropDownSetting = [];
            this.menuClosed = new i0.EventEmitter();
            this.togglePauseFlagEvent = new i0.EventEmitter();
            this.expandChild = false;
            this.isSelectedMap = [];
            this.expandCollapseIconMap = [];
            this.getSortIconDisplayFlag = {};
            this.isDataAvailable = false;
            this.ascFlag = 'asc';
            shareInforBewteenComponents.clickedOutSide.subscribe(function (e) {
                // this.selectedCol = '';
            });
        }
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.hasChildren = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                return this.childRows.findIndex(function (item) { return item.fundid === row.fundid; }) === -1 ? false : true;
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                this.expandCollapseIconMap = this.setDefaultExpandCollapseMapping(this.rows);
                this.getSortIconDisplayFlag = this.setDefaultSortIconDisplayFlag(this.normalColumn);
                this.expandChild = this.childRows.length > 0 ? true : false;
                this.isDataAvailable = this.rows.length > 0 ? true : false;
                /** @type {?} */
                var data = this.getSortColumnDetailsInfo();
                this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var layOutComp = document.getElementsByClassName('layout-item')[1];
                if (layOutComp) {
                    layOutComp.classList.add('table-layout');
                    this.onResize(event);
                }
            };
        /**
         * @param {?} data
         * @return {?}
         */
        CommonDataTableComponent.prototype.setDefaultExpandCollapseMapping = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                /** @type {?} */
                var mappingArr = [];
                data.forEach(function (item) {
                    /** @type {?} */
                    var obj = {
                        fundid: item.fundid,
                        expand: false
                    };
                    mappingArr.push(obj);
                });
                return mappingArr;
            };
        /**
         * @param {?} column
         * @return {?}
         */
        CommonDataTableComponent.prototype.setDefaultSortIconDisplayFlag = /**
         * @param {?} column
         * @return {?}
         */
            function (column) {
                /** @type {?} */
                var tempMap = {};
                column.forEach(function (item) {
                    /** @type {?} */
                    var obj = new Object();
                    obj[item.prop] = false;
                    tempMap = Object.assign(_.cloneDeep(tempMap), obj);
                });
                return tempMap;
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.getSortColumnDetailsInfo = /**
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var obj = {
                    map: this.expandCollapseIconMap,
                    prop: this.defaultSortCol,
                    ascFlag: true
                };
                this.normalColumn.forEach(function (item) {
                    if (item.sortColumnAscOrDesc) {
                        obj = {
                            map: _this.expandCollapseIconMap,
                            prop: item.prop,
                            ascFlag: item.sortColumnAscOrDesc === 'asc' ? true : false
                        };
                    }
                });
                return obj;
            };
        /**
         * @param {?} column
         * @return {?}
         */
        CommonDataTableComponent.prototype.getHeaderClass = /**
         * @param {?} column
         * @return {?}
         */
            function (column) {
                switch (column.headerClassFormat) {
                    case 'headerLeft':
                        return 'columnHeader header-align-left';
                    case 'headerCenter':
                        return 'columnHeader header-align-center';
                    case 'headerRight':
                        return 'columnHeader header-align-right';
                    default:
                        return 'columnHeader';
                }
            };
        /**
         * @param {?} row
         * @param {?} column
         * @param {?} value
         * @return {?}
         */
        CommonDataTableComponent.prototype.getCellClass = /**
         * @param {?} row
         * @param {?} column
         * @param {?} value
         * @return {?}
         */
            function (row, column, value) {
                switch (column.cellClassFormat) {
                    case 'cellLeft':
                        return ' align-left';
                    case 'cellRight':
                        return ' align-right';
                    case 'cellNumber':// need more anlyze here
                        if (value !== 0) {
                            if (value.toString().indexOf('-') !== -1 && value.toString().indexOf('-') === 0) {
                                return ' is-nagetive';
                            }
                            else {
                                return ' is-positive';
                            }
                        }
                        else if (column.prop === 'navChangePercent') {
                            if (row['navChange'].toString().indexOf('-') !== -1 && row['navChange'].toString().indexOf('-') === 0) {
                                return ' is-nagetive';
                            }
                            else {
                                return ' is-positive';
                            }
                        }
                        else if (column.prop === 'fundmvChangePercent') {
                            if (row['fundmvChange'].toString().indexOf('-') !== -1 && row['fundmvChange'].toString().indexOf('-') === 0) {
                                return ' is-nagetive';
                            }
                            else {
                                return ' is-positive';
                            }
                        }
                        else if (value === 0) {
                            return ' is-zero';
                        }
                    // tslint:disable-next-line:no-switch-case-fall-through
                    default:
                        return;
                }
            };
        /**
         * @param {?} col
         * @return {?}
         */
        CommonDataTableComponent.prototype.getColSettingWidth = /**
         * @param {?} col
         * @return {?}
         */
            function (col) {
                if (col && col.width && !isNaN(Number(col.width))) {
                    return col.width;
                }
                else {
                    return 150;
                }
            };
        /**
         * @param {?} fund
         * @param {?} classID
         * @return {?}
         */
        CommonDataTableComponent.prototype.showYellowAlert = /**
         * @param {?} fund
         * @param {?} classID
         * @return {?}
         */
            function (fund, classID) {
                /** @type {?} */
                var show = false;
                show = this.alertData.find(function (item) { return item.name === fund && item.classID === classID && item.alertType === 1; });
                return show;
            };
        /**
         * @param {?} fund
         * @param {?} classID
         * @return {?}
         */
        CommonDataTableComponent.prototype.showRedAlert = /**
         * @param {?} fund
         * @param {?} classID
         * @return {?}
         */
            function (fund, classID) {
                /** @type {?} */
                var show = false;
                show = this.alertData.find(function (item) { return item.name === fund && item.classID === classID && item.alertType === 2; });
                return show;
            };
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.showNews = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                // according to row info to determine show news icon or not 
                return true;
            };
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.getSideColorStyle = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                /** @type {?} */
                var backgroundColor = '';
                this.shareInforBewteenComponents.colorSchema.forEach(function (item) {
                    if (row && row['fundid'] && item['fundid'] === row['fundid']) {
                        backgroundColor = item['color'];
                    }
                });
                return backgroundColor;
            };
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.toggleExpandRow = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                var _this = this;
                /** @type {?} */
                var parentFundId = row.fundid;
                /** @type {?} */
                var currentExpand;
                this.expandCollapseIconMap.forEach(function (item) {
                    if (parentFundId === item.fundid) {
                        item.expand = !item.expand;
                        currentExpand = item.expand;
                    }
                });
                /** @type {?} */
                var index = this.rows.findIndex(function (item) { return item.fundid === parentFundId; });
                this.childRows.forEach(function (item) {
                    if (item.fundid === parentFundId) {
                        currentExpand ? _this.rows.splice(index + 1, 0, item) : _this.rows.splice(index + 1, 1);
                    }
                });
            };
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.getExpandCollapseIcon = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                /** @type {?} */
                var fundid = row.fundid;
                /** @type {?} */
                var expandFlag = false;
                this.expandCollapseIconMap.forEach(function (item) {
                    if (fundid === item.fundid)
                        expandFlag = item.expand;
                });
                return row.child === "child" ? "" : expandFlag ? "arrow_down" : "arrow_right";
            };
        /**
         * @param {?} para
         * @return {?}
         */
        CommonDataTableComponent.prototype.getRowHeight = /**
         * @param {?} para
         * @return {?}
         */
            function (para) {
                // debugger;
                para === 'standard' ? this.rowHeight = 50 : this.rowHeight = 40;
            };
        /**
         * @param {?} e
         * @return {?}
         */
        CommonDataTableComponent.prototype.onClickedOutside = /**
         * @param {?} e
         * @return {?}
         */
            function (e) {
                this.shareInforBewteenComponents.clickedOutSide.emit(e);
            };
        /**
         * @param {?} event
         * @param {?} prop
         * @return {?}
         */
        CommonDataTableComponent.prototype.selectCurrentCol = /**
         * @param {?} event
         * @param {?} prop
         * @return {?}
         */
            function (event, prop) {
                this.selectedCol = prop;
                event.currentTarget.classList.add("drop-is-visible");
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.closeMenu = /**
         * @return {?}
         */
            function () {
                document.getElementsByClassName("drop-is-visible")[0].classList.remove("drop-is-visible");
            };
        /**
         * @param {?} event
         * @return {?}
         */
        CommonDataTableComponent.prototype.onResize = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                //calcute  datatable-body height according to gridster-item height 
                /** @type {?} */
                var height = Number((((document.getElementsByClassName('table-layout')[0]))).style.height.slice(0, length - 2));
                /** @type {?} */
                var tableBodyHeight = 260;
                height = (height - 148) > tableBodyHeight ? tableBodyHeight : height - 148;
                if (document.getElementsByClassName('datatable-body')[0]) {
                    (((document.getElementsByClassName('datatable-body')[0]))).style.height = height + 'px';
                }
            };
        /**
         * @param {?} name
         * @return {?}
         */
        CommonDataTableComponent.prototype.getMatMenuItemDisplayname = /**
         * @param {?} name
         * @return {?}
         */
            function (name) {
                switch (name) {
                    case 'Sort Column':
                        return this.getSortIconDisplayFlag[this.selectedCol] ? 'Disable Sort' : 'Sort Column';
                    case 'Freeze Column':
                        return this.getFrozenIconDisplayFalg(this.selectedCol) ? 'Unfreeze Column' : 'Freeze Column';
                    default:
                        return name;
                }
            };
        /**
         * @param {?} colProp
         * @return {?}
         */
        CommonDataTableComponent.prototype.getFrozenIconDisplayFalg = /**
         * @param {?} colProp
         * @return {?}
         */
            function (colProp) {
                /** @type {?} */
                var freezeFlag = false;
                this.normalColumn.forEach(function (item) {
                    if (item.prop === colProp && item.frozenLeft) {
                        freezeFlag = true;
                    }
                });
                return freezeFlag;
            };
        /**
         * @param {?} type
         * @return {?}
         */
        CommonDataTableComponent.prototype.handleMenuItemClick = /**
         * @param {?} type
         * @return {?}
         */
            function (type) {
                switch (type) {
                    case 'resizeToFit':
                        this.resizeToFit();
                        return;
                    case 'freezeColumn':
                        this.freezeColumn();
                        return;
                    case 'sortColumn':
                        this.sortColumn();
                        return;
                    default:
                        return;
                }
            };
        //todo...
        //todo...
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.resizeToFit =
            //todo...
            /**
             * @return {?}
             */
            function () {
                console.log(this.selectedCol);
                this.selectedCol = "";
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.freezeColumn = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.normalColumn.forEach(function (item, i) {
                    if (item.prop == _this.selectedCol) {
                        item.frozenLeft = !item.frozenLeft;
                    }
                });
            };
        /**
         * @param {?} selectedCol
         * @return {?}
         */
        CommonDataTableComponent.prototype.syncColumnSettingForSortFlag = /**
         * @param {?} selectedCol
         * @return {?}
         */
            function (selectedCol) {
                var _this = this;
                this.normalColumn.forEach(function (item, i) {
                    if (item.prop === selectedCol) {
                        item.sortColumnAscOrDesc = _this.ascFlag;
                    }
                    else {
                        item.sortColumnAscOrDesc = '';
                    }
                });
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.sortColumn = /**
         * @return {?}
         */
            function () {
                this.syncColumnSettingForSortFlag(this.selectedCol);
                for (var key in this.getSortIconDisplayFlag) {
                    if (key === this.selectedCol) {
                        if (!this.getSortIconDisplayFlag[key]) {
                            /** @type {?} */
                            var data = {
                                map: this.expandCollapseIconMap,
                                prop: this.selectedCol,
                                ascFlag: true
                            };
                            this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                        }
                        else {
                            // the default order is sorted by fundid.
                            /** @type {?} */
                            var data = {
                                map: this.expandCollapseIconMap,
                                prop: this.defaultSortCol,
                                ascFlag: true
                            };
                            this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                        }
                        this.getSortIconDisplayFlag[key] = !this.getSortIconDisplayFlag[key];
                    }
                    else {
                        this.getSortIconDisplayFlag[key] = false;
                    }
                }
                this.selectedCol = "";
            };
        /**
         * @param {?} e
         * @param {?} prop
         * @return {?}
         */
        CommonDataTableComponent.prototype.changeAscAndDescSort = /**
         * @param {?} e
         * @param {?} prop
         * @return {?}
         */
            function (e, prop) {
                e.stopPropagation();
                if (this.ascFlag === "asc") {
                    this.ascFlag = "desc";
                    /** @type {?} */
                    var data = {
                        map: this.expandCollapseIconMap,
                        prop: prop,
                        ascFlag: false
                    };
                    this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                }
                else if (this.ascFlag === "desc") {
                    this.ascFlag = "asc";
                    /** @type {?} */
                    var data = {
                        map: this.expandCollapseIconMap,
                        prop: prop,
                        ascFlag: true
                    };
                    this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                }
                this.syncColumnSettingForSortFlag(prop);
                this.selectedCol = "";
            };
        /**
         * @param {?} prop
         * @return {?}
         */
        CommonDataTableComponent.prototype.getSortIconDisplaySty = /**
         * @param {?} prop
         * @return {?}
         */
            function (prop) {
                /** @type {?} */
                var visibility = false;
                this.normalColumn.forEach(function (item) {
                    if (item.prop === prop && item.sortColumnAscOrDesc)
                        visibility = true;
                });
                return visibility;
            };
        /**
         * @param {?} prop
         * @return {?}
         */
        CommonDataTableComponent.prototype.getSortIcon = /**
         * @param {?} prop
         * @return {?}
         */
            function (prop) {
                /** @type {?} */
                var icon = '';
                this.normalColumn.forEach(function (item) {
                    if (item.prop === prop)
                        icon = item.sortColumnAscOrDesc;
                });
                if (icon !== '') {
                    return icon === "asc" ? "circle_arrow_up" : "circle_arrow_down";
                }
                else {
                    return this.ascFlag === "asc" ? "circle_arrow_up" : "circle_arrow_down";
                }
            };
        /**
         * @param {?} col
         * @param {?} index
         * @return {?}
         */
        CommonDataTableComponent.prototype.removeOrAddColumn = /**
         * @param {?} col
         * @param {?} index
         * @return {?}
         */
            function (col, index) {
                console.log(col.prop + "---" + index + "--" + this.selectedCol);
                this.selectedCol = "";
            };
        /**
         * @param {?} row
         * @return {?}
         */
        CommonDataTableComponent.prototype.hyperLinkNavigate = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                this.shareInforBewteenComponents.hyperLinkNavigate.emit(row);
            };
        /**
         * @param {?} row
         * @param {?} type
         * @return {?}
         */
        CommonDataTableComponent.prototype.openAlertModal = /**
         * @param {?} row
         * @param {?} type
         * @return {?}
         */
            function (row, type) {
                /** @type {?} */
                var obj = {
                    rowData: row,
                    type: type
                };
                this.shareInforBewteenComponents.openModalData.emit(obj);
            };
        /**
         * @return {?}
         */
        CommonDataTableComponent.prototype.togglePauseFlag = /**
         * @return {?}
         */
            function () {
                this.isDataTablePaused = !this.isDataTablePaused;
                this.togglePauseFlagEvent.emit();
            };
        CommonDataTableComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-common-data-table',
                        template: "<div *ngIf=\"isDataAvailable\" style=\"height:50px\" class=\"main-box\" (clickOutside)=\"onClickedOutside($event)\">\n\n  <div *ngIf=\"headerSetting\" class=\"more-icon\">\n    <button mat-icon-button [matMenuTriggerFor]=\"menu\">\n      <mat-icon svgIcon=\"more\"></mat-icon>\n    </button>\n    <mat-menu #menu=\"matMenu\" [overlapTrigger]='false'>\n      <button mat-menu-item [matMenuTriggerFor]=\"adjustRowHeight\">\n        <span>Row Height</span>\n      </button>\n      <button *ngIf='!isDataTablePaused' mat-menu-item (click)=\"togglePauseFlag()\">\n        <span>Pause</span>\n      </button>  \n      <button *ngIf='isDataTablePaused' mat-menu-item (click)=\"togglePauseFlag()\">\n        <span>Un-Pause</span>\n      </button>    \n    </mat-menu>\n\n    <mat-menu #adjustRowHeight=\"matMenu\">\n      <button mat-menu-item (click)=\"getRowHeight('standard')\">Standard\n        <mat-icon *ngIf='rowHeight==50' svgIcon=\"check\" class=\"check-icon\"></mat-icon>\n      </button>\n      <button mat-menu-item (click)=\"getRowHeight('small')\">Small\n        <mat-icon *ngIf='rowHeight==40' svgIcon=\"check\" class=\"check-icon\"></mat-icon>\n      </button>\n    </mat-menu>\n  </div>\n  <!--rowHeight setting-->\n\n  <!--column menu dropdow-->\n  <div>\n    <mat-menu #columnHeaderMenu=\"matMenu\" [overlapTrigger]='false'>\n      <span *ngFor=\"let item of columnMenuDropDownSetting\">\n        <button mat-menu-item *ngIf=\"!item.hasSubMenu\">\n          <span (click)=\"handleMenuItemClick(item.type)\">{{getMatMenuItemDisplayname(item.name)}}</span>\n        </button>\n        <button mat-menu-item *ngIf=\"item.hasSubMenu\" [matMenuTriggerFor]=\"additionalFunctions\">\n          <span>{{item.name}}</span>\n        </button>\n      </span>\n    </mat-menu>\n\n\n    <mat-menu #additionalFunctions=\"matMenu\">\n      <button *ngFor=\"let col of normalColumn;let i=index;\" mat-menu-item (click)=\"removeOrAddColumn(col, i)\">\n        <span class=\"dropdowMenuListSty\">{{col.name}}</span>\n        <mat-icon *ngIf='1===1' svgIcon=\"check\" class=\"check-icon\"></mat-icon>\n      </button>\n    </mat-menu>\n  </div>\n\n\n  <ngx-datatable \n    #mydatatable \n    class=\"material expandable\" \n    [headerHeight]=\"headerHeight\" \n    [limit]=\"limit\"\n    [scrollbarH]='true' \n    [columnMode]=\"'force'\" \n    [footerHeight]=\"footerHeight\" \n    [rowHeight]=\"rowHeight\"\n    [trackByProp]=\"'updated'\" \n    [rows]=\"rows\">\n    <ngx-datatable-column *ngIf=\"expandChild\" [width]=\"30\" [resizeable]=\"false\" [sortable]=\"false\" [draggable]=\"false\"\n      [frozenLeft]=\"true\" [canAutoResize]=\"false\">\n      <ng-template let-row=\"row\" ngx-datatable-cell-template>\n        <span class='sideColorStyle' [style.background]='getSideColorStyle(row)'></span>\n        <mat-icon class=\"expanded-icon\" *ngIf=\"hasChildren(row)\" [svgIcon]=\"getExpandCollapseIcon(row)\" (click)=\"toggleExpandRow(row)\">\n        </mat-icon>\n      </ng-template>\n    </ngx-datatable-column>\n    <ngx-datatable-column *ngIf=\"headerCheckBox\" [width]=\"50\" [sortable]=\"false\" [canAutoResize]=\"false\"\n      [draggable]=\"false\" [frozenLeft]=\"true\" [resizeable]=\"false\">\n      <ng-template let-row=\"row\" ngx-datatable-header-template>\n        <span *ngIf=\"!expandChild\" class='sideColorStyle' [style.background]='getSideColorStyle(row)'></span>\n        <input type=\"checkbox\" [disabled]=\"getAllRowsDisabled()\" [checked]=\"getAllRowChecked(rows)\"\n          (change)=\"onSelectAll(!allRowsSelected, rows)\" />\n      </ng-template>\n      <ng-template ngx-datatable-cell-template let-row=\"row\">\n        <input type=\"checkbox\" [disabled]=\"getSingleRowDisabled(row)\" [checked]=\"getSingleRowChecked(row['fundTicker'])\"\n          (change)=\"onCheckboxChange(row['fundTicker'])\" />\n      </ng-template>\n    </ngx-datatable-column>\n    <ngx-datatable-column *ngFor=\"let col of customColumn\" \n      [width]=\"55\" \n      [sortable]=\"false\" \n      [canAutoResize]=\"false\"\n      [draggable]=\"false\" \n      [resizeable]=\"false\" \n      [frozenLeft]=\"true\">\n      <ng-template *ngIf=\"col.type==='redAlert' \" ngx-datatable-header-template>\n        <mat-icon class=\"alertHeader\" svgIcon=\"flag\"></mat-icon>\n      </ng-template>\n      <ng-template *ngIf=\"col.type==='yellowAlert' \" ngx-datatable-header-template>\n        <mat-icon class=\"alertHeader\" svgIcon=\"flag\"></mat-icon>\n      </ng-template>\n      <ng-template *ngIf=\"col.type==='news' \" ngx-datatable-header-template>\n        <span>News</span>\n      </ng-template>\n      <ng-template *ngIf=\"col.type==='redAlert' \" let-row=\"row\" let-column=\"col\" ngx-datatable-cell-template>\n        <mat-icon class=\"alertClass\" svgIcon=\"circle_alert\"\n          [style.display]=\"showRedAlert(row['fundid'],row['classID']) ? 'inline-flex' : 'none' \"\n          (click)=\"openAlertModal(row,col.type)\">\n        </mat-icon>\n      </ng-template>\n      <ng-template *ngIf=\"col.type==='yellowAlert' \" let-row=\"row\" let-column=\"col\" ngx-datatable-cell-template>\n        <mat-icon class=\"alertClass\" svgIcon=\"trianglealert\"\n          [style.display]=\"showYellowAlert(row['fundid'],row['classID']) ? 'inline-flex' : 'none' \"\n          (click)=\"openAlertModal(row,col.type)\">\n        </mat-icon>\n      </ng-template>\n      <ng-template *ngIf=\"col.type==='news' \" let-row=\"row\" ngx-datatable-cell-template>\n        <mat-icon class=\"showNewsClass\" [style.display]=\"showNews(row) ? 'inline-flex' : 'none' \" svgIcon=\"globe\">\n        </mat-icon>\n      </ng-template>\n    </ngx-datatable-column>\n    <ngx-datatable-column *ngFor=\"let col of normalColumn\" \n      [prop]=\"col.prop\" \n      [draggable]=\"col.draggable\"\n      [canAutoResize]=\"col.canAutoResize\" \n      [sortable]=\"false\" \n      [frozenLeft]=\"col.frozenLeft\"\n      [width]=\"getColSettingWidth(col)\">\n      <ng-template let-column=\"col\" ngx-datatable-header-template>\n        <div [class]=\"getHeaderClass(col)\"  \n        (click)=\"selectCurrentCol($event, col.prop)\" (menuClosed)=\"closeMenu()\"  [matMenuTriggerFor]=\"columnHeaderMenu\"\n          *ngIf=\"(col.columnSetting && columnMenuDropDownSetting.length > 0) else elseBlock\">\n          <!-- sort icon start-->\n          <span class=\"sortIconStyContainer\">\n            <mat-icon [class]=\"getSortIconDisplaySty(col.prop)\" [svgIcon]=\"getSortIcon(col.prop)\"\n              (click)=\"changeAscAndDescSort($event, col.prop)\"></mat-icon>\n          </span>\n           <!-- sort icon end-->\n\n          <!-- header name start-->\n          <span class=\"header-cell-label-sty\">\n            {{col.name}}\n            <mat-icon class=\"dropdowIconSty\" svgIcon=\"arrow_down\"></mat-icon>\n          </span>\n             <!-- header name end-->\n        </div>\n        <ng-template #elseBlock>\n          <span class=\"columnHeader\">\n            {{col.name}}\n          </span>\n        </ng-template>\n      </ng-template>\n      <ng-template *ngIf=\"col.cellTemplate==='hyperLink' \" let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\n        <div [class]=\"getCellClass(row, col, value)\">\n          <span *ngIf=\"row.child === 'parent'\" class=\"hyperLinkCellSty\"\n            (click)=\"hyperLinkNavigate(row)\">{{row.name}}</span>\n          <span *ngIf=\"row.child === 'child'\">{{row.name}}</span>\n        </div>\n      </ng-template>\n      <ng-template *ngIf=\"col.cellTemplate==='numberFormatShort' \" let-row=\"row\" let-value=\"value\" let-i=\"index\"\n        ngx-datatable-cell-template>\n        <div [class]=\"getCellClass(row, col, value)\">\n          {{value | numberRoundUp:2 | number: '1.2-2'}}\n        </div>\n      </ng-template>\n      <ng-template *ngIf=\"col.cellTemplate==='numberFormatLong' \" let-row=\"row\" let-value=\"value\" let-i=\"index\"\n        ngx-datatable-cell-template>\n        <div [class]=\"getCellClass(row, col, value)\">\n          {{value | numberRoundUp:5 | number: '1.5-5'}}\n        </div>\n      </ng-template>\n      <ng-template *ngIf=\"col.cellTemplate==='percentFormat' \" let-row=\"row\" let-value=\"value\" let-i=\"index\"\n        ngx-datatable-cell-template>\n        <div [class]=\"getCellClass(row, col, value)\">\n          {{value | numberRoundUp:5 | percent: '1.3-3' | percentFormat}}\n        </div>\n      </ng-template>\n      <ng-template *ngIf=\"col.cellTemplate==='default' \" let-row=\"row\" let-value=\"value\" let-i=\"index\"\n        ngx-datatable-cell-template>\n        <div [class]=\"getCellClass(row, col, value)\">\n          {{value}}\n        </div>\n      </ng-template>\n    </ngx-datatable-column>\n  </ngx-datatable>\n</div>",
                        styles: [".ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:\" \";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:\"\";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:\"\";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}", ".main-box .ngx-datatable.material{background:#fff}.main-box .ngx-datatable.material .showNewsClass{display:inline-block;width:20px;height:20px;transition:width .3s}.main-box .ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.main-box .ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#e1ecf2;cursor:pointer}.main-box .ngx-datatable.material .alertClass{text-align:center;display:inline-block;width:22px;height:22px;transition:width .3s;cursor:pointer;margin-left:-10px}.main-box .ngx-datatable.material .datatable-body-cell .expanded-icon{text-align:center;display:inline-block;width:20px;height:20px;cursor:pointer;color:rgba(0,0,0,.54);font-size:12px;transition:width .3s}.main-box .ngx-datatable.material .datatable-header-cell{line-height:50px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap{cursor:pointer;height:100%;line-height:50px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap .alertHeader{display:inline-block;width:20px;height:20px;transition:width .3s;margin-left:-10px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap .columnHeader{color:#000;position:relative;padding-right:5px}.main-box .ngx-datatable.material .datatable-header-cell .header-align-center,.main-box .ngx-datatable.material .datatable-header-cell .header-align-left,.main-box .ngx-datatable.material .datatable-header-cell .header-align-right{display:flex;align-items:center}.main-box .ngx-datatable.material .datatable-header-cell .header-align-left{justify-content:flex-start}.main-box .ngx-datatable.material .datatable-header-cell .header-align-center{justify-content:center}.main-box .ngx-datatable.material .datatable-header-cell .header-align-right{justify-content:flex-end}.main-box .ngx-datatable.material .dropdowIconSty{visibility:hidden}.main-box .ngx-datatable.material .dropdowIconSty,.main-box .ngx-datatable.material .sortIconStyContainer svg{width:15px!important;height:15px!important;min-width:15px!important;max-width:15px!important}.main-box .ngx-datatable.material .dropdowIconSty svg,.main-box .ngx-datatable.material .sortIconStyContainer svg{vertical-align:middle}.main-box .ngx-datatable.material .columnHeader .header-cell-label-sty{padding-left:3px}.main-box .ngx-datatable.material .columnHeader .dropdowIconSty{visibility:hidden}.main-box .ngx-datatable.material .columnHeader.drop-is-visible .dropdowIconSty,.main-box .ngx-datatable.material .columnHeader:hover .dropdowIconSty{visibility:visible}.main-box .ngx-datatable.material .columnHeader.drop-is-visible{background-color:#e1ecf2}.main-box .ngx-datatable.material .columnHeader .true{visibility:visible}.main-box .ngx-datatable.material .columnHeader .false{visibility:hidden}.main-box .ngx-datatable.material .datatable-body{overflow-y:auto!important}.main-box .ngx-datatable.material .datatable-body .align-right{padding-right:25px;text-align:right}.main-box .ngx-datatable.material .datatable-body .align-left{text-align:left;padding-left:19px}.main-box .ngx-datatable.material .datatable-body .sideColorStyle{position:absolute;width:4px;height:45px;top:3px;left:0}.main-box .ngx-datatable.material .datatable-body .hyperLinkCellSty{cursor:pointer;color:#2f7491;text-decoration:none}.main-box .ngx-datatable.material .datatable-header .datatable-row-left{background-image:none;display:flex}.main-box .more-icon{position:absolute;top:6px;right:58px;cursor:pointer}.main-box .more-icon .mat-icon-button{background-color:#fff;cursor:pointer}.table-layout .adjust-for-show-header{overflow-y:hidden!important}"],
                        encapsulation: i0.ViewEncapsulation.None //If you are using PrimeNG or Angular Material in your project that styleUrl will not work like this. You need to import ViewEncapsulation and put encapsulation: ViewEncapsulation.None in the @component definition.
                    },] },
        ];
        CommonDataTableComponent.ctorParameters = function () {
            return [
                { type: i0.ChangeDetectorRef },
                { type: i0.ViewContainerRef },
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService }
            ];
        };
        CommonDataTableComponent.propDecorators = {
            mydatatable: [{ type: i0.ViewChild, args: ['mydatatable',] }],
            headerSetting: [{ type: i0.Input }],
            headerHeight: [{ type: i0.Input }],
            isDataTablePaused: [{ type: i0.Input }],
            rows: [{ type: i0.Input }],
            childRows: [{ type: i0.Input }],
            alertData: [{ type: i0.Input }],
            rowHeight: [{ type: i0.Input }],
            customColumn: [{ type: i0.Input }],
            normalColumn: [{ type: i0.Input }],
            limit: [{ type: i0.Input }],
            footerHeight: [{ type: i0.Input }],
            headerCheckBox: [{ type: i0.Input }],
            columnMenuDropDownSetting: [{ type: i0.Input }],
            allRowsSelected: [{ type: i0.Input }],
            getAllRowsDisabled: [{ type: i0.Input }],
            getSingleRowDisabled: [{ type: i0.Input }],
            getAllRowChecked: [{ type: i0.Input }],
            getSingleRowChecked: [{ type: i0.Input }],
            onSelectAll: [{ type: i0.Input }],
            onCheckboxChange: [{ type: i0.Input }],
            defaultSortCol: [{ type: i0.Input }],
            menuClosed: [{ type: i0.Output }],
            togglePauseFlagEvent: [{ type: i0.Output }],
            onResize: [{ type: i0.HostListener, args: ['window:resize', ['$event'],] }]
        };
        return CommonDataTableComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    /** @type {?} */
    var customColumn$1 = [
        {
            type: "redAlert",
            details: "",
        },
        {
            type: "yellowAlert",
            details: "",
        }
    ];
    /** @type {?} */
    var normalColumn$1 = [
        {
            prop: 'name',
            name: 'Entity Name',
            width: 200,
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'hyperLink',
            headerClassFormat: 'headerCenter',
            cellClassFormat: 'cellCenter',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'fundid',
            name: 'Entity Id Ref',
            width: 120,
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'default',
            headerClassFormat: 'headerLeft',
            cellClassFormat: 'cellLeft',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'fundTicker',
            name: 'Entity Ticker',
            width: 120,
            draggable: true,
            canAutoResize: false,
            columnSetting: true,
            cellTemplate: 'default',
            headerClassFormat: 'headerLeft',
            cellClassFormat: 'cellLeft',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'classID',
            name: 'Class ID',
            width: 80,
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'default',
            headerClassFormat: 'headerLeft',
            cellClassFormat: 'cellLeft',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'sodNav',
            name: 'NAV Previous',
            width: 125,
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatLong',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'nav',
            name: 'NAV Current',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatLong',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'navChange',
            name: 'NAV Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatLong',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'navChangePercent',
            name: 'NAV % Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'percentFormat',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'sodTna',
            name: 'TNA Previous',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'tna',
            name: 'TNA Current',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'tnaChange',
            name: 'TNA Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'tnaChangePercent',
            name: 'TNA % Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'percentFormat',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'sodMv',
            name: 'MV Amt Base Previous',
            width: '200',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'fundmv',
            name: 'MV Amt Base',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellRight',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'fundmvChange',
            name: 'MV Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'numberFormatShort',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        },
        {
            prop: 'fundmvChangePercent',
            name: 'MV % Change',
            width: '',
            draggable: true,
            canAutoResize: true,
            columnSetting: true,
            cellTemplate: 'percentFormat',
            headerClassFormat: 'headerRight',
            cellClassFormat: 'cellNumber',
            treeToggleTemplate: 'columnHeaderMenu',
            frozenLeft: false,
            sortColumnAscOrDesc: '',
        }
    ];
    /** @type {?} */
    var columnMenuDropDownSetting$1 = [
        // {
        //   name: "Resize to Fit",
        //   type: "resizeToFit",
        //   hasSubMenu: false,
        // },
        {
            name: "Freeze Column",
            type: "freezeColumn",
            hasSubMenu: false,
        },
        {
            name: "Sort Column",
            type: "sortColumn",
            hasSubMenu: false,
        },
    ];

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var MainDatatableComponent = (function (_super) {
        __extends(MainDatatableComponent, _super);
        function MainDatatableComponent(cd, navService, appRegistry, appContext, navSocketService, dialog$$1, viewContainer, shareInforBewteenComponents, commonUtils, resourceManger) {
            var _this = _super.call(this) || this;
            _this.cd = cd;
            _this.navService = navService;
            _this.appRegistry = appRegistry;
            _this.appContext = appContext;
            _this.navSocketService = navSocketService;
            _this.dialog = dialog$$1;
            _this.viewContainer = viewContainer;
            _this.shareInforBewteenComponents = shareInforBewteenComponents;
            _this.commonUtils = commonUtils;
            _this.resourceManger = resourceManger;
            _this.rows = [];
            _this.childRows = [];
            _this.isDataAvailable = false;
            _this.isDataTablePaused = false;
            _this.rowHeight = 50;
            _this.alertData = [];
            _this.allRowsSelected = false;
            _this.isSelectedMap = [];
            _this.headerSetting = true;
            _this.headerHeight = 50;
            // temp data structure
            _this.customColumn = customColumn$1;
            _this.normalColumn = normalColumn$1;
            _this.columnMenuDropDownSetting = columnMenuDropDownSetting$1;
            _this.limit = 5;
            _this.footerHeight = 50;
            _this.headerCheckBox = true;
            return _this;
        }
        /**
         * @return {?}
         */
        MainDatatableComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                //reset component data and user validation;
                this.commonUtils.validateUser();
                this.subs = [];
                this.rows = [];
                this.isDataAvailable = false;
                this.subs.push(this.navService.getFundList().subscribe(function (data) {
                    _this.rows = _this.commonUtils.extractFundLevelData(data);
                    _this.childRows = _this.commonUtils.extractClassLevelData(data);
                    if (data.length > 0) {
                        //this.alertData = [...this.updateAlertData(this.rows)];
                        _this.alertData = __spread(_this.updateAlertDataAtClassLevel(data));
                        _this.isDataAvailable = true;
                        // seting position page default fund info if fundInfo is null
                        if (_this.shareInforBewteenComponents.fundInfo.length === 0) {
                            /** @type {?} */
                            var fundInfo = [];
                            fundInfo.push(data[0].fundid);
                            fundInfo.push(data[0].name);
                            fundInfo.push(data[0].fundTicker);
                            _this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
                        }
                    }
                    _this.rows = __spread(_this.rows);
                    _this.rows.forEach(function (row) {
                        _this.navSocketService.registerFunds([row['fundid']]);
                    });
                }));
                this.subs.push(this.navSocketService.getNav().subscribe(function (data) {
                    if (data['eventType'] === 'fundChange') {
                        /** @type {?} */
                        var fundLevelRow = _this.commonUtils.extractWSData(data["eventData"], false);
                        /** @type {?} */
                        var childLevelRow = _this.commonUtils.extractWSData(data["eventData"], true);
                        _this.updateRow(fundLevelRow);
                        childLevelRow.forEach(function (row) { return _this.updateRow(row); });
                    }
                    else if (data['eventType'] === 'sodChange') {
                        _this.doupdate(data["eventData"]);
                    }
                }));
                this.resourceManger.registInterval(function () { _this.rows = __spread(_this.rows); }, 300);
                this.shareInforBewteenComponents.hyperLinkNavigate.subscribe(function (data) {
                    console.log("hyperlink navigate");
                    console.log(data);
                    _this.hyperLinkNavigateTo(data);
                });
                this.shareInforBewteenComponents.openModalData.subscribe(function (data) {
                    _this.openAlertModal(data.rowData, data.type);
                });
                this.shareInforBewteenComponents.sortDatatableColumn.subscribe(function (data) {
                    _this.rows = __spread(_this.commonUtils.sortColumnByProp(_this.rows, _this.childRows, data.map, data.prop, data.ascFlag));
                });
            };
        /**
         * @return {?}
         */
        MainDatatableComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.rows.forEach(function (row) {
                    _this.navSocketService.unRegisterFunds([row['fundid']]);
                });
                this.subs.forEach(function (sub) { return sub.unsubscribe(); });
                this.resourceManger.cleanResources();
            };
        /**
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.updateRow = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
                    if (data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
                        /** @type {?} */
                        var alertObj = {
                            "name": data['fundid'],
                            "classID": data['classID'],
                            "alertType": data['alertType'],
                            "nav": data['nav'],
                            "marketval": data['fundmv'],
                            "value": data['navChangePercent'],
                            "fundmvChangePercent": data['fundmvChangePercent'],
                            "pricetime": data['pricetime'],
                        };
                        this.alertData.push(alertObj);
                        this.alertData = __spread(this.alertData);
                    }
                    this.doupdate(data);
                }
            };
        /**
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.doupdate = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                if (this.rows.length) {
                    /** @type {?} */
                    var fundId_1 = data['fundid'];
                    /** @type {?} */
                    var fundTicker_1 = data['fundTicker'];
                    /** @type {?} */
                    var classID_1 = data['classID'];
                    this.rows.forEach(function (item) {
                        if (item['fundid'] === fundId_1 && item['fundTicker'] === fundTicker_1 && item['classID'] === classID_1) {
                            _this.normalColumn.forEach(function (colItem) {
                                if (null != data[colItem.prop] && (['fundid', 'name', 'fundTicker', 'classID'].indexOf(colItem.prop) === -1)) {
                                    item[colItem.prop] = data[colItem.prop];
                                }
                            });
                            /** @type {?} */
                            var counts = _this.getAlertCounts(fundId_1, classID_1, _this.alertData);
                            item['redAlert'] = counts[0];
                            item['yellowAlert'] = counts[1];
                        }
                    });
                }
            };
        /**
         * @param {?} fundid
         * @param {?} classID
         * @param {?} alerts
         * @return {?}
         */
        MainDatatableComponent.prototype.getAlertCounts = /**
         * @param {?} fundid
         * @param {?} classID
         * @param {?} alerts
         * @return {?}
         */
            function (fundid, classID, alerts) {
                /** @type {?} */
                var counts = [0, 0];
                alerts.forEach(function (alert) {
                    if (alert['name'] === fundid && alert['classID'] === classID) {
                        if (alert['alertType'] === 2) {
                            counts[0] += 1;
                        }
                        if (alert['alertType'] === 1) {
                            counts[1] += 1;
                        }
                    }
                });
                //console.log("alert counts for fund :"+fundid+" class:"+classID+" counts for type 1:"+counts[0] +" counts for type 1:"+counts[1]);
                return counts;
            };
        /**
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.updateAlertDataAtClassLevel = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                var _this = this;
                /** @type {?} */
                var alertAry = [];
                /** @type {?} */
                var fundLevelData = (((data))).map(function (d) {
                    for (var key in d.classLevelTrialData) {
                        alertAry = alertAry.concat(_this.filterAlertDataByClass(d.fundid, key, d.classLevelTrialData[key].priceChanges));
                    }
                });
                return alertAry;
            };
        // colllects the alert data from getFundList call
        // colllects the alert data from getFundList call
        /**
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.updateAlertData =
            // colllects the alert data from getFundList call
            /**
             * @param {?} data
             * @return {?}
             */
            function (data) {
                var _this = this;
                /** @type {?} */
                var alertAry = [];
                data.forEach(function (item) {
                    alertAry = alertAry.concat(_this.filterAlertData(item['fundid'], item['priceChanges']));
                });
                return alertAry;
            };
        /**
         * @param {?} fundID
         * @param {?} classID
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.filterAlertDataByClass = /**
         * @param {?} fundID
         * @param {?} classID
         * @param {?} data
         * @return {?}
         */
            function (fundID, classID, data) {
                var _this = this;
                /** @type {?} */
                var tempAlertCricleData = [];
                data.forEach(function (item) {
                    if (_this.commonUtils.isValidTime(new Date(item['pricetime']))
                        && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                        /** @type {?} */
                        var alertObj = {
                            "name": fundID,
                            "classID": classID,
                            "alertType": item['alertType'],
                            "nav": item['nav'],
                            "marketval": item['fundmv'],
                            "value": item['navChangePercent'],
                            "fundmvChangePercent": item['fundmvChangePercent'],
                            "pricetime": item['pricetime'],
                        };
                        tempAlertCricleData.push(alertObj);
                    }
                });
                return tempAlertCricleData;
            };
        /**
         * @param {?} fundID
         * @param {?} data
         * @return {?}
         */
        MainDatatableComponent.prototype.filterAlertData = /**
         * @param {?} fundID
         * @param {?} data
         * @return {?}
         */
            function (fundID, data) {
                var _this = this;
                /** @type {?} */
                var tempAlertCricleData = [];
                data.forEach(function (item) {
                    if (_this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                        /** @type {?} */
                        var alertObj = {
                            "name": fundID,
                            "alertType": item['alertType'],
                            "nav": item['nav'],
                            "marketval": item['fundmv'],
                            "value": item['navChangePercent'],
                            "fundmvChangePercent": item['fundmvChangePercent'],
                            "pricetime": item['pricetime'],
                        };
                        tempAlertCricleData.push(alertObj);
                    }
                });
                return tempAlertCricleData;
            };
        /**
         * @param {?} row
         * @param {?} type
         * @return {?}
         */
        MainDatatableComponent.prototype.openAlertModal = /**
         * @param {?} row
         * @param {?} type
         * @return {?}
         */
            function (row, type) {
                /** @type {?} */
                var dialogRef = this.dialog.open(CustomAlertModalComponent, {
                    width: '680px',
                    data: {
                        "type": type === 'yellowAlert' ? '' : 'Critical',
                        "now": new Date() > this.commonUtils.endTime ? this.commonUtils.endTime : new Date(),
                        "title": row['name'] + " class-" + row['classID'],
                        "fundId": row['fundid'],
                        "alertData": this.getAlertDataForFundByClass(row['fundid'], row['classID'], type === 'yellowAlert' ? 1 : 2)
                    }
                });
                //    console.log("length fund:"+row+"class: alerttype:");  
                dialogRef.afterClosed().subscribe(function (result) {
                    console.log('The dialog was closed');
                });
            };
        /**
         * @param {?} fundId
         * @param {?} classID
         * @param {?} alertType
         * @return {?}
         */
        MainDatatableComponent.prototype.getAlertDataForFundByClass = /**
         * @param {?} fundId
         * @param {?} classID
         * @param {?} alertType
         * @return {?}
         */
            function (fundId, classID, alertType) {
                /** @type {?} */
                var alertDataForFund = [];
                this.alertData.forEach(function (item) {
                    if (item['name'] === fundId
                        && item['classID'] === classID
                        && item['alertType'] === alertType) {
                        alertDataForFund.push(item);
                    }
                });
                console.log("Fund:" + fundId + ",class:" + classID + ",count:" + alertDataForFund.length);
                return alertDataForFund.reverse();
            };
        /**
         * @param {?} fundId
         * @param {?} alertType
         * @return {?}
         */
        MainDatatableComponent.prototype.getAlertDataForFund = /**
         * @param {?} fundId
         * @param {?} alertType
         * @return {?}
         */
            function (fundId, alertType) {
                /** @type {?} */
                var alertDataForFund = [];
                this.alertData.forEach(function (item) {
                    if (item['name'] === fundId && item['alertType'] === alertType) {
                        alertDataForFund.push(item);
                    }
                });
                return alertDataForFund.reverse();
            };
        /**
         * @param {?} row
         * @return {?}
         */
        MainDatatableComponent.prototype.hyperLinkNavigateTo = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                /** @type {?} */
                var fundInfo = [];
                /** @type {?} */
                var fundID = row['fundid'];
                fundInfo.push(fundID);
                /** @type {?} */
                var fundName = row['name'];
                fundInfo.push(fundName);
                fundInfo.push(row['fundTicker']);
                this.nagativateToPosition(fundInfo);
            };
        /**
         * @param {?} fundInfo
         * @return {?}
         */
        MainDatatableComponent.prototype.nagativateToPosition = /**
         * @param {?} fundInfo
         * @return {?}
         */
            function (fundInfo) {
                this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
                this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-002');
            };
        /**
         * @return {?}
         */
        MainDatatableComponent.prototype.getAllRowsDisabled = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var list = this.shareInforBewteenComponents.getFundList();
                /** @type {?} */
                var disableAll = true;
                list.forEach(function (item) {
                    if (item.checked)
                        disableAll = false;
                });
                return disableAll;
            };
        /**
         * @param {?} row
         * @return {?}
         */
        MainDatatableComponent.prototype.getSingleRowDisabled = /**
         * @param {?} row
         * @return {?}
         */
            function (row) {
                /** @type {?} */
                var list = this.shareInforBewteenComponents.getFundList();
                /** @type {?} */
                var disableSingleRow = true;
                list.forEach(function (item) {
                    if (item.checked && item.fundID === row['fundid'] && row.child === "parent")
                        disableSingleRow = false;
                });
                return disableSingleRow;
            };
        /**
         * @param {?} rows
         * @return {?}
         */
        MainDatatableComponent.prototype.getAllRowChecked = /**
         * @param {?} rows
         * @return {?}
         */
            function (rows) {
                var _this = this;
                /** @type {?} */
                var list = this.shareInforBewteenComponents.getFundList().filter(function (item) { return item.checked; });
                /** @type {?} */
                var tempFlag = true;
                /** @type {?} */
                var noFundShowInChart = list.length === 0 ? true : false;
                if (list.length > this.isSelectedMap.length) {
                    tempFlag = false;
                }
                else {
                    list.forEach(function (item) {
                        _this.isSelectedMap.forEach(function (s) {
                            if (item.fundTicker === s.name && !s.checked) {
                                tempFlag = false;
                            }
                        });
                        if (_this.isSelectedMap.length === 0)
                            tempFlag = false;
                    });
                }
                this.allRowsSelected = noFundShowInChart ? !noFundShowInChart : tempFlag;
                return this.allRowsSelected;
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        MainDatatableComponent.prototype.getSingleRowChecked = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                var _this = this;
                /** @type {?} */
                var isChecked = false;
                this.isSelectedMap.forEach(function (item) {
                    if (item.name === fund) {
                        isChecked = _this.shareInforBewteenComponents.getFundList().find(function (list) { return (list.fundTicker === fund && list.checked); }) ? item.checked : false;
                        item.checked = _this.shareInforBewteenComponents.getFundList().find(function (list) { return (list.fundTicker === fund && list.checked); }) ? item.checked : false;
                    }
                });
                return isChecked;
            };
        /**
         * @param {?} checked
         * @param {?} rows
         * @return {?}
         */
        MainDatatableComponent.prototype.onSelectAll = /**
         * @param {?} checked
         * @param {?} rows
         * @return {?}
         */
            function (checked, rows) {
                var _this = this;
                this.allRowsSelected = checked;
                rows.forEach(function (item) {
                    /** @type {?} */
                    var obj = {
                        name: item.fundTicker,
                        checked: _this.shareInforBewteenComponents.getFundList().find(function (list) { return (list.fundID === item.fundid && list.checked); }) ? checked : false
                    };
                    if (!_this.isSelectedMap.find(function (s) { return s.name === item.fundTicker; })) {
                        _this.isSelectedMap.push(obj);
                    }
                    else {
                        /** @type {?} */
                        var i = _this.isSelectedMap.findIndex(function (s) { return s.name === item.fundTicker; });
                        _this.isSelectedMap[i]['checked'] = _this.shareInforBewteenComponents.getFundList().find(function (list) { return (list.fundID === item.fundid && list.checked); }) ? checked : false;
                    }
                });
                // this.setHighLightActiveEntries(this.isSelectedMap);
                /** @type {?} */
                var activeEntries = [];
                this.isSelectedMap.forEach(function (item) {
                    if (item.checked) {
                        activeEntries.push({ name: item.name });
                    }
                });
                this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
            };
        /**
         * @param {?} fund
         * @return {?}
         */
        MainDatatableComponent.prototype.onCheckboxChange = /**
         * @param {?} fund
         * @return {?}
         */
            function (fund) {
                if (this.isSelectedMap.length > 0 && this.isSelectedMap.find(function (s) { return s.name === fund; })) {
                    /** @type {?} */
                    var i = this.isSelectedMap.findIndex(function (s) { return s.name === fund; });
                    this.isSelectedMap[i]['checked'] = !this.isSelectedMap[i]['checked'];
                    if (this.isSelectedMap[i]['checked']) {
                        this.allRowsSelected = false;
                    }
                }
                else {
                    /** @type {?} */
                    var obj = {
                        name: fund,
                        checked: true
                    };
                    this.isSelectedMap.push(obj);
                }
                // this.setHighLightActiveEntries(this.isSelectedMap);
                /** @type {?} */
                var activeEntries = [];
                this.isSelectedMap.forEach(function (item) {
                    if (item.checked) {
                        activeEntries.push({ name: item.name });
                    }
                });
                this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
            };
        /**
         * @param {?} selectedMap
         * @return {?}
         */
        MainDatatableComponent.prototype.setHighLightActiveEntries = /**
         * @param {?} selectedMap
         * @return {?}
         */
            function (selectedMap) {
                /** @type {?} */
                var activeEntries = [];
                selectedMap.forEach(function (item) {
                    if (item.checked) {
                        activeEntries.push({ name: item.name });
                    }
                });
                this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
            };
        /**
         * @param {?} e
         * @return {?}
         */
        MainDatatableComponent.prototype.onClickedOutside = /**
         * @param {?} e
         * @return {?}
         */
            function (e) {
                this.shareInforBewteenComponents.clickedOutSide.emit(e);
            };
        /**
         * @return {?}
         */
        MainDatatableComponent.prototype.togglePauseFlag = /**
         * @return {?}
         */
            function () {
                this.isDataTablePaused = !this.isDataTablePaused;
            };
        MainDatatableComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-main-datatable',
                        template: "<div class=\"datatableContainer\" *ngIf=\"isDataAvailable\" (clickOutside)=\"onClickedOutside($event)\">\n\n  <div class=\"live-time-for-title\">\n    <p *ngIf=\"commonUtils.isAfterMarketClose else elseBlock\">Final Data (\n      {{commonUtils.liveTime | date:\"MM/dd/yyyy, h:mm aaaaa'm'\"}} )</p>\n    <ng-template #elseBlock>\n      <p>\n        Real Time Data ({{commonUtils.liveTime | date:\"MM/dd/yyyy, h:mm aaaaa'm'\"}})\n      </p>\n    </ng-template>\n  </div>\n  \n<lib-common-data-table\n[headerSetting]=\"headerSetting\"\n[isDataTablePaused]=\"isDataTablePaused\"\n[headerHeight]=\"headerHeight\"\n[rows]=\"rows\"\n[childRows]=\"childRows\"\n[alertData]=\"alertData\"\n[rowHeight]=\"rowHeight\"\n[customColumn]=\"customColumn\"\n[normalColumn]=\"normalColumn\"\n[limit]=\"limit\"\n[footerHeight]=\"footerHeight\"\n[headerCheckBox]=\"headerCheckBox\"\n[getAllRowsDisabled]=\"getAllRowsDisabled\"\n[getSingleRowDisabled]=\"getSingleRowDisabled\"\n[getAllRowChecked]=\"getAllRowChecked\"\n[getSingleRowChecked]=\"getSingleRowChecked\"\n[onSelectAll]=\"onSelectAll\"\n[onCheckboxChange]=\"onCheckboxChange\"\n[allRowsSelected]=\"allRowsSelected\"\n[columnMenuDropDownSetting]='columnMenuDropDownSetting'\n[defaultSortCol]=\"'fundid'\"\n(togglePauseFlagEvent)=\"togglePauseFlag()\"\n>\n</lib-common-data-table>\n</div>",
                        styles: [".ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:\" \";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:\"\";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:\"\";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}", ".datatableContainer .live-time-for-title{position:absolute;top:2px;left:15px;font-size:16px;font-family:DINNextLTPro-Medium;color:#464646}"],
                        encapsulation: i0.ViewEncapsulation.None
                    },] },
        ];
        MainDatatableComponent.ctorParameters = function () {
            return [
                { type: i0.ChangeDetectorRef },
                { type: NavService },
                { type: uiCommon.AppRegistry },
                { type: uiCommon.AppContext },
                { type: NavSocketService },
                { type: material.MatDialog },
                { type: i0.ViewContainerRef },
                { type: ShareInfoBeweenComponentsService },
                { type: CommonUtilsService },
                { type: ResourceManagerService }
            ];
        };
        return MainDatatableComponent;
    }(uiCommon.BaseWidgetComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */
    var UiQNavModule = (function () {
        function UiQNavModule(appRegistry) {
            this.appRegistry = appRegistry;
            this.permissions = ['Application/navdeveloper', 'Application/navanalyst'];
            appRegistry.registerComponent('lineChart', QnavLineChartComponent);
            appRegistry.registerComponent('liveDataTable', MainDatatableComponent);
            appRegistry.registerComponent('livePosition', QnavPositionComponent);
            appRegistry.registerComponent('positionHeatMap', PositionHeatMapComponent);
            appRegistry.registerComponent('positionFundSummary', PositionFundSummaryComponent);
            appRegistry.registerDashboard('QNAV-001', 'QNAV Entity List', [
                { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'lineChart', title: null, showHeader: true },
                { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'liveDataTable', title: null, showHeader: true }
            ], true, true, 'qnf', 'QNAV', this.permissions);
            appRegistry.registerDashboard('QNAV-002', 'QNAV Position', [
                { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'positionHeatMap', title: null, showHeader: true },
                // { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'positionFundSummary', title: null, showHeader: true },
                { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'livePosition', title: null, showHeader: true }
            ], true, true, 'qnp', 'QNAV', this.permissions);
        }
        /**
         * @param {?} environment
         * @return {?}
         */
        UiQNavModule.forRoot = /**
         * @param {?} environment
         * @return {?}
         */
            function (environment) {
                return {
                    ngModule: UiQNavModule,
                    providers: [
                        {
                            provide: 'env',
                            useValue: environment
                        }
                    ]
                };
            };
        UiQNavModule.decorators = [
            { type: i0.NgModule, args: [{
                        imports: [
                            animations$1.BrowserAnimationsModule,
                            material.MatButtonModule,
                            material.MatCheckboxModule,
                            uiCommon.UiCommonModule,
                            ngDynamicComponent.DynamicModule.withComponents([
                                QnavLineChartComponent,
                                MainDatatableComponent,
                                QnavPositionComponent,
                                PositionHeatMapComponent,
                                PositionFundSummaryComponent
                            ]),
                            ngxDatatable.NgxDatatableModule,
                            ngxCharts.NgxChartsModule,
                            chips.MatChipsModule,
                            material.MatIconModule,
                            i1.HttpClientModule,
                            dialog.MatDialogModule,
                            menu.MatMenuModule,
                            ngClickOutside.ClickOutsideModule
                        ],
                        declarations: [
                            QnavLineChartComponent,
                            LineChartComponent,
                            CustomLegendComponent,
                            QnavPositionComponent,
                            PercentFormatPipe,
                            NumberRoundUpPipe,
                            CustomAlertModalComponent,
                            AddFundModalComponent,
                            PositionHeatMapComponent,
                            HeatMapComponent,
                            PositionFundSummaryComponent,
                            SingleLineChartComponent,
                            CommonDataTableComponent,
                            MainDatatableComponent
                        ],
                        providers: [common.DatePipe, uiCommon.AppRegistry],
                        exports: [
                            QnavLineChartComponent,
                            QnavPositionComponent,
                            PositionHeatMapComponent,
                            PositionFundSummaryComponent,
                            MainDatatableComponent
                        ],
                        entryComponents: [
                            QnavLineChartComponent,
                            QnavPositionComponent,
                            CustomAlertModalComponent,
                            AddFundModalComponent,
                            PositionHeatMapComponent,
                            PositionFundSummaryComponent,
                            MainDatatableComponent
                        ]
                    },] },
        ];
        UiQNavModule.ctorParameters = function () {
            return [
                { type: uiCommon.AppRegistry }
            ];
        };
        return UiQNavModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
     */

    exports.UiQNavModule = UiQNavModule;
    exports.CustomLegendComponent = CustomLegendComponent;
    exports.LineChartComponent = LineChartComponent;
    exports.CommonDataTableComponent = CommonDataTableComponent;
    exports.ɵn = AddFundModalComponent;
    exports.ɵm = CustomAlertModalComponent;
    exports.ɵo = HeatMapComponent;
    exports.ɵg = MainDatatableComponent;
    exports.ɵl = NumberRoundUpPipe;
    exports.ɵk = PercentFormatPipe;
    exports.ɵj = PositionFundSummaryComponent;
    exports.ɵi = PositionHeatMapComponent;
    exports.ɵa = QnavLineChartComponent;
    exports.ɵh = QnavPositionComponent;
    exports.ɵe = CommonUtilsService;
    exports.ɵb = NavService;
    exports.ɵc = NavSocketService;
    exports.ɵf = ResourceManagerService;
    exports.ɵd = ShareInfoBeweenComponentsService;
    exports.ɵp = SingleLineChartComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib21uaWEtdWktcW5hdi51bWQuanMubWFwIiwic291cmNlcyI6W251bGwsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbGluZS1jaGFydC9saW5lLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2N1c3RvbS1sZWdlbmQvY3VzdG9tLWxlZ2VuZC5jb21wb25lbnQudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9zZXJ2aWNlcy9uYXYtc2VydmljZS5zZXJ2aWNlLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbW9kZWwvcW5hdi50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL25hdi1zb2NrZXQuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3FuYXYtcG9zaXRpb24vY29sdW1uLWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9xbmF2LXBvc2l0aW9uL3FuYXYtcG9zaXRpb24uY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvYWRkLWZ1bmQtbW9kYWwvYWRkLWZ1bmQtbW9kYWwuY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvY29sb3JzLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvcW5hdi1saW5lLWNoYXJ0LW9sZC9saW5lLWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9xbmF2LWxpbmUtY2hhcnQtb2xkL3FuYXYtbGluZS1jaGFydC5jb21wb25lbnQudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9waXBlL3BlcmNlbnQtZm9ybWF0LnBpcGUudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9waXBlL251bWJlci1yb3VuZHVwLnBpcGUudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9jdXN0b20tYWxlcnQtbW9kYWwvY3VzdG9tLWFsZXJ0LW1vZGFsLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3Bvc2l0aW9uLWhlYXQtbWFwL3Bvc2l0aW9uLWhlYXQtbWFwLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2hlYXQtbWFwL2hlYXQtbWFwLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3Bvc2l0aW9uLWZ1bmQtc3VtbWFyeS9wb3NpdGlvbi1zdW1tYXJ5LWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9wb3NpdGlvbi1mdW5kLXN1bW1hcnkvcG9zaXRpb24tZnVuZC1zdW1tYXJ5LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NpbmdsZS1saW5lLWNoYXJ0L3NpbmdsZS1saW5lLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2NvbW1vbi1kYXRhLXRhYmxlL2NvbW1vbi1kYXRhLXRhYmxlLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL21haW4tZGF0YXRhYmxlL2NvbHVtbi1kYXRhLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbWFpbi1kYXRhdGFibGUvbWFpbi1kYXRhdGFibGUuY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvdWktcW5hdi5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UgKi9cclxuXHJcbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcclxuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XHJcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgaXNEYXRlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL3NyYy9pMThuL2Zvcm1hdF9kYXRlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlIHtcclxuICBwdWJsaWMgYWNjZXNzVG9rZW47XHJcbiAgcHVibGljIGZ1bmRJbmZvIDogYW55ID0gW107XHJcbiAgcHJpdmF0ZSB2YXJpYWJsZUZ1bmRMaXN0OiBhbnkgPSBbXTtcclxuICBwdWJsaWMgY29sb3JTY2hlbWE6IGFueVtdID0gW107XHJcbiAgcHVibGljIGhpZ2hMaWdodEFjdGl2ZUVudHJpZXM6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3ICBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gIHB1YmxpYyBjbGlja2VkT3V0U2lkZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgIEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgLy8gZGF0YS10YWJsZSBjb21wb25lbnRzIGRhdGEgY29tbXVuaWNhdGlvblxyXG4gIHB1YmxpYyBoeXBlckxpbmtOYXZpZ2F0ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuICBwdWJsaWMgb3Blbk1vZGFsRGF0YTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuICBwdWJsaWMgc29ydERhdGF0YWJsZUNvbHVtbjogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgcHVibGljIHNhdmVQb3NpdGlvbkRldGFpbHNGdW5kSW5mbyhmdW5kSW5mbykge1xyXG4gICAgdGhpcy5mdW5kSW5mbyA9IGZ1bmRJbmZvO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHNldFZhcmlhYmxlRnVuZExpc3QoZGF0YSkge1xyXG4gICAgdGhpcy52YXJpYWJsZUZ1bmRMaXN0ID0gZGF0YTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBzZXRDb2xvclNjaGVtYShjb2xvclNjaGVtYSA6IGFueVtdKSB7XHJcbiAgICB0aGlzLmNvbG9yU2NoZW1hID0gY29sb3JTY2hlbWE7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0RnVuZExpc3QoKSA6IGFueVtde1xyXG4gICAgcmV0dXJuIHRoaXMudmFyaWFibGVGdW5kTGlzdDtcclxuICB9XHJcbiAgcHVibGljIHJlc2V0KCkge1xyXG4gICAgdGhpcy5mdW5kSW5mbyA9IFtdO1xyXG4gICAgdGhpcy52YXJpYWJsZUZ1bmRMaXN0ID0gW107XHJcbiAgICB0aGlzLmNvbG9yU2NoZW1hID0gW107XHJcbiAgICB0aGlzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMgPSBuZXcgIEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgICB0aGlzLmh5cGVyTGlua05hdmlnYXRlID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgICB0aGlzLm9wZW5Nb2RhbERhdGEgPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuICAgIHRoaXMuc29ydERhdGF0YWJsZUNvbHVtbiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvc2hhcmUtaW5mby1iZXdlZW4tY29tcG9uZW50cy5zZXJ2aWNlJztcclxuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIENvbW1vblV0aWxzU2VydmljZSB7XHJcbiAgc3RhcnRUaW1lOiBEYXRlID0gbmV3IERhdGUoKTtcclxuICBlbmRUaW1lOiBEYXRlID0gbmV3IERhdGUoKTtcclxuICB0aW1lRGl2aXNpb246IERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gIGxpdmVUaW1lOiBEYXRlID0gbmV3IERhdGUoKTtcclxuICBpc0FmdGVyTWFya2V0Q2xvc2U6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50czogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2VcclxuICApIHtcclxuICAgIHRoaXMuc3RhcnRUaW1lLnNldEhvdXJzKDksIDMwLCAwLCAwKTtcclxuICAgIHRoaXMuZW5kVGltZS5zZXRIb3VycygxNiwgMzAsIDAsIDApO1xyXG4gICAgdGhpcy50aW1lRGl2aXNpb24uc2V0SG91cnMoMTUsIDMwLCAwLCAwKTtcclxuICAgIGxldCBpbnN0YW5jZSA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgaWYgKG5ldyBEYXRlKCkgPCB0aGlzLmVuZFRpbWUpIHtcclxuICAgICAgICB0aGlzLmxpdmVUaW1lID0gbmV3IERhdGUoKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMubGl2ZVRpbWUgPSB0aGlzLmVuZFRpbWU7XHJcbiAgICAgICAgY2xlYXJJbnRlcnZhbChpbnN0YW5jZSk7XHJcbiAgICAgIH1cclxuICAgIH0sIDEwMDApO1xyXG4gICAgdGhpcy5pc0FmdGVyTWFya2V0Q2xvc2UgPSB0aGlzLmlzQWZ0ZXJNYXJrZXRDb2xzZSh0aGlzLmxpdmVUaW1lKTtcclxuICB9XHJcbiAgaXNBZnRlck1hcmtldENvbHNlKHRpbWU6IERhdGUpOiBib29sZWFuIHtcclxuICAgIGlmICggdGltZSA8PSB0aGlzLmVuZFRpbWUpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIGlzQmVmb3JlTWFya2V0T3Blbih0aW1lOiBEYXRlKTogYm9vbGVhbiB7XHJcbiAgICBpZiAoIHRpbWUgPj0gdGhpcy5zdGFydFRpbWUpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG5cclxuICBpc1ZhbGlkVGltZSh0aW1lOiBEYXRlKTogYm9vbGVhbiB7XHJcblxyXG4gICAgaWYgKHRpbWUgPj0gdGhpcy5zdGFydFRpbWUgJiYgdGltZSA8PSB0aGlzLmVuZFRpbWUpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgaXNCZXlvbmREaXZpc2lvbih0aW1lOiBEYXRlKTogYm9vbGVhbiB7XHJcbiAgICBpZiAodGltZSA+PSB0aGlzLnRpbWVEaXZpc2lvbikge1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBnZXRSYW5kb21Db2xvcigpIHtcclxuICAgIGNvbnN0IGxldHRlcnMgPSAnMDEyMzQ1Njc4OUFCQ0RFRic7XHJcbiAgICBsZXQgY29sb3IgPSAnIyc7XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDY7IGkrKykge1xyXG4gICAgICBjb2xvciArPSBsZXR0ZXJzW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDE2KV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gY29sb3I7XHJcbiAgfVxyXG4gIFxyXG4gIHB1YmxpYyBnZXRDb2xvckZvckZ1bmQoZnVuZGlkOiBTdHJpbmcpIHtcclxuICAgIHRoaXMucmVzZXRDb2xvckZvckZ1bmQoZnVuZGlkKTtcclxuICAgIGZvciAobGV0IGl0ZW0gb2YgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuY29sb3JTY2hlbWEpIHtcclxuICAgICAgaWYgKGl0ZW1bJ2Z1bmRpZCddID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBpdGVtWydmdW5kaWQnXSA9IGZ1bmRpZDtcclxuICAgICAgICByZXR1cm4gaXRlbVsnY29sb3InXTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMuZ2V0UmFuZG9tQ29sb3IoKTtcclxuXHJcbiAgfVxyXG4gIHB1YmxpYyByZXNldENvbG9yRm9yRnVuZChmdW5kaWQ6IFN0cmluZykge1xyXG4gICAgZm9yIChsZXQgaXRlbSBvZiB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5jb2xvclNjaGVtYSkge1xyXG4gICAgICBpZiAoaXRlbVsnZnVuZGlkJ10gPT09IGZ1bmRpZCkge1xyXG4gICAgICAgIGl0ZW1bJ2Z1bmRpZCddID0gdW5kZWZpbmVkO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgdXBkYXRlRnVuZFN0YXR1cyhmdW5kaWQ6IFN0cmluZywgaXNDaGVja2VkOiBib29sZWFuKSB7XHJcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmluZEluZGV4KGVsZW1lbnQgPT4gZWxlbWVudC5mdW5kSUQgPT09IGZ1bmRpZCk7XHJcbiAgICBpZiAoaXNDaGVja2VkID09PSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpW2luZGV4XVsnY2hlY2tlZCddKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KClbaW5kZXhdWydjaGVja2VkJ10gPSBpc0NoZWNrZWQ7XHJcbiAgICAvL3JlbW92ZSB0aGUgY29sb3IgZm9yIHRoZSBmdW5kIGFzIHdlbGxcclxuICAgIGlmIChpc0NoZWNrZWQgPT09IGZhbHNlKSB7XHJcbiAgICAgIHRoaXMucmVzZXRDb2xvckZvckZ1bmQoZnVuZGlkKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuZ2V0Q29sb3JGb3JGdW5kKGZ1bmRpZCk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgcHVibGljIGZvcm1hdFRpbWUodGltZTogRGF0ZSk6IHN0cmluZyB7XHJcbiAgICBsZXQgdCA9IG5ldyBEYXRlKHRpbWUpO1xyXG4gICAgbGV0IHNlY29uZCA9ICcwMCc7XHJcbiAgICBpZiAodC5nZXRTZWNvbmRzKCkgPD0gMjApIHtcclxuICAgICAgc2Vjb25kID0gJzAwJztcclxuICAgIH0gZWxzZSBpZiAodC5nZXRTZWNvbmRzKCkgPiAyMCAmJiB0LmdldFNlY29uZHMoKSA8PSA0MCkge1xyXG4gICAgICBzZWNvbmQgPSAnMjAnO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2Vjb25kID0gJzQwJztcclxuICAgIH1cclxuICAgIHJldHVybiAoXCIwXCIgKyB0LmdldEhvdXJzKCkpLnNsaWNlKC0yKSArICc6JyArIChcIjBcIiArIHQuZ2V0TWludXRlcygpKS5zbGljZSgtMikgKyAnOicgKyBzZWNvbmQ7XHJcbiAgfVxyXG4gIHB1YmxpYyBmb3JtYXREYXRlVGltZSh0aW1lKTogRGF0ZSB7XHJcbiAgICBsZXQgdCA9IG5ldyBEYXRlKHRpbWUpO1xyXG4gICAgbGV0IHNlY29uZCA9ICcwMCc7XHJcbiAgICBpZiAodC5nZXRTZWNvbmRzKCkgPD0gMjApIHtcclxuICAgICAgdC5zZXRTZWNvbmRzKDApO1xyXG4gICAgICB0LnNldE1pbGxpc2Vjb25kcygwKTtcclxuICAgIH0gZWxzZSBpZiAodC5nZXRTZWNvbmRzKCkgPiAyMCAmJiB0LmdldFNlY29uZHMoKSA8PSA0MCkge1xyXG4gICAgICB0LnNldFNlY29uZHMoMjApO1xyXG4gICAgICB0LnNldE1pbGxpc2Vjb25kcygwKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHQuc2V0U2Vjb25kcyg0MCk7XHJcbiAgICAgIHQuc2V0TWlsbGlzZWNvbmRzKDApO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHQ7XHJcbiAgfVxyXG4gIC8vcmVzdCBjb21wb25lbnQgc2hhcmVkIGluZm9ybWF0aW9uIGlmIGxvZ2luIHVzZXIvYXV0aG9yaXplZCB0b2tlbiBjaGFuZ2VkXHJcbiAgcHVibGljIHZhbGlkYXRlVXNlcigpIHtcclxuICAgIGlmKHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmFjY2Vzc1Rva2VuKSB7XHJcbiAgICAgIGlmKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ2FjY2Vzc190b2tlbicpID09PSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5hY2Nlc3NUb2tlbikge1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5yZXNldCgpO1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuYWNjZXNzVG9rZW4gPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdhY2Nlc3NfdG9rZW4nKTtcclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBleHRyYWN0RnVuZExldmVsRGF0YShkYXRhKSB7XHJcbiAgICBjb25zdCBmdW5kTGV2ZWxEYXRhID0gKGRhdGEgYXMgYW55W10pLm1hcChkID0+IHtcclxuICAgICAgICAgIGNvbnN0IHJvd1RlbXAgPSB7XHJcbiAgICAgICAgICAgICAgLy9mdW5kaWQ6IGQuZnVuZGlkLFxyXG4gICAgICAgICAgICAgIGZ1bmRpZDogZC5mdW5kaWQsXHJcbiAgICAgICAgICAgICAgbWFza2VkSWQ6IGQubWFza2VkSWQsXHJcbiAgICAgICAgICAgICAgbmFtZTogZC5uYW1lLFxyXG4gICAgICAgICAgICAgIGNsYXNzSUQ6IFwiQVwiLFxyXG4gICAgICAgICAgICAgIGNoaWxkOiBcInBhcmVudFwiLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBtdWx0aUNsYXNzRGF0YSA9IGQuY2xhc3NMZXZlbFRyaWFsRGF0YTtcclxuICAgICAgICAgICAgY29uc3Qgcm93ID0gT2JqZWN0LmFzc2lnbihyb3dUZW1wLCBtdWx0aUNsYXNzRGF0YS5BKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJvdztcclxuICAgICAgICAgIH0pO1xyXG4gICAgcmV0dXJuIGZ1bmRMZXZlbERhdGE7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZXh0cmFjdENsYXNzTGV2ZWxEYXRhKGRhdGEpIHtcclxuICAgIGNvbnN0IGNsYXNzTGV2ZWxEYXRhID0gW107XHJcbiAgICAoZGF0YSBhcyBhbnlbXSkuZm9yRWFjaChkID0+IHtcclxuICAgICAgICAgICBjb25zdCByb3dUZW1wID0ge1xyXG4gICAgICAgICAgICAvL2Z1bmRpZDogZC5mdW5kaWQsXHJcbiAgICAgICAgICAgIGZ1bmRpZDogZC5mdW5kaWQsXHJcbiAgICAgICAgICAgIG1hc2tlZElkOiBkLm1hc2tlZElkLFxyXG4gICAgICAgICAgICBuYW1lOiBkLm5hbWUsXHJcbiAgICAgICAgICAgIGNoaWxkOiBcImNoaWxkXCIsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgY29uc3QgbXVsdGlDbGFzc0RhdGEgPSBkLmNsYXNzTGV2ZWxUcmlhbERhdGE7XHJcbiAgICAgICAgICBmb3IobGV0IGtleSBpbiBtdWx0aUNsYXNzRGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoa2V5ICE9PSBcIkFcIikge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGNoaWxkUm93ID0gT2JqZWN0LmFzc2lnbihyb3dUZW1wLCBtdWx0aUNsYXNzRGF0YVtrZXldLCB7Y2xhc3NJRDoga2V5fSk7XHJcbiAgICAgICAgICAgICAgY2xhc3NMZXZlbERhdGEucHVzaChfLmNsb25lRGVlcChjaGlsZFJvdykpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gY2xhc3NMZXZlbERhdGEucmV2ZXJzZSgpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGV4dHJhY3RXU0RhdGEoZGF0YSxjaGlsZE9yTm90KSB7XHJcbiAgICBsZXQgcmV0dXJuRGF0YSA9IFtdO1xyXG4gICAgY29uc3QgdGVtcCA9IHtcclxuICAgICAgY3VzaXA6IGRhdGEuY3VzaXAsXHJcbiAgICAgIGV4Y2hhbmdlUmF0ZTogZGF0YS5leGNoYW5nZVJhdGUsXHJcbiAgICAgIC8vZnVuZGlkOiBkYXRhLmZ1bmRpZCxcclxuICAgICAgZnVuZGlkOiBkYXRhLmZ1bmRpZCxcclxuICAgICAgbG9uZ1Nob3J0SW5kaWNhdG9yOiBkYXRhLmxvbmdTaG9ydEluZGljYXRvcixcclxuICAgICAgbXY6IGRhdGEubXYsXHJcbiAgICAgIG12Q2hhbmdlOiBkYXRhLm12Q2hhbmdlLFxyXG4gICAgICBuYXZJbXBhY3Q6IGRhdGEubmF2SW1wYWN0LFxyXG4gICAgICBwcmljZTogZGF0YS5wcmljZSxcclxuICAgICAgcHJpY2VDaGFuZ2VQZXJjZW50OiBkYXRhLnByaWNlQ2hhbmdlUGVyY2VudCxcclxuICAgICAgc29kTXY6IGRhdGEuc29kTXYsXHJcbiAgICAgIHNvZFByaWNlOiBkYXRhLnNvZFByaWNlLFxyXG4gICAgICB1cGRhdGV0aW1lOiBkYXRhLnVwZGF0ZXRpbWVcclxuICAgIH1cclxuICAgIGlmIChjaGlsZE9yTm90KSB7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIGRhdGEpIHtcclxuICAgICAgICBpZiAoTnVtYmVyKGtleSkpIHtcclxuICAgICAgICAgIGNvbnN0IHJvdyA9IE9iamVjdC5hc3NpZ24odGVtcCwgZGF0YVtrZXldLCB7Y2xhc3NJRDoga2V5fSk7XHJcbiAgICAgICAgICByZXR1cm5EYXRhLnB1c2goXy5jbG9uZURlZXAocm93KSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm5EYXRhID0gZGF0YVtcIkFcIl07XHJcbiAgICAgIHJldHVybkRhdGEgPSAgT2JqZWN0LmFzc2lnbih0ZW1wLCByZXR1cm5EYXRhLCB7Y2xhc3NJRDogXCJBXCJ9KTtcclxuICAgIH1cclxuICAgIHJldHVybiByZXR1cm5EYXRhO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHNvcnRDb2x1bW5CeVByb3Aocm93cywgY2hpbGRSb3dzLCBleHBhbmRDb2xsYXBzZUljb25NYXAsIHByb3AsIGFzY0ZsYWcpIHtcclxuICAgIGNvbnN0IHBSb3dzID0gW107XHJcbiAgICByb3dzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLmNsYXNzSUQgPT09IFwiQVwiKSBwUm93cy5wdXNoKGl0ZW0pO1xyXG4gICAgICBpZiAoY2hpbGRSb3dzLmxlbmd0aCA9PT0gMCkgcFJvd3MucHVzaChpdGVtKTtcclxuICAgIH0pO1xyXG4gICAgYXNjRmxhZyA/IHBSb3dzLnNvcnQodGhpcy5zb3J0Q29tcGFyZUFzYyhwcm9wKSkgOiBwUm93cy5zb3J0KHRoaXMuc29ydENvbXBhcmVEZXNjKHByb3ApKTtcclxuICAgIGNoaWxkUm93cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBjb25zdCBmdW5kaWQgPSBpdGVtLmZ1bmRpZDtcclxuICAgICAgZXhwYW5kQ29sbGFwc2VJY29uTWFwLmZvckVhY2goZXhwYW5kSXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKGV4cGFuZEl0ZW0uZnVuZGlkID09PSBmdW5kaWQgJiYgZXhwYW5kSXRlbS5leHBhbmQpIHtcclxuICAgICAgICAgIGNvbnN0IGluZGV4ID0gcFJvd3MuZmluZEluZGV4KHBpdGVtID0+IHtyZXR1cm4gcGl0ZW0uZnVuZGlkID09PSBmdW5kaWR9KTtcclxuICAgICAgICAgIHBSb3dzLnNwbGljZShpbmRleCArIDEsIDAsIGl0ZW0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gcFJvd3M7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHNvcnRDb21wYXJlQXNjKHByb3ApIHtcclxuICAgIHJldHVybiBmdW5jdGlvbiAob2JqMSwgb2JqMikge1xyXG4gICAgICBsZXQgdjEgPSBvYmoxW3Byb3BdO1xyXG4gICAgICBsZXQgdjIgID0gb2JqMltwcm9wXTtcclxuICAgICAgaWYgKCFpc05hTihOdW1iZXIodjEpKSAmJiAhaXNOYU4oTnVtYmVyKHYyKSkpIHtcclxuICAgICAgICB2MSA9IE51bWJlcih2MSk7XHJcbiAgICAgICAgdjIgPSBOdW1iZXIodjIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAodjEgPT09IHVuZGVmaW5lZCB8fCB2MSA8IHYyKSB7XHJcbiAgICAgICAgcmV0dXJuIC0xXHJcbiAgICAgIH0gZWxzZSBpZiAodjIgPT09IHVuZGVmaW5lZCB8fCAgdjEgPiB2Mikge1xyXG4gICAgICAgIHJldHVybiAxO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiAwXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgc29ydENvbXBhcmVEZXNjKHByb3ApIHtcclxuICAgIHJldHVybiBmdW5jdGlvbiAob2JqMSwgb2JqMikge1xyXG4gICAgICBsZXQgdjEgPSBvYmoxW3Byb3BdO1xyXG4gICAgICBsZXQgdjIgID0gb2JqMltwcm9wXTtcclxuICAgICAgaWYgKCFpc05hTihOdW1iZXIodjEpKSAmJiAhaXNOYU4oTnVtYmVyKHYyKSkpIHtcclxuICAgICAgICB2MSA9IE51bWJlcih2MSk7XHJcbiAgICAgICAgdjIgPSBOdW1iZXIodjIpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICh2MSA9PT0gdW5kZWZpbmVkIHx8IHYxIDwgdjIgKSB7XHJcbiAgICAgICAgcmV0dXJuIDFcclxuICAgICAgfSBlbHNlIGlmICh2MiA9PT0gdW5kZWZpbmVkIHx8IHYxID4gdjIpIHtcclxuICAgICAgICByZXR1cm4gLTE7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIDBcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBFbGVtZW50UmVmLCBOZ1pvbmUsIENoYW5nZURldGVjdG9yUmVmLFxyXG4gIENvbXBvbmVudCxcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIEhvc3RMaXN0ZW5lcixcclxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICBDb250ZW50Q2hpbGQsXHJcbiAgVGVtcGxhdGVSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICB0cmlnZ2VyLFxyXG4gIHN0eWxlLFxyXG4gIGFuaW1hdGUsXHJcbiAgdHJhbnNpdGlvblxyXG59IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xyXG5pbXBvcnQgeyBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IHNjYWxlTGluZWFyLCBzY2FsZVRpbWUsIHNjYWxlUG9pbnQgfSBmcm9tICdkMy1zY2FsZSc7XHJcbmltcG9ydCB7IGN1cnZlTGluZWFyIH0gZnJvbSAnZDMtc2hhcGUnO1xyXG5cclxuaW1wb3J0IHsgaWQgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cy9yZWxlYXNlL3V0aWxzJztcclxuaW1wb3J0IHsgZ2V0VW5pcXVlWERvbWFpblZhbHVlcyB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzL3JlbGVhc2UvY29tbW9uL2RvbWFpbi5oZWxwZXInO1xyXG5cclxuaW1wb3J0IHsgY2FsY3VsYXRlVmlld0RpbWVuc2lvbnMsIFZpZXdEaW1lbnNpb25zLCBCYXNlQ2hhcnRDb21wb25lbnQsIENvbG9ySGVscGVyIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xyXG5pbXBvcnQgeyBDb21tb25VdGlsc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb21tb24tdXRpbHMuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1maW5lLWxpbmUtY2hhcnQnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cImN1c3RvbS1jaGFydFwiPlxyXG4gIDxuZ3gtY2hhcnRzLWNoYXJ0IFxyXG4gICAgICBbdmlld109XCJbd2lkdGgsIGhlaWdodF1cIlxyXG4gICAgICBbc2hvd0xlZ2VuZF09XCJmYWxzZVwiXHJcbiAgICAgIFtsZWdlbmRPcHRpb25zXT1cImxlZ2VuZE9wdGlvbnNcIlxyXG4gICAgICBbYWN0aXZlRW50cmllc109XCJhY3RpdmVFbnRyaWVzXCJcclxuICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiXHJcbiAgICAgIChsZWdlbmRMYWJlbENsaWNrKT1cIm9uQ2xpY2soJGV2ZW50KVwiXHJcbiAgICAgIChsZWdlbmRMYWJlbEFjdGl2YXRlKT1cIm9uQWN0aXZhdGUoJGV2ZW50KVwiXHJcbiAgICAgIChsZWdlbmRMYWJlbERlYWN0aXZhdGUpPVwib25EZWFjdGl2YXRlKCRldmVudClcIj5cclxuICAgICAgPHN2ZzpkZWZzPlxyXG4gICAgICAgIDxzdmc6Y2xpcFBhdGggW2F0dHIuaWRdPVwiY2xpcFBhdGhJZFwiPlxyXG4gICAgICAgICAgPHN2ZzpyZWN0XHJcbiAgICAgICAgICAgIFthdHRyLndpZHRoXT1cImRpbXMud2lkdGggKyAxMFwiXHJcbiAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCJkaW1zLmhlaWdodCArIDEwXCJcclxuICAgICAgICAgICAgW2F0dHIudHJhbnNmb3JtXT1cIid0cmFuc2xhdGUoLTUsIC01KSdcIi8+XHJcbiAgICAgICAgPC9zdmc6Y2xpcFBhdGg+XHJcbiAgICAgIDwvc3ZnOmRlZnM+XHJcbiAgICAgIDxzdmc6ZyBbYXR0ci50cmFuc2Zvcm1dPVwidHJhbnNmb3JtXCIgY2xhc3M9XCJsaW5lLWNoYXJ0IGNoYXJ0XCI+XHJcbiAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMteC1heGlzIFxyXG4gICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgW2RpbXNdPVwiZGltc1wiXHJcbiAgICAgICAgICBbc2hvd0xhYmVsXT1cInNob3dYQXhpc0xhYmVsXCJcclxuICAgICAgICAgIFtzaG93R3JpZExpbmVzXT1cInNob3dHcmlkTGluZXNcIlxyXG4gICAgICAgICAgW2xhYmVsVGV4dF09XCJ4QXhpc0xhYmVsXCJcclxuICAgICAgICAgIFt0aWNrc109XCJ0aWNrVmFsdWVzXCJcclxuICAgICAgICAgIFt0aWNrRm9ybWF0dGluZ109XCJ4QXhpc1RpY2tGb3JtYXR0aW5nXCJcclxuICAgICAgICAgIChkaW1lbnNpb25zQ2hhbmdlZCk9XCJ1cGRhdGVYQXhpc0hlaWdodCgkZXZlbnQpXCI+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy15LWF4aXNcclxuICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgIFtkaW1zXT1cImRpbXNcIlxyXG4gICAgICAgICAgW3Nob3dMYWJlbF09XCJzaG93WUF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbbGFiZWxUZXh0XT1cInlBeGlzTGFiZWxcIlxyXG4gICAgICAgICAgW3JlZmVyZW5jZUxpbmVzXT1cInJlZmVyZW5jZUxpbmVzXCJcclxuICAgICAgICAgIFtzaG93UmVmTGluZXNdPVwic2hvd1JlZkxpbmVzXCJcclxuICAgICAgICAgIFtzaG93R3JpZExpbmVzXT1cInNob3dHcmlkTGluZXNcIlxyXG4gICAgICAgICAgW3Nob3dSZWZMYWJlbHNdPVwic2hvd1JlZkxhYmVsc1wiXHJcbiAgICAgICAgICAoZGltZW5zaW9uc0NoYW5nZWQpPVwidXBkYXRlWUF4aXNXaWR0aCgkZXZlbnQpXCI+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICA8c3ZnOmxpbmVcclxuICAgICAgICBbYXR0ci54MV09XCJsYXN0RGF0YVhcIlxyXG4gICAgICAgIFthdHRyLnkxXT1cIjBcIlxyXG4gICAgICAgIFthdHRyLngyXT1cImxhc3REYXRhWFwiXHJcbiAgICAgICAgW2F0dHIueTJdPVwiaGVpZ2h0XCJcclxuICAgICAgICBbYXR0ci5jbGFzc109XCInZW5kLWxpbmUnXCJcclxuICAgICAgLz5cclxuICAgICAgPHN2Zzpmb3JlaWduT2JqZWN0XHJcbiAgICAgICAgW2F0dHIueF09XCJsYXN0RGF0YVggLSA0MFwiXHJcbiAgICAgICAgW2F0dHIueV09XCJoZWlnaHQgLSAxNVwiXHJcbiAgICAgICAgW2F0dHIud2lkdGhdPVwiODAgKyAncHgnXCJcclxuICAgICAgICBbYXR0ci5oZWlnaHRdPVwiMzAgKyAncHgnXCJcclxuICAgICAgICBbc3R5bGUucG9pbnRlci1ldmVudHNdPVwiJ25vbmUnXCI+XHJcbiAgICAgICAgPHhodG1sOmRpdlxyXG4gICAgICAgICAgY2xhc3M9J2xhc3QtdGltZSdcclxuICAgICAgICAgIFtzdHlsZS53aWR0aF09XCI4MCArICdweCdcIlxyXG4gICAgICAgICAgW3N0eWxlLmhlaWdodF09XCIyMCArICdweCdcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgPHhodG1sOnNwYW4+IHt7ZGlzcGxheUxpdmVUaW1lIHwgZGF0ZTogXCJoOm1tOnNzIGFhYWFhJ20nXCJ9fVxyXG4gICAgICAgICAgPC94aHRtbDpzcGFuPlxyXG4gICAgICAgIDwveGh0bWw6ZGl2PlxyXG4gICAgICA8L3N2Zzpmb3JlaWduT2JqZWN0PlxyXG4gICAgICAgIDxzdmc6ZyBbYXR0ci5jbGlwLXBhdGhdPVwiY2xpcFBhdGhcIj5cclxuICAgICAgICAgIDxzdmc6ZyAqbmdGb3I9XCJsZXQgc2VyaWVzIG9mIHJlc3VsdHM7IHRyYWNrQnk6dHJhY2tCeVwiIFtAYW5pbWF0aW9uU3RhdGVdPVwiJ2FjdGl2ZSdcIj5cclxuICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtbGluZS1zZXJpZXNcclxuICAgICAgICAgICAgICBbeFNjYWxlXT1cInhTY2FsZVwiXHJcbiAgICAgICAgICAgICAgW3lTY2FsZV09XCJ5U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFtjb2xvcnNdPVwiY29sb3JzXCJcclxuICAgICAgICAgICAgICBbZGF0YV09XCJzZXJpZXNcIlxyXG4gICAgICAgICAgICAgIFthY3RpdmVFbnRyaWVzXT1cImFjdGl2ZUVudHJpZXNcIlxyXG4gICAgICAgICAgICAgIFtzY2FsZVR5cGVdPVwic2NhbGVUeXBlXCJcclxuICAgICAgICAgICAgICBbY3VydmVdPVwiY3VydmVcIlxyXG4gICAgICAgICAgICAgIFtyYW5nZUZpbGxPcGFjaXR5XT1cInJhbmdlRmlsbE9wYWNpdHlcIlxyXG4gICAgICAgICAgICAgIFtoYXNSYW5nZV09XCJoYXNSYW5nZVwiXHJcbiAgICAgICAgICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgICAgPHN2ZzpnICpuZ0lmPVwiIXRvb2x0aXBEaXNhYmxlZFwiIChtb3VzZWxlYXZlKT1cImhpZGVDaXJjbGVzKClcIj5cclxuICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtdG9vbHRpcC1hcmVhXHJcbiAgICAgICAgICAgICAgW2RpbXNdPVwiZGltc1wiXHJcbiAgICAgICAgICAgICAgW3hTZXRdPVwieFNldFwiXHJcbiAgICAgICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgICAgICBbcmVzdWx0c109XCJyZXN1bHRzXCJcclxuICAgICAgICAgICAgICBbY29sb3JzXT1cImNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgW3Rvb2x0aXBEaXNhYmxlZF09XCIhdG9vbHRpcERpc2FibGVkXCJcclxuICAgICAgICAgICAgICAoaG92ZXIpPVwidXBkYXRlSG92ZXJlZFZlcnRpY2FsKCRldmVudClcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAgIDxzdmc6ZyAqbmdGb3I9XCJsZXQgc2VyaWVzIG9mIHJlc3VsdHNcIj5cclxuICAgICAgICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy1jaXJjbGUtc2VyaWVzXHJcbiAgICAgICAgICAgICAgICBbeFNjYWxlXT1cInhTY2FsZVwiXHJcbiAgICAgICAgICAgICAgICBbeVNjYWxlXT1cInlTY2FsZVwiXHJcbiAgICAgICAgICAgICAgICBbY29sb3JzXT1cImNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICBbZGF0YV09XCJzZXJpZXNcIlxyXG4gICAgICAgICAgICAgICAgW3NjYWxlVHlwZV09XCJzY2FsZVR5cGVcIlxyXG4gICAgICAgICAgICAgICAgW3Zpc2libGVWYWx1ZV09XCJob3ZlcmVkVmVydGljYWxcIlxyXG4gICAgICAgICAgICAgICAgW2FjdGl2ZUVudHJpZXNdPVwiYWN0aXZlRW50cmllc1wiXHJcbiAgICAgICAgICAgICAgICAoc2VsZWN0KT1cIm9uQ2xpY2soJGV2ZW50LCBzZXJpZXMpXCJcclxuICAgICAgICAgICAgICAgIChhY3RpdmF0ZSk9XCJvbkFjdGl2YXRlKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKGRlYWN0aXZhdGUpPVwib25EZWFjdGl2YXRlKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgW3Rvb2x0aXBUZW1wbGF0ZV09XCJ0b29sdGlwVGVtcGxhdGVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8c3ZnOmcgKm5nRm9yPVwibGV0IGNpcmNsZSBvZiBjaXJjbGVTZXJpZXNcIj5cclxuICAgICAgICAgICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLWNpcmNsZVxyXG4gICAgICAgICAgICAgICAgICBbY3hdPVwiY2lyY2xlLnhcIlxyXG4gICAgICAgICAgICAgICAgICBbY3ldPVwiY2lyY2xlLnZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgW3JdPVwiY2lyY2xlUmFkaXVzXCJcclxuICAgICAgICAgICAgICAgICAgW2RhdGFdPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgW2ZpbGxdPVwiY2lyY2xlLmZpbGxcIlxyXG4gICAgICAgICAgICAgICAgICAoc2VsZWN0KT1cIm9uQ2xpY2tBbGVydENpcmNsZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgPHN2ZzpnICpuZ0Zvcj1cImxldCBjaXJjbGUgb2YgY2lyY2xlU2VyaWVzXCI+XHJcbiAgICAgICAgICAgIDxzdmc6Zm9yZWlnbk9iamVjdFxyXG4gICAgICAgICAgICAgICAgICAqbmdJZj1cImdldFNob3dBbGVydERldGFpbHMoY2lyY2xlKVwiXHJcbiAgICAgICAgICAgICAgICAgIFthdHRyLnhdPVwiZ2V0UmVjdExvYWN0aW9uWChjaXJjbGUpXCJcclxuICAgICAgICAgICAgICAgICAgW2F0dHIueV09XCJnZXRSZWN0TG9hY3Rpb25ZKGNpcmNsZSlcIlxyXG4gICAgICAgICAgICAgICAgICBbYXR0ci53aWR0aF09XCIyMTAgKyAncHgnXCJcclxuICAgICAgICAgICAgICAgICAgW2F0dHIuaGVpZ2h0XT1cIjE0MCArICdweCdcIlxyXG4gICAgICAgICAgICAgICAgICBbc3R5bGUucG9pbnRlci1ldmVudHNdPVwiJ25vbmUnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHhodG1sOmRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3M9J2FsZXJ0LWRldGFpbHMtc3R5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgW3N0eWxlLmJvcmRlci1jb2xvcl09XCJjaXJjbGUuZmlsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8eGh0bWw6c3Bhbj4ge3tjaXJjbGUubmFtZX19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3hodG1sOnNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8eGh0bWw6c3Bhbj4ge3tjaXJjbGUudGltZX19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3hodG1sOnNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgPHhodG1sOmxhYmVsPiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOQVYgZGl2ZXJnaW5nIGZyb20gbWFya2V0IHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3hodG1sOmxhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHhodG1sOnRhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8eGh0bWw6dHI+TkFWIENoYW5nZTo8eGh0bWw6dGQ+e3tjaXJjbGUubmF2Q2hhbmdlIHwgcGVyY2VudDogJzEuMi0yJ319PC94aHRtbDp0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDp0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHhodG1sOnRyPk1WIENoYW5nZTo8eGh0bWw6dGQ+e3tjaXJjbGUubXZDaGFuZ2UgfCBwZXJjZW50OiAnMS4yLTInfX08L3hodG1sOnRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3hodG1sOnRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDp0YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L3hodG1sOmRpdj5cclxuICAgICAgICAgICAgICAgIDwvc3ZnOmZvcmVpZ25PYmplY3Q+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgPC9zdmc6Zz5cclxuICA8L25neC1jaGFydHMtY2hhcnQ+XHJcbiAgPG5nLXRlbXBsYXRlICN0b29sdGlwVGVtcGxhdGU+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJsaW5lLXRvb2x0aXBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0b3BcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZ1bmQtbmFtZVwiPnt7dG9vbHRpcE9iai5uYW1lfX0gPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuPiAtIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRpbWVcIj57e3Rvb2x0aXBPYmoudmFsdWUgfCBkYXRlOiBcImg6bW06c3MgYWFhYWEnbSdcIn19PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICAgIDx0ciBhbGlnbj0ncmlnaHQnPk5BVjx0ZD57e3Rvb2x0aXBPYmoubmF2IHwgbnVtYmVyOiAnMS4yLTInfX08L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0ciBhbGlnbj0ncmlnaHQnPk1WIEFtdCBCYXNlPHRkPnt7dG9vbHRpcE9iai5tYXJrZXR2YWwgfCBudW1iZXI6ICcxLjItMid9fTwvdGQ+PC90cj5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgIDwvZGl2PlxyXG4gIDwvbmctdGVtcGxhdGU+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYC5jdXN0b20tY2hhcnR7cG9zaXRpb246cmVsYXRpdmV9LmN1c3RvbS1jaGFydCAuY3VzdG9tLXRvb2x0aXB7YmFja2dyb3VuZC1jb2xvcjojZGRkO2JvcmRlcjoycHggc29saWQgZ3JleTtwb3NpdGlvbjphYnNvbHV0ZTt6LWluZGV4Ojk5fS5jdXN0b20tY2hhcnQgLmN1c3RvbS10b29sdGlwIHRhYmxle2JvcmRlci1zcGFjaW5nOjA7Ym9yZGVyLWNvbGxhcHNlOmNvbGxhcHNlO3dpZHRoOjEwMCV9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0c3tmbG9hdDpsZWZ0O292ZXJmbG93OnZpc2libGV9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY3VzdG9tLWF4aXMtbGluZXtzdHJva2U6I2VlZTtzdHJva2Utd2lkdGg6Mn0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5lbmQtbGluZXtzdHJva2U6IzZjNzU3ZDtzdHJva2Utd2lkdGg6MX0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5sYXN0LXRpbWV7YmFja2dyb3VuZC1jb2xvcjojZWVlO2JveC1zaGFkb3c6MCAwIDJweCAwIHJnYmEoMCwwLDAsLjE1KTtkaXNwbGF5OmZsZXg7anVzdGlmeS1jb250ZW50OmNlbnRlcjthbGlnbi1pdGVtczpjZW50ZXI7Zm9udC13ZWlnaHQ6NzAwO2ZvbnQtc2l6ZToxNHB4O2JvcmRlci1yYWRpdXM6NXB4fS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFsZXJ0LWRldGFpbHMtc3R5e2NvbG9yOiM2Yzc1N2Q7Ym9yZGVyOjJweCBzb2xpZDtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMjU1LDI1NSwyNTUsLjkpO3dpZHRoOjIwMHB4O2hlaWdodDo5NXB4O3BhZGRpbmctbGVmdDo1cHh9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYWxlcnQtZGV0YWlscy1zdHkgc3Bhbnt0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmlubGluZS1mbGV4O3dpZHRoOjgwcHg7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NzAwfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFsZXJ0LWRldGFpbHMtc3R5IGxhYmVse2Rpc3BsYXk6aW5saW5lLWJsb2NrO2ZvbnQtc2l6ZToxMnB4O3BhZGRpbmc6NXB4IDAgNXB4IDJweH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hbGVydC1kZXRhaWxzLXN0eSB0YWJsZXtmb250LXNpemU6MTJweH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hcmMsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYmFyLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmNpcmNsZXtjdXJzb3I6cG9pbnRlcn0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hcmMuYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFyYzpob3ZlciwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5iYXIuYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmJhcjpob3ZlciwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jYXJkLmFjdGl2ZSwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jYXJkOmhvdmVyLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmNlbGwuYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmNlbGw6aG92ZXJ7b3BhY2l0eTouODt0cmFuc2l0aW9uOm9wYWNpdHkgLjFzIGVhc2UtaW4tb3V0fS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFyYzpmb2N1cywuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5iYXI6Zm9jdXMsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY2FyZDpmb2N1cywuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jZWxsOmZvY3VzLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgZzpmb2N1c3tvdXRsaW5lOjB9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYXJlYS1zZXJpZXMuaW5hY3RpdmUsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAubGluZS1zZXJpZXMtcmFuZ2UuaW5hY3RpdmUsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAubGluZS1zZXJpZXMuaW5hY3RpdmUsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAucG9sYXItc2VyaWVzLWFyZWEuaW5hY3RpdmUsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAucG9sYXItc2VyaWVzLXBhdGguaW5hY3RpdmV7dHJhbnNpdGlvbjpvcGFjaXR5IC4xcyBlYXNlLWluLW91dDtvcGFjaXR5Oi4yfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmxpbmUtaGlnaGxpZ2h0e2Rpc3BsYXk6bm9uZX0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5saW5lLWhpZ2hsaWdodC5hY3RpdmV7ZGlzcGxheTpibG9ja30uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hcmVhe29wYWNpdHk6LjZ9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY2lyY2xlOmhvdmVye2N1cnNvcjpwb2ludGVyfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmxhYmVse2ZvbnQtc2l6ZToxOHB4O2ZvbnQtd2VpZ2h0OjQwMH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC50b29sdGlwLWFuY2hvcntmaWxsOiMwMDB9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuZ3JpZGxpbmUtcGF0aHtzdHJva2U6I2RkZDtzdHJva2Utd2lkdGg6MTtmaWxsOm5vbmV9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAucmVmbGluZS1wYXRoe3N0cm9rZTojYThiMmM3O3N0cm9rZS13aWR0aDoxO3N0cm9rZS1kYXNoYXJyYXk6NTtzdHJva2UtZGFzaG9mZnNldDo1fS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLnJlZmxpbmUtbGFiZWx7Zm9udC1zaXplOjlweH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5yZWZlcmVuY2UtYXJlYXtmaWxsLW9wYWNpdHk6LjA1O2ZpbGw6IzAwMH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5ncmlkbGluZS1wYXRoLWRvdHRlZHtzdHJva2U6I2RkZDtzdHJva2Utd2lkdGg6MTtmaWxsOm5vbmU7c3Ryb2tlLWRhc2hhcnJheToxLDIwO3N0cm9rZS1kYXNob2Zmc2V0OjN9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuZ3JpZC1wYW5lbCByZWN0e2ZpbGw6bm9uZX0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5ncmlkLXBhbmVsLm9kZCByZWN0e2ZpbGw6cmdiYSgxNzAsMzUsMzUsLjA1KX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50e3Bvc2l0aW9uOmZpeGVkO2JvcmRlci1yYWRpdXM6M3B4O3otaW5kZXg6NTAwMDtkaXNwbGF5OmJsb2NrO2ZvbnQtd2VpZ2h0OjQwMDtvcGFjaXR5OjA7cG9pbnRlci1ldmVudHM6bm9uZSFpbXBvcnRhbnQ7Zm9udC1zaXplOjE0cHh9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIC50b3B7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgZ3JleTtwYWRkaW5nLWJvdHRvbTo1cHg7bWFyZ2luLWJvdHRvbTowO292ZXJmbG93OmF1dG99LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIC50b3AgLmZ1bmQtbmFtZXtmbG9hdDpsZWZ0O2ZvbnQtd2VpZ2h0OjcwMH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50IC5saW5lLXRvb2x0aXAgLnRvcCAudGltZXtmbG9hdDpyaWdodDtmb250LXdlaWdodDo3MDB9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIC5kZXNjcmlwdGlvbntjbGVhcjpib3RoO2ZvbnQtc2l6ZToxNHB4O21hcmdpbi10b3A6MTBweH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50IC5saW5lLXRvb2x0aXAgdGR7cGFkZGluZzoycHggMjBweDt0ZXh0LWFsaWduOnJpZ2h0fS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLmxpbmUtdG9vbHRpcCAuYnRoLWdyb3Vwe2Zsb2F0OnJpZ2h0O21hcmdpbi1yaWdodDotMTBweDttYXJnaW4tdG9wOjE1cHh9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIC5idGgtZ3JvdXAgYnV0dG9ue2JhY2tncm91bmQtY29sb3I6I2ZmZjtwYWRkaW5nOjhweDtib3JkZXI6MnB4IHNvbGlkICNkZGQ7d2lkdGg6ODVweDtmb250LXNpemU6MTJweH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnR5cGUtdG9vbHRpcHtjb2xvcjojMDAwO2JhY2tncm91bmQ6I2VlZTtmb250LXNpemU6MTRweDtwYWRkaW5nOjE1cHggMThweDt0ZXh0LWFsaWduOmxlZnQ7cG9pbnRlci1ldmVudHM6YXV0bzt3aWR0aDoyMjBweDtoZWlnaHQ6MTE1cHg7Ym9yZGVyOjJweCBzb2xpZCAjZGRkfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwLmFsZXJ0MXtib3JkZXI6MnB4IHNvbGlkICNmZmJjMDY7aGVpZ2h0OjE1MHB4O3dpZHRoOjI0OXB4fS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwLmFsZXJ0Mntib3JkZXI6MnB4IHNvbGlkICNiOTEyMjQ7aGVpZ2h0OjE1MHB4O3dpZHRoOjI0OXB4fS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwIC50b29sdGlwLWNhcmV0LnBvc2l0aW9uLWxlZnR7Ym9yZGVyLXRvcDo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLWJvdHRvbTo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLWxlZnQ6N3B4IHNvbGlkICNlZWV9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC50eXBlLXRvb2x0aXAgLnRvb2x0aXAtY2FyZXQucG9zaXRpb24tdG9we2JvcmRlci1sZWZ0OjdweCBzb2xpZCB0cmFuc3BhcmVudDtib3JkZXItcmlnaHQ6N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci10b3A6N3B4IHNvbGlkICNlZWV9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC50eXBlLXRvb2x0aXAgLnRvb2x0aXAtY2FyZXQucG9zaXRpb24tcmlnaHR7Ym9yZGVyLXRvcDo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLWJvdHRvbTo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLXJpZ2h0OjdweCBzb2xpZCAjZWVlfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwIC50b29sdGlwLWNhcmV0LnBvc2l0aW9uLWJvdHRvbXtib3JkZXItbGVmdDo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLXJpZ2h0OjdweCBzb2xpZCB0cmFuc3BhcmVudDtib3JkZXItYm90dG9tOjdweCBzb2xpZCAjZWVlfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLnRvb2x0aXAtY2FyZXR7cG9zaXRpb246YWJzb2x1dGU7ei1pbmRleDo1MDAxO3dpZHRoOjA7aGVpZ2h0OjB9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC5wb3NpdGlvbi1yaWdodHstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGUzZCgxMHB4LDAsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDEwcHgsMCwwKX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnBvc2l0aW9uLWxlZnR7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlM2QoLTEwcHgsMCwwKTt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoLTEwcHgsMCwwKX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnBvc2l0aW9uLXRvcHstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGUzZCgwLC0xMHB4LDApO3RyYW5zZm9ybTp0cmFuc2xhdGUzZCgwLC0xMHB4LDApfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQucG9zaXRpb24tYm90dG9tey13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDAsMTBweCwwKTt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoMCwxMHB4LDApfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQuYW5pbWF0ZXtvcGFjaXR5OjE7dHJhbnNpdGlvbjpvcGFjaXR5IC4zcyx0cmFuc2Zvcm0gLjNzLC13ZWJraXQtdHJhbnNmb3JtIC4zczstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGUzZCgwLDAsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDAsMCwwKTtwb2ludGVyLWV2ZW50czphdXRvfS5hcmVhLXRvb2x0aXAtY29udGFpbmVye3BhZGRpbmc6NXB4IDA7cG9pbnRlci1ldmVudHM6bm9uZX0udG9vbHRpcC1pdGVte3RleHQtYWxpZ246bGVmdDtsaW5lLWhlaWdodDoxLjJlbTtwYWRkaW5nOjVweCAwfS50b29sdGlwLWl0ZW0gLnRvb2x0aXAtaXRlbS1jb2xvcntkaXNwbGF5OmlubGluZS1ibG9jaztoZWlnaHQ6MTJweDt3aWR0aDoxMnB4O21hcmdpbi1yaWdodDo1cHg7Y29sb3I6IzViNjQ2Yjtib3JkZXItcmFkaXVzOjNweH1gXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5TaGFkb3dEb20sXHJcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXHJcbiAgYW5pbWF0aW9uczogW1xyXG4gICAgdHJpZ2dlcignYW5pbWF0aW9uU3RhdGUnLCBbXHJcbiAgICAgIHRyYW5zaXRpb24oJzpsZWF2ZScsIFtcclxuICAgICAgICBzdHlsZSh7XHJcbiAgICAgICAgICBvcGFjaXR5OiAxLFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIGFuaW1hdGUoNTAwLCBzdHlsZSh7XHJcbiAgICAgICAgICBvcGFjaXR5OiAwXHJcbiAgICAgICAgfSkpXHJcbiAgICAgIF0pXHJcbiAgICBdKVxyXG4gIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIExpbmVDaGFydENvbXBvbmVudCBleHRlbmRzIEJhc2VDaGFydENvbXBvbmVudCB7XHJcbiAgQElucHV0KCkgbGVnZW5kO1xyXG4gIEBJbnB1dCgpIGxlZ2VuZFRpdGxlOiBzdHJpbmcgPSAnTGVnZW5kJztcclxuICBASW5wdXQoKSBzaG93WEF4aXNMYWJlbDtcclxuICBASW5wdXQoKSBzaG93WUF4aXNMYWJlbDtcclxuICBASW5wdXQoKSB4QXhpc0xhYmVsO1xyXG4gIEBJbnB1dCgpIHlBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgYXV0b1NjYWxlO1xyXG4gIEBJbnB1dCgpIHRpbWVsaW5lO1xyXG4gIEBJbnB1dCgpIGdyYWRpZW50OiBib29sZWFuO1xyXG4gIEBJbnB1dCgpIHNob3dHcmlkTGluZXM6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIEBJbnB1dCgpIGN1cnZlOiBhbnkgPSBjdXJ2ZUxpbmVhcjtcclxuICBASW5wdXQoKSBzY2hlbWVUeXBlOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgcmFuZ2VGaWxsT3BhY2l0eTogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHhBeGlzVGlja0Zvcm1hdHRpbmc6IGFueTtcclxuICBASW5wdXQoKSB5QXhpc1RpY2tGb3JtYXR0aW5nOiBhbnk7XHJcbiAgQElucHV0KCkgeEF4aXNUaWNrczogYW55W107XHJcbiAgQElucHV0KCkgeUF4aXNUaWNrczogYW55W107XHJcbiAgQElucHV0KCkgcm91bmREb21haW5zOiBib29sZWFuID0gZmFsc2U7XHJcbiAgQElucHV0KCkgdG9vbHRpcERpc2FibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgQElucHV0KCkgc2hvd1JlZkxpbmVzOiBib29sZWFuID0gZmFsc2U7IC8vIGlmIGRvbid0IHNob3cgZ3JpZCBsaW5lIGluIHgtYXhpcyBsZXZlbCB3ZSBjYW4gdXNlIHJlZkxpbmUgdG8gY3VzdG9taXplIHgtYXhpcyBsZXZlbCBsaW5lcy4uXHJcbiAgQElucHV0KCkgcmVmZXJlbmNlTGluZXM6IGFueSA9IFtdOyAvL1t7IHZhbHVlOiAwLjEsIG5hbWU6ICdNYXhpbXVtJyB9LCB7IHZhbHVlOiAwLjAsIG5hbWU6ICdBdmVyYWdlJyB9LCB7IHZhbHVlOiAtMC4xLCBuYW1lOiAnTWluaW11bScgfV07XHJcbiAgQElucHV0KCkgc2hvd1JlZkxhYmVsczogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHhTY2FsZU1pbjogYW55O1xyXG4gIEBJbnB1dCgpIHhTY2FsZU1heDogYW55O1xyXG4gIEBJbnB1dCgpIHlTY2FsZU1pbjogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHlTY2FsZU1heDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHNlbGVjdGFibGU7XHJcbiAgQElucHV0KCkgaGVpZ2h0OiBudW1iZXI7XHJcbiAgQElucHV0KCkgd2lkdGg6IG51bWJlcjtcclxuICBASW5wdXQoKSBtYXJnaW46IG51bWJlcjtcclxuICBASW5wdXQoKSBjb2xvckRvbWFpbjogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSByZXN1bHRzOiBhbnlbXTtcclxuICBASW5wdXQoKSBjaXJjbGVEYXRhOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIGN1cnJlbnRMaW5lVGltZTogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIHRpY2tWYWx1ZXM6IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgZGlzcGxheUxpdmVUaW1lOiBhbnk7XHJcbiAgQElucHV0KCkgYWN0aXZlRW50cmllczogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSBoaWdoTGlnaHRBY3RpdmVFbnRyaWVzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBAT3V0cHV0KCkgYWN0aXZhdGU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gIEBPdXRwdXQoKSBkZWFjdGl2YXRlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgQENvbnRlbnRDaGlsZCgndG9vbHRpcFRlbXBsYXRlJykgdG9vbHRpcFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xyXG4gIEBDb250ZW50Q2hpbGQoJ3Nlcmllc1Rvb2x0aXBUZW1wbGF0ZScpIHNlcmllc1Rvb2x0aXBUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcclxuICBkaW1zOiBWaWV3RGltZW5zaW9ucztcclxuICB4U2V0OiBhbnk7XHJcbiAgeERvbWFpbjogYW55O1xyXG4gIHlEb21haW46IGFueTtcclxuICBzZXJpZXNEb21haW46IGFueTtcclxuICB5U2NhbGU6IGFueTtcclxuICB4U2NhbGU6IGFueTtcclxuICBjb2xvcnM6IENvbG9ySGVscGVyO1xyXG4gIHNjYWxlVHlwZTogc3RyaW5nO1xyXG4gIHRyYW5zZm9ybTogc3RyaW5nO1xyXG4gIGNsaXBQYXRoOiBzdHJpbmc7XHJcbiAgY2xpcFBhdGhJZDogc3RyaW5nO1xyXG4gIHNlcmllczogYW55O1xyXG4gIGFyZWFQYXRoOiBhbnk7XHJcbiAgaG92ZXJlZFZlcnRpY2FsOiBhbnk7IC8vIHRoZSB2YWx1ZSBvZiB0aGUgeCBheGlzIHRoYXQgaXMgaG92ZXJlZCBvdmVyXHJcbiAgeEF4aXNIZWlnaHQ6IG51bWJlciA9IDA7XHJcbiAgeUF4aXNXaWR0aDogbnVtYmVyID0gMDtcclxuICBmaWx0ZXJlZERvbWFpbjogYW55O1xyXG4gIGxlZ2VuZE9wdGlvbnM6IGFueTtcclxuICBoYXNSYW5nZTogYm9vbGVhbjsgLy8gd2hldGhlciB0aGUgbGluZSBoYXMgYSBtaW4tbWF4IHJhbmdlIGFyb3VuZCBpdFxyXG4gIHRpbWVsaW5lV2lkdGg6IGFueTtcclxuICB0aW1lbGluZUhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgdGltZWxpbmVYU2NhbGU6IGFueTtcclxuICB0aW1lbGluZVlTY2FsZTogYW55O1xyXG4gIHRpbWVsaW5lWERvbWFpbjogYW55O1xyXG4gIHRpbWVsaW5lVHJhbnNmb3JtOiBhbnk7XHJcbiAgdGltZWxpbmVQYWRkaW5nOiBudW1iZXIgPSAxMDtcclxuICBjaXJjbGVTZXJpZXM6IGFueTtcclxuICBjdXN0b21Db2xvcnM6IGFueVtdO1xyXG4gIGNpcmNsZVJhZGl1czogbnVtYmVyID0gNTtcclxuICB0b29sdGlwT2JqOiBhbnkgPSB7fTtcclxuICBjdXN0b21Ub29sdGlwQ2xhc3M6IHN0cmluZztcclxuICBsYXN0RGF0YVg6IG51bWJlcjtcclxuICBzaG93QWxlcnREZXRhaWxzTWFwOiBhbnlbXSA9IFtdO1xyXG5cclxuICBjb25zdHJ1Y3RvcihjaGFydEVsZW1lbnQ6IEVsZW1lbnRSZWYsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgem9uZTogTmdab25lLCBcclxuICAgICAgICAgICAgICAgICAgICAgIGNkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgZGF0ZVBpcGU6IERhdGVQaXBlKSB7XHJcbiAgICBzdXBlcihjaGFydEVsZW1lbnQsIHpvbmUsIGNkKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZSgpOiB2b2lkIHtcclxuXHJcbiAgICB0aGlzLmRpbXMgPSBjYWxjdWxhdGVWaWV3RGltZW5zaW9ucyh7XHJcbiAgICAgIHdpZHRoOiB0aGlzLndpZHRoLFxyXG4gICAgICBoZWlnaHQ6IHRoaXMuaGVpZ2h0LFxyXG4gICAgICBtYXJnaW5zOiB0aGlzLm1hcmdpbixcclxuICAgICAgeEF4aXNIZWlnaHQ6IHRoaXMueEF4aXNIZWlnaHQsXHJcbiAgICAgIHlBeGlzV2lkdGg6IHRoaXMueUF4aXNXaWR0aCxcclxuICAgICAgc2hvd1hMYWJlbDogdGhpcy5zaG93WEF4aXNMYWJlbCxcclxuICAgICAgc2hvd1lMYWJlbDogdGhpcy5zaG93WUF4aXNMYWJlbCxcclxuICAgICAgc2hvd0xlZ2VuZDogdGhpcy5sZWdlbmQsXHJcbiAgICAgIGxlZ2VuZFR5cGU6IHRoaXMuc2NoZW1lVHlwZSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICh0aGlzLnRpbWVsaW5lKSB7XHJcbiAgICAgIHRoaXMuZGltcy5oZWlnaHQgLT0gKHRoaXMudGltZWxpbmVIZWlnaHQgKyB0aGlzLm1hcmdpblsyXSArIHRoaXMudGltZWxpbmVQYWRkaW5nKTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnhEb21haW4gPSB0aGlzLmdldFhEb21haW4oKTtcclxuICAgIGlmICh0aGlzLmZpbHRlcmVkRG9tYWluKSB7XHJcbiAgICAgIHRoaXMueERvbWFpbiA9IHRoaXMuZmlsdGVyZWREb21haW47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy55RG9tYWluID0gdGhpcy5nZXRZRG9tYWluKCk7XHJcbiAgICB0aGlzLnNlcmllc0RvbWFpbiA9IHRoaXMuZ2V0U2VyaWVzRG9tYWluKCk7XHJcblxyXG4gICAgdGhpcy54U2NhbGUgPSB0aGlzLmdldFhTY2FsZSh0aGlzLnhEb21haW4sIHRoaXMuZGltcy53aWR0aCk7XHJcblxyXG4gICAgdGhpcy55U2NhbGUgPSB0aGlzLmdldFlTY2FsZSh0aGlzLnlEb21haW4sIHRoaXMuZGltcy5oZWlnaHQpO1xyXG5cclxuICAgIHRoaXMuY3VzdG9tQ29sb3JzID0gdGhpcy5zZXRDdXN0b21jb2xvcnMoKTtcclxuICAgIHRoaXMuc2V0Q29sb3JzKCk7XHJcbiAgICB0aGlzLmxlZ2VuZE9wdGlvbnMgPSB0aGlzLmdldExlZ2VuZE9wdGlvbnMoKTtcclxuXHJcbiAgICB0aGlzLnRyYW5zZm9ybSA9IGB0cmFuc2xhdGUoJHt0aGlzLmRpbXMueE9mZnNldH0gLCAke3RoaXMubWFyZ2luWzBdfSlgO1xyXG5cclxuICAgIHRoaXMuY2xpcFBhdGhJZCA9ICdjbGlwJyArIGlkKCkudG9TdHJpbmcoKTtcclxuICAgIHRoaXMuY2xpcFBhdGggPSBgdXJsKCMke3RoaXMuY2xpcFBhdGhJZH0pYDtcclxuXHJcbiAgICAvL21hcCBjaXJjbGVcclxuICAgIHRoaXMuY2lyY2xlU2VyaWVzID0gdGhpcy5tYXBDaXJjbGUodGhpcy5jaXJjbGVEYXRhKTtcclxuICAgIHRoaXMubGFzdERhdGFYPXRoaXMueFNjYWxlKHRoaXMuY3VycmVudExpbmVUaW1lKTtcclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgbWFwQ2lyY2xlKGNpcmNsZURhdGEpOiBhbnlbXSB7XHJcbiAgICBsZXQgeHNjYWxlID0gdGhpcy54U2NhbGU7XHJcbiAgICBsZXQgeXNjYWxlID0gdGhpcy55U2NhbGU7XHJcbiAgICBsZXQgYXJyID0gW107XHJcblxyXG4gICAgY2lyY2xlRGF0YS5mb3JFYWNoKChpdGVtLCBpbmRleCkgID0+IHtcclxuICAgICAgbGV0IG9iaiA9IHtcclxuICAgICAgICB4OiB4c2NhbGUoaXRlbS54KSxcclxuICAgICAgICB0aW1lOiB0aGlzLmRhdGVQaXBlLnRyYW5zZm9ybShpdGVtLnByaWNldGltZSxcImhoOm1tOnNzIGFhYWFhJ20nXCIpLFxyXG4gICAgICAgIHZhbHVlOiB5c2NhbGUoaXRlbS52YWx1ZSksXHJcbiAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgICAgIGZpbGw6IGl0ZW0uYWxlcnRUeXBlID09IDEgPyBbJyNmZmJjMDYnXSA6IFsnI2I5MTIyNCddLFxyXG4gICAgICAgIGFsZXJ0VHlwZTogaXRlbS5hbGVydFR5cGUsXHJcbiAgICAgICAgbmF2Q2hhbmdlOiBpdGVtLnZhbHVlLFxyXG4gICAgICAgIG12Q2hhbmdlOiBpdGVtLmZ1bmRtdkNoYW5nZVBlcmNlbnQsXHJcbiAgICAgICAgcHJpY2V0aW1lOiBpdGVtLnByaWNldGltZSxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGFyci5wdXNoKG9iaik7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gYXJyO1xyXG4gIH1cclxuXHJcbiAgc2V0Q3VzdG9tY29sb3JzKCk6IGFueVtdIHtcclxuICAgIGxldCBhcnIgPSBbXTtcclxuICAgIHRoaXMucmVzdWx0cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICB0aGlzLmNvbG9yRG9tYWluLmZvckVhY2goY29sb3IgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtWyduYW1lJ10gPT09IGNvbG9yWydmdW5kaWQnXSkge1xyXG4gICAgICAgICAgbGV0IG9iaiA9IHtcclxuICAgICAgICAgICAgbmFtZTogY29sb3IuZnVuZGlkLFxyXG4gICAgICAgICAgICB2YWx1ZTogY29sb3IuY29sb3JcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGFyci5wdXNoKG9iailcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBhcnI7XHJcbiAgfVxyXG5cclxuICBnZXRYRG9tYWluKCk6IGFueVtdIHtcclxuICAgIGxldCB2YWx1ZXMgPSBnZXRVbmlxdWVYRG9tYWluVmFsdWVzKHRoaXMucmVzdWx0cyk7XHJcbiAgICB0aGlzLnNjYWxlVHlwZSA9IHRoaXMuZ2V0U2NhbGVUeXBlKHZhbHVlcyk7XHJcbiAgICBsZXQgZG9tYWluID0gW107XHJcblxyXG4gICAgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAnbGluZWFyJykge1xyXG4gICAgICB2YWx1ZXMgPSB2YWx1ZXMubWFwKHYgPT4gTnVtYmVyKHYpKTtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgbWluO1xyXG4gICAgbGV0IG1heDtcclxuICAgIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ3RpbWUnIHx8IHRoaXMuc2NhbGVUeXBlID09PSAnbGluZWFyJykge1xyXG4gICAgICBtaW4gPSB0aGlzLnhTY2FsZU1pblxyXG4gICAgICAgID8gdGhpcy54U2NhbGVNaW5cclxuICAgICAgICA6IE1hdGgubWluKC4uLnZhbHVlcyk7XHJcblxyXG4gICAgICBtYXggPSB0aGlzLnhTY2FsZU1heFxyXG4gICAgICAgID8gdGhpcy54U2NhbGVNYXhcclxuICAgICAgICA6IE1hdGgubWF4KC4uLnZhbHVlcyk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAndGltZScpIHtcclxuICAgICAgZG9tYWluID0gW25ldyBEYXRlKG1pbiksIG5ldyBEYXRlKG1heCldO1xyXG4gICAgICB0aGlzLnhTZXQgPSBbLi4udmFsdWVzXS5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYURhdGUgPSBhLmdldFRpbWUoKTtcclxuICAgICAgICBjb25zdCBiRGF0ZSA9IGIuZ2V0VGltZSgpO1xyXG4gICAgICAgIGlmIChhRGF0ZSA+IGJEYXRlKSByZXR1cm4gMTtcclxuICAgICAgICBpZiAoYkRhdGUgPiBhRGF0ZSkgcmV0dXJuIC0xO1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdsaW5lYXInKSB7XHJcbiAgICAgIGRvbWFpbiA9IFttaW4sIG1heF07XHJcbiAgICAgIC8vIFVzZSBjb21wYXJlIGZ1bmN0aW9uIHRvIHNvcnQgbnVtYmVycyBudW1lcmljYWxseVxyXG4gICAgICB0aGlzLnhTZXQgPSBbLi4udmFsdWVzXS5zb3J0KChhLCBiKSA9PiAoYSAtIGIpKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGRvbWFpbiA9IHZhbHVlcztcclxuICAgICAgdGhpcy54U2V0ID0gdmFsdWVzO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBkb21haW47XHJcbiAgfVxyXG5cclxuICBnZXRZRG9tYWluKCk6IGFueVtdIHtcclxuICAgIGNvbnN0IGRvbWFpbiA9IFtdO1xyXG4gICAgZm9yIChjb25zdCByZXN1bHRzIG9mIHRoaXMucmVzdWx0cykge1xyXG4gICAgICBmb3IgKGNvbnN0IGQgb2YgcmVzdWx0cy5zZXJpZXMpIHtcclxuICAgICAgICBpZiAoZC52YWx1ZSAmJiBkb21haW4uaW5kZXhPZihkLnZhbHVlKSA8IDApIHtcclxuICAgICAgICAgIGRvbWFpbi5wdXNoKGQudmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZC5taW4gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgdGhpcy5oYXNSYW5nZSA9IHRydWU7XHJcbiAgICAgICAgICBpZiAoZG9tYWluLmluZGV4T2YoZC5taW4pIDwgMCkge1xyXG4gICAgICAgICAgICBkb21haW4ucHVzaChkLm1pbik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChkLm1heCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICB0aGlzLmhhc1JhbmdlID0gdHJ1ZTtcclxuICAgICAgICAgIGlmIChkb21haW4uaW5kZXhPZihkLm1heCkgPCAwKSB7XHJcbiAgICAgICAgICAgIGRvbWFpbi5wdXNoKGQubWF4KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB2YWx1ZXMgPSBbLi4uZG9tYWluXTtcclxuICAgIGlmICghdGhpcy5hdXRvU2NhbGUpIHtcclxuICAgICAgdmFsdWVzLnB1c2goMCk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbWluID0gdGhpcy55U2NhbGVNaW5cclxuICAgICAgPyB0aGlzLnlTY2FsZU1pblxyXG4gICAgICA6IE1hdGgubWluKC4uLnZhbHVlcyk7XHJcblxyXG4gICAgY29uc3QgbWF4ID0gdGhpcy55U2NhbGVNYXhcclxuICAgICAgPyB0aGlzLnlTY2FsZU1heFxyXG4gICAgICA6IE1hdGgubWF4KC4uLnZhbHVlcyk7XHJcblxyXG4gICAgICBpZiAobWluICE9PSB1bmRlZmluZWQgJiYgbWF4ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICByZXR1cm4gW21pbiwgbWF4XTtcclxuICAgICAgfWVsc2Uge1xyXG4gICAgICAgIHJldHVybiBbLTAuMSwgMC4xXTtcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0U2VyaWVzRG9tYWluKCk6IGFueVtdIHtcclxuICAgIHJldHVybiB0aGlzLnJlc3VsdHMubWFwKGQgPT4gZC5uYW1lKTtcclxuICB9XHJcblxyXG4gIGdldFhTY2FsZShkb21haW4sIHdpZHRoKTogYW55IHtcclxuICAgIGxldCBzY2FsZTtcclxuXHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICd0aW1lJykge1xyXG4gICAgICBzY2FsZSA9IHNjYWxlVGltZSgpXHJcbiAgICAgICAgLnJhbmdlKFswLCB3aWR0aF0pXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZUxpbmVhcigpXHJcbiAgICAgICAgLnJhbmdlKFswLCB3aWR0aF0pXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG5cclxuICAgICAgaWYgKHRoaXMucm91bmREb21haW5zKSB7XHJcbiAgICAgICAgc2NhbGUgPSBzY2FsZS5uaWNlKCk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBzY2FsZSA9IHNjYWxlUG9pbnQoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5wYWRkaW5nKDAuMSlcclxuICAgICAgICAuZG9tYWluKGRvbWFpbik7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHNjYWxlO1xyXG4gIH1cclxuXHJcbiAgZ2V0WVNjYWxlKGRvbWFpbiwgaGVpZ2h0KTogYW55IHtcclxuICAgIGNvbnN0IHNjYWxlID0gc2NhbGVMaW5lYXIoKVxyXG4gICAgICAucmFuZ2UoW2hlaWdodCwgMF0pXHJcbiAgICAgIC5kb21haW4oZG9tYWluKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5yb3VuZERvbWFpbnMgPyBzY2FsZS5uaWNlKCkgOiBzY2FsZTtcclxuICB9XHJcblxyXG4gIGdldFNjYWxlVHlwZSh2YWx1ZXMpOiBzdHJpbmcge1xyXG4gICAgbGV0IGRhdGUgPSB0cnVlO1xyXG4gICAgbGV0IG51bSA9IHRydWU7XHJcblxyXG4gICAgZm9yIChjb25zdCB2YWx1ZSBvZiB2YWx1ZXMpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzRGF0ZSh2YWx1ZSkpIHtcclxuICAgICAgICBkYXRlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgbnVtID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0ZSkgcmV0dXJuICd0aW1lJztcclxuICAgIGlmIChudW0pIHJldHVybiAnbGluZWFyJztcclxuICAgIHJldHVybiAnb3JkaW5hbCc7XHJcbiAgfVxyXG5cclxuICBpc0RhdGUodmFsdWUpOiBib29sZWFuIHtcclxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlWUF4aXNXaWR0aCh7IHdpZHRoIH0pOiB2b2lkIHtcclxuICAgIHRoaXMueUF4aXNXaWR0aCA9IHdpZHRoO1xyXG4gICAgdGhpcy51cGRhdGUoKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVhBeGlzSGVpZ2h0KHsgaGVpZ2h0IH0pOiB2b2lkIHtcclxuICAgIHRoaXMueEF4aXNIZWlnaHQgPSBoZWlnaHQ7XHJcbiAgICB0aGlzLnVwZGF0ZSgpO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlSG92ZXJlZFZlcnRpY2FsKGl0ZW0pOiB2b2lkIHtcclxuICAgIHRoaXMudG9vbHRpcE9iaiA9IE9iamVjdC5hc3NpZ24odGhpcy50b29sdGlwT2JqLCBpdGVtKVxyXG5cclxuICAgIHRoaXMuaG92ZXJlZFZlcnRpY2FsID0gaXRlbS52YWx1ZTtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZUFsbCgpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignbW91c2VsZWF2ZScpXHJcbiAgaGlkZUNpcmNsZXMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmhvdmVyZWRWZXJ0aWNhbCA9IG51bGw7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IHRoaXMuaGlnaExpZ2h0QWN0aXZlRW50cmllcztcclxuICB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ21vdXNlZW50ZXInLCBbXCJzZXJpZXNcIl0pXHJcbiAgb25Nb3VzZUVudGVyKHNlcmllcyk6IHZvaWQge1xyXG4gICAgdGhpcy5hY3RpdmF0ZS5lbWl0KHNlcmllcyk7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCdtb3VzZWxlYXZlJywgW1wiJGV2ZW50XCJdKVxyXG4gIG9uTW91c2VMZWF2ZShzZXJpZXMpOiB2b2lkIHtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZS5lbWl0KHNlcmllcyk7XHJcbiAgfVxyXG5cclxuICBvbkNsaWNrKGRhdGEsIHNlcmllcz8pOiB2b2lkIHtcclxuICAgIGlmIChzZXJpZXMpIHtcclxuICAgICAgZGF0YS5zZXJpZXMgPSBzZXJpZXMubmFtZTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNlbGVjdC5lbWl0KGRhdGEpO1xyXG4gIH1cclxuXHJcbiAgdHJhY2tCeShpbmRleCwgaXRlbSk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gaXRlbS5uYW1lO1xyXG4gIH1cclxuXHJcbiAgc2V0Q29sb3JzKCk6IHZvaWQge1xyXG4gICAgbGV0IGRvbWFpbjtcclxuICAgIGlmICh0aGlzLnNjaGVtZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBkb21haW4gPSB0aGlzLnNlcmllc0RvbWFpbjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGRvbWFpbiA9IHRoaXMueURvbWFpbjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmNvbG9ycyA9IG5ldyBDb2xvckhlbHBlcih0aGlzLnNjaGVtZSwgdGhpcy5zY2hlbWVUeXBlLCBkb21haW4sIHRoaXMuY3VzdG9tQ29sb3JzKTtcclxuICB9XHJcblxyXG4gIGdldExlZ2VuZE9wdGlvbnMoKSB7XHJcbiAgICBjb25zdCBvcHRzID0ge1xyXG4gICAgICBzY2FsZVR5cGU6IHRoaXMuc2NoZW1lVHlwZSxcclxuICAgICAgY29sb3JzOiB1bmRlZmluZWQsXHJcbiAgICAgIGRvbWFpbjogW10sXHJcbiAgICAgIHRpdGxlOiB1bmRlZmluZWRcclxuICAgIH07XHJcbiAgICBpZiAob3B0cy5zY2FsZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBvcHRzLmRvbWFpbiA9IHRoaXMuc2VyaWVzRG9tYWluO1xyXG4gICAgICBvcHRzLmNvbG9ycyA9IHRoaXMuY29sb3JzO1xyXG4gICAgICBvcHRzLnRpdGxlID0gdGhpcy5sZWdlbmRUaXRsZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG9wdHMuZG9tYWluID0gdGhpcy55RG9tYWluO1xyXG4gICAgICBvcHRzLmNvbG9ycyA9IHRoaXMuY29sb3JzLnNjYWxlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG9wdHM7XHJcbiAgfVxyXG5cclxuICBvbkFjdGl2YXRlKGl0ZW0pIHtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZUFsbCgpO1xyXG5cclxuICAgIGNvbnN0IGlkeCA9IHRoaXMuYWN0aXZlRW50cmllcy5maW5kSW5kZXgoZCA9PiB7XHJcbiAgICAgIHJldHVybiBkLm5hbWUgPT09IGl0ZW0ubmFtZSAmJiBkLnZhbHVlID09PSBpdGVtLnZhbHVlO1xyXG4gICAgfSk7XHJcbiAgICBpZiAoaWR4ID4gLTEpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFtpdGVtXTtcclxuICAgIHRoaXMuYWN0aXZhdGUuZW1pdCh7IHZhbHVlOiBpdGVtLCBlbnRyaWVzOiB0aGlzLmFjdGl2ZUVudHJpZXMgfSk7XHJcblxyXG4gICAgdGhpcy50b29sdGlwT2JqID0gT2JqZWN0LmFzc2lnbih0aGlzLnRvb2x0aXBPYmosIGl0ZW0pXHJcbiAgICB0aGlzLmZpbmRPdGhlclByb3BlcnR5KCk7XHJcbiAgICB0aGlzLnNldEN1c3RvbUNsYXNzKCk7XHJcbiAgfVxyXG5cclxuICBvbkRlYWN0aXZhdGUoaXRlbSkge1xyXG4gICAgY29uc3QgaWR4ID0gdGhpcy5hY3RpdmVFbnRyaWVzLmZpbmRJbmRleChkID0+IHtcclxuICAgICAgcmV0dXJuIGQubmFtZSA9PT0gaXRlbS5uYW1lICYmIGQudmFsdWUgPT09IGl0ZW0udmFsdWU7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMuc3BsaWNlKGlkeCwgMSk7XHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSBbLi4udGhpcy5hY3RpdmVFbnRyaWVzXTtcclxuXHJcbiAgICB0aGlzLmRlYWN0aXZhdGUuZW1pdCh7IHZhbHVlOiBpdGVtLCBlbnRyaWVzOiB0aGlzLmFjdGl2ZUVudHJpZXMgfSk7XHJcbiAgfVxyXG5cclxuICBkZWFjdGl2YXRlQWxsKCkge1xyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gWy4uLnRoaXMuYWN0aXZlRW50cmllc107XHJcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMuYWN0aXZlRW50cmllcykge1xyXG4gICAgICB0aGlzLmRlYWN0aXZhdGUuZW1pdCh7IHZhbHVlOiBlbnRyeSwgZW50cmllczogW10gfSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSBbXTtcclxuICB9XHJcblxyXG4gIHNldEN1c3RvbUNsYXNzKCkge1xyXG4gICAgbGV0IGFsZXJ0VHlwZSA9IHRoaXMudG9vbHRpcE9ialtcImFsZXJ0VHlwZVwiXTtcclxuICAgIGlmIChhbGVydFR5cGUpIHtcclxuICAgICAgaWYgKGFsZXJ0VHlwZSA9PSAxKSB7XHJcbiAgICAgICAgdGhpcy5jdXN0b21Ub29sdGlwQ2xhc3MgPSAnYWxlcnQxJ1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuY3VzdG9tVG9vbHRpcENsYXNzID0gJ2FsZXJ0MidcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGZpbmRPdGhlclByb3BlcnR5KCkge1xyXG4gICAgbGV0IGFyciA9IHRoaXMucmVzdWx0cztcclxuICAgIGxldCBmdW5kTmFtZSA9IHRoaXMudG9vbHRpcE9ialtcIm5hbWVcIl07XHJcbiAgICBsZXQgdGltZU5hbWUgPSB0aGlzLnRvb2x0aXBPYmpbXCJ2YWx1ZVwiXTtcclxuICAgIGxldCBmaW5kU2VyaWVzID0ge307XHJcbiAgICBsZXQgb2JqO1xyXG5cclxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGlmIChhcnJbaV1bXCJuYW1lXCJdID09PSBmdW5kTmFtZSkge1xyXG4gICAgICAgIGZpbmRTZXJpZXMgPSBPYmplY3QuYXNzaWduKGZpbmRTZXJpZXMsIGFycltpXSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBsZXQgc2VyaWVzID0gZmluZFNlcmllc1tcInNlcmllc1wiXTtcclxuXHJcbiAgICBmb3IgKHZhciBqID0gMDsgaiA8IHNlcmllcy5sZW5ndGg7IGorKykge1xyXG4gICAgICBpZiAoc2VyaWVzW2pdW1wibmFtZVwiXSA9PT0gdGltZU5hbWUpIHtcclxuICAgICAgICBvYmogPSB7XHJcbiAgICAgICAgICBcIm5hdlwiOiBzZXJpZXNbal1bXCJuYXZcIl0sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBzZXJpZXNbal1bXCJtYXJrZXR2YWxcIl1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy50b29sdGlwT2JqID0gT2JqZWN0LmFzc2lnbih0aGlzLnRvb2x0aXBPYmosIG9iailcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gYmVsb3cgaXMgZm9yIGN1c3RvbSBhbGVydCBkZXRhaWxzIHJlY3QgbG9naWNcclxuICAgb25DbGlja0FsZXJ0Q2lyY2xlKGRhdGEpOiB2b2lkIHtcclxuICAgIGlmIChkYXRhKSB7XHJcbiAgICAgIGxldCBhbHJlYWR5SW5TaG93TWFwID0gZmFsc2U7XHJcbiAgICAgIHRoaXMuc2hvd0FsZXJ0RGV0YWlsc01hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgIGlmIChkYXRhLnggPT09IGl0ZW0ueCAmJiBkYXRhLm5hbWUgPT09IGl0ZW0ubmFtZSkge1xyXG4gICAgICAgICAgYWxyZWFkeUluU2hvd01hcCA9IHRydWU7XHJcbiAgICAgICAgICBpdGVtLnNob3cgPSAhaXRlbS5zaG93O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBpdGVtLnNob3cgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAoIWFscmVhZHlJblNob3dNYXApe1xyXG4gICAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgICB4OiBkYXRhLngsXHJcbiAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgICAgICBzaG93OiBkYXRhWydzaG93J10gPyAhZGF0YVsnc2hvdyddIDogdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNob3dBbGVydERldGFpbHNNYXAucHVzaChvYmopO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRTaG93QWxlcnREZXRhaWxzKGRhdGEpIHtcclxuICAgIGxldCBzaG93T3JOb3QgPSBmYWxzZTtcclxuICAgIHRoaXMuc2hvd0FsZXJ0RGV0YWlsc01hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoZGF0YS54ID09PSBpdGVtLnggJiYgZGF0YS5uYW1lID09PSBpdGVtLm5hbWUpIHtcclxuICAgICAgICBzaG93T3JOb3QgPSBpdGVtLnNob3c7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHNob3dPck5vdDtcclxuICB9XHJcblxyXG4gIGdldFJlY3RMb2FjdGlvblgoY2lyY2xlKTogbnVtYmVyIHtcclxuICAgIGxldCB4TG9jYXRpb24gPSAwO1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc0JleW9uZERpdmlzaW9uKG5ldyBEYXRlKGNpcmNsZS5wcmljZXRpbWUpKSkge1xyXG4gICAgICB4TG9jYXRpb24gPSBjaXJjbGUueCAtMjIwXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB4TG9jYXRpb24gPSBjaXJjbGUueCArMTBcclxuICAgIH1cclxuICAgIHJldHVybiB4TG9jYXRpb247XHJcbiAgfVxyXG5cclxuICBnZXRSZWN0TG9hY3Rpb25ZKGNpcmNsZSk6IG51bWJlciB7XHJcbiAgICBsZXQgeUxvY2F0aW9uID0gMDtcclxuICAgIGlmKGNpcmNsZS5uYXZDaGFuZ2UgPj0wKSB7XHJcbiAgICAgIHlMb2NhdGlvbiA9IGNpcmNsZS52YWx1ZSArIDEwXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB5TG9jYXRpb24gPSBjaXJjbGUudmFsdWUgLTExMFxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHlMb2NhdGlvblxyXG4gIH1cclxufSIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCAgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1jdXN0b20tbGVnZW5kJyxcclxuICB0ZW1wbGF0ZTogYDxtYXQtY2hpcC1saXN0IGNsYXNzPVwibWF0LWNoaXAtbGlzdFwiPlxyXG4gIDxuZy1jb250YWluZXJcclxuICAqbmdGb3I9XCJsZXQgZnVuZCBvZiByZXN1bHRzO2xldCBpPWluZGV4O3RyYWNrQnk6aW5kZXhcIiBcclxuICA+XHJcbiAgICAgPG1hdC1iYXNpYy1jaGlwXHJcbiAgICAgICpuZ0lmPVwiZ2V0U2hvd0xlZ2VuZEFuZENvbnNpc3RlbnQoZnVuZClcIlxyXG4gICAgICBbc2VsZWN0YWJsZV09XCJzZWxlY3RhYmxlXCIgXHJcbiAgICAgIFtyZW1vdmFibGVdPVwicmVtb3ZhYmxlXCIgXHJcbiAgICAgIFtzdHlsZS5ib3JkZXJDb2xvcl09XCJnZXRGdW5kUmVsYXRlZENvbG9yKGZ1bmQpXCJcclxuICAgICAgZGlzYWJsZVJpcHBsZT5cclxuICAgICAgICB7e2Z1bmQuZnVuZFRpY2tlciA/IGZ1bmQuZnVuZFRpY2tlciA6IGZ1bmQuZnVuZElEIH19XHJcbiAgICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cInJlbW92ZUljb25cIiBzdmdJY29uPVwiY2xvc2VcIiBtYXRDaGlwUmVtb3ZlIChjbGljayk9XCJyZW1vdmUoZnVuZClcIj48L21hdC1pY29uPiBcclxuICA8L21hdC1iYXNpYy1jaGlwPlxyXG4gIDwvbmctY29udGFpbmVyPlxyXG48L21hdC1jaGlwLWxpc3Q+YCxcclxuICBzdHlsZXM6IFtgLm1hdC1iYXNpYy1jaGlwe21hcmdpbjoxMHB4IDEwcHggMTVweDtib3JkZXItdG9wOjFweCBzb2xpZDtib3JkZXItYm90dG9tOjFweCBzb2xpZDtib3JkZXItcmlnaHQ6MXB4IHNvbGlkO2JvcmRlci1sZWZ0OjVweCBzb2xpZDtkaXNwbGF5OmlubGluZS1mbGV4O3BhZGRpbmc6M3B4IDAgMCAxMHB4O2ZvbnQtc2l6ZToxNHB4fS5tYXQtYmFzaWMtY2hpcCAucmVtb3ZlSWNvbnt3aWR0aDoxMHB4IWltcG9ydGFudDtoZWlnaHQ6MTBweCFpbXBvcnRhbnQ7bWFyZ2luOjAgOHB4O2N1cnNvcjpwb2ludGVyO21pbi1oZWlnaHQ6MTBweCFpbXBvcnRhbnQ7bWluLXdpZHRoOjEwcHghaW1wb3J0YW50fWBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDdXN0b21MZWdlbmRDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIEBJbnB1dCgpIHJlc3VsdHM7XHJcbiAgQElucHV0KCkgc2VsZWN0YWJsZTtcclxuICBASW5wdXQoKSByZW1vdmFibGU7XHJcbiAgQElucHV0KCkgY29sb3JEb21haW47XHJcbiAgQElucHV0KCkgaW5kZXg7XHJcbiAgQElucHV0KCkgc2VsZWN0ZWRGdW5kQ2hhbmdlXHJcblxyXG4gIGNvbnN0cnVjdG9yKCAgICBwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cyA6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLCAgXHJcbiAgICAgcHJpdmF0ZSBjb21tb25VdGlscyA6IENvbW1vblV0aWxzU2VydmljZSkgeyBcclxuICAgICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgXHJcbiAgfVxyXG5cclxuICBuZ09uRGVzdHJveSgpIHtcclxuICB9XHJcblxyXG4gIGdldFNob3dMZWdlbmRBbmRDb25zaXN0ZW50KGZ1bmQpIHtcclxuICAgIFxyXG4gICAgaWYgKGZ1bmQubmFtZSA9PT0gXCJcIikge1xyXG4gICAgICByZXR1cm4gZmFsc2VcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IGxpc3QgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgICBsZXQgc2hvdyA9IGZhbHNlO1xyXG4gICAgICBsaXN0LmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW0uZnVuZElEID09PSBmdW5kLm5hbWUgJiYgaXRlbS5jaGVja2VkKSB7XHJcbiAgICAgICAgICBzaG93ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIHJldHVybiBzaG93XHJcbiAgICB9XHJcbiAgfVxyXG4gIGdldEZ1bmRSZWxhdGVkQ29sb3IoZnVuZCkge1xyXG4gICAgbGV0IGNvbG9yU3RyID0gJyc7XHJcbiAgICB0aGlzLmNvbG9yRG9tYWluLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtWydmdW5kaWQnXSA9PT0gZnVuZFsnbmFtZSddKSB7XHJcbiAgICAgICAgY29sb3JTdHIgPSBpdGVtWydjb2xvciddO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGNvbG9yU3RyO1xyXG4gIH1cclxuICBcclxuXHJcbiAgcmVtb3ZlKGZ1bmQpOiB2b2lkIHtcclxuICAgIHRoaXMuY29tbW9uVXRpbHMudXBkYXRlRnVuZFN0YXR1cyhmdW5kWydmdW5kSUQnXSwgZmFsc2UpO1xyXG4gICAgbGV0IGZ1bmRJbmRleCA9IC0xO1xyXG4gICAgdGhpcy5yZXN1bHRzLmZvckVhY2goKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgIGlmIChpdGVtWyduYW1lJ10gPT09IGZ1bmRbJ25hbWUnXSkge1xyXG4gICAgICAgIGZ1bmRJbmRleCA9IGluZGV4O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoZnVuZEluZGV4ID49IDApIHtcclxuICAgICAgdGhpcy5yZXN1bHRzLnNwbGljZShmdW5kSW5kZXgsIDEpO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuc2VsZWN0ZWRGdW5kQ2hhbmdlLmVtaXQoZnVuZCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkluaXQsIEluamVjdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG4vL2ltcG9ydCB7IGRldiwgcHJvZCB9IGZyb20gJy4uL2xpYi1lbnYnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgTmF2U2VydmljZSB7XHJcblxyXG4gIHByaXZhdGUgZGF0YSA6IEJlaGF2aW9yU3ViamVjdDxhbnlbXT4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KFtdIGFzIGFueVtdKTtcclxuXHJcbiAgLy9iYXNlVXJsID0gdGhpcy5lbnYucHJvZHVjdGlvbj8gcHJvZC5zZXJ2aWNlX2Jhc2VfdXJsOiBkZXYuc2VydmljZV9iYXNlX3VybDtcclxuICAvL2NvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCwgQEluamVjdCgnZW52JykgcHJpdmF0ZSBlbnYpIHsgfVxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkgeyB9XHJcblxyXG5cclxuICBnZXRUb2RheU5hdihmdW5kcyk6IE9ic2VydmFibGU8YW55W10+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PGFueVtdPignL2FwaS90b2RheScpOy8vIGRlbW8gYXBpLCBjYW4gYmUgcmVtb3ZlZCBhZnRlciBtZXJnZSBxbmF2LWxpbmUtY2hhcnRcclxuICB9XHJcbiAgLy8gY2FsbCB0aGlzIG9uZSBmcm9tIGNoYXJ0IGNvbXBvbmVudCBvbmx5IHRvIGF2b2lkIG11bHRpcGxlIGNhbGwgcmVxdWVzdCBieSBkaWZmZXJlbnQgY29tcG9uZW50XHJcbiAgZmV0Y2hGdW5kTGlzdCgpIHtcclxuICAgIC8vcmV0dXJuIHRoaXMuaHR0cC5nZXQ8YW55W10+KCcvYXBpL2Z1bmRMaXN0Jykuc3Vic2NyaWJlKGQgPT4gdGhpcy5kYXRhLm5leHQoZCBhcyBhbnlbXSkpO1xyXG4gICAgdGhpcy5kYXRhID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSBhcyBhbnlbXSk7Ly9yZXNldCBkYXRhIGFzIHRoZSBnZXRGdW5kTGlzdCBzdWJjcmlwdGlvbiBtYXkgc3RpbGwgZ2V0IHRoZSBvbGQgZGF0YSBpZiBuZXcgY2FsbCBoYXNuJ3QgcmV0dXJuZWQgeWV0LlxyXG4gICAgdGhpcy5odHRwLmdldDxhbnlbXT4oJy9xbmF2LXdlYi1tdWx0aWNsYXNzL2RhdGEvZnVuZGxpc3Q/dGltZVpvbmVPZmZzZXQ9JyArIG5ldyBEYXRlKCkuZ2V0VGltZXpvbmVPZmZzZXQoKSAqICgtMSkpXHJcbiAgICAgIC5zdWJzY3JpYmUoZCA9PiB7XHJcbiAgICAgICAgdGhpcy5kYXRhLm5leHQoZCBhcyBhbnlbXSlcclxuICAgICAgfSxcclxuICAgICAgICBlcnJvciA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcilcclxuICAgICAgICB9KTtcclxuICB9XHJcbiAgLy8gY2FsbCB0aGlzIG9uZSBmb3IgYWxsIGNvbXBvbmVudHMgdG8gZ2V0IGZ1bmRsaXN0IGlmIGl0J3MgYWxyZWFkeSBmZXRjaGVkLlxyXG4gIGdldEZ1bmRMaXN0KCk6IE9ic2VydmFibGU8YW55W10+IHtcclxuICAgICAgcmV0dXJuIHRoaXMuZGF0YS5hc09ic2VydmFibGUoKTtcclxuICB9XHJcbiAgZ2V0UG9zaXRpb25EZXRhaWxzKGZ1bmQ6IHN0cmluZykgOiBPYnNlcnZhYmxlPGFueVtdPiB7XHJcbiAgICAvL3JldHVybiB0aGlzLmh0dHAuZ2V0KCdhcGkvcG9zaXRpb25EZXRhaWxzJylcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PGFueVtdPignL3FuYXYtd2ViLW11bHRpY2xhc3MvZGF0YS9mdW5kRGV0YWlsP2Z1bmRJZD0nK2Z1bmQpOztcclxuICB9XHJcblxyXG59XHJcbiIsImV4cG9ydCBlbnVtIEFjdGlvbiB7XHJcbiAgICBSRUdJU1RFUiA9IFwicmVnaXN0ZXJcIixcclxuICAgIFNFTkRUTyA9IFwic2VuZFRvXCIsXHJcbiAgICBTVE9QV0FUQ0hGVU5EID0gXCJzdG9wV2F0Y2hGdW5kXCIsXHJcbiAgICBXQVRDSEZVTkQgPSBcIndhdGNoRnVuZFwiXHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUmVxdWVzdCB7XHJcbiAgICBhY3Rpb24/OiBBY3Rpb247XHJcbiAgICBzZXNzaW9uSWQ/OiBhbnk7XHJcbiAgICBmdW5kSWQ/OmFueTtcclxuICAgIHRpbWVab25lT2Zmc2V0Pzphbnk7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgU2VyaWVzIHtcclxuICAgIG5hbWU6IGFueTtcclxuICAgIHZhbHVlOiBhbnk7XHJcbn1cclxuZXhwb3J0IGludGVyZmFjZSBOYXYge1xyXG5cclxuICAgIGN1c2lwPzogYW55O1xyXG4gICAgZXhjaGFuZ2VSYXRlPzogbnVtYmVyO1xyXG4gICAgZnVuZGlkOiBhbnk7XHJcbiAgICBwYXJTaGFyZTogbnVtYmVyO1xyXG4gICAgZnVuZG12OiBudW1iZXI7XHJcbiAgICBmdW5kbXZDaGFuZ2U/OiBudW1iZXI7XHJcbiAgICBmdW5kbXZDaGFuZ2VQZXJjZW50PzogbnVtYmVyO1xyXG4gICAgbXY/OiBudW1iZXI7XHJcbiAgICBtdkNoYW5nZT86IG51bWJlcjtcclxuICAgIG5hdj86IG51bWJlcjtcclxuICAgIG5hdkNoYW5nZT86IG51bWJlcjtcclxuICAgIG5hdkNoYW5nZVBlcmNlbnQ/OiBudW1iZXI7XHJcbiAgICBwcmV2aW91c1ByaWNlPzogbnVtYmVyOyAvL25ld1xyXG4gICAgcHJpY2U/OiBudW1iZXI7XHJcbiAgICBzb2Rtdj86IG51bWJlcjtcclxuICAgIHVwZGF0ZXRpbWU/OiBudW1iZXI7IC8vbmV3XHJcbiAgICBwcmljZXRpbWU/Om51bWJlcjtcclxuIFxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5hdkV2ZW50IHtcclxuICAgIGV2ZW50VHlwZT87IC8vZnVuZENoYW5nZSBvciBzb2RDaGFuZ2VcclxuICAgIGV2ZW50RGF0YT86IE5hdjtcclxufSIsImltcG9ydCB7IEluamVjdGFibGUsIEluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgd2ViU29ja2V0LCBXZWJTb2NrZXRTdWJqZWN0fSBmcm9tICdyeGpzL3dlYlNvY2tldCcgLy8gZm9yIFJ4SlMgNiwgZm9yIHY1IHVzZSBPYnNlcnZhYmxlLndlYlNvY2tldFxyXG5pbXBvcnQgeyBOYXYsUmVxdWVzdCwgQWN0aW9uLCBOYXZFdmVudCB9IGZyb20gJy4uL21vZGVsL3FuYXYnO1xyXG4vL2ltcG9ydCB7IGRldiwgcHJvZCB9IGZyb20gJy4uL2xpYi1lbnYnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgTmF2U29ja2V0U2VydmljZSB7XHJcbiAgIFxyXG4gICAgcHJpdmF0ZSBzdWJqZWN0OyAvLzogV2ViU29ja2V0U3ViamVjdDxOYXZFdmVudD47XHJcblxyXG4gICAgcHJpdmF0ZSBuYXYgOiBCZWhhdmlvclN1YmplY3Q8TmF2RXZlbnQ+ID0gbmV3IEJlaGF2aW9yU3ViamVjdCh7fSBhcyBOYXZFdmVudCk7XHJcbiAgICBcclxuICAgIFxyXG4gICAgLy8gY29uc3RydWN0b3IoQEluamVjdCgnZW52JykgcHJpdmF0ZSBlbnYpIHtcclxuICAgIC8vICAgICB0aGlzLmluaXRTb2NrZXQoKTtcclxuICAgIC8vICAgICB0aGlzLnJlZ2lzdGVyU2VydmljZSgpO1xyXG4gICAgLy8gfVxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW5pdFNvY2tldCgpO1xyXG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyU2VydmljZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpbml0U29ja2V0KCkgIHtcclxuICAgICAgICB0aGlzLnN1YmplY3QgPSB3ZWJTb2NrZXQoJ3dzczovLycrd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lK1wiOlwiK3dpbmRvdy5sb2NhdGlvbi5wb3J0KycvcW5hdi13ZWItbXVsdGljbGFzcy9jb25uJyk7IC8vICBwcm94eSB3b24ndCBiZSBhYmxlIHRvIGZ1bmN0aW9uIGlmIHRoZSBwb3J0IG5vdCBtYXRjaCB3aXRoIHN0YXJ0IHBvcnRcclxuICAgICAgICAvL3JldHVybiB0aGlzLnN1YmplY3Q7XHJcbiAgICAgICAgdGhpcy5zdWJqZWN0LnN1YnNjcmliZShcclxuICAgICAgICAgICAgKG1zZykgPT4ge3RoaXMubmF2Lm5leHQobXNnIGFzIE5hdkV2ZW50KTt9LFxyXG4gICAgICAgICAgICAoZXJyKSA9PiBjb25zb2xlLmxvZyhcIkVSUk9SISEhIVwiK2VyciksXHJcbiAgICAgICAgICAgICgpID0+IGNvbnNvbGUubG9nKFwiTkFWIFNvY2tldCBDT01QTEVURUQuLi4uLlwiKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAvLyBjb25zb2xlLmxvZyhuZXcgRGF0ZSgxNTI0ODIzODA5MjAwNDMxKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE5hdigpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5uYXYuYXNPYnNlcnZhYmxlKCk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgc2VuZChyZXF1ZXN0OiBSZXF1ZXN0KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zdWJqZWN0Lm5leHQocmVxdWVzdCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlZ2lzdGVyRnVuZHMoZnVuZHM6IGFueVtdKSB7XHJcblxyXG4gICAgICAgIGZ1bmRzLmZvckVhY2goZnVuZCA9PiB7XHJcbiAgICAgICAgICB0aGlzLnNlbmQoe1wiYWN0aW9uXCI6QWN0aW9uLldBVENIRlVORCxcImZ1bmRJZFwiOmZ1bmR9KSAgICAgIFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVuUmVnaXN0ZXJGdW5kcyhmdW5kczogYW55W10pIHtcclxuICAgICAgICBmdW5kcy5mb3JFYWNoKGZ1bmQgPT4ge1xyXG4gICAgICAgICAgdGhpcy5zZW5kKHtcImFjdGlvblwiOkFjdGlvbi5TVE9QV0FUQ0hGVU5ELFwiZnVuZElkXCI6ZnVuZH0pICAgICAgXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgcmVnaXN0ZXJTZXJ2aWNlKCkge1xyXG4gICAgICAgIHRoaXMuc2VuZCh7YWN0aW9uOkFjdGlvbi5SRUdJU1RFUixzZXNzaW9uSWQ6bmV3IERhdGUoKS52YWx1ZU9mKCkgKyAnJyx0aW1lWm9uZU9mZnNldDpuZXcgRGF0ZSgpLmdldFRpbWV6b25lT2Zmc2V0KCkqKC0xKX0pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFJlc291cmNlTWFuYWdlclNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgLy93aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYmx1cicsKGV2ZW50KT0+e3RoaXMuZGVhY3RpdmUoZXZlbnQpfSk7XHJcbiAgICAgIC8vd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywoZXZlbnQpPT57dGhpcy5hY3RpdmUoZXZlbnQpfSk7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywoZXZlbnQpPT57XHJcbiAgICAgICAgaWYoZG9jdW1lbnQuaGlkZGVuKSB7XHJcbiAgICAgICAgICB0aGlzLmRlYWN0aXZlKGV2ZW50KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5hY3RpdmUoZXZlbnQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgfVxyXG5cclxuICBwcml2YXRlIGludGVydmFsSW5zdGFuY2VzOiBhbnlbXSA9IFtdO1xyXG4gIHByaXZhdGUgaW50ZXJ2YWxGdW5jczogYW55W10gPSBbXTtcclxuICBwcml2YXRlIGRlYWN0aXZlKGV2ZW50OiBhbnkpIHtcclxuICAgIC8vY29uc29sZS5sb2coZXZlbnQpO1xyXG4gICAgIHRoaXMuZG9EZWFjdGl2ZSgpOyAgXHJcbiAgfVxyXG4gIHByaXZhdGUgZG9EZWFjdGl2ZSgpIHtcclxuICAgICAgdGhpcy5pbnRlcnZhbEluc3RhbmNlcy5mb3JFYWNoICggaXRlbSA9PiB7XHJcbiAgICAgICAgbGV0IHRpbWUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBjbGVhciB0aGUgc2V0aW50ZXJ2YWwgZm9yIGNvbXBvbmVudDogJHtpdGVtfSwgJHt0aW1lfWApO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwoaXRlbSk7XHJcbiAgICB9KVxyXG4gIH1cclxuICBwcml2YXRlIGFjdGl2ZShldmVudDogYW55KSB7XHJcbiAgICAvL2NvbnNvbGUubG9nKGV2ZW50KTtcclxuICAgIHRoaXMuaW50ZXJ2YWxGdW5jcy5mb3JFYWNoKCBpdGVtID0+IHtcclxuICAgICAgbGV0IHRpbWUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAvL2NvbnNvbGUubG9nKGBhY3RpdmUgdGhlIHNldGludGVydmFsIGZvciBjb21wb25lbnQ6ICR7aXRlbVsnZnVuYyddfSwgaW50ZXJ2YWw6JHtpdGVtWydpbnRlcnZhbCddfSwgJHt0aW1lfWApO1xyXG4gICAgICB0aGlzLmludGVydmFsSW5zdGFuY2VzLnB1c2goc2V0SW50ZXJ2YWwoaXRlbVsnZnVuYyddLCBpdGVtWydpbnRlcnZhbCddKSk7XHJcbiAgICB9KVxyXG4gIH1cclxuICByZWdpc3RJbnRlcnZhbChpbnRlcnZhbEZ1bmMsIGludGVydmFsOiBudW1iZXIpIHtcclxuICAgIGxldCBpbnN0YW5jZSA9IHNldEludGVydmFsKGludGVydmFsRnVuYywgaW50ZXJ2YWwpO1xyXG4gICAgdGhpcy5pbnRlcnZhbEluc3RhbmNlcy5wdXNoKGluc3RhbmNlKTtcclxuICAgIHRoaXMuaW50ZXJ2YWxGdW5jcy5wdXNoKHsnZnVuYyc6aW50ZXJ2YWxGdW5jLCAnaW50ZXJ2YWwnOmludGVydmFsfSk7XHJcbiAgfVxyXG4gIC8vbmVlZCBjYWxsIGluIGNvbXBvbmVudCBuZ09uRGVzdHJveSgpIHRvIGNsZWFyIHJlc291cmNlcyBmb3IgY3VycmVudCBjb21wb25lbnRcclxuICBjbGVhblJlc291cmNlcygpIHtcclxuICAgIHRoaXMuZG9EZWFjdGl2ZSgpO1xyXG4gICAgdGhpcy5pbnRlcnZhbEluc3RhbmNlcyA9IFtdO1xyXG4gICAgdGhpcy5pbnRlcnZhbEZ1bmNzID0gW107XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBjb25zdCBjdXN0b21Db2x1bW4gPSBbXTtcclxuXHJcbiAgZXhwb3J0IGNvbnN0IG5vcm1hbENvbHVtbiA9ICBbXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdjdXNpcCcsXHJcbiAgICAgIG5hbWU6ICdJbnN0cnVtZW50IElkIFJlZicsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiBmYWxzZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnZGVmYXVsdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyTGVmdCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxMZWZ0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdsb25nU2hvcnRJbmRpY2F0b3InLFxyXG4gICAgICBuYW1lOiAnTG9uZy9TaG9ydCcsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiBmYWxzZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnZGVmYXVsdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyTGVmdCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxMZWZ0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdwYXJTaGFyZScsXHJcbiAgICAgIG5hbWU6ICdVbml0cycsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiBmYWxzZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdzb2RQcmljZScsXHJcbiAgICAgIG5hbWU6ICdQcmljZSBQcmV2aW91cycsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRTaG9ydCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsUmlnaHQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ3ByaWNlJyxcclxuICAgICAgbmFtZTogJ1ByaWNlIEN1cnJlbnQnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdtdicsXHJcbiAgICAgIG5hbWU6ICdNYXJrZXQgVmFsdWUnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdwcmljZUNoYW5nZVBlcmNlbnQnLFxyXG4gICAgICBuYW1lOiAnUHJpY2UgJSBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAncGVyY2VudEZvcm1hdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICduYXZJbXBhY3QnLFxyXG4gICAgICBuYW1lOiAnTkFWIEltcGFjdCcsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRMb25nJyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxOdW1iZXInLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGV4cG9ydCBjb25zdCBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nID0gW1xyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBcIlJlc2l6ZSB0byBGaXRcIixcclxuICAgIC8vICAgdHlwZTogXCJyZXNpemVUb0ZpdFwiLFxyXG4gICAgLy8gICBoYXNTdWJNZW51OiBmYWxzZSxcclxuICAgIC8vIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6IFwiRnJlZXplIENvbHVtblwiLFxyXG4gICAgICB0eXBlOiBcImZyZWV6ZUNvbHVtblwiLFxyXG4gICAgICBoYXNTdWJNZW51OiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6IFwiU29ydCBDb2x1bW5cIixcclxuICAgICAgdHlwZTogXCJzb3J0Q29sdW1uXCIsXHJcbiAgICAgIGhhc1N1Yk1lbnU6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogXCJWaWV3IE1vcmUgQ29sdW1uc1wiLFxyXG4gICAgLy8gICB0eXBlOiBcInZpZXdNb3JlQ29sdW1uc1wiLFxyXG4gICAgLy8gICBoYXNTdWJNZW51OiB0cnVlLFxyXG4gICAgLy8gfSxcclxuICBdOyIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uLCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBCYXNlV2lkZ2V0Q29tcG9uZW50LCBBcHBDb250ZXh0LCBBcHBSZWdpc3RyeSB9IGZyb20gJ0BvbW5pYS91aS1jb21tb24nO1xyXG5pbXBvcnQgeyBOYXZTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNlcnZpY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdlNvY2tldFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9uYXYtc29ja2V0LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb21tb25VdGlsc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb21tb24tdXRpbHMuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdkV2ZW50IH0gZnJvbSAnLi4vbW9kZWwvcW5hdic7XHJcbmltcG9ydCB7IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvc2hhcmUtaW5mby1iZXdlZW4tY29tcG9uZW50cy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJlc291cmNlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9yZXNvdXJjZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQge2N1c3RvbUNvbHVtbiwgbm9ybWFsQ29sdW1uLCBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nfSBmcm9tICcuL2NvbHVtbi1kYXRhJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLXFuYXYtcG9zaXRpb24nLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cInFuYXYtcG9zaXRpb24tY29udGFpbmVyXCIgKm5nSWY9XCJpc0RhdGFBdmFpbGFibGVcIj5cclxuICAgIDwhLS0gPGRpdiBjbGFzcz1cInJldHVybkJhY2tcIiAoY2xpY2spPVwicmV0dXJuQmFjaygpXCI+XHJcbiAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwiaG9tZVwiIHN2Z0ljb249XCJob21lXCI+PC9tYXQtaWNvbj5cclxuICAgIDwvZGl2PiAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmdW5kRGV0YWlsc1wiPlxyXG4gICAgICAgIDx1bD5cclxuICAgICAgICAgICAgPGxpPlBvc2l0aW9uIERldGFpbHMgZm9yPC9saT5cclxuICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPkVudGl0eSBUaWNrZXI6IDwvbGFiZWw+IHt7ZnVuZEluZm9bMl19fVxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPkVudGl0eSBOYW1lOiA8L2xhYmVsPiB7e2Z1bmRJbmZvWzFdfX1cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICA8L3VsPlxyXG4gICAgPC9kaXY+XHJcbjxsaWItY29tbW9uLWRhdGEtdGFibGVcclxuICAgIFtoZWFkZXJTZXR0aW5nXT1cImhlYWRlclNldHRpbmdcIlxyXG4gICAgW2hlYWRlckhlaWdodF09XCJoZWFkZXJIZWlnaHRcIlxyXG4gICAgW3Jvd3NdPVwicm93c1wiXHJcbiAgICBbY2hpbGRSb3dzXT1cImNoaWxkUm93c1wiXHJcbiAgICBbYWxlcnREYXRhXT1cImFsZXJ0RGF0YVwiXHJcbiAgICBbcm93SGVpZ2h0XT1cInJvd0hlaWdodFwiXHJcbiAgICBbY3VzdG9tQ29sdW1uXT1cImN1c3RvbUNvbHVtblwiXHJcbiAgICBbbm9ybWFsQ29sdW1uXT1cIm5vcm1hbENvbHVtblwiXHJcbiAgICBbbGltaXRdPVwibGltaXRcIlxyXG4gICAgW2Zvb3RlckhlaWdodF09XCJmb290ZXJIZWlnaHRcIlxyXG4gICAgW2hlYWRlckNoZWNrQm94XT1cImhlYWRlckNoZWNrQm94XCJcclxuICAgIFtpc0RhdGFUYWJsZVBhdXNlZF09XCJpc0RhdGFUYWJsZVBhdXNlZFwiXHJcbiAgICBbY29sdW1uTWVudURyb3BEb3duU2V0dGluZ109XCJjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nXCJcclxuICAgIFtkZWZhdWx0U29ydENvbF09XCInY3VzaXAnXCJcclxuICAgICh0b2dnbGVQYXVzZUZsYWdFdmVudCk9XCJ0b2dnbGVQYXVzZUZsYWcoKVwiXHJcbj5cclxuPC9saWItY29tbW9uLWRhdGEtdGFibGU+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnN0cmlwZWQgLmRhdGF0YWJsZS1yb3ctb2Rke2JhY2tncm91bmQ6I2VlZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzMwNGZmZTtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMTkzYWU0O2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMyMDQxZWY7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNlZWU7dHJhbnNpdGlvbi1wcm9wZXJ0eTpiYWNrZ3JvdW5kO3RyYW5zaXRpb24tZHVyYXRpb246LjNzO3RyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOmxpbmVhcn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmVtcHR5LXJvd3toZWlnaHQ6NTBweDt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouNXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAubG9hZGluZy1yb3d7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1yb3ctbGVmdHtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1wb3NpdGlvbjoxMDAlIDA7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJSFdQU2tOZVNCbUpoVFFWdGJpRE5DZ0FTYWdJSXVKWDhPZ0FBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LXJpZ2h0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0e2JhY2tncm91bmQtcG9zaXRpb246MCAwO2JhY2tncm91bmQtY29sb3I6I2ZmZjtiYWNrZ3JvdW5kLXJlcGVhdDpyZXBlYXQteTtiYWNrZ3JvdW5kLWltYWdlOnVybChkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFRQUFBQUJDQVlBQUFENVBBL05BQUFBRmtsRVFWUUkxMlBRa05kaTFWVFE1Z2JTd2tBc0RRQVJMQUlHdE9TRlVBQUFBQUJKUlU1RXJrSmdnZz09KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlcntib3gtc2hhZG93OjAgMnB4IDRweCAwIHJnYmEoMCwwLDAsLjE1KTtwb3NpdGlvbjpzdGlja3k7cG9zaXRpb246LXdlYmtpdC1zdGlja3k7dG9wOjA7ei1pbmRleDo5OTk7YmFja2dyb3VuZC1jb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGx7dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6cmdiYSgwLDAsMCwuNTQpO3ZlcnRpY2FsLWFsaWduOmJvdHRvbTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo1MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJ7cG9zaXRpb246cmVsYXRpdmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5sb25ncHJlc3MgLmRyYWdnYWJsZTo6YWZ0ZXJ7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjRzLG9wYWNpdHkgLjRzLC13ZWJraXQtdHJhbnNmb3JtIC40cztvcGFjaXR5Oi41Oy13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKDEpO3RyYW5zZm9ybTpzY2FsZSgxKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kcmFnZ2FibGU6OmFmdGVye2NvbnRlbnQ6XCIgXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjUwJTtsZWZ0OjUwJTttYXJnaW46LTMwcHggMCAwIC0zMHB4O2hlaWdodDo2MHB4O3dpZHRoOjYwcHg7YmFja2dyb3VuZDojZWVlO2JvcmRlci1yYWRpdXM6MTAwJTtvcGFjaXR5OjE7LXdlYmtpdC1maWx0ZXI6bm9uZTtmaWx0ZXI6bm9uZTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgwKTt0cmFuc2Zvcm06c2NhbGUoMCk7ei1pbmRleDo5OTk5O3BvaW50ZXItZXZlbnRzOm5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5kcmFnZ2luZyAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6bm9uZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWRldGFpbHtiYWNrZ3JvdW5kOiNmNWY1ZjU7cGFkZGluZzoxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWdyb3VwLWhlYWRlcntiYWNrZ3JvdW5kOiNmNWY1ZjU7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgI2Q5ZDhkOTtib3JkZXItdG9wOjFweCBzb2xpZCAjZDlkOGQ5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse3RleHQtYWxpZ246Y2VudGVyO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7bGluZS1oZWlnaHQ6NTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktZ3JvdXAtY2VsbHt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouOXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDtjb2xvcjojMzUzNTM1O3RyYW5zaXRpb246d2lkdGggLjNzO2ZvbnQtc2l6ZToxNHB4O2ZvbnQtd2VpZ2h0OjQwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLnByb2dyZXNzLWxpbmVhcntkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCU7aGVpZ2h0OjVweDtwYWRkaW5nOjA7bWFyZ2luOjA7cG9zaXRpb246YWJzb2x1dGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lcntkaXNwbGF5OmJsb2NrO3Bvc2l0aW9uOnJlbGF0aXZlO292ZXJmbG93OmhpZGRlbjt3aWR0aDoxMDAlO2hlaWdodDo1cHg7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTtiYWNrZ3JvdW5kLWNvbG9yOiNhYWQxZjl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lciAuYmFye3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXI7LXdlYmtpdC1hbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O2FuaW1hdGlvbjouOHMgY3ViaWMtYmV6aWVyKC4zOSwuNTc1LC41NjUsMSkgaW5maW5pdGUgcXVlcnk7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjJzIGxpbmVhciwtd2Via2l0LXRyYW5zZm9ybSAuMnMgbGluZWFyO2JhY2tncm91bmQtY29sb3I6IzEwNmNjODtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7dG9wOjA7Ym90dG9tOjA7d2lkdGg6MTAwJTtoZWlnaHQ6NXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVye2JvcmRlci10b3A6MXB4IHNvbGlkIHJnYmEoMCwwLDAsLjEyKTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo0MDA7Y29sb3I6cmdiYSgwLDAsMCwuNTQpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5wYWdlLWNvdW50e2xpbmUtaGVpZ2h0OjUwcHg7aGVpZ2h0OjUwcHg7cGFkZGluZzowIDEuMnJlbX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2Vye21hcmdpbjowIDEwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaXt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5kaXNhYmxlZCBhe2NvbG9yOnJnYmEoMCwwLDAsLjI2KSFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCFpbXBvcnRhbnR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5hY3RpdmUgYXtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpO2ZvbnQtd2VpZ2h0OjcwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIGF7aGVpZ2h0OjIycHg7bWluLXdpZHRoOjI0cHg7bGluZS1oZWlnaHQ6MjJweDtwYWRkaW5nOjAgNnB4O2JvcmRlci1yYWRpdXM6M3B4O21hcmdpbjo2cHggM3B4O3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt0ZXh0LWRlY29yYXRpb246bm9uZTt2ZXJ0aWNhbC1hbGlnbjpib3R0b219Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhOmhvdmVye2NvbG9yOnJnYmEoMCwwLDAsLjc1KTtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcHJldiwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1za2lwe2ZvbnQtc2l6ZToyMHB4O2xpbmUtaGVpZ2h0OjIwcHg7cGFkZGluZzowIDNweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3csLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVye2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWNlbGx7Zm9udC13ZWlnaHQ6NzAwfS5kYXRhdGFibGUtY2hlY2tib3h7cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjA7Y3Vyc29yOnBvaW50ZXI7dmVydGljYWwtYWxpZ246bWlkZGxlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO2JveC1zaXppbmc6Ym9yZGVyLWJveDtwYWRkaW5nOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XXtwb3NpdGlvbjpyZWxhdGl2ZTttYXJnaW46MCAxcmVtIDAgMDtjdXJzb3I6cG9pbnRlcjtvdXRsaW5lOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpiZWZvcmV7dHJhbnNpdGlvbjouM3MgZWFzZS1pbi1vdXQ7Y29udGVudDpcIlwiO3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MDt6LWluZGV4OjE7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtib3JkZXI6MnB4IHNvbGlkICNmMmYyZjJ9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkOmJlZm9yZXstd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTt0cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7aGVpZ2h0Oi41cmVtO2JvcmRlci1jb2xvcjojMDA5Njg4O2JvcmRlci10b3Atc3R5bGU6bm9uZTtib3JkZXItcmlnaHQtc3R5bGU6bm9uZX0uZGF0YXRhYmxlLWNoZWNrYm94IGlucHV0W3R5cGU9Y2hlY2tib3hdOmFmdGVye2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MDtsZWZ0OjA7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtiYWNrZ3JvdW5kOiNmZmY7Y3Vyc29yOnBvaW50ZXJ9QC13ZWJraXQta2V5ZnJhbWVzIHF1ZXJ5ezAle29wYWNpdHk6MTstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKX0xMDAle29wYWNpdHk6MDstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKX19QGtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy16ZXJve3RleHQtYWxpZ246cmlnaHQ7dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1uYWdldGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6I2I5MTIyNDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1wb3NpdGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzI4NzQzZTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1hbGlnbi1sZWZ0e3RleHQtYWxpZ246bGVmdDtjb2xvcjojMzUzNTM1fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1jZW50ZXJ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tcmlnaHR7dGV4dC1hbGlnbjpyaWdodDtjb2xvcjojMzUzNTM1fWJ1dHRvbi5tYXQtbWVudS1pdGVte2hlaWdodDozMHB4O2xpbmUtaGVpZ2h0OjMwcHg7Zm9udC1zaXplOjEzcHg7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWF0LW1lbnUtaXRlbTpob3Zlcjpub3QoW2Rpc2FibGVkXSl7YmFja2dyb3VuZDojZTFlY2YyfS5jaGVjay1pY29uLm1hdC1pY29ue3dpZHRoOjE0cHg7aGVpZ2h0OjE0cHg7bWFyZ2luLWxlZnQ6MjBweDtjb2xvcjojMDAwfS5uZ3gtZGF0YXRhYmxlLmZpeGVkLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1pbm5lcntoZWlnaHQ6MTAwJX1gLCBgLm5neC1kYXRhdGFibGUubWF0ZXJpYWx7ZGlzcGxheTp1bnNldH0ubmd4LWRhdGF0YWJsZSAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwtdGVtcGxhdGUtd3JhcCAuY29sdW1uSGVhZGVye2NvbG9yOiMwMDB9LnJldHVybkJhY2t7d2lkdGg6MjBweDtoZWlnaHQ6MjBweDtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MTRweDtyaWdodDo2MHB4O2N1cnNvcjpwb2ludGVyfS5xbmF2LXBvc2l0aW9uLWNvbnRhaW5lcnt3aWR0aDoxMDAlO2hlaWdodDoxMDAlfS5mdW5kRGV0YWlsc3tjb2xvcjojNDY0NjQ2O2ZvbnQtc2l6ZToxNnB4O3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6LTE1cHg7Zm9udC1mYW1pbHk6RElOTmV4dExUUHJvLU1lZGl1bX11bHtsaXN0LXN0eWxlOm5vbmU7ZGlzcGxheTppbmxpbmUtZmxleH1saXttYXJnaW4tcmlnaHQ6NXB4fWBdLFxyXG4gIC8vZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uU2hhZG93RG9tXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBRbmF2UG9zaXRpb25Db21wb25lbnQgZXh0ZW5kcyBCYXNlV2lkZ2V0Q29tcG9uZW50IHtcclxuXHJcbiAgcHJpdmF0ZSBzdWJzOiBTdWJzY3JpcHRpb25bXTtcclxuICByb3dzOiBhbnlbXSA9IFtdO1xyXG4gIGNoaWxkUm93czogYW55W10gPSBbXTtcclxuICBpc0RhdGFBdmFpbGFibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICByb3dIZWlnaHQ6bnVtYmVyPTUwO1xyXG4gIGFsZXJ0RGF0YTogYW55W10gPSBbXTtcclxuICBhbGxSb3dzU2VsZWN0ZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBpc1NlbGVjdGVkTWFwOiBhbnlbXSA9IFtdO1xyXG4gIGhlYWRlclNldHRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIGhlYWRlckhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgLy8gdGVtcCBkYXRhIHN0cnVjdHVyZVxyXG4gIGlzRGF0YVRhYmxlUGF1c2VkOmJvb2xlYW4gPSBmYWxzZTtcclxuICBjdXN0b21Db2x1bW46IGFueVtdID0gY3VzdG9tQ29sdW1uO1xyXG4gIG5vcm1hbENvbHVtbjogYW55W10gPSBub3JtYWxDb2x1bW47XHJcbiAgY29sdW1uTWVudURyb3BEb3duU2V0dGluZzogYW55W10gPSBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nO1xyXG4gIGxpbWl0OiBudW1iZXIgPSA1O1xyXG4gIGZvb3RlckhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgaGVhZGVyQ2hlY2tCb3g6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBmdW5kSW5mbzogYW55ID0gW107XHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBuYXZTZXJ2aWNlOiBOYXZTZXJ2aWNlLCAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBwcml2YXRlIGFwcFJlZ2lzdHJ5OiBBcHBSZWdpc3RyeSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIGFwcENvbnRleHQ6IEFwcENvbnRleHQsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBuYXZTb2NrZXRTZXJ2aWNlOiBOYXZTb2NrZXRTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBzaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZTogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIHJlc291cmNlTWFuZ2VyOiBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlKSB7IFxyXG4gICAgc3VwZXIoKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgLy9yZXNldCBjb21wb25lbnQgZGF0YSBhbmQgdXNlciB2YWxpZGF0aW9uO1xyXG4gICAgdGhpcy5jb21tb25VdGlscy52YWxpZGF0ZVVzZXIoKTtcclxuICAgIHRoaXMucm93cyA9IFtdO1xyXG4gICAgdGhpcy5zdWJzID0gW107XHJcbiAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IGZhbHNlO1xyXG5cclxuICAgIHRoaXMuZnVuZEluZm8gPSB0aGlzLnNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLmZ1bmRJbmZvO1xyXG4gICAgaWYgKHRoaXMuZnVuZEluZm8ubGVuZ3RoID4gMCkge1xyXG4gICAgIHRoaXMucmVuZGVyUG9zaXRpb25EZXRhaWxzKCk7XHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICAvL3RoaXMubmF2U2VydmljZS5mZXRjaEZ1bmRMaXN0KCk7XHJcbiAgICAgIHRoaXMubmF2U2VydmljZS5nZXRGdW5kTGlzdCgpLnN1YnNjcmliZShcclxuICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICBpZihkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBcclxuICAgICAgICAgICAgY29uc3QgZnVuZEluZm8gPSBbXTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRpZCk7XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5uYW1lKTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRUaWNrZXIpXHJcbiAgICAgICAgICAgIHRoaXMuc2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2Uuc2F2ZVBvc2l0aW9uRGV0YWlsc0Z1bmRJbmZvKGZ1bmRJbmZvKTtcclxuICAgICAgICAgICAgdGhpcy5yZW5kZXJQb3NpdGlvbkRldGFpbHMoKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLnNvcnREYXRhdGFibGVDb2x1bW4uc3Vic2NyaWJlKGRhdGEgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhbLi4udGhpcy5jb21tb25VdGlscy5zb3J0Q29sdW1uQnlQcm9wKHRoaXMucm93cywgdGhpcy5jaGlsZFJvd3MsIGRhdGEubWFwLCBkYXRhLnByb3AsIGRhdGEuYXNjRmxhZyldKTtcclxuICAgICAgdGhpcy5yb3dzID0gWy4uLnRoaXMuY29tbW9uVXRpbHMuc29ydENvbHVtbkJ5UHJvcCh0aGlzLnJvd3MsIHRoaXMuY2hpbGRSb3dzLCBkYXRhLm1hcCwgZGF0YS5wcm9wLCBkYXRhLmFzY0ZsYWcpXTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG5cclxuICByZW5kZXJQb3NpdGlvbkRldGFpbHMoKXtcclxuICAgIHRoaXMuZnVuZEluZm8gPSB0aGlzLnNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLmZ1bmRJbmZvO1xyXG4gICAgaWYgKHRoaXMuZnVuZEluZm8ubGVuZ3RoID4gMCkge1xyXG4gICAgICB0aGlzLnN1YnMucHVzaCh0aGlzLm5hdlNlcnZpY2UuZ2V0UG9zaXRpb25EZXRhaWxzKHRoaXMuZnVuZEluZm9bMF0pLnN1YnNjcmliZShcclxuICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgIHRoaXMuaXNEYXRhQXZhaWxhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgIHRoaXMucm93cyA9IGRhdGFbXCJob2xkaW5nc1wiXTtcclxuICAgICAgICAgIHRoaXMucm93cyA9IFsuLi50aGlzLnJvd3NdO1xyXG4gICAgICAgIH1cclxuICAgICAgKSk7XHJcblxyXG4gICAgICB0aGlzLnN1YnMucHVzaCh0aGlzLm5hdlNvY2tldFNlcnZpY2UuZ2V0TmF2KCkuc3Vic2NyaWJlKFxyXG4gICAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZGF0YVsnZXZlbnRUeXBlJ10gPT09ICdmdW5kQ2hhbmdlJykge1xyXG4gICAgICAgICAgICBjb25zdCBmdW5kTGV2ZWxSb3cgPSB0aGlzLmNvbW1vblV0aWxzLmV4dHJhY3RXU0RhdGEoZGF0YVtcImV2ZW50RGF0YVwiXSwgZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVJvdyhmdW5kTGV2ZWxSb3cpXHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVJvdyhkYXRhKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgdGhpcy5uYXZTb2NrZXRTZXJ2aWNlLnJlZ2lzdGVyRnVuZHMoW3RoaXMuZnVuZEluZm9bMF1dKTtcclxuXHJcbiAgICB0aGlzLnJlc291cmNlTWFuZ2VyLnJlZ2lzdEludGVydmFsKCgpID0+IHsgdGhpcy5yb3dzID0gWy4uLnRoaXMucm93c107IH0sMzAwKTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBuZ09uRGVzdHJveSgpIHtcclxuICAgIGlmICh0aGlzLmZ1bmRJbmZvLmxlbmd0aCA+IDApIHtcclxuICAgICAgdGhpcy5uYXZTb2NrZXRTZXJ2aWNlLnVuUmVnaXN0ZXJGdW5kcyhbdGhpcy5mdW5kSW5mb1swXV0pO1xyXG4gICAgICB0aGlzLnN1YnMuZm9yRWFjaCAoc3ViID0+IHN1Yi51bnN1YnNjcmliZSgpKTtcclxuICAgIH1cclxuICAgIHRoaXMucmVzb3VyY2VNYW5nZXIuY2xlYW5SZXNvdXJjZXMoKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVJvdyhkYXRhKSB7XHJcbiAgICBpZiAoZGF0YSAmJiAhdGhpcy5pc0RhdGFUYWJsZVBhdXNlZCAmJiB0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKSkpIHtcclxuICAgICAgaWYgKHRoaXMucm93cy5sZW5ndGggJiYgZGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGZ1bmRpZCA9IGRhdGFbJ2Z1bmRpZCddO1xyXG4gICAgICAgIGNvbnN0IGN1c2lwID0gZGF0YVsnY3VzaXAnXTtcclxuICAgICAgICBjb25zdCBsb25nU2hvcnRJbmRpY2F0b3IgPSBkYXRhWydsb25nU2hvcnRJbmRpY2F0b3InXTtcclxuICAgICAgICB0aGlzLnJvd3MuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLmZ1bmRJbmZvWzBdID09PSBmdW5kaWQgJiYgaXRlbVsnY3VzaXAnXSA9PT0gY3VzaXAgJiYgaXRlbVsnbG9uZ1Nob3J0SW5kaWNhdG9yJ10gPT09IGxvbmdTaG9ydEluZGljYXRvcikge1xyXG4gICAgICAgICAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKGNvbEl0ZW0gPT4geyBpZiAobnVsbCAhPSBkYXRhW2NvbEl0ZW0ucHJvcF0pIHtpdGVtW2NvbEl0ZW0ucHJvcF0gPSBkYXRhW2NvbEl0ZW0ucHJvcF0gfX0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZihkYXRhICYmIGRhdGFbJ2V2ZW50VHlwZSddID09PSAnc29kQ2hhbmdlJykge1xyXG4gICAgICB0aGlzLm5hdlNlcnZpY2UuZ2V0UG9zaXRpb25EZXRhaWxzKHRoaXMuZnVuZEluZm9bMF0pLnN1YnNjcmliZShcclxuICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICB0aGlzLnJvd3MgPSBkYXRhW1wiaG9sZGluZ3NcIl07XHJcbiAgICAgICAgICAgdGhpcy5yb3dzID0gWy4uLnRoaXMucm93c107XHJcbiAgICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gcmV0dXJuQmFjaygpOiBhbnkge1xyXG4gIC8vICAgdGhpcy5hcHBDb250ZXh0LmN1cnJlbnREYXNoYm9hcmQgPSB0aGlzLmFwcFJlZ2lzdHJ5LmdldERhc2hib2FyZCgnUU5BVi0wMDEnKTtcclxuICAvLyB9XHJcbiAgdG9nZ2xlUGF1c2VGbGFnKCkge1xyXG4gICAgdGhpcy5pc0RhdGFUYWJsZVBhdXNlZCA9ICF0aGlzLmlzRGF0YVRhYmxlUGF1c2VkO1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5qZWN0LCBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtNYXREaWFsb2dSZWYsIE1BVF9ESUFMT0dfREFUQX0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyBDb21tb25VdGlsc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb21tb24tdXRpbHMuc2VydmljZSc7XHJcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1hZGQtZnVuZC1tb2RhbCcsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XHJcblx0PGgxIG1hdC1kaWFsb2ctdGl0bGU+QWRkIEVudGl0eSB0byBDaGFydDwvaDE+XHJcbiAgPHNwYW4gY2xhc3M9XCJhbGVydC1jbG9zZVwiIChjbGljayk9XCJvbk5vQ2xpY2soKVwiPsODwpc8L3NwYW4+XHJcbjwvZGl2PlxyXG48ZGl2IG1hdC1kaWFsb2ctY29udGVudD5cclxuIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcblx0PGRpdiBcclxuICAqbmdGb3I9XCJsZXQgZnVuZCBvZiBmdW5kTGlzdFwiXHJcblx0Y2xhc3M9XCJmdW5kLWxpc3QtaXRlbVwiXHJcbiAgID5cclxuXHRcdDxkaXYgY2xhc3M9XCJjaGVja2JveFwiPlxyXG5cdFx0XHQ8bGFiZWw+XHJcblx0XHRcdFx0IDxuZy1jb250YWluZXJcclxuXHRcdFx0XHQgKm5nSWY9XCJmdW5kLmNoZWNrZWRcIj5cclxuXHRcdFx0XHRcdCA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgKGNsaWNrKT1cImhhbmRsZVNlbGVjdEZ1bmQoZnVuZClcIiBjaGVja2VkPiB7e2Z1bmQuZnVuZFRpY2tlciA/IGZ1bmQuZnVuZFRpY2tlciA6IGZ1bmQuZnVuZElEIH19XHJcblx0XHRcdFx0IDwvbmctY29udGFpbmVyPlxyXG5cdFx0XHRcdCA8bmctY29udGFpbmVyXHJcblx0XHRcdFx0ICpuZ0lmPVwiIWZ1bmQuY2hlY2tlZFwiPlxyXG5cdFx0XHRcdFx0IDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiAoY2xpY2spPVwiaGFuZGxlU2VsZWN0RnVuZChmdW5kKVwiPiB7e2Z1bmQuZnVuZFRpY2tlciA/IGZ1bmQuZnVuZFRpY2tlciA6IGZ1bmQuZnVuZElEIH19XHJcblx0XHRcdFx0IDwvbmctY29udGFpbmVyPlxyXG4gICAgIFx0XHQ8L2xhYmVsPlxyXG5cdFx0PC9kaXY+XHJcblx0PC9kaXY+XHJcbjwvZGl2PlxyXG48L2Rpdj5cclxuPGRpdiBtYXQtZGlhbG9nLWFjdGlvbnMgYWxpZ249XCJlbmRcIj5cclxuICA8YnV0dG9uIG1hdC1idXR0b24gKGNsaWNrKT1cIm9uTm9DbGljaygpXCIgY2RrRm9jdXNJbml0aWFsPkNhbmNlbDwvYnV0dG9uPlxyXG4gIDxidXR0b24gbWF0LWJ1dHRvbiAoY2xpY2spPVwiaGFuZGxlQ2xpY2tTZWxlY3RCdG4oKVwiIGNsYXNzPVwicHJpbWFyeS1idG5cIj5TZWxlY3Q8L2J1dHRvbj5cclxuPC9kaXY+YCxcclxuICBzdHlsZXM6IFtgLm1vZGFsLWhlYWRlcntwb3NpdGlvbjpyZWxhdGl2ZX0ubWF0LWRpYWxvZy10aXRsZXtjb2xvcjojNDY0NjQ2O21hcmdpbjotMTBweCAwIDIwcHh9LmFsZXJ0LWNsb3Nle3Bvc2l0aW9uOmFic29sdXRlO3RvcDotNnB4O3JpZ2h0Oi02cHg7Y29sb3I6cmdiYSgxMDUsMTA1LDEwNSwuNzgpO2N1cnNvcjpwb2ludGVyO2ZvbnQtc2l6ZTo0MHB4fS5tYXQtZGlhbG9nLWNvbnRlbnR7Y29sb3I6IzQ2NDY0Njtmb250LXNpemU6MTZweDtib3JkZXItYm90dG9tOjJweCBzb2xpZCByZ2JhKDAsMCwwLC4xNSl9LmZvcm0tZ3JvdXB7bWFyZ2luLWJvdHRvbToxZW19LmZ1bmQtbGlzdC1pdGVte21hcmdpbjowIDAgMTVweH0ucHJpbWFyeS1idG57YmFja2dyb3VuZDojMmY3NDlhO2NvbG9yOiNmZmZ9YF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFkZEZ1bmRNb2RhbENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGZ1bmRMaXN0OiBhbnlbXTtcclxuICBzZWxlY3RlZEZ1bmRDaGFuZ2U6ICBFdmVudEVtaXR0ZXI8YW55PjtcclxuICBcclxuICAgY29uc3RydWN0b3IoXHJcbiAgICAgcHJpdmF0ZSBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgcHVibGljIGRpYWxvZ1JlZjogTWF0RGlhbG9nUmVmPEFkZEZ1bmRNb2RhbENvbXBvbmVudD4sXHJcbiAgICBASW5qZWN0KE1BVF9ESUFMT0dfREFUQSkgcHVibGljIGRhdGE6IGFueSkge1xyXG4gICAgICB0aGlzLmZ1bmRMaXN0ID0gXy5jbG9uZURlZXAoZGF0YVsnZnVuZExpc3QnXSk7XHJcbiAgICAgIHRoaXMuc2VsZWN0ZWRGdW5kQ2hhbmdlID0gZGF0YS5kYXRhQ2hhbmdlO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gIH1cclxuXHJcbiAgaGFuZGxlU2VsZWN0RnVuZChmdW5kKSB7XHJcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuZnVuZExpc3QuaW5kZXhPZihmdW5kKTtcclxuICAgIHRoaXMuZnVuZExpc3RbaW5kZXhdWydjaGVja2VkJ10gPSAhdGhpcy5mdW5kTGlzdFtpbmRleF1bJ2NoZWNrZWQnXTtcclxuICB9XHJcblxyXG4gIGhhbmRsZUNsaWNrU2VsZWN0QnRuKCkge1xyXG4gICAgY29uc3QgcmVtb3ZlRnVuZExpc3QgPSB0aGlzLmZ1bmRMaXN0LmZpbHRlcihpdGVtID0+IGl0ZW0uY2hlY2tlZCA9PT0gZmFsc2UpO1xyXG4gICAgY29uc3QgYWRkRnVuZGxpc3QgPSB0aGlzLmZ1bmRMaXN0LmZpbHRlcihpdGVtID0+IGl0ZW0uY2hlY2tlZCA9PT0gdHJ1ZSk7XHJcbiAgICByZW1vdmVGdW5kTGlzdC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgdGhpcy51cGRhdGVWYXJpYWJsZUZ1bmRMaXN0KGl0ZW0pO1xyXG4gICAgIH0pO1xyXG5cclxuICAgICBhZGRGdW5kbGlzdC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgdGhpcy51cGRhdGVWYXJpYWJsZUZ1bmRMaXN0KGl0ZW0pO1xyXG4gICAgIH0pO1xyXG5cclxuICAgICB0aGlzLnNlbGVjdGVkRnVuZENoYW5nZS5lbWl0KGFkZEZ1bmRsaXN0KTtcclxuICAgICB0aGlzLm9uTm9DbGljaygpO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlVmFyaWFibGVGdW5kTGlzdChmdW5kKSB7XHJcbiAgICBsZXQgaW5kZXggPSAtMTtcclxuICAgIHRoaXMuY29tbW9uVXRpbHMudXBkYXRlRnVuZFN0YXR1cyhmdW5kWydmdW5kSUQnXSxmdW5kWydjaGVja2VkJ10pO1xyXG4gIH1cclxuXHJcbiAgb25Ob0NsaWNrKCk6IHZvaWQge1xyXG4gICAgdGhpcy5kaWFsb2dSZWYuY2xvc2UoKTtcclxuICB9XHJcblxyXG59XHJcbiIsIi8vIGZ1bmQgY29sb3IgbWFwLCBuZWVkIHNldCBjb2xvciBmb3IgZWFjaCBmdW5kIGlmIGFkZCBtb3JlIGZ1bmRzXHJcbmV4cG9ydCBjb25zdCBkYXRhVmlzdWFsRnVuZENvbG9yTWFwID0gW1xyXG4gICAge1xyXG4gICAgICAgIGZ1bmRJRDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGNvbG9yOicjODZCQkQxJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgZnVuZElEOiB1bmRlZmluZWQsXHJcbiAgICAgICAgY29sb3I6JyNGQzdDNDInXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGZ1bmRJRDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGNvbG9yOicjMDA4MTk4J1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBmdW5kSUQ6IHVuZGVmaW5lZCxcclxuICAgICAgICBjb2xvcjonI0NEREMzOSdcclxuICAgIH1cclxuXVxyXG5cclxuZXhwb3J0IGNvbnN0IGRhdGFWaXN1YWxDb2xvciA9IFtcclxuICAgICcjODZCQkQxJywnI0ZDN0M0MicsICcjMDA4MTk4JywnI0NEREMzOSdcclxuXVxyXG5cclxuLy8gZm9yIGhlYXRtYXAgY29tcG9uZW50IGNvbG9yIHNldHRpbmdcclxuZXhwb3J0IGNvbnN0IGhlYXRNYXBDb2xvclNldHRpbmcgPSBbXHJcbiAgICB7XHJcbiAgICAgICAgdmFsdWU6IC0zLFxyXG4gICAgICAgIGNvbG9yOiAnI0I5MTIyNCcsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIHZhbHVlOiAtMixcclxuICAgICAgICBjb2xvcjogJyNFQUI3QkQnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICB2YWx1ZTogLTEsXHJcbiAgICAgICAgY29sb3I6ICcjRjVEQ0RFJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgdmFsdWU6IDEsXHJcbiAgICAgICAgY29sb3I6ICcjREZFQUUyJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgdmFsdWU6IDIsXHJcbiAgICAgICAgY29sb3I6ICcjQkVENUM1JyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgdmFsdWU6IDMsXHJcbiAgICAgICAgY29sb3I6ICcjMjg3NDNFJyxcclxuICAgIH1cclxuXVxyXG5cclxuZXhwb3J0IGNvbnN0IGhlYXRNYXBDb2xvclNjaGVtZSA9IHtcclxuICAgIGRvbWFpbjogWycjQjkxMjI0JywgJyNFQUI3QkQnLCAnI0Y1RENERScsICcjREZFQUUyJywnI0JFRDVDNScsJyMyODc0M0UnXVxyXG4gIH07IiwiZXhwb3J0IGNvbnN0IGRlZmF1bHRGdW5kTGlzdCA9IFtcclxuXHJcbiAge1xyXG4gICAgXCJuYW1lXCI6IFwiXCIsXHJcbiAgICBcInNlcmllc1wiOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBcIm5hbWVcIjogXCIwOTozMDowMFwiLFxyXG4gICAgICAgIFwidmFsdWVcIjogMC4wLFxyXG4gICAgICAgIFwibmF2XCI6IFwiMC4wXCIsXHJcbiAgICAgICAgXCJtYXJrZXR2YWxcIjogXCIwLjBcIlxyXG4gICAgICB9XHJcbiAgICBdXHJcbiAgfVxyXG5dO1xyXG5cclxuZXhwb3J0IGNvbnN0IHRpY2tzVmFsdWUgPSBbXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDksIDMwLCAwKSwgXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDEwLCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDExLCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDEyLCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDEzLCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDE0LCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDE1LCAzMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDE2LCAzMCwgMClcclxuICAgIF07XHJcbiAgICBcclxuIiwiaW1wb3J0IHtcclxuICBFbGVtZW50UmVmLCBOZ1pvbmUsIENoYW5nZURldGVjdG9yUmVmLFxyXG4gIENvbXBvbmVudCxcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIEhvc3RMaXN0ZW5lcixcclxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICBDb250ZW50Q2hpbGQsXHJcbiAgVGVtcGxhdGVSZWYsXHJcbiAgVmlld0NvbnRhaW5lclJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgQmFzZVdpZGdldENvbXBvbmVudCB9IGZyb20gJ0BvbW5pYS91aS1jb21tb24nO1xyXG5pbXBvcnQge01hdERpYWxvZ30gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyBBZGRGdW5kTW9kYWxDb21wb25lbnQgfSBmcm9tICcuLi9hZGQtZnVuZC1tb2RhbC9hZGQtZnVuZC1tb2RhbC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBOYXZTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNlcnZpY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdlNvY2tldFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9uYXYtc29ja2V0LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb21tb25VdGlsc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb21tb24tdXRpbHMuc2VydmljZSc7XHJcbmltcG9ydCB7IGRhdGFWaXN1YWxGdW5kQ29sb3JNYXAgfSBmcm9tICcuLi9jb2xvcnMnO1xyXG5pbXBvcnQgeyBOYXYgfSBmcm9tICcuLi9tb2RlbC9xbmF2JztcclxuaW1wb3J0IHsgdGlja3NWYWx1ZSwgZGVmYXVsdEZ1bmRMaXN0IH0gZnJvbSAnLi9saW5lLWRhdGEnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBUSElTX0VYUFIgfSBmcm9tICdAYW5ndWxhci9jb21waWxlci9zcmMvb3V0cHV0L291dHB1dF9hc3QnO1xyXG5pbXBvcnQgeyBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvcmVzb3VyY2UtbWFuYWdlci5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLXFuYXYtbGluZS1jaGFydCcsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2ICBjbGFzcz1cInFuYXYtY29udGFpbmVyXCIgKm5nSWY9XCJpc0RhdGFBdmFpbGFibGVcIiAod2luZG93OnJlc2l6ZSk9XCJyZXNpemluZ0NoYXJ0KCRldmVudClcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJsaXZlLXRpbWUtZm9yLXRpdGxlXCI+XHJcbiAgICAgICAgPHAgKm5nSWY9XCJjb21tb25VdGlscy5pc0FmdGVyTWFya2V0Q2xvc2UgZWxzZSBlbHNlQmxvY2tcIj5DaGFuZ2UgaW4gTkFWIHBlciBzaGFyZSBmb3Ige3tjb21tb25VdGlscy5saXZlVGltZSB8IGRhdGU6J0VFRUUnfX0sIHt7Y29tbW9uVXRpbHMubGl2ZVRpbWUgfCBkYXRlOidNTS9kZC95eXl5J319LCBhcyBvZiBNYXJrZXQgQ2xvc2U6IHt7Y29tbW9uVXRpbHMubGl2ZVRpbWUgfCBkYXRlOlwiaDptbSBhYWFhYSdtJ1wifX08L3A+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlICNlbHNlQmxvY2s+PHA+Q2hhbmdlIGluIE5BViBwZXIgc2hhcmUgZm9yIHt7Y29tbW9uVXRpbHMubGl2ZVRpbWUgfCBkYXRlOidFRUVFJ319LCB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTonTU0vZGQveXl5eSd9fSwgUmVhbCBUaW1lOiB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTpcImg6bW0gYWFhYWEnbSdcIn19PC9wPjwvbmctdGVtcGxhdGU+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJjdXN0b20tbGVnZW5kXCI+XHJcbiAgICA8YXBwLWN1c3RvbS1sZWdlbmRcclxuICAgICAgW3Jlc3VsdHNdPVwicmVzdWx0c1wiXHJcbiAgICAgIFtzZWxlY3RhYmxlXT1cInNlbGVjdGFibGVcIlxyXG4gICAgICBbcmVtb3ZhYmxlXT1cInJlbW92YWJsZVwiXHJcbiAgICAgIFtjb2xvckRvbWFpbl09J2NvbG9yRG9tYWluJ1xyXG4gICAgICBbc2VsZWN0ZWRGdW5kQ2hhbmdlXT1cImZ1bmRDaGFuZ2VcIlxyXG4gICAgPlxyXG4gICAgPC9hcHAtY3VzdG9tLWxlZ2VuZD5cclxuICAgIDxkaXYgY2xhc3M9XCJhZGRDaHVua1wiPlxyXG4gICAgICA8bWF0LWljb24gY2xhc3M9XCJhZGRGdW5kSWNvblwiIHN2Z0ljb249XCJjaXJjbGVfcGx1c1wiICAoY2xpY2spPVwib3BlbkFkZEZ1bmRNb2RhbCgkZXZlbnQpXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPHNwYW4gY2xhc3M9XCJhZGRDb250ZW50XCI+QWRkIEVudGl0eTwvc3Bhbj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG4gIDxsaWItZmluZS1saW5lLWNoYXJ0XHJcbiAgW3Jlc3VsdHNdPSdyZXN1bHRzJ1xyXG4gIFtoZWlnaHRdPSdoZWlnaHQnXHJcbiAgW3dpZHRoXT0nd2lkdGgnXHJcbiAgW21hcmdpbl09J21hcmdpbidcclxuICBbY29sb3JEb21haW5dPSdjb2xvckRvbWFpbidcclxuICBbY2lyY2xlRGF0YV09J2NpcmNsZURhdGEnXHJcbiAgW2N1cnJlbnRMaW5lVGltZV09J2N1cnJlbnRMaW5lVGltZSdcclxuICBbZGlzcGxheUxpdmVUaW1lXT0nZGlzcGxheUxpdmVUaW1lJ1xyXG4gIFt0aWNrVmFsdWVzXT0ndGlja1ZhbHVlcydcclxuICBbeEF4aXNUaWNrRm9ybWF0dGluZ109J3hBeGlzVGlja0Zvcm1hdHRpbmcnXHJcbiAgW3hTY2FsZU1pbl09J3hTY2FsZU1pbidcclxuICBbeFNjYWxlTWF4XT0neFNjYWxlTWF4J1xyXG4gIFtzaG93WUF4aXNMYWJlbF09J3Nob3dZQXhpc0xhYmVsJ1xyXG4gIFt5QXhpc0xhYmVsXT0neUF4aXNMYWJlbCdcclxuICBbYWN0aXZlRW50cmllc109J2FjdGl2ZUVudHJpZXMnXHJcbiAgW2hpZ2hMaWdodEFjdGl2ZUVudHJpZXNdPSdoaWdoTGlnaHRBY3RpdmVFbnRyaWVzJ1xyXG4gID5cclxuICA8L2xpYi1maW5lLWxpbmUtY2hhcnQ+XHJcbjwvZGl2PlxyXG5gLFxyXG4gIHN0eWxlczogW2Aubmd4LWNoYXJ0Lm1hdGVyaWFse2Rpc3BsYXk6dW5zZXR9LnFuYXYtY29udGFpbmVye3dpZHRoOjEwMCU7aGVpZ2h0OjEwMCV9LmN1c3RvbS1sZWdlbmR7ZGlzcGxheTppbmxpbmUtZmxleDt3aWR0aDo5OCU7YWxpZ24taXRlbXM6Y2VudGVyO21hcmdpbi10b3A6NXB4O3BhZGRpbmc6MCAxMnB4O21pbi1oZWlnaHQ6NDBweH0uYWRkQ2h1bmt7cG9zaXRpb246cmVsYXRpdmU7ZGlzcGxheTppbmxpbmUtYmxvY2s7bWluLWhlaWdodDozMHB4O21pbi13aWR0aDoxNTBweH0uYWRkQ2h1bmsgLmFkZEZ1bmRJY29ue3Bvc2l0aW9uOmFic29sdXRlO3RvcDo2cHg7bWFyZ2luLXJpZ2h0OjVweDt3aWR0aDoxNXB4IWltcG9ydGFudDtoZWlnaHQ6MTVweCFpbXBvcnRhbnQ7bWFyZ2luLWxlZnQ6MjBweDtjdXJzb3I6cG9pbnRlcjttaW4taGVpZ2h0OjE1cHghaW1wb3J0YW50O21pbi13aWR0aDoxNXB4IWltcG9ydGFudH0uYWRkQ2h1bmsgLmFkZENvbnRlbnR7cG9zaXRpb246YWJzb2x1dGU7dG9wOjZweDtsZWZ0OjQwcHh9LmxpdmUtdGltZS1mb3ItdGl0bGV7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDoxNXB4O2ZvbnQtc2l6ZToxNnB4O2ZvbnQtZmFtaWx5OkRJTk5leHRMVFByby1NZWRpdW07Y29sb3I6IzQ2NDY0Nn1gXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgUW5hdkxpbmVDaGFydENvbXBvbmVudCBleHRlbmRzIEJhc2VXaWRnZXRDb21wb25lbnQge1xyXG4gIHJlbW92YWJsZTogYm9vbGVhbiA9IHRydWU7XHJcbiAgc2VsZWN0YWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICByZXN1bHRzOiBhbnlbXSA9IFtdO1xyXG4gIHBlcm1hbmVudFJlc3VsdHM6IGFueVtdID0gW107XHJcbiAgaXNEYXRhQXZhaWxhYmxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgaGVpZ2h0OiBudW1iZXIgPSAyNDA7XHJcbiAgbWFyZ2luOiBhbnlbXSA9IFsyMCwgMTAwLCAzMCwgMTAwXTtcclxuICBjb2xvckRvbWFpbjogYW55W10gPSBbXTtcclxuICB3aWR0aDogbnVtYmVyO1xyXG4gIHRpY2tWYWx1ZXM6IGFueVtdID0gdGlja3NWYWx1ZTtcclxuICBjdXJyZW50TGluZVRpbWU6IERhdGU7XHJcbiAgZGlzcGxheUxpdmVUaW1lOiBhbnk7XHJcbiAgY2lyY2xlRGF0YTogYW55W10gPSBbXTtcclxuICBwZXJtYW5lbnRDaXJjbGVEYXRhOiBhbnlbXSA9IFtdO1xyXG4gIHByZXZpb3VzVGltZU1hcDogTWFwPFN0cmluZywgRGF0ZT47XHJcbiAgeFNjYWxlTWluOiBhbnk7XHJcbiAgeFNjYWxlTWF4OiBhbnk7XHJcbiAgc2hvd1lBeGlzTGFiZWwgPSB0cnVlO1xyXG4gIHlBeGlzTGFiZWwgPSAnTmF2ICUgQ2hhbmdlJ1xyXG4gIHByZXZpb3VzVGltZSA9IG5ldyBEYXRlKCk7XHJcbiAgYWN0aXZlRW50cmllczogYW55W10gPSBbXTtcclxuICBoaWdoTGlnaHRBY3RpdmVFbnRyaWVzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBmdW5kQ2hhbmdlOiAgRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgIEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgcmVtb3ZlSW5kZXhzOiBhbnlbXSA9IFtdO1xyXG4gIHByaXZhdGUgc3ViczogU3Vic2NyaXB0aW9uW107XHJcbiAgY29uc3RydWN0b3IoY2hhcnRFbGVtZW50OiBFbGVtZW50UmVmLCB6b25lOiBOZ1pvbmUsIGNkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgIHByaXZhdGUgbmF2U2VydmljZTogTmF2U2VydmljZSwgcHJpdmF0ZSBuYXZTb2NrZXRTZXJ2aWNlOiBOYXZTb2NrZXRTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBkaWFsb2c6IE1hdERpYWxvZyxcclxuICAgIHByaXZhdGUgdmlld0NvbnRhaW5lcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgIHByaXZhdGUgc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzIDogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsXHJcbiAgICBwdWJsaWMgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgIHByaXZhdGUgcmVzb3VyY2VNYW5nZXI6IFJlc291cmNlTWFuYWdlclNlcnZpY2UpIHtcclxuICAgIHN1cGVyKCk7XHJcbiAgICB0aGlzLndpZHRoID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnbWFpbicpWzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoIC0gMTAwO1xyXG4gICAgdGhpcy54U2NhbGVNaW4gPSBjb21tb25VdGlscy5zdGFydFRpbWU7XHJcbiAgICB0aGlzLnhTY2FsZU1heCA9IGNvbW1vblV0aWxzLmVuZFRpbWU7XHJcbiAgICB0aGlzLmN1cnJlbnRMaW5lVGltZSA9IGNvbW1vblV0aWxzLnN0YXJ0VGltZTtcclxuXHJcbiAgICB0aGlzLnJlc291cmNlTWFuZ2VyLnJlZ2lzdEludGVydmFsKCgpID0+IHtcclxuICAgICAgaWYgKG5ldyBEYXRlKCkgPCBjb21tb25VdGlscy5lbmRUaW1lKSB7XHJcbiAgICAgICAgdGhpcy5kaXNwbGF5TGl2ZVRpbWUgPSBuZXcgRGF0ZSgpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5kaXNwbGF5TGl2ZVRpbWUgPSBjb21tb25VdGlscy5lbmRUaW1lO1xyXG4gICAgICB9XHJcbiAgICB9LDEwMDApO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICAvL25lZWQgdG8gcmVzZXQgdmFsdWUgaGVyZSB3aGVuIHN3aXRjaCBiYWNrIGZyb20gb3RoZXIgZGFzaGJvYXJkIGxpa2UgcG9zaXRpb24gb3Igd2hlbiBzd2l0Y2ggdXNlcnNcclxuICAgIHRoaXMuY29tbW9uVXRpbHMudmFsaWRhdGVVc2VyKCk7XHJcbiAgICAvL2luaXRpYWxpemUgdGhlICBjb2xvckRvbWFpbiB3aXRoIHByZWRlZmluZWQgY29sb3JzLlxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc2V0Q29sb3JTY2hlbWEoZGF0YVZpc3VhbEZ1bmRDb2xvck1hcCk7XHJcbiAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IGZhbHNlO1xyXG4gICAgdGhpcy5zdWJzID0gW107XHJcbiAgICB0aGlzLnJlc3VsdHMgPSBbXTtcclxuICAgIHRoaXMucGVybWFuZW50UmVzdWx0cyA9IFtdO1xyXG4gICAgdGhpcy5jb2xvckRvbWFpbiA9IFtdO1xyXG4gICAgdGhpcy5jaXJjbGVEYXRhID0gW107XHJcbiAgICB0aGlzLnBlcm1hbmVudENpcmNsZURhdGEgPSBbXTtcclxuICAgIHRoaXMucHJldmlvdXNUaW1lTWFwID0gbnVsbDtcclxuICAgIC8vcmVzZXQgZG9uZVxyXG4gICAgdGhpcy5uYXZTZXJ2aWNlLmZldGNoRnVuZExpc3QoKTtcclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U2VydmljZS5nZXRGdW5kTGlzdCgpLnN1YnNjcmliZShcclxuICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgaWYgKGRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgZnVuZExldmVsRGF0YSA9IHRoaXMuY29tbW9uVXRpbHMuZXh0cmFjdEZ1bmRMZXZlbERhdGEoZGF0YSk7XHJcbiAgICAgICAgICB0aGlzLnBlcm1hbmVudFJlc3VsdHMgPSBbLi4udGhpcy5jb252ZXJ0VG9SZXN1bHRzKGZ1bmRMZXZlbERhdGEpXTtcclxuICAgICAgICAgIHRoaXMucGVybWFuZW50Q2lyY2xlRGF0YSA9IFsuLi50aGlzLnVwZGF0ZUNpcmNsZURhdGEoZnVuZExldmVsRGF0YSldO1xyXG4gICAgICAgICAgdGhpcy5jb2xvckRvbWFpbiA9IFsuLi50aGlzLnNldEZ1bmRDb2xvck1hcChmdW5kTGV2ZWxEYXRhKV07XHJcbiAgICAgICAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zZXRDb2xvclNjaGVtYSh0aGlzLmNvbG9yRG9tYWluKTtcclxuICAgICAgICAgIHRoaXMuaXNEYXRhQXZhaWxhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgIHRoaXMucHJldmlvdXNUaW1lTWFwID0gbmV3IE1hcCgpO1xyXG4gICAgICAgICAgdGhpcy5wZXJtYW5lbnRSZXN1bHRzLmZvckVhY2goZiA9PiB7XHJcbiAgICAgICAgICAgIGxldCBzZXJpZXMgPSBmWydzZXJpZXMnXTtcclxuICAgICAgICAgICAgdGhpcy5wcmV2aW91c1RpbWVNYXAuc2V0KGZbJ25hbWUnXSwgc2VyaWVzW3Nlcmllcy5sZW5ndGggLSAxXVsncHJpY2V0aW1lJ10pO1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRMaW5lVGltZSA9IG5ldyBEYXRlKHRoaXMucHJldmlvdXNUaW1lTWFwLmdldChmWyduYW1lJ10pKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgdGhpcy5yZXN1bHRzID0gdGhpcy5maWx0ZXJSZXN1bHRzKHRoaXMucGVybWFuZW50UmVzdWx0cyk7XHJcbiAgICAgICAgICB0aGlzLmNpcmNsZURhdGEgPSB0aGlzLmZpbHRlckNpcmNsZURhdGUodGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICkpO1xyXG5cclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U29ja2V0U2VydmljZS5nZXROYXYoKS5zdWJzY3JpYmUoXHJcbiAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgaWYgKGRhdGEgJiYgZGF0YVtcImV2ZW50RGF0YVwiXSkge1xyXG4gICAgICAgICAgY29uc3QgZnVuZExldmVsVXBkYXRlRGF0YSA9IHRoaXMuY29tbW9uVXRpbHMuZXh0cmFjdFdTRGF0YShkYXRhW1wiZXZlbnREYXRhXCJdLCBmYWxzZSk7XHJcbiAgICAgICAgICB0aGlzLnVwZGF0ZUNoYXJ0KGZ1bmRMZXZlbFVwZGF0ZURhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKSk7XHJcblxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaGlnaExpZ2h0QWN0aXZlRW50cmllcy5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgIGNvbnN0IGZpbHRlcmVkQWN0aXZlRGF0YSA9IFtdO1xyXG4gICAgICBjb25zdCBsaXN0cyA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCk7XHJcbiAgICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICBpZiAobGlzdHMuZmluZChsaXN0ID0+IChsaXN0LmZ1bmRJRCA9PT0gaXRlbS5uYW1lICYmIGxpc3QuY2hlY2tlZCkpKSB7XHJcbiAgICAgICAgICBmaWx0ZXJlZEFjdGl2ZURhdGEucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIHRoaXMuaGlnaExpZ2h0QWN0aXZlRW50cmllcyA9IGZpbHRlcmVkQWN0aXZlRGF0YTtcclxuICAgICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gZmlsdGVyZWRBY3RpdmVEYXRhO1xyXG4gICAgfSlcclxuXHJcbiAgICAgIHRoaXMuZnVuZENoYW5nZS5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaGlnaExpZ2h0QWN0aXZlRW50cmllcy5lbWl0KHRoaXMuaGlnaExpZ2h0QWN0aXZlRW50cmllcyk7XHJcbiAgICAgICAgdGhpcy5yZXN1bHRzID0gW107XHJcbiAgICAgICAgdGhpcy5jaXJjbGVEYXRhID0gW107XHJcbiAgICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5mb3JFYWNoIChmdW5kID0+IHtcclxuICAgICAgICAgIHRoaXMucGVybWFuZW50UmVzdWx0cy5mb3JFYWNoIChyZXN1bHQgPT4ge1xyXG4gICAgICAgICAgICBpZihmdW5kWydmdW5kSUQnXSA9PT0gcmVzdWx0WyduYW1lJ10gJiYgZnVuZFsnY2hlY2tlZCddKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5yZXN1bHRzLnB1c2gocmVzdWx0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICB0aGlzLnBlcm1hbmVudENpcmNsZURhdGEuZm9yRWFjaChjaXJjbGUgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZnVuZFsnZnVuZElEJ10gPT09IGNpcmNsZVsnbmFtZSddICYmIGZ1bmRbJ2NoZWNrZWQnXSkge1xyXG4gICAgICAgICAgICAgIHRoaXMuY2lyY2xlRGF0YS5wdXNoKGNpcmNsZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyUmVzdWx0cyhwZXJtbmFudFJlc3VsdCk6IGFueVtdIHtcclxuICAgIGxldCBmaWx0ZXJlZFJlc3VsdHMgPSBbXTtcclxuICAgICBwZXJtbmFudFJlc3VsdC5mb3JFYWNoKHJlc3VsdCA9PiB7XHJcbiAgICAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgIGlmICggcmVzdWx0Lm5hbWUgPT09IGl0ZW0uZnVuZElEICYmIGl0ZW0uY2hlY2tlZCkge1xyXG4gICAgICAgICAgIGZpbHRlcmVkUmVzdWx0cy5wdXNoKHJlc3VsdCk7XHJcbiAgICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZmlsdGVyZWRSZXN1bHRzO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyQ2lyY2xlRGF0ZShwZXJtYW5lbnRDaXJjbGVEYXRhKTogYW55W10ge1xyXG4gICAgbGV0IGZpbHRlcmVkQ2lyY2xlRGF0YSA9IFtdO1xyXG4gICAgIHBlcm1hbmVudENpcmNsZURhdGEuZm9yRWFjaChyZXN1bHQgPT4ge1xyXG4gICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgICBpZiAoIHJlc3VsdC5uYW1lID09PSBpdGVtLmZ1bmRJRCAmJiBpdGVtLmNoZWNrZWQpIHtcclxuICAgICAgICAgICBmaWx0ZXJlZENpcmNsZURhdGEucHVzaChyZXN1bHQpO1xyXG4gICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGZpbHRlcmVkQ2lyY2xlRGF0YTtcclxuICB9XHJcblxyXG4gIHNldEZ1bmRDb2xvck1hcChkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wID0gW107XHJcbiAgICBjb25zdCBsaXN0cyA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCk7XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGxldCBzZXRDb2xvciA9IGZhbHNlO1xyXG4gICAgICBsaXN0cy5mb3JFYWNoKGxpc3QgPT4ge1xyXG4gICAgICAgaWYgKGl0ZW0uZnVuZGlkID09PSBsaXN0LmZ1bmRJRCAmJiBsaXN0LmNoZWNrZWQpIHNldENvbG9yID0gdHJ1ZTtcclxuICAgICAgfSlcclxuICAgICAgIGlmIChzZXRDb2xvcikge1xyXG4gICAgICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgICBmdW5kaWQ6IGl0ZW0uZnVuZGlkLFxyXG4gICAgICAgICAgY29sb3I6IHRoaXMuY29tbW9uVXRpbHMuZ2V0Q29sb3JGb3JGdW5kKGl0ZW0uZnVuZGlkKVxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wLnB1c2gob2JqKVxyXG4gICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgZnVuZGlkOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICBjb2xvcjogdGhpcy5jb21tb25VdGlscy5nZXRDb2xvckZvckZ1bmQoaXRlbS5mdW5kaWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRlbXAucHVzaChvYmopXHJcbiAgICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXA7XHJcbiAgfVxyXG5cclxuICBcclxuICAvL25lZWQgdG8gdW5zdWJzY3JpYmUgdG8gYXZvaWQgcG90ZW50aWFsIG1lbW9yeSBsZWFrLlxyXG4gIG5nT25EZXN0cm95KCkge1xyXG4gICAgdGhpcy5zdWJzLmZvckVhY2goc3ViID0+IHN1Yi51bnN1YnNjcmliZSgpKTtcclxuICAgIHRoaXMuY29sb3JEb21haW4gPSBbXTtcclxuICAgIHRoaXMucmVzb3VyY2VNYW5nZXIuY2xlYW5SZXNvdXJjZXMoKTtcclxuICB9XHJcblxyXG4gIHJlc2l6aW5nQ2hhcnQoZXZlbnQpIHtcclxuICAgIHRoaXMud2lkdGggPSBldmVudC50YXJnZXQuaW5uZXJXaWR0aCAtIDEwMDtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0UmVzdWx0cyhyZXN1bHRzOiBhbnlbXSkgOiBhbnlbXXtcclxuICAgIGlmKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRGdW5kTGlzdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiByZXN1bHRzO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdXBkYXRlQ2hhcnQoZGF0YSkge1xyXG4gICAgaWYgKGRhdGEpIHtcclxuICAgICAgY29uc3QgZnVuZGlkID0gZGF0YVsnZnVuZGlkJ107XHJcbiAgICAgIGxldCB0aW1lXHJcbiAgICAgIGxldCBjdXJyZW50VGltZTogRGF0ZTtcclxuICAgICAgaWYgKGRhdGFbJ3ByaWNldGltZSddKSB7XHJcbiAgICAgICAgY3VycmVudFRpbWUgPSBuZXcgRGF0ZShkYXRhWydwcmljZXRpbWUnXSk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29tbW9uVXRpbHMuaXNWYWxpZFRpbWUoY3VycmVudFRpbWUpKSB7XHJcbiAgICAgICAgICB0aW1lID0gY3VycmVudFRpbWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGlmIChjdXJyZW50VGltZSA+IHRoaXMuY29tbW9uVXRpbHMuZW5kVGltZSkge1xyXG4gICAgICAgIHRoaXMuY3VycmVudExpbmVUaW1lID0gdGhpcy5jb21tb25VdGlscy5lbmRUaW1lO1xyXG4gICAgICB9XHJcbiAgICAgIC8vZm9yIGFkZGluZyBhbGVydCBkYXRhIGlmIGFueS5cclxuICAgICAgaWYgKHRoaXMuY29tbW9uVXRpbHMuaXNWYWxpZFRpbWUobmV3IERhdGUoZGF0YVsncHJpY2V0aW1lJ10pKSAmJiBkYXRhWydhbGVydFR5cGUnXSAmJiAoZGF0YVsnYWxlcnRUeXBlJ10gPT0gMSB8fCBkYXRhWydhbGVydFR5cGUnXSA9PT0gMikpIHtcclxuICAgICAgICBjb25zdCBhbGVydE9iaiA9IHtcclxuICAgICAgICAgIFwibmFtZVwiOiBmdW5kaWQsXHJcbiAgICAgICAgICBcInhcIjogbmV3IERhdGUoZGF0YVsncHJpY2V0aW1lJ10pLFxyXG4gICAgICAgICAgXCJhbGVydFR5cGVcIjogZGF0YVsnYWxlcnRUeXBlJ10sXHJcbiAgICAgICAgICBcInZhbHVlXCI6IGRhdGFbJ25hdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgIFwiZnVuZG12Q2hhbmdlUGVyY2VudFwiOiBkYXRhWydmdW5kbXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcIm5hdlwiOiBkYXRhWyduYXYnXSxcclxuICAgICAgICAgIFwibWFya2V0dmFsXCI6IGRhdGFbJ2Z1bmRtdiddLFxyXG4gICAgICAgICAgXCJwcmljZXRpbWVcIjogZGF0YVsncHJpY2V0aW1lJ11cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhLnB1c2goYWxlcnRPYmopO1xyXG4gICAgICAgIC8vdGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhID0gWy4uLnRoaXMucGVybWFuZW50Q2lyY2xlRGF0YV07XHJcbiAgICAgICAgdGhpcy5jaXJjbGVEYXRhID0gWy4uLnRoaXMuZmlsdGVyQ2lyY2xlRGF0ZSh0aGlzLnBlcm1hbmVudENpcmNsZURhdGEpXTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLnBlcm1hbmVudFJlc3VsdHMuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICBpZiAoaXRlbVsnbmFtZSddID09PSBmdW5kaWQpIHtcclxuICAgICAgICAgIC8vb25seSBzaG93cyBkYXRhIGJldHdlZW4gOTozMEFNIHRvIDQ6MzBQTVxyXG4gICAgICAgICAgaWYgKHRpbWUpIHtcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRUaW1lLmdldFRpbWUoKSAtIG5ldyBEYXRlKHRoaXMucHJldmlvdXNUaW1lTWFwLmdldChmdW5kaWQpKS5nZXRUaW1lKCkgPj0gMjAwMDApIHtcclxuICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRMaW5lVGltZSA9IG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKTtcclxuICAgICAgICAgICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgICAgICAgICAnbWFya2V0dmFsJzogZGF0YVsnZnVuZG12J10sIC8vIGZ1bmQgbWFya2V0IHZhbHVlXHJcbiAgICAgICAgICAgICAgICAnbmFtZSc6IHRoaXMubmV4dFRpbWVGb3JGdW5kKHRoaXMucHJldmlvdXNUaW1lTWFwLCBmdW5kaWQsIGRhdGFbJ3ByaWNldGltZSddKSxcclxuICAgICAgICAgICAgICAgICduYXYnOiBkYXRhWyduYXYnXSxcclxuICAgICAgICAgICAgICAgICd2YWx1ZSc6IGRhdGFbJ25hdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgICAgICAgICdwcmljZXRpbWUnOiBkYXRhWydwcmljZXRpbWUnXVxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgaXRlbVsnc2VyaWVzJ10ucHVzaChvYmopO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYoY3VycmVudFRpbWUuZ2V0VGltZSgpIC0gdGhpcy5wcmV2aW91c1RpbWUuZ2V0VGltZSgpID49MjAwMCl7XHJcbiAgICAgICAgICAgICAgdGhpcy5wcmV2aW91c1RpbWUgPSBjdXJyZW50VGltZTtcclxuICAgICAgICAgICAgICAvL3RoaXMuY3VycmVudExpbmVUaW1lID0gbmV3IERhdGUodGhpcy5wcmV2aW91c1RpbWVNYXAuZ2V0KGZ1bmRUaWNrZXIpKTsgLy90aGlzIHdpbGwgY2F1c2UgY29tcG9uZW50IHJlLXJlbmRlciB3aGVuZXZlciB0aGlzIGlzIHdzIGRhdGEgY29taW5nXHJcbiAgICAgICAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgICAgICAgJ21hcmtldHZhbCc6IGRhdGFbJ2Z1bmRtdiddLFxyXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBuZXcgRGF0ZSh0aGlzLnByZXZpb3VzVGltZU1hcC5nZXQoZnVuZGlkKSksXHJcbiAgICAgICAgICAgICAgICAnbmF2JzogZGF0YVsnbmF2J10sXHJcbiAgICAgICAgICAgICAgICAndmFsdWUnOiBkYXRhWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICAgICAgICAncHJpY2V0aW1lJzogZGF0YVsncHJpY2V0aW1lJ11cclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIC8vdGhpcyB3aWxsIGluY3JlYXNlIGNwdSB1c2FnZSBhcyB3ZWxsLCBuZWVkIHRvIGZpbmQgYmV0dGVyIHdheSB0byB1cGRhdGUgcmVzdWx0c1xyXG4gICAgICAgICAgICAgIGl0ZW1bJ3NlcmllcyddLnBvcCgpO1xyXG4gICAgICAgICAgICAgIGl0ZW1bJ3NlcmllcyddLnB1c2gob2JqKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICB9XHJcblxyXG4gIH1cclxuICAvLyB0aGUgZ2V0IGZ1bmQgbGlzdCBzZXJ2aWNlIHdpbGwgcmV0dXJuIHRoZSBoaXN0b3J5IGNoYXJ0IGRhdGEsIHVzaW5nIGJlbG93IGZ1bmN0aW9ucyB0byBjb3ZlcnQgdGhlIGRhdGEgdG8gZXhwZWN0ZWQgcmVzdWx0IHNldFxyXG4gIGNvbnZlcnRUb1Jlc3VsdHMoZGF0YTogYW55W10pOiBhbnlbXSB7XHJcbiAgICBjb25zdCByZXN1bHRzOiBhbnlbXSA9IFtdO1xyXG4gICAgY29uc3QgdmFyaWFibGVGdW5kTGlzdDogYW55W10gPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAvLyBmb3IgcGVyc2lzdGVudCB1c2VyIHNlbGVjdGVkIGZ1bmRzIGluIGxlZ2VuZC5cclxuICAgICAgaWYgKHZhcmlhYmxlRnVuZExpc3QuZmluZEluZGV4KGxpc3QgPT4gbGlzdC5mdW5kSUQgPT09IGl0ZW0uZnVuZGlkKSA9PT0gLTEpIHsgICAgICAgIFxyXG4gICAgICAgICAgdmFyaWFibGVGdW5kTGlzdC5wdXNoKHtcclxuICAgICAgICAgICdmdW5kSUQnOiBpdGVtWydmdW5kaWQnXSxcclxuICAgICAgICAgICdmdW5kVGlja2VyJzppdGVtWydmdW5kVGlja2VyJ10sXHJcbiAgICAgICAgICAnY2hlY2tlZCc6IHRydWVcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICAnbmFtZSc6IGl0ZW1bJ2Z1bmRpZCddLFxyXG4gICAgICAgICdmdW5kSUQnOiBpdGVtWydmdW5kaWQnXSxcclxuICAgICAgICAnZnVuZFRpY2tlcic6aXRlbVsnZnVuZFRpY2tlciddLFxyXG4gICAgICAgICdzZXJpZXMnOiB0aGlzLmNyZWF0ZVNlcmllcyhpdGVtKVxyXG4gICAgICB9XHJcbiAgICAgIHJlc3VsdHMucHVzaChvYmopO1xyXG4gICAgfSlcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNldFZhcmlhYmxlRnVuZExpc3QodmFyaWFibGVGdW5kTGlzdCk7XHJcbiAgICByZXR1cm4gcmVzdWx0cztcclxuICB9XHJcbiAgY3JlYXRlU2VyaWVzKGRhdGE6IGFueSk6IGFueVtdIHtcclxuICAgIGNvbnN0IHNlcmllczogYW55W10gPSBbXTtcclxuICAgIGRhdGFbJ3ByaWNlQ2hhbmdlcyddLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSkpIHtcclxuICAgICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgICAnbWFya2V0dmFsJzogaXRlbVsnZnVuZG12J10sIC8vZnVuZCBtYXJrZXQgdmFsdWUgZnJvbSBoaXN0b3J5IGRhdGFcclxuICAgICAgICAgICduYW1lJzogbmV3IERhdGUoaXRlbVsncHJpY2V0aW1lJ10pLFxyXG4gICAgICAgICAgJ25hdic6IGl0ZW1bJ25hdiddLFxyXG4gICAgICAgICAgJ3ZhbHVlJzogaXRlbVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgJ3ByaWNldGltZSc6IGl0ZW1bJ3ByaWNldGltZSddXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNlcmllcy5wdXNoKG9iaik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIClcclxuICAgIGlmIChzZXJpZXMubGVuZ3RoID09IDApIHtcclxuICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICdtYXJrZXR2YWwnOiBkYXRhWydmdW5kbXYnXSwgLy9mdW5kIG1hcmtldCB2YWx1ZSBmcm9tIGhpc3RvcnkgZGF0YVxyXG4gICAgICAgICduYW1lJzogdGhpcy54U2NhbGVNaW4sXHJcbiAgICAgICAgJ25hdic6IGRhdGFbJ25hdiddLFxyXG4gICAgICAgICd2YWx1ZSc6IDAsXHJcbiAgICAgICAgJ3ByaWNldGltZSc6IHRoaXMuY29tbW9uVXRpbHMuc3RhcnRUaW1lXHJcbiAgICAgIH1cclxuICAgICAgc2VyaWVzLnB1c2gob2JqKTtcclxuICAgIH1cclxuICAgIHJldHVybiBzZXJpZXM7XHJcbiAgfVxyXG5cclxuICAvLyBmb3IgY29sbGVjdGluZyBoaXN0b3JpYyBhbGVydCBkYXRhXHJcbiAgdXBkYXRlQ2lyY2xlRGF0YShkYXRhKSB7XHJcbiAgICBsZXQgQ3JpY2xlRGF0YSA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBDcmljbGVEYXRhID0gQ3JpY2xlRGF0YS5jb25jYXQodGhpcy5maWx0ZXJBbGVydERhdGEoaXRlbVsnZnVuZGlkJ10sIGl0ZW1bJ3ByaWNlQ2hhbmdlcyddKSk7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIENyaWNsZURhdGE7XHJcbiAgfVxyXG5cclxuICBmaWx0ZXJBbGVydERhdGEoZnVuZGlkLCBkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wQWxlcnRDcmljbGVEYXRhID0gW107XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSkgJiYgaXRlbVsnYWxlcnRUeXBlJ10gJiYgKGl0ZW1bJ2FsZXJ0VHlwZSddID09IDEgfHwgaXRlbVsnYWxlcnRUeXBlJ10gPT09IDIpKSB7XHJcbiAgICAgICAgY29uc3QgYWxlcnRPYmogPSB7XHJcbiAgICAgICAgICBcIm5hbWVcIjogZnVuZGlkLFxyXG4gICAgICAgICAgXCJ4XCI6IG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSxcclxuICAgICAgICAgIFwiYWxlcnRUeXBlXCI6IGl0ZW1bJ2FsZXJ0VHlwZSddLFxyXG4gICAgICAgICAgXCJ2YWx1ZVwiOiBpdGVtWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcIm5hdlwiOiBpdGVtWyduYXYnXSxcclxuICAgICAgICAgIFwiZnVuZG12Q2hhbmdlUGVyY2VudFwiOiBpdGVtWydmdW5kbXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBpdGVtWydmdW5kbXYnXSxcclxuICAgICAgICAgIFwicHJpY2V0aW1lXCI6IGl0ZW1bJ3ByaWNldGltZSddLFxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wQWxlcnRDcmljbGVEYXRhLnB1c2goYWxlcnRPYmopO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBBbGVydENyaWNsZURhdGE7XHJcbiAgfVxyXG5cclxuXHJcbiAgLy8gdGhpcyBtZXRob2Qgd2lsbCByZXR1cm4gdGhlIG5leHQgdGltZSBhbmQgc2V0IHRoZSBuZXcgdGltZSB0byB0aGUgcHJldmlvdXMgdGltZSBtYXAgZm9yIHRoZSBnaXZlbiBmdW5kXHJcbiAgbmV4dFRpbWVGb3JGdW5kKHByZXZpb3VzVGltZU1hcDogTWFwPFN0cmluZywgRGF0ZT4sIGZ1bmRpZDogU3RyaW5nLCB0aW1lKSB7XHJcbiAgICBwcmV2aW91c1RpbWVNYXAuc2V0KGZ1bmRpZCwgdGltZSk7IC8vIHNldCBiYWNrIHRvIHRoZSBtYXBcclxuICAgIHJldHVybiBuZXcgRGF0ZSh0aW1lKTtcclxuICB9XHJcblxyXG4gIG9wZW5BZGRGdW5kTW9kYWwoZXZlbnQpOiB2b2lkIHtcclxuICAgIGNvbnN0IGRpYWxvZ1JlZiA9IHRoaXMuZGlhbG9nLm9wZW4oQWRkRnVuZE1vZGFsQ29tcG9uZW50LCB7XHJcbiAgICAgIHdpZHRoOiAnMzAwcHgnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAnZnVuZExpc3QnOiB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpLFxyXG4gICAgICAgICAgJ2RhdGFDaGFuZ2UnOiB0aGlzLmZ1bmRDaGFuZ2UgLy9jcmVhdGUgZXZlbnRlbWl0dGVyIG91cnNlbGYgYXMgY2xvc2VEaWFsb2dTdWJqZWN0IGlzIG5vdCB3b3JraW5nXHJcbiAgICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgZGlhbG9nUmVmLmFmdGVyQ2xvc2VkKCkuc3Vic2NyaWJlKHJlc3VsdCA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdUaGUgZGlhbG9nIHdhcyBjbG9zZWQnKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgeEF4aXNUaWNrRm9ybWF0dGluZyh2KSB7XHJcbiAgIGNvbnN0IHRlbXBEYXRlID0gbmV3IERhdGUodik7XHJcbiAgIHJldHVybiBmb3JtYXREYXRlKHRlbXBEYXRlLFwiaDptbSBhYWFhYSdtJ1wiLCdlbi1VUycpO1xyXG4gfVxyXG5cclxufVxyXG4iLCJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AUGlwZSh7XHJcbiAgbmFtZTogJ3BlcmNlbnRGb3JtYXQnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBQZXJjZW50Rm9ybWF0UGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG5cclxuICB0cmFuc2Zvcm0odmFsdWU6IGFueSk6IGFueSB7XHJcbiAgICBpZiAodmFsdWUgIT0gMCkge1xyXG4gICAgICBpZiAodmFsdWUudG9TdHJpbmcoKS5pbmRleE9mKCctJykgPT09IDApIHtcclxuICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuICcrJyArIHZhbHVlO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gXCIwLjAwMCVcIjtcclxuICAgIH1cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7IFBpcGUsIFBpcGVUcmFuc2Zvcm0gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBQaXBlKHtcclxuICBuYW1lOiAnbnVtYmVyUm91bmRVcCdcclxufSlcclxuZXhwb3J0IGNsYXNzIE51bWJlclJvdW5kVXBQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XHJcblxyXG4gIHRyYW5zZm9ybSh2YWx1ZTogYW55LCBtYXhGcmFjdGlvbkRpZ2l0czogbnVtYmVyKTogYW55IHtcclxuICAgIHJldHVybiBNYXRoLnJvdW5kKDEwKiptYXhGcmFjdGlvbkRpZ2l0cyp2YWx1ZSkvMTAqKm1heEZyYWN0aW9uRGlnaXRzO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEluamVjdCwgRXZlbnRFbWl0dGVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7TWF0RGlhbG9nUmVmLCBNQVRfRElBTE9HX0RBVEF9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItY3VzdG9tLWFsZXJ0LW1vZGFsJyxcclxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cclxuICA8aDEgbWF0LWRpYWxvZy10aXRsZT57e2RhdGEudGl0bGV9fSB7e2RhdGEudHlwZX19IEFsZXJ0cyBmb3Ige3tkYXRhLm5vdyB8IGRhdGU6IFwiRUVFRSwgTS9kLCBoOm1tIGFhYWFhJ20nXCJ9fTwvaDE+XHJcbiAgPHNwYW4gY2xhc3M9XCJhbGVydC1jbG9zZVwiIChjbGljayk9XCJvbk5vQ2xpY2soKVwiID7Dg8KXPC9zcGFuPlxyXG48L2Rpdj5cclxuPGRpdiBtYXQtZGlhbG9nLWNvbnRlbnQ+XHJcbiAgPGRpdiBjbGFzcz1cImNvbnRhaW5lciBjdXN0b20tYWxlcnQtc3R5XCIgKm5nRm9yPVwibGV0IGRhdGEgb2YgYWxlcnREYXRhXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiYWxlcnQtZGV0YWlscy1pdGVtLWNvbnRhaW5lclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwidG9wLWxpbmVcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwidG9wLWxpbmUtaXRlbVwiPlxyXG4gICAgICAgIHt7ZGF0YS5wcmljZXRpbWUgfCBkYXRlOiBcImg6bW06c3MgYWFhYWEnbSdcIn19XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInRvcC1saW5lLWl0ZW1cIj5cclxuICAgICAgICAgIE5BViBEaXZlcmdpbmcgZnJvbSBNYXJrZXQgVmFsdWVcclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJidXR0b24tbGluZVwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvbi1saW5lLWl0ZW1cIj5cclxuICAgICAgICAgICAgIE5BViAlIENoYW5nZTpcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvbi1saW5lLWl0ZW1cIj5cclxuICAgICAgICAgICAge3tkYXRhLnZhbHVlIHwgcGVyY2VudDogJzEuMi0yJ319XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICA8ZGl2IGNsYXNzPVwiYnV0dG9uLWxpbmUtaXRlbVwiPlxyXG4gICAgICAgICAgICAgTVYgJSBDaGFuZ2U6XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJidXR0b24tbGluZS1pdGVtXCI+XHJcbiAgICAgICAgICAgIHt7ZGF0YS5mdW5kbXZDaGFuZ2VQZXJjZW50IHwgcGVyY2VudDogJzEuMi0yJ319XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PlxyXG48ZGl2IG1hdC1kaWFsb2ctYWN0aW9ucyBhbGlnbj1cImVuZFwiPlxyXG4gIDwhLS0gPGJ1dHRvbiBtYXQtYnV0dG9uIChjbGljayk9XCJvbk5vQ2xpY2soKVwiIGNka0ZvY3VzSW5pdGlhbD5DYW5jZWw8L2J1dHRvbj4gLS0+XHJcbiAgPGJ1dHRvbiBtYXQtYnV0dG9uIChjbGljayk9XCJvbk5vQ2xpY2soKVwiIGNsYXNzPVwicHJpbWFyeS1idG5cIj5PSzwvYnV0dG9uPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2AubW9kYWwtaGVhZGVye3Bvc2l0aW9uOnJlbGF0aXZlfS5tYXQtZGlhbG9nLXRpdGxle2NvbG9yOiM0NjQ2NDY7bWFyZ2luOi0xMHB4IDAgMjBweH0uYWxlcnQtY2xvc2V7cG9zaXRpb246YWJzb2x1dGU7dG9wOi02cHg7cmlnaHQ6LTZweDtjb2xvcjpyZ2JhKDEwNSwxMDUsMTA1LC43OCk7Y3Vyc29yOnBvaW50ZXI7Zm9udC1zaXplOjQwcHh9Lm1hdC1kaWFsb2ctY29udGVudHtib3JkZXItYm90dG9tOjJweCBzb2xpZCByZ2JhKDAsMCwwLC4xNSk7aGVpZ2h0OjI1MHB4O292ZXJmbG93OmF1dG99LmN1c3RvbS1hbGVydC1zdHl7Y29sb3I6IzQ2NDY0Njtmb250LXNpemU6MTZweDtwYWRkaW5nLWxlZnQ6MCFpbXBvcnRhbnQ7bWFyZ2luLWJvdHRvbToyMHB4fS5hbGVydC1kZXRhaWxzLWl0ZW0tY29udGFpbmVye3BhZGRpbmc6MCAwIDEwcHh9LnRvcC1saW5le2Rpc3BsYXk6aW5saW5lLWZsZXh9LnRvcC1saW5lLWl0ZW17bWFyZ2luLXJpZ2h0OjE1cHh9LmJ1dHRvbi1saW5le21hcmdpbi10b3A6NXB4O21hcmdpbi1sZWZ0OjkwcHh9LmJ1dHRvbi1saW5lLWl0ZW17ZGlzcGxheTppbmxpbmUtZmxleDt3aWR0aDoxNTBweH0ucHJpbWFyeS1idG57YmFja2dyb3VuZDojMmY3NDlhO2NvbG9yOiNmZmZ9YF1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBhbGVydERhdGEgOiBhbnlbXSA9IFtdO1xyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgICBwcml2YXRlIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICBwdWJsaWMgZGlhbG9nUmVmOiBNYXREaWFsb2dSZWY8Q3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudD4sXHJcbiAgICBASW5qZWN0KE1BVF9ESUFMT0dfREFUQSkgcHVibGljIGRhdGE6IGFueSkgIHtcclxuICAgIHRoaXMuYWxlcnREYXRhID0gZGF0YVsnYWxlcnREYXRhJ107ICAgIFxyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICBvbk5vQ2xpY2soKTogdm9pZCB7XHJcbiAgICB0aGlzLmRpYWxvZ1JlZi5jbG9zZSgpO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBFbGVtZW50UmVmLCBOZ1pvbmUsIENoYW5nZURldGVjdG9yUmVmLFxyXG4gIENvbXBvbmVudCxcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIEhvc3RMaXN0ZW5lcixcclxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICBDb250ZW50Q2hpbGQsXHJcbiAgVGVtcGxhdGVSZWYsXHJcbiAgVmlld0NvbnRhaW5lclJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBmb3JtYXROdW1iZXIgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBCYXNlV2lkZ2V0Q29tcG9uZW50IH0gZnJvbSAnQG9tbmlhL3VpLWNvbW1vbic7XHJcbmltcG9ydCB7IGhlYXRNYXBDb2xvclNldHRpbmcsIGhlYXRNYXBDb2xvclNjaGVtZSB9IGZyb20gJy4uL2NvbG9ycyc7XHJcbmltcG9ydCB7IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvc2hhcmUtaW5mby1iZXdlZW4tY29tcG9uZW50cy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zZXJ2aWNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZTb2NrZXRTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNvY2tldC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUmVzb3VyY2VNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1wb3NpdGlvbi1oZWF0LW1hcCcsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwicG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyXCIgKm5nSWY9XCJpc0RhdGFBdmFpbGFibGVcIiAod2luZG93OnJlc2l6ZSk9XCJyZXNpemluZ0hlYXRNYXAoJGV2ZW50KVwiPlxyXG5cclxuICA8ZGl2IGNsYXNzPVwiaGVhdC1tYXAtdGl0bGVcIj5cclxuICAgIDxwPlBvc3Rpb24gfCBOQVYgSW1wYWN0IFQgKyAxPC9wPlxyXG4gIDwvZGl2PiA8IS0tIHRpdGxlLS0+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJsZWZ0LXNpZGUtcGFuZWxcIj5cclxuICAgIDxwIGNsYXNzPVwicGFuZWwtdGl0bGVcIj5UICsgMSBWaWV3PC9wPlxyXG4gICAgPGRpdiAgY2xhc3M9XCJkYXRlLWRldGFpbHNcIj5cclxuICAgICAgPHAgY2xhc3M9XCJkYXlcIj57e2RhdGVOb3cgfCBkYXRlIDogJ2RkJ319PC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZGF0ZS1pdGVtc1wiPlxyXG4gICAgICAgIDxwPnt7ZGF0ZU5vdyB8IGRhdGUgOiAnRUVFRSd9fTwvcD5cclxuICAgICAgICA8cD57e2RhdGVOb3cgfCBkYXRlIDogJ0xMTEwnfX08L3A+XHJcbiAgICAgICAgPHA+e3tkYXRlTm93IHwgZGF0ZSA6ICd5eXl5J319PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgPC9kaXY+XHJcbiAgIDx1bD5cclxuICAgICA8bGlcclxuICAgICAqbmdGb3I9XCJsZXQgaXRlbSBvZiB0b3BGaXZlUmVzdWx0czsgbGV0IGkgPSBpbmRleDtcIlxyXG4gICAgID5cclxuICAgICA8cCBjbGFzcz1cImxlZnQtbmFtZVwiPnt7aXRlbS5uYW1lfX08L3A+XHJcbiAgICAgPHAgY2xhc3M9XCJyaWdodC12YWx1ZVwiPnt7aXRlbS52YWx1ZX19PC9wPlxyXG4gICAgIDwvbGk+XHJcbiAgIDwvdWw+XHJcbiAgIDxkaXYgY2xhc3M9XCJidG4td3JhcHBlclwiPlxyXG4gICAgIDxhIGNsYXNzPVwidmlldy1hbGwtYnRuXCI+VmlldyBBbGwgUG9zaXRpb25zPC9hPlxyXG4gICA8L2Rpdj5cclxuICA8L2Rpdj4gPCEtLSBsZWZ0IHNpZGUgcGFuZWwtLT5cclxuXHJcbiAgPGRpdiBjbGFzcz1cImhlYXQtbWFwLWNvbnRhaW5lclwiPlxyXG4gICAgPHBvc2l0aW9uLWhlYXQtbWFwLWNoYXJ0XHJcbiAgICBbc3luY1Jlc3VsdHNdPVwic3luY1Jlc3VsdHNcIlxyXG4gICAgW2hlaWdodF09J2hlaWdodCdcclxuICAgIFt3aWR0aF09J3dpZHRoJ1xyXG4gICAgW21hcmdpbl09J21hcmdpbidcclxuICAgIFt0b29sdGlwRGlzYWJsZWRdPVwiZmFsc2VcIlxyXG4gICAgW3NjaGVtZV09XCJjb2xvclNjaGVtZVwiXHJcbiAgICBbdmFsdWVGb3JtYXR0aW5nXT1cImhlYXRNYXBWYWx1ZUZvcm1hdHRpbmdcIlxyXG4gICAgW2xhYmVsRm9ybWF0dGluZ109XCJoZWF0TWFwTGFiZWxGb3JtYXR0aW5nXCJcclxuICAgID5cclxuICAgIDwvcG9zaXRpb24taGVhdC1tYXAtY2hhcnQ+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImJvdHRvbVwiPlxyXG4gICAgPHA+U2l6ZSByZXByZXNlbnRzIG1hcmtldCBjYXA8L3A+XHJcbiAgICA8dWw+XHJcbiAgICAgIDxsaVxyXG4gICAgICAqbmdGb3I9XCJsZXQgaXRlbSBvZiBoZWF0TWFwQ29sb3JTZXR0aW5nOyBsZXQgaT1pbmRleDtcIlxyXG4gICAgICBbc3R5bGUuYmFja2dyb3VuZF09XCJpdGVtLmNvbG9yXCJcclxuICAgICAgPnt7aXRlbS52YWx1ZX19JTwvbGk+XHJcbiAgICA8L3VsPlxyXG4gIDwvZGl2PlxyXG4gIDwvZGl2PiA8IS0tIGhlYXQgbWFwIC0tPlxyXG5cclxuPC9kaXY+XHJcbmAsXHJcbiAgc3R5bGVzOiBbYC5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXJ7aGVpZ2h0OjEwMCU7Y29sb3I6IzQ2NDY0NiFpbXBvcnRhbnR9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAuaGVhdC1tYXAtdGl0bGV7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDoxNXB4O2ZvbnQtc2l6ZToxNnB4fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbHtkaXNwbGF5OmlubGluZS1ibG9jaztib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNlZWU7dGV4dC1hbGlnbjpjZW50ZXI7cGFkZGluZzowIDIwcHg7d2lkdGg6MTUlfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCAucGFuZWwtdGl0bGV7bWFyZ2luOjEwcHggMCAwO2ZvbnQtc2l6ZToxNXB4O29wYWNpdHk6LjY7dGV4dC1hbGlnbjpsZWZ0fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCAuZGF0ZS1kZXRhaWxzIC5kYXl7ZGlzcGxheTppbmxpbmUtYmxvY2s7Zm9udC1zaXplOjYwcHg7cGFkZGluZzowO21hcmdpbjowIDIwcHggMCAwfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCAuZGF0ZS1kZXRhaWxzIC5kYXRlLWl0ZW1ze2Rpc3BsYXk6aW5saW5lLWJsb2NrfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCAuZGF0ZS1kZXRhaWxzIC5kYXRlLWl0ZW1zIHB7bWFyZ2luOjA7cGFkZGluZzowIDAgMnB4O2ZvbnQtc2l6ZToxNHB4O3RleHQtYWxpZ246bGVmdH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgdWx7bGlzdC1zdHlsZS10eXBlOm5vbmU7cGFkZGluZzowfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCB1bCBsaXttYXJnaW46MTJweCAwO2Rpc3BsYXk6YmxvY2t9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAubGVmdC1zaWRlLXBhbmVsIHVsIGxpIHB7ZGlzcGxheTppbmxpbmUtYmxvY2s7bWFyZ2luOjA7d2lkdGg6NDUlfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCB1bCBsaSAubGVmdC1uYW1le2ZvbnQtc2l6ZToxNnB4O3RleHQtYWxpZ246bGVmdH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgdWwgbGkgLnJpZ2h0LXZhbHVle2ZvbnQtc2l6ZToxMnB4O29wYWNpdHk6Ljk7dGV4dC1hbGlnbjpyaWdodH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgLmJ0bi13cmFwcGVye3BhZGRpbmc6MTBweCAwIDB9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAubGVmdC1zaWRlLXBhbmVsIC5idG4td3JhcHBlciAudmlldy1hbGwtYnRue2JvcmRlcjoxcHggc29saWQgcmdiYSgwLDAsMCwuMyk7Y3Vyc29yOnBvaW50ZXI7Ym9yZGVyLXJhZGl1czozcHg7cGFkZGluZzozcHggNXB4fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmhlYXQtbWFwLWNvbnRhaW5lcnt3aWR0aDo3MCU7ZGlzcGxheTppbmxpbmUtYmxvY2s7bWFyZ2luLWxlZnQ6MjVweH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5oZWF0LW1hcC1jb250YWluZXIgLmJvdHRvbXt0ZXh0LWFsaWduOnJpZ2h0O2ZvbnQtc2l6ZToxNHB4fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmhlYXQtbWFwLWNvbnRhaW5lciAuYm90dG9tIHB7ZGlzcGxheTppbmxpbmUtZmxleDtmb250LXN0eWxlOml0YWxpY30ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5oZWF0LW1hcC1jb250YWluZXIgLmJvdHRvbSB1bHtkaXNwbGF5OmlubGluZS1mbGV4fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmhlYXQtbWFwLWNvbnRhaW5lciAuYm90dG9tIGxpe2Rpc3BsYXk6aW5saW5lLWZsZXg7cGFkZGluZzowIDEwcHh9YF1cclxufSlcclxuZXhwb3J0IGNsYXNzIFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCBleHRlbmRzIEJhc2VXaWRnZXRDb21wb25lbnQge1xyXG5cclxucHJpdmF0ZSBzdWJzOiBTdWJzY3JpcHRpb25bXTtcclxuc3luY1Jlc3VsdHM6IGFueVtdID0gW107IC8vIGl0J3MgcmVzdWx0cywgIGNoYW5nZSBuYW1lIHRvIHN5bmNSZXN1bHRzXHJcbnRvcEZpdmVSZXN1bHRzID0gW107XHJcbmhlaWdodDogbnVtYmVyID0gMjYwO1xyXG53aWR0aDogbnVtYmVyO1xyXG5tYXJnaW4gPSBbMjAsIDEwLCAxMCwgMTBdO1xyXG5pc0RhdGFBdmFpbGFibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuaGVhdE1hcENvbG9yU2V0dGluZzogYW55W10gPSBoZWF0TWFwQ29sb3JTZXR0aW5nO1xyXG5kYXRlTm93ID0gbmV3IERhdGUoKTtcclxuY29sb3JTY2hlbWUgPSBoZWF0TWFwQ29sb3JTY2hlbWU7XHJcbmZ1bmRJbmZvOiBhbnkgPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3IoY2hhcnRFbGVtZW50OiBFbGVtZW50UmVmLCBcclxuICAgICAgICAgICAgICAgICAgICAgIHpvbmU6IE5nWm9uZSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIG5hdlNvY2tldFNlcnZpY2U6IE5hdlNvY2tldFNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIHNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlOiBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgbmF2U2VydmljZTogTmF2U2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgcmVzb3VyY2VNYW5nZXI6IFJlc291cmNlTWFuYWdlclNlcnZpY2UpIHsgXHJcbiAgICBzdXBlcigpO1xyXG4gICAgdGhpcy53aWR0aCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ21haW4nKVswXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCAqIDAuNztcclxuICAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIHRoaXMuc3luY1Jlc3VsdHMgPSBbXTtcclxuICAgIHRoaXMudG9wRml2ZVJlc3VsdHMgPSBbXTtcclxuICAgIHRoaXMuc3VicyA9IFtdO1xyXG4gICAgdGhpcy5pc0RhdGFBdmFpbGFibGUgPSBmYWxzZTtcclxuXHJcbiAgICB0aGlzLmZ1bmRJbmZvID0gdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5mdW5kSW5mbztcclxuICAgIGlmKHRoaXMuZnVuZEluZm8ubGVuZ3RoID4gMCkge1xyXG4gICAgICB0aGlzLnJlbmRlclBvc2l0aW9uTWFwKCk7XHJcbiAgICB9ZWxzZXtcclxuICAgICAgdGhpcy5uYXZTZXJ2aWNlLmZldGNoRnVuZExpc3QoKTtcclxuICAgICAgdGhpcy5uYXZTZXJ2aWNlLmdldEZ1bmRMaXN0KCkuc3Vic2NyaWJlKFxyXG4gICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJkYXRhXCIpO1xyXG4gICAgICAgICAgIGlmKGRhdGEubGVuZ3RoPjApIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgICBjb25zdCBmdW5kSW5mbyA9IFtdO1xyXG4gICAgICAgICAgICBmdW5kSW5mby5wdXNoKGRhdGFbMF0uZnVuZGlkKTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLm5hbWUpO1xyXG4gICAgICAgICAgICBmdW5kSW5mby5wdXNoKGRhdGFbMF0uZnVuZFRpY2tlcilcclxuICAgICAgICAgICAgdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5zYXZlUG9zaXRpb25EZXRhaWxzRnVuZEluZm8oZnVuZEluZm8pO1xyXG4gICAgICAgICAgICB0aGlzLnJlbmRlclBvc2l0aW9uTWFwKCk7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG4gIHJlbmRlclBvc2l0aW9uTWFwKCl7XHJcbiAgICB0aGlzLmZ1bmRJbmZvID0gdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5mdW5kSW5mbztcclxuICAgIGlmKHRoaXMuZnVuZEluZm8ubGVuZ3RoID4gMCkge1xyXG4gICAgdGhpcy5zdWJzLnB1c2godGhpcy5uYXZTZXJ2aWNlLmdldFBvc2l0aW9uRGV0YWlscyh0aGlzLmZ1bmRJbmZvWzBdKS5zdWJzY3JpYmUoXHJcbiAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgIHRoaXMuaXNEYXRhQXZhaWxhYmxlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnN5bmNSZXN1bHRzID0gdGhpcy5maWx0ZXJIb2xkaW5nc1RvSGVhdE1hcChkYXRhWydob2xkaW5ncyddKTtcclxuICAgICAgICB0aGlzLnRvcEZpdmVSZXN1bHRzID0gdGhpcy5maWx0ZXJIb2xkaW5nc1RvVG9wRml2ZShkYXRhWydob2xkaW5ncyddKTtcclxuICAgICAgfVxyXG4gICAgKSlcclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U29ja2V0U2VydmljZS5nZXROYXYoKS5zdWJzY3JpYmUoXHJcbiAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgIHRoaXMudXBkYXRlSGVhdE1hcChkYXRhLmV2ZW50RGF0YSk7XHJcbiAgICAgIH0pKTtcclxuICAgIFxyXG4gICAgIHRoaXMubmF2U29ja2V0U2VydmljZS5yZWdpc3RlckZ1bmRzKFt0aGlzLmZ1bmRJbmZvWzBdXSk7XHJcblxyXG4gICAgIHRoaXMucmVzb3VyY2VNYW5nZXIucmVnaXN0SW50ZXJ2YWwoKCkgPT4geyB0aGlzLnN5bmNSZXN1bHRzID0gWy4uLnRoaXMuc3luY1Jlc3VsdHNdfSw0MDApOyAvLyBzZXQgaW50ZXJ2YWwgdGltZSBmb3IgMC40IHNlY29uZHMgdGVtcG9yYXJpbHlcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBmaWx0ZXJIb2xkaW5nc1RvSGVhdE1hcChkYXRhKXtcclxuICAgIGNvbnN0IHRlbXBSZXN1bHRzID0gW107XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICBcIm5hbWVcIjogaXRlbS5jdXNpcCxcclxuICAgICAgICBcInZhbHVlXCI6IE1hdGguYWJzKGl0ZW0ubmF2SW1wYWN0KSxcclxuICAgICAgICBcIm5hdkltcGFjdFwiOiBpdGVtLm5hdkltcGFjdFxyXG4gICAgICB9O1xyXG4gICAgICB0ZW1wUmVzdWx0cy5wdXNoKG9iaik7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBSZXN1bHRzO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVySG9sZGluZ3NUb1RvcEZpdmUoZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcFRvcEZpdmUgPSBbXTtcclxuICAgIGRhdGEuc29ydCgoaXRlbWEsIGl0ZW1iKSA9PiB7XHJcbiAgICAgIHJldHVybiBpdGVtYi5uYXZJbXBhY3QgIC0gaXRlbWEubmF2SW1wYWN0O1xyXG4gICAgICAvLyByZXR1cm4gTWF0aC5hYnMoaXRlbWIubmF2SW1wYWN0KSAgLSBNYXRoLmFicyhpdGVtYS5uYXZJbXBhY3QpOyBUQkMuLi4gIGlmIHdlIHNvcnQgaXQgdXNpbmcgcmVhbCB2YWx1ZSBub3QgYWJzb2x1dGUgdmFsdWUsIHdpbGwgbWFrZSBjb25mdXNpb24gYmV0d2VlbiB0b3AgZml2ZSByZWNvcmRzIGFuZCBoZWF0IG1hcCBjaGFydC5cclxuICAgIH0pO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGVtcFRvcEZpdmUubGVuZ3RoIDwgNSkge1xyXG4gICAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgICBcIm5hbWVcIjogaXRlbS5jdXNpcCA/IGl0ZW0uY3VzaXAgOiBpdGVtLm5hbWUsXHJcbiAgICAgICAgICBcInZhbHVlXCI6IGZvcm1hdE51bWJlcihpdGVtLm5hdkltcGFjdCwgJ2VuLVVTJywgJzEuNS01JylcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcFRvcEZpdmUucHVzaChvYmopO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBUb3BGaXZlO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlSGVhdE1hcChkYXRhKXtcclxuICAgIGlmIChkYXRhICYmIHRoaXMuY29tbW9uVXRpbHMuaXNWYWxpZFRpbWUobmV3IERhdGUoZGF0YVsncHJpY2V0aW1lJ10pKSkge1xyXG4gICAgICB0aGlzLnN5bmNSZXN1bHRzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW0ubmFtZSA9PT0gZGF0YS5jdXNpcCkge1xyXG4gICAgICAgICAgaXRlbS52YWx1ZSA9IE1hdGguYWJzKGRhdGEubmF2SW1wYWN0KTtcclxuICAgICAgICAgIGl0ZW0ubmF2SW1wYWN0ID0gZGF0YS5uYXZJbXBhY3RcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmVzaXppbmdIZWF0TWFwKGV2ZW50KSB7XHJcbiAgICB0aGlzLndpZHRoID0gZXZlbnQudGFyZ2V0LmlubmVyV2lkdGggKiAwLjc7XHJcbiAgfVxyXG5cclxuICAvLyBuZWVkcyBtb3JlIGFuYWx5emUgaGVyZVxyXG4gIGhlYXRNYXBWYWx1ZUZvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIC8vIGNvbnN0IGZvcm1hdFZhbHVlID0gIGZvcm1hdE51bWJlcih2YWx1ZSwgJ2VuLVVTJywgJzEuNS01Jyk7XHJcbiAgICAvLyByZXR1cm4gZm9ybWF0VmFsdWU7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBoZWF0TWFwTGFiZWxGb3JtYXR0aW5nKG9iail7XHJcbiAgICBjb25zdCBmb3JtYXRWYWx1ZSA9ICBmb3JtYXROdW1iZXIob2JqLnZhbHVlLCAnZW4tVVMnLCAnMS41LTUnKTtcclxuICAgIHJldHVybiBgJHtvYmoubGFiZWx9PGJyLz48c21hbGw+YCArIGAke2Zvcm1hdFZhbHVlfTwvc21hbGw+YDtcclxuICAgIC8vIHJldHVybiBgJHtvYmoubGFiZWx9PGJyLz48c21hbGw+SW5zdHJ1bWVudCBJZCBSZWY8L3NtYWxsPmA7XHJcbiAgfVxyXG5cclxuICAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICBpZiAodGhpcy5mdW5kSW5mby5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHRoaXMubmF2U29ja2V0U2VydmljZS51blJlZ2lzdGVyRnVuZHMoW3RoaXMuZnVuZEluZm9bMF1dKTtcclxuICAgICAgdGhpcy5zdWJzLmZvckVhY2ggKHN1YiA9PiBzdWIudW5zdWJzY3JpYmUoKSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnJlc291cmNlTWFuZ2VyLmNsZWFuUmVzb3VyY2VzKCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIENvbXBvbmVudCxcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxyXG4gIENvbnRlbnRDaGlsZCxcclxuICBUZW1wbGF0ZVJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgdHJlZW1hcCwgc3RyYXRpZnkgfSBmcm9tICdkMy1oaWVyYXJjaHknO1xyXG5pbXBvcnQgeyBjYWxjdWxhdGVWaWV3RGltZW5zaW9ucywgVmlld0RpbWVuc2lvbnMsIEJhc2VDaGFydENvbXBvbmVudCwgQ29sb3JIZWxwZXIgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3Bvc2l0aW9uLWhlYXQtbWFwLWNoYXJ0JyxcclxuICB0ZW1wbGF0ZTogYDxuZ3gtY2hhcnRzLWNoYXJ0XHJcbiAgICAgIFt2aWV3XT1cIlt3aWR0aCwgaGVpZ2h0XVwiXHJcbiAgICAgIFtzaG93TGVnZW5kXT1cImZhbHNlXCJcclxuICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiPlxyXG4gICAgICA8c3ZnOmcgW2F0dHIudHJhbnNmb3JtXT1cInRyYW5zZm9ybVwiIGNsYXNzPVwidHJlZS1tYXAgY2hhcnRcIj5cclxuICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy10cmVlLW1hcC1jZWxsLXNlcmllc1xyXG4gICAgICAgICAgW2NvbG9yc109XCJjb2xvcnNcIlxyXG4gICAgICAgICAgW2RhdGFdPVwiZGF0YVwiXHJcbiAgICAgICAgICBbZGltc109XCJkaW1zXCJcclxuICAgICAgICAgIFt0b29sdGlwRGlzYWJsZWRdPVwidG9vbHRpcERpc2FibGVkXCJcclxuICAgICAgICAgIFt0b29sdGlwVGVtcGxhdGVdPVwidG9vbHRpcFRlbXBsYXRlXCJcclxuICAgICAgICAgIFt2YWx1ZUZvcm1hdHRpbmddPVwidmFsdWVGb3JtYXR0aW5nXCJcclxuICAgICAgICAgIFtsYWJlbEZvcm1hdHRpbmddPVwibGFiZWxGb3JtYXR0aW5nXCJcclxuICAgICAgICAgIFtncmFkaWVudF09XCJncmFkaWVudFwiXHJcbiAgICAgICAgICBbYW5pbWF0aW9uc109XCJhbmltYXRpb25zXCJcclxuICAgICAgICAgIChzZWxlY3QpPVwib25DbGljaygkZXZlbnQpXCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L3N2ZzpnPlxyXG4gICAgPC9uZ3gtY2hhcnRzLWNoYXJ0PmAsXHJcbiAgc3R5bGVzOiBbYC50cmVlLW1hcCAudHJlZW1hcC12YWx7Zm9udC1zaXplOjEuM2VtO3BhZGRpbmctdG9wOjVweDtkaXNwbGF5OmlubGluZS1ibG9ja30udHJlZS1tYXAgLmxhYmVsIHB7ZGlzcGxheTp0YWJsZS1jZWxsO3RleHQtYWxpZ246Y2VudGVyO2xpbmUtaGVpZ2h0OjEuMmVtO3ZlcnRpY2FsLWFsaWduOm1pZGRsZX1gXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBIZWF0TWFwQ29tcG9uZW50IGV4dGVuZHMgQmFzZUNoYXJ0Q29tcG9uZW50IHtcclxuXHJcbiAgQElucHV0KCkgc3luY1Jlc3VsdHM7XHJcbiAgQElucHV0KCkgdG9vbHRpcERpc2FibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgQElucHV0KCkgdmFsdWVGb3JtYXR0aW5nOiBhbnk7XHJcbiAgQElucHV0KCkgbGFiZWxGb3JtYXR0aW5nOiBhbnk7XHJcbiAgQElucHV0KCkgZ3JhZGllbnQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSBoZWlnaHQ6IG51bWJlcjtcclxuICBASW5wdXQoKSB3aWR0aDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHNjaGVtZTogYW55ID0ge307XHJcbiAgQElucHV0KCkgbWFyZ2luOiBhbnlbXTtcclxuICBASW5wdXQoKSBhbmltYXRpb25zOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgQE91dHB1dCgpIHNlbGVjdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgQENvbnRlbnRDaGlsZCgndG9vbHRpcFRlbXBsYXRlJykgdG9vbHRpcFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xyXG5cclxuICBkaW1zOiBhbnk7XHJcbiAgZG9tYWluOiBhbnk7XHJcbiAgdHJhbnNmb3JtOiBhbnk7XHJcbiAgY29sb3JzOiBDb2xvckhlbHBlcjtcclxuICB0cmVlbWFwOiBhbnk7XHJcbiAgZGF0YTogYW55O1xyXG4gIGN1c3RvbUNvbG9yczogYW55O1xyXG4gIFxyXG5cclxuICB1cGRhdGUoKTogdm9pZCB7XHJcbiAgICBzdXBlci51cGRhdGUoKTtcclxuXHJcbiAgICB0aGlzLmRpbXMgPSBjYWxjdWxhdGVWaWV3RGltZW5zaW9ucyh7XHJcbiAgICAgIHdpZHRoOiB0aGlzLndpZHRoLFxyXG4gICAgICBoZWlnaHQ6IDI2MCxcclxuICAgICAgbWFyZ2luczogdGhpcy5tYXJnaW5cclxuICAgIH0pO1xyXG4gICAgdGhpcy5oZWlnaHQgPSAyNjA7XHJcblxyXG4gICAgdGhpcy5kb21haW4gPSB0aGlzLmdldERvbWFpbigpO1xyXG5cclxuICAgIHRoaXMudHJlZW1hcCA9IHRyZWVtYXA8YW55PigpXHJcbiAgICAgIC5zaXplKFt0aGlzLmRpbXMud2lkdGgsIHRoaXMuZGltcy5oZWlnaHRdKTtcclxuXHJcbiAgICBjb25zdCByb290Tm9kZSA9IHtcclxuICAgICAgbmFtZTogJ3Jvb3QnLFxyXG4gICAgICB2YWx1ZTogMCxcclxuICAgICAgaXNSb290OiB0cnVlXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHJvb3QgPSBzdHJhdGlmeTxhbnk+KClcclxuICAgICAgLmlkKGQgPT4ge1xyXG4gICAgICAgIGxldCBsYWJlbCA9IGQubmFtZTtcclxuXHJcbiAgICAgICAgaWYgKGxhYmVsLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgICAgbGFiZWwgPSBsYWJlbC50b0xvY2FsZURhdGVTdHJpbmcoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbGFiZWwgPSBsYWJlbC50b0xvY2FsZVN0cmluZygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbGFiZWw7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5wYXJlbnRJZChkID0+IGQuaXNSb290ID8gbnVsbCA6ICdyb290JylcclxuICAgICAgKFtyb290Tm9kZSwgLi4udGhpcy5zeW5jUmVzdWx0c10pXHJcbiAgICAgIC5zdW0oZCA9PiBkLnZhbHVlKTtcclxuXHJcbiAgICB0aGlzLmRhdGEgPSB0aGlzLnRyZWVtYXAocm9vdCk7XHJcblxyXG4gICAgdGhpcy5jdXN0b21Db2xvcnMgPSB0aGlzLnNldEN1c3RvbUNvbG9ycygpO1xyXG5cclxuICAgIHRoaXMuc2V0Q29sb3JzKCk7XHJcblxyXG4gICAgdGhpcy50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlKCR7IHRoaXMuZGltcy54T2Zmc2V0IH0gLCAkeyB0aGlzLm1hcmdpblswXSB9KWA7XHJcbiAgfVxyXG5cclxuICBzZXRDdXN0b21Db2xvcnMoKTogYW55W10ge1xyXG4gICAgY29uc3QgYXJyID0gW107XHJcbiAgICB0aGlzLnN5bmNSZXN1bHRzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGxldCBjb2xvcjogc3RyaW5nID0gJyc7XHJcbiAgICAgIGlmIChpdGVtLm5hdkltcGFjdCA8PSAtMykgeyAvLyAtM1xyXG4gICAgICAgIGNvbG9yID0gJyNCOTEyMjQnO1xyXG4gICAgICB9IGVsc2UgaWYgKGl0ZW0ubmF2SW1wYWN0ID4gLTMgJiYgaXRlbS5uYXZJbXBhY3QgPD0gLTIpIHsgLy8gLTJcclxuICAgICAgICBjb2xvciA9ICcjRUFCN0JEJztcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLm5hdkltcGFjdCA+IC0yICYmIGl0ZW0ubmF2SW1wYWN0IDw9IDApIHsgLy8gLTFcclxuICAgICAgICBjb2xvciA9ICcjRjVEQ0RFJztcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLm5hdkltcGFjdCA+PSAwICYmIGl0ZW0ubmF2SW1wYWN0IDwgMikgey8vIDFcclxuICAgICAgICBjb2xvciA9ICcjREZFQUUyJztcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLm5hdkltcGFjdCA+PSAyICYmIGl0ZW0ubmF2SW1wYWN0IDwgMykgey8vIDJcclxuICAgICAgICBjb2xvciA9ICcjQkVENUM1JztcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLm5hdkltcGFjdCA+PSAzKSB7IC8vM1xyXG4gICAgICAgIGNvbG9yID0gJyMyODc0M0UnO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbG9yID0gJyc7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IG9iaiA9IHtcclxuICAgICAgICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAgICAgdmFsdWU6IGNvbG9yXHJcbiAgICAgIH1cclxuICAgICAgYXJyLnB1c2gob2JqKTtcclxuICAgIH0pXHJcbiAgICByZXR1cm4gYXJyO1xyXG4gIH1cclxuXHJcbiAgZ2V0RG9tYWluKCk6IGFueVtdIHtcclxuICAgIHJldHVybiB0aGlzLnN5bmNSZXN1bHRzLm1hcChkID0+IGQubmFtZSk7XHJcbiAgfVxyXG5cclxuICBvbkNsaWNrKGRhdGEpOiB2b2lkIHtcclxuICAgIHRoaXMuc2VsZWN0LmVtaXQoZGF0YSk7XHJcbiAgfVxyXG5cclxuICBzZXRDb2xvcnMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmNvbG9ycyA9IG5ldyBDb2xvckhlbHBlcih0aGlzLnNjaGVtZSwgJ29yZGluYWwnLCB0aGlzLmRvbWFpbiwgdGhpcy5jdXN0b21Db2xvcnMpO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiZXhwb3J0IGNvbnN0IHNpbmdsZUxpbmVUaWNrc1ZhbHVlID0gW1xyXG4gICAgbmV3IERhdGUoKS5zZXRIb3Vycyg5LCAzMCwgMCksIFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxMiwgMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDE0LCAwLCAwKSxcclxuICAgIG5ldyBEYXRlKCkuc2V0SG91cnMoMTYsIDAsIDApXHJcbiAgICBdO1xyXG4gICAgIiwiaW1wb3J0IHtcclxuICBFbGVtZW50UmVmLCBOZ1pvbmUsIENoYW5nZURldGVjdG9yUmVmLFxyXG4gIENvbXBvbmVudCxcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIEhvc3RMaXN0ZW5lcixcclxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICBDb250ZW50Q2hpbGQsXHJcbiAgVGVtcGxhdGVSZWYsXHJcbiAgVmlld0NvbnRhaW5lclJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBCYXNlV2lkZ2V0Q29tcG9uZW50IH0gZnJvbSAnQG9tbmlhL3VpLWNvbW1vbic7XHJcbmltcG9ydCB7IGZvcm1hdERhdGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBzaW5nbGVMaW5lVGlja3NWYWx1ZSB9IGZyb20gJy4vcG9zaXRpb24tc3VtbWFyeS1kYXRhJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNlcnZpY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvc2hhcmUtaW5mby1iZXdlZW4tY29tcG9uZW50cy5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLXBvc2l0aW9uLWZ1bmQtc3VtbWFyeScsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwicG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lclwiICh3aW5kb3c6cmVzaXplKT1cInJlc2l6aW5nU2luZ2xlTGluZUNoYXJ0KCRldmVudClcIj5cclxuXHJcbiAgPGRpdiBjbGFzcz1cImZ1bmQtc3VtbWFyeS10aXRsZVwiPlxyXG4gICAgPHA+RnVuZCBTdW1tYXJ5IHwge3tkYXRlTm93IHwgZGF0ZSA6ICdsb25nRGF0ZSd9fTwvcD5cclxuICA8L2Rpdj4gPCEtLSB0aXRsZS0tPlxyXG5cclxuICA8ZGl2IGNsYXNzPVwibWFpbi1ib2R5LXdyYXBwZXJcIj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwidG9wLXNlYXJjaFwiPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIlNlYXJjaCBNdXR1YWwgRnVuZCBOYW1lXCIvPlxyXG4gICAgICA8bWF0LWljb24gc3ZnSWNvbj1cInNlYXJjaFwiID48L21hdC1pY29uPlxyXG4gICAgPC9kaXY+IDwhLS1JZiBuZWVkIHVzZSBhbmd1bGFyIHNlYXJjaCBjb21wb25lbnQgPy0tPlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJsZWZ0LXNpZGUtcGFuZWwtd3JhcHBlclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibGVmdC1zaWRlLXBhbmVsXCJcclxuICAgICAgKm5nRm9yPVwibGV0IGl0ZW0gb2Ygc3VtbWFyeUFzc2V0c1ZhbHVlOyBsZXQgaSA9IGluZGV4O1wiXHJcbiAgICAgID5cclxuICAgICAgICA8cD57e2l0ZW0udmFsdWUgfCBjdXJyZW5jeSA6ICdVU0QnOiAnJyA6ICc1LjAtMCd9fTwvcD5cclxuICAgICAgICA8bGFiZWw+e3tpdGVtLnRpdGxlfX08L2xhYmVsPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgIDxkaXYgY2xhc3M9XCJzaW5nbGUtbGluZS1jaGFydFwiPlxyXG5cclxuICAgICA8ZGl2IGNsYXNzPVwiZmxvYXRpbmctcmVjdC13cmFwcGVyXCI+XHJcbiAgICAgICA8ZGl2IGNsYXNzPVwidG9wLWxlZnQtaW5mb1wiPlxyXG4gICAgICAgICA8cCBjbGFzcz1cInRvcC1sZWZ0LWluZm8tdlwiPjUwMCwwMDA8L3A+XHJcbiAgICAgICAgIDxsYWJlbD5TaGFyZXMgT3V0c3RhbmRpbmc8L2xhYmVsPlxyXG4gICAgICAgPC9kaXY+XHJcbiAgICAgICA8ZGl2IGNsYXNzPVwidG9wLXJpZ2h0dC1pbmZvXCI+XHJcbiAgICAgICAgIDxsYWJlbD5NYXJrZXQgVmFsdWUgQ2hhbmdlOiBUb2RheTwvbGFiZWw+XHJcbiAgICAgICAgIDxwIGNsYXNzPVwidG9wLXJpZ2h0dC1pbmZvLXZcIj4rMTAwLDAwMDwvcD5cclxuICAgICAgICAgPHAgY2xhc3M9XCJ0b3AtcmlnaHR0LWluZm8tdlwiPiswLjAzJTwvcD5cclxuICAgICAgIDwvZGl2PlxyXG4gICAgICAgPGRpdiBjbGFzcz1cIm1pZGRsZS1pbmZvXCI+XHJcbiAgICAgICAgIDQsNDAwLDAwMFxyXG4gICAgICAgPC9kaXY+XHJcbiAgICAgICA8ZGl2IGNsYXNzPVwiYm90dG9tLWluZm9cIj5cclxuICAgICAgICAgNCwzMDAsMDAwXHJcbiAgICAgICA8L2Rpdj5cclxuICAgICA8L2Rpdj5cclxuXHJcbiAgICA8bGliLXNpbmdsZS1saW5lLWNoYXJ0XHJcbiAgICAgIFtyZXN1bHRzXT0ncmVzdWx0cydcclxuICAgICAgW2hlaWdodF09J2hlaWdodCdcclxuICAgICAgW3dpZHRoXT0nd2lkdGgnXHJcbiAgICAgIFttYXJnaW5dPSdtYXJnaW4nXHJcbiAgICAgIFtjb2xvckRvbWFpbl09J2NvbG9yRG9tYWluJ1xyXG4gICAgICBbdGlja1ZhbHVlc109J3RpY2tWYWx1ZXMnXHJcbiAgICAgIFt4QXhpc1RpY2tGb3JtYXR0aW5nXT0neEF4aXNUaWNrRm9ybWF0dGluZydcclxuICAgICAgW3hTY2FsZU1pbl09J3hTY2FsZU1pbidcclxuICAgICAgW3hTY2FsZU1heF09J3hTY2FsZU1heCdcclxuICAgICAgPlxyXG4gICAgPC9saWItc2luZ2xlLWxpbmUtY2hhcnQ+XHJcbiAgIDwvZGl2PlxyXG5cclxuICAgPGRpdiBjbGFzcz1cInJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVyXCI+XHJcbiAgICAgPGg0PllvdXIgVGhyZWUgRGF5IFRyZW5kPC9oND5cclxuICAgICAgIDxkaXZcclxuICAgICAgICpuZ0Zvcj1cImxldCBvbmVEYXlEYXRhIG9mIHRocmVlRGF5VHJlbmREYXRhOyBsZXQgaSA9IGluZGV4O1wiXHJcbiAgICAgICBbc3R5bGUuYmFja2dyb3VuZF09XCJvbmVEYXlEYXRhLmNvbG9yXCJcclxuICAgICAgIGNsYXNzPVwidGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtXCJcclxuICAgICAgID5cclxuICAgICAgICAgPGxhYmVsIGNsYXNzPVwiZGV0YWlsLWl0ZW0tZGF0ZVwiPnt7b25lRGF5RGF0YS5kYXkgfCBkYXRlIDogJ2xvbmdEYXRlJ319PC9sYWJlbD5cclxuICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICpuZ0Zvcj1cImxldCBpdGVtIG9mIG9uZURheURhdGEuZGV0YWlscztcIlxyXG4gICAgICAgICAgID5cclxuICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICBbc3R5bGUuY29sb3JdPVwiZ2V0VmFsdWVTdHkoaXRlbS52YWx1ZSlcIlxyXG4gICAgICAgICAgICAgPnt7aXRlbS52YWx1ZX19PC9wPlxyXG4gICAgICAgICAgICAgPGxhYmVsPnt7aXRlbS50aXRsZX19PC9sYWJlbD5cclxuICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICA8L3VsPlxyXG4gICAgICAgPC9kaXY+XHJcbiAgICAgPC9kaXY+XHJcblxyXG4gIDwvZGl2PjwhLS0gbWFpbi0tPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2AucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lcntmb250LWZhbWlseTpESU5OZXh0TFRQcm8tTWVkaXVtO2NvbG9yOiM0NjQ2NDZ9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLmZ1bmQtc3VtbWFyeS10aXRsZXtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MDtsZWZ0OjE1cHg7Zm9udC1zaXplOjE2cHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC50b3Atc2VhcmNoe3Bvc2l0aW9uOmFic29sdXRlO3RvcDo2MHB4O2xlZnQ6MjBweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnRvcC1zZWFyY2ggaW5wdXR7d2lkdGg6MTYwcHg7cGFkZGluZzo4cHggMjBweDtkaXNwbGF5OmlubGluZS1ibG9ja30ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnRvcC1zZWFyY2ggbWF0LWljb257cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDoyMDBweDtiYWNrZ3JvdW5kLWNvbG9yOiM4NmJiZDE7cGFkZGluZzo1cHggNXB4IDZweCA4cHg7Y3Vyc29yOnBvaW50ZXJ9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5sZWZ0LXNpZGUtcGFuZWwtd3JhcHBlcntkaXNwbGF5OmlubGluZS1ibG9jazttYXJnaW4tbGVmdDoyMHB4O3BhZGRpbmctdG9wOjQwcHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5sZWZ0LXNpZGUtcGFuZWwtd3JhcHBlciAubGVmdC1zaWRlLXBhbmVsIHB7Zm9udC1zaXplOjQwcHg7bWFyZ2luOjEwcHggMDtwYWRkaW5nOjB9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5sZWZ0LXNpZGUtcGFuZWwtd3JhcHBlciAubGVmdC1zaWRlLXBhbmVsIGxhYmVse2ZvbnQtc2l6ZToxNHB4O21hcmdpbjowO3BhZGRpbmc6MH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0e2Rpc3BsYXk6aW5saW5lLWJsb2NrO2hlaWdodDoyNTBweDttYXJnaW46MCAyMHB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlcntwb3NpdGlvbjpyZWxhdGl2ZX0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgZGl2e3Bvc2l0aW9uOmFic29sdXRlfS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciBwe21hcmdpbjowfS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciBsYWJlbHtkaXNwbGF5OmJsb2NrO2ZvbnQtc2l6ZToxMnB4O3RleHQtYWxpZ246cmlnaHR9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5zaW5nbGUtbGluZS1jaGFydCAuZmxvYXRpbmctcmVjdC13cmFwcGVyIC50b3AtbGVmdC1pbmZve3RvcDotNjVweDtyaWdodDoyNTBweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgLnRvcC1sZWZ0LWluZm8gLnRvcC1sZWZ0LWluZm8tdnt0ZXh0LWFsaWduOnJpZ2h0O2ZvbnQtc2l6ZToyNXB4O21hcmdpbi1ib3R0b206NnB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciAudG9wLXJpZ2h0dC1pbmZve3RvcDotNzBweDtyaWdodDoxMHB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciAudG9wLXJpZ2h0dC1pbmZvIC50b3AtcmlnaHR0LWluZm8tdntkaXNwbGF5OmlubGluZS1ibG9jaztiYWNrZ3JvdW5kLWNvbG9yOiMyODc0M2U7Y29sb3I6I2ZhZWJkNztwYWRkaW5nOjVweCAxNnB4O2ZvbnQtc2l6ZToxOHB4O21hcmdpbi10b3A6NnB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciAubWlkZGxlLWluZm97dG9wOjI1cHg7cmlnaHQ6MTBweDtiYWNrZ3JvdW5kLWNvbG9yOiMyODc0M2U7Y29sb3I6I2ZhZWJkNztmb250LXNpemU6MTZweDtwYWRkaW5nOjJweCAxNXB4IDJweCA1cHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5zaW5nbGUtbGluZS1jaGFydCAuZmxvYXRpbmctcmVjdC13cmFwcGVyIC5ib3R0b20taW5mb3t0b3A6ODBweDtyaWdodDoxMHB4O2JhY2tncm91bmQtY29sb3I6IzcyNzI3Mjtjb2xvcjojZmFlYmQ3O2ZvbnQtc2l6ZToxNnB4O3BhZGRpbmc6MnB4IDE1cHggMnB4IDVweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVye2Rpc3BsYXk6aW5saW5lLWJsb2NrfS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAucmlnaHQtc2lkZS1ncmlkLXdyYXBwZXIgLnRocmVlLWRheS1kYXRhLWRldGFpbHMtaXRlbXtwYWRkaW5nOjEwcHggMH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVyIC50aHJlZS1kYXktZGF0YS1kZXRhaWxzLWl0ZW0gLmRldGFpbC1pdGVtLWRhdGV7bWFyZ2luLWxlZnQ6MTBweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVyIC50aHJlZS1kYXktZGF0YS1kZXRhaWxzLWl0ZW0gbGFiZWx7Zm9udC1zaXplOjEycHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlciAudGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtIHVse2xpc3Qtc3R5bGUtdHlwZTpub25lO21hcmdpbjowO3BhZGRpbmc6MH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVyIC50aHJlZS1kYXktZGF0YS1kZXRhaWxzLWl0ZW0gdWwgbGl7ZGlzcGxheTppbmxpbmUtYmxvY2s7bWFyZ2luOjEwcHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlciAudGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtIHVsIGxpIHB7bWFyZ2luOjB9YF1cclxufSlcclxuZXhwb3J0IGNsYXNzIFBvc2l0aW9uRnVuZFN1bW1hcnlDb21wb25lbnQgZXh0ZW5kcyBCYXNlV2lkZ2V0Q29tcG9uZW50IHtcclxuXHJcbiAgZGF0ZU5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgLy8gdGVtcCBtb2NrIGRhdGFcclxuICBzdW1tYXJ5QXNzZXRzVmFsdWUgPSBbXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiAnVG90YWwgTmV0IEFzc2V0czogVVNEJyxcclxuICAgICAgdmFsdWU6IDUwMDAwMDBcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiAnTWFya2V0IFZhbHVlOiBVU0QnLFxyXG4gICAgICB2YWx1ZTogNDQwMDAwMFxyXG4gICAgfVxyXG4gIF07XHJcbiAgdGhyZWVEYXlUcmVuZERhdGE6IGFueVtdID0gW1xyXG4gICAge1xyXG4gICAgICBkYXk6IG5ldyBEYXRlKCksXHJcbiAgICAgIGRldGFpbHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ05BViBQcmljZScsXHJcbiAgICAgICAgICB2YWx1ZTogOS45MVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdNYXJrZXQgVmFsdWUnLFxyXG4gICAgICAgICAgdmFsdWU6ICc0LjNNJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgQ2hhbmdlJyxcclxuICAgICAgICAgIHZhbHVlOiAnLTIuMDUlJ1xyXG4gICAgICAgIH1cclxuICAgICAgXSxcclxuICAgICAgY29sb3I6ICcnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBkYXk6IG5ldyBEYXRlKCksXHJcbiAgICAgIGRldGFpbHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ05BViBQcmljZScsXHJcbiAgICAgICAgICB2YWx1ZTogMTAuMTFcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHRpdGxlOiAnTWFya2V0IFZhbHVlJyxcclxuICAgICAgICAgIHZhbHVlOiAnNC4yNU0nXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ05BViBDaGFuZ2UnLFxyXG4gICAgICAgICAgdmFsdWU6ICctMS4xOSUnXHJcbiAgICAgICAgfVxyXG4gICAgICBdLFxyXG4gICAgICBjb2xvcjogJyNERkVBRTInXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBkYXk6IG5ldyBEYXRlKCksXHJcbiAgICAgIGRldGFpbHM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ05BViBQcmljZScsXHJcbiAgICAgICAgICB2YWx1ZTogMTAuMjNcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHRpdGxlOiAnTWFya2V0IFZhbHVlJyxcclxuICAgICAgICAgIHZhbHVlOiAnNC4wNU0nXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ05BViBDaGFuZ2UnLFxyXG4gICAgICAgICAgdmFsdWU6ICcxLjgxJSdcclxuICAgICAgICB9XHJcbiAgICAgIF0sXHJcbiAgICAgIGNvbG9yOiAnI0JFRDVDNSdcclxuICAgIH1cclxuICBdO1xyXG4gIHJlc3VsdHM6IGFueVtdID0gW107XHJcbiAgaGVpZ2h0OiBudW1iZXIgPSAyNDA7XHJcbiAgd2lkdGg6IG51bWJlcjtcclxuICBtYXJnaW46IGFueVtdID0gWzIwLCAxMDAsIDMwLCA1MF07XHJcbiAgY29sb3JEb21haW46IGFueVtdID0gW107XHJcbiAgdGlja1ZhbHVlczogYW55W10gPSBzaW5nbGVMaW5lVGlja3NWYWx1ZTtcclxuICB4U2NhbGVNaW46IGFueTtcclxuICB4U2NhbGVNYXg6IGFueTtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBjaGFydEVsZW1lbnQ6IEVsZW1lbnRSZWYsIHpvbmU6IE5nWm9uZSwgXHJcbiAgICBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICAgcHVibGljIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICAgcHJpdmF0ZSBuYXZTZXJ2aWNlOiBOYXZTZXJ2aWNlLFxyXG4gICAgIHByaXZhdGUgc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzIDogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsKSB7IFxyXG4gICAgc3VwZXIoKTtcclxuICAgIHRoaXMud2lkdGggPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdtYWluJylbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggKiAwLjU1O1xyXG4gICAgdGhpcy54U2NhbGVNaW4gPSBjb21tb25VdGlscy5zdGFydFRpbWU7XHJcbiAgICB0aGlzLnhTY2FsZU1heCA9IGNvbW1vblV0aWxzLmVuZFRpbWU7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIHRoaXMubmF2U2VydmljZS5nZXRGdW5kTGlzdCgpLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgaWYgKGRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHRoaXMucmVzdWx0cyA9IFsuLi50aGlzLmZpbHRlckZ1bmREYXRhKGRhdGEpXVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLmNvbG9yRG9tYWluID0gdGhpcy5zZXRDb2xvckZvclNlbGVjdGVkRnVuZCgpO1xyXG4gIH1cclxuXHJcbiAgc2V0Q29sb3JGb3JTZWxlY3RlZEZ1bmQoKSB7XHJcbiAgICAvLyBuZWVkIGVuaGFuY2VtZW4gaGVyZTogaWYgdGhlIGxpbmUgY29sb3Igc2hvdWxkIGJlIGFzIHNhbWUgYXMgcHJldmlvdXMgbGl2ZS1saW5lLWNoYXJ0PyBUZW1wb3JhcmlseSBzZXQgdGhlIGNvbG9yICMyODc0M0UuXHJcbiAgICBjb25zdCBjb2xvciA9IFtdO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRGdW5kVGlja2VyID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZnVuZEluZm9bMl07XHJcbiAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgIGZ1bmRUaWNrZXI6IHNlbGVjdGVkRnVuZFRpY2tlcixcclxuICAgICAgY29sb3I6IFwiIzI4NzQzRVwiXHJcbiAgICB9XHJcbiAgICBjb2xvci5wdXNoKG9iaik7XHJcbiAgICByZXR1cm4gY29sb3I7XHJcbiAgfVxyXG5cclxuLy8gYmVsb3cgZnVuY3Rpb24gaXMgZHVwbGljYXRlZCB3aXRoIHFuYXYtbGluZS1jaGFydCBuZWVkcyBleHRyYWN0IHRvIGEgY29tbW9uIGNsYXNzLlxyXG4gIGZpbHRlckZ1bmREYXRhKGRhdGE6IGFueVtdKTogYW55W10ge1xyXG4gICAgY29uc3QgcmVzdWx0czogYW55W10gPSBbXTtcclxuICAgIGNvbnN0IHNlbGVjdGVkRnVuZFRpY2tlciA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmZ1bmRJbmZvWzJdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbVsnZnVuZFRpY2tlciddID09PSBzZWxlY3RlZEZ1bmRUaWNrZXIpIHtcclxuICAgICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgICAnbmFtZSc6IGl0ZW1bJ2Z1bmRUaWNrZXInXSxcclxuICAgICAgICAgICdmdW5kSUQnOiBpdGVtWydmdW5kaWQnXSxcclxuICAgICAgICAgICdzZXJpZXMnOiB0aGlzLmNyZWF0ZVNlcmllcyhpdGVtKVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXN1bHRzLnB1c2gob2JqKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiByZXN1bHRzO1xyXG4gIH1cclxuXHJcbiAgY3JlYXRlU2VyaWVzKGRhdGE6IGFueSk6IGFueVtdIHtcclxuICAgIGNvbnN0IHNlcmllczogYW55W10gPSBbXTtcclxuICAgIGRhdGFbJ3ByaWNlQ2hhbmdlcyddLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSkpIHtcclxuICAgICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgICAnbWFya2V0dmFsJzogaXRlbVsnZnVuZG12J10sXHJcbiAgICAgICAgICAnbmFtZSc6IG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSxcclxuICAgICAgICAgICduYXYnOiBpdGVtWyduYXYnXSxcclxuICAgICAgICAgICd2YWx1ZSc6IGl0ZW1bJ25hdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgICdwcmljZXRpbWUnOiBpdGVtWydwcmljZXRpbWUnXVxyXG4gICAgICAgIH1cclxuICAgICAgICBzZXJpZXMucHVzaChvYmopO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICApXHJcbiAgICBpZiAoc2VyaWVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICAnbWFya2V0dmFsJzogZGF0YVsnZnVuZG12J10sIFxyXG4gICAgICAgICduYW1lJzogdGhpcy54U2NhbGVNaW4sXHJcbiAgICAgICAgJ25hdic6IGRhdGFbJ25hdiddLFxyXG4gICAgICAgICd2YWx1ZSc6IDAsXHJcbiAgICAgICAgJ3ByaWNldGltZSc6IHRoaXMuY29tbW9uVXRpbHMuc3RhcnRUaW1lXHJcbiAgICAgIH1cclxuICAgICAgc2VyaWVzLnB1c2gob2JqKTtcclxuICAgIH1cclxuICAgIHJldHVybiBzZXJpZXM7XHJcbiAgfVxyXG5cclxuICAgeEF4aXNUaWNrRm9ybWF0dGluZyh2KSB7XHJcbiAgIGNvbnN0IHRlbXBEYXRlID0gbmV3IERhdGUodik7XHJcbiAgIHJldHVybiBmb3JtYXREYXRlKHRlbXBEYXRlLFwiaDptbSBhYWFhYSdtJ1wiLCdlbi1VUycpO1xyXG4gfVxyXG5cclxuIGdldFZhbHVlU3R5KHZhbHVlKTogc3RyaW5nIHtcclxuICAgbGV0IGNvbG9yID0gJyc7XHJcbiAgIGlmICh2YWx1ZS50b1N0cmluZygpLmluZGV4T2YoJyUnKSAhPT0gLTEpIHtcclxuICAgICBpZiAodmFsdWUudG9TdHJpbmcoKS5pbmRleE9mKCctJykpIHtcclxuICAgICAgIGNvbG9yID0gJyMyODc0M0UnXHJcbiAgICAgfSBlbHNlIHtcclxuICAgICAgIGNvbG9yPScjQjkxMjI0J1xyXG4gICAgIH1cclxuICAgfVxyXG4gICByZXR1cm4gY29sb3I7XHJcbiB9XHJcblxyXG4gbmdPbkRlc3Ryb3koKSB7XHJcbiAgICB0aGlzLmNvbG9yRG9tYWluID0gW107XHJcbiAgfVxyXG5cclxuICByZXNpemluZ1NpbmdsZUxpbmVDaGFydChldmVudCkge1xyXG4gICAgdGhpcy53aWR0aCA9IGV2ZW50LnRhcmdldC5pbm5lcldpZHRoICogMC41NTtcclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgdHJpZ2dlcixcclxuICBzdHlsZSxcclxuICBhbmltYXRlLFxyXG4gIHRyYW5zaXRpb25cclxufSBmcm9tICdAYW5ndWxhci9hbmltYXRpb25zJztcclxuaW1wb3J0IHsgRGF0ZVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBzY2FsZUxpbmVhciwgc2NhbGVUaW1lLCBzY2FsZVBvaW50IH0gZnJvbSAnZDMtc2NhbGUnO1xyXG5pbXBvcnQgeyBjdXJ2ZUxpbmVhciB9IGZyb20gJ2QzLXNoYXBlJztcclxuXHJcbmltcG9ydCB7IGlkIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMvcmVsZWFzZS91dGlscyc7XHJcbmltcG9ydCB7IGdldFVuaXF1ZVhEb21haW5WYWx1ZXMgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cy9yZWxlYXNlL2NvbW1vbi9kb21haW4uaGVscGVyJztcclxuXHJcbmltcG9ydCB7IGNhbGN1bGF0ZVZpZXdEaW1lbnNpb25zLCBWaWV3RGltZW5zaW9ucywgQmFzZUNoYXJ0Q29tcG9uZW50LCBDb2xvckhlbHBlciB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItc2luZ2xlLWxpbmUtY2hhcnQnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cImN1c3RvbS1jaGFydFwiPlxyXG4gIDxuZ3gtY2hhcnRzLWNoYXJ0IFxyXG4gICAgICBbdmlld109XCJbd2lkdGgsIGhlaWdodF1cIlxyXG4gICAgICBbc2hvd0xlZ2VuZF09XCJmYWxzZVwiXHJcbiAgICAgIFtsZWdlbmRPcHRpb25zXT1cImxlZ2VuZE9wdGlvbnNcIlxyXG4gICAgICBbYWN0aXZlRW50cmllc109XCJhY3RpdmVFbnRyaWVzXCJcclxuICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiXHJcbiAgICAgIChsZWdlbmRMYWJlbENsaWNrKT1cIm9uQ2xpY2soJGV2ZW50KVwiXHJcbiAgICAgIChsZWdlbmRMYWJlbEFjdGl2YXRlKT1cIm9uQWN0aXZhdGUoJGV2ZW50KVwiXHJcbiAgICAgIChsZWdlbmRMYWJlbERlYWN0aXZhdGUpPVwib25EZWFjdGl2YXRlKCRldmVudClcIj5cclxuICAgICAgPHN2ZzpkZWZzPlxyXG4gICAgICAgIDxzdmc6Y2xpcFBhdGggW2F0dHIuaWRdPVwiY2xpcFBhdGhJZFwiPlxyXG4gICAgICAgICAgPHN2ZzpyZWN0XHJcbiAgICAgICAgICAgIFthdHRyLndpZHRoXT1cImRpbXMud2lkdGggKyAxMFwiXHJcbiAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCJkaW1zLmhlaWdodCArIDEwXCJcclxuICAgICAgICAgICAgW2F0dHIudHJhbnNmb3JtXT1cIid0cmFuc2xhdGUoLTUsIC01KSdcIi8+XHJcbiAgICAgICAgPC9zdmc6Y2xpcFBhdGg+XHJcbiAgICAgIDwvc3ZnOmRlZnM+XHJcbiAgICAgIDxzdmc6ZyBbYXR0ci50cmFuc2Zvcm1dPVwidHJhbnNmb3JtXCIgY2xhc3M9XCJsaW5lLWNoYXJ0IGNoYXJ0XCI+XHJcbiAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMteC1heGlzIFxyXG4gICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgW2RpbXNdPVwiZGltc1wiXHJcbiAgICAgICAgICBbc2hvd0xhYmVsXT1cInNob3dYQXhpc0xhYmVsXCJcclxuICAgICAgICAgIFtzaG93R3JpZExpbmVzXT1cInNob3dHcmlkTGluZXNcIlxyXG4gICAgICAgICAgW2xhYmVsVGV4dF09XCJ4QXhpc0xhYmVsXCJcclxuICAgICAgICAgIFt0aWNrc109XCJ0aWNrVmFsdWVzXCJcclxuICAgICAgICAgIFt0aWNrRm9ybWF0dGluZ109XCJ4QXhpc1RpY2tGb3JtYXR0aW5nXCJcclxuICAgICAgICAgIChkaW1lbnNpb25zQ2hhbmdlZCk9XCJ1cGRhdGVYQXhpc0hlaWdodCgkZXZlbnQpXCI+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy15LWF4aXNcclxuICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgIFtkaW1zXT1cImRpbXNcIlxyXG4gICAgICAgICAgW3Nob3dMYWJlbF09XCJzaG93WUF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbbGFiZWxUZXh0XT1cInlBeGlzTGFiZWxcIlxyXG4gICAgICAgICAgW3JlZmVyZW5jZUxpbmVzXT1cInJlZmVyZW5jZUxpbmVzXCJcclxuICAgICAgICAgIFtzaG93UmVmTGluZXNdPVwic2hvd1JlZkxpbmVzXCJcclxuICAgICAgICAgIFtzaG93R3JpZExpbmVzXT1cInNob3dHcmlkTGluZXNcIlxyXG4gICAgICAgICAgW3Nob3dSZWZMYWJlbHNdPVwic2hvd1JlZkxhYmVsc1wiXHJcbiAgICAgICAgICAoZGltZW5zaW9uc0NoYW5nZWQpPVwidXBkYXRlWUF4aXNXaWR0aCgkZXZlbnQpXCI+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuXHJcbiAgICAgICAgPHN2ZzpnIFthdHRyLmNsaXAtcGF0aF09XCJjbGlwUGF0aFwiPlxyXG4gICAgICAgICAgPHN2ZzpnICpuZ0Zvcj1cImxldCBzZXJpZXMgb2YgcmVzdWx0czsgdHJhY2tCeTp0cmFja0J5XCIgW0BhbmltYXRpb25TdGF0ZV09XCInYWN0aXZlJ1wiPlxyXG4gICAgICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy1saW5lLXNlcmllc1xyXG4gICAgICAgICAgICAgIFt4U2NhbGVdPVwieFNjYWxlXCJcclxuICAgICAgICAgICAgICBbeVNjYWxlXT1cInlTY2FsZVwiXHJcbiAgICAgICAgICAgICAgW2NvbG9yc109XCJjb2xvcnNcIlxyXG4gICAgICAgICAgICAgIFtkYXRhXT1cInNlcmllc1wiXHJcbiAgICAgICAgICAgICAgW2FjdGl2ZUVudHJpZXNdPVwiYWN0aXZlRW50cmllc1wiXHJcbiAgICAgICAgICAgICAgW3NjYWxlVHlwZV09XCJzY2FsZVR5cGVcIlxyXG4gICAgICAgICAgICAgIFtjdXJ2ZV09XCJjdXJ2ZVwiXHJcbiAgICAgICAgICAgICAgW3JhbmdlRmlsbE9wYWNpdHldPVwicmFuZ2VGaWxsT3BhY2l0eVwiXHJcbiAgICAgICAgICAgICAgW2hhc1JhbmdlXT1cImhhc1JhbmdlXCJcclxuICAgICAgICAgICAgICBbYW5pbWF0aW9uc109XCJhbmltYXRpb25zXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgICA8c3ZnOmcgKm5nSWY9XCIhdG9vbHRpcERpc2FibGVkXCIgKG1vdXNlbGVhdmUpPVwiaGlkZUNpcmNsZXMoKVwiPlxyXG4gICAgICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy10b29sdGlwLWFyZWFcclxuICAgICAgICAgICAgICBbZGltc109XCJkaW1zXCJcclxuICAgICAgICAgICAgICBbeFNldF09XCJ4U2V0XCJcclxuICAgICAgICAgICAgICBbeFNjYWxlXT1cInhTY2FsZVwiXHJcbiAgICAgICAgICAgICAgW3lTY2FsZV09XCJ5U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFtyZXN1bHRzXT1cInJlc3VsdHNcIlxyXG4gICAgICAgICAgICAgIFtjb2xvcnNdPVwiY29sb3JzXCJcclxuICAgICAgICAgICAgICBbdG9vbHRpcERpc2FibGVkXT1cIiF0b29sdGlwRGlzYWJsZWRcIlxyXG4gICAgICAgICAgICAgIChob3Zlcik9XCJ1cGRhdGVIb3ZlcmVkVmVydGljYWwoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8c3ZnOmcgKm5nRm9yPVwibGV0IHNlcmllcyBvZiByZXN1bHRzXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtY2lyY2xlLXNlcmllc1xyXG4gICAgICAgICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgICAgICAgW3lTY2FsZV09XCJ5U2NhbGVcIlxyXG4gICAgICAgICAgICAgICAgW2NvbG9yc109XCJjb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgW2RhdGFdPVwic2VyaWVzXCJcclxuICAgICAgICAgICAgICAgIFtzY2FsZVR5cGVdPVwic2NhbGVUeXBlXCJcclxuICAgICAgICAgICAgICAgIFt2aXNpYmxlVmFsdWVdPVwiaG92ZXJlZFZlcnRpY2FsXCJcclxuICAgICAgICAgICAgICAgIFthY3RpdmVFbnRyaWVzXT1cImFjdGl2ZUVudHJpZXNcIlxyXG4gICAgICAgICAgICAgICAgKHNlbGVjdCk9XCJvbkNsaWNrKCRldmVudCwgc2VyaWVzKVwiXHJcbiAgICAgICAgICAgICAgICAoYWN0aXZhdGUpPVwib25BY3RpdmF0ZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChkZWFjdGl2YXRlKT1cIm9uRGVhY3RpdmF0ZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIFt0b29sdGlwVGVtcGxhdGVdPVwidG9vbHRpcFRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgIFxyXG4gICAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICA8L3N2ZzpnPlxyXG4gIDwvbmd4LWNoYXJ0cy1jaGFydD5cclxuICA8bmctdGVtcGxhdGUgI3Rvb2x0aXBUZW1wbGF0ZT5cclxuICAgIDxkaXYgY2xhc3M9XCJzaW5nbGUtdG9vbHRpcFwiPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9uZy10ZW1wbGF0ZT5cclxuPC9kaXY+YCxcclxuICBzdHlsZXM6IFtgYF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uU2hhZG93RG9tLFxyXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxyXG4gIGFuaW1hdGlvbnM6IFtcclxuICAgIHRyaWdnZXIoJ2FuaW1hdGlvblN0YXRlJywgW1xyXG4gICAgICB0cmFuc2l0aW9uKCc6bGVhdmUnLCBbXHJcbiAgICAgICAgc3R5bGUoe1xyXG4gICAgICAgICAgb3BhY2l0eTogMSxcclxuICAgICAgICB9KSxcclxuICAgICAgICBhbmltYXRlKDUwMCwgc3R5bGUoe1xyXG4gICAgICAgICAgb3BhY2l0eTogMFxyXG4gICAgICAgIH0pKVxyXG4gICAgICBdKVxyXG4gICAgXSlcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTaW5nbGVMaW5lQ2hhcnRDb21wb25lbnQgZXh0ZW5kcyBCYXNlQ2hhcnRDb21wb25lbnQge1xyXG4gIEBJbnB1dCgpIGxlZ2VuZDtcclxuICBASW5wdXQoKSBsZWdlbmRUaXRsZTogc3RyaW5nID0gJ0xlZ2VuZCc7XHJcbiAgQElucHV0KCkgc2hvd1hBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgc2hvd1lBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgeEF4aXNMYWJlbDtcclxuICBASW5wdXQoKSB5QXhpc0xhYmVsO1xyXG4gIEBJbnB1dCgpIGF1dG9TY2FsZTtcclxuICBASW5wdXQoKSB0aW1lbGluZTtcclxuICBASW5wdXQoKSBncmFkaWVudDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBzaG93R3JpZExpbmVzOiBib29sZWFuID0gdHJ1ZTtcclxuICBASW5wdXQoKSBjdXJ2ZTogYW55ID0gY3VydmVMaW5lYXI7XHJcbiAgQElucHV0KCkgc2NoZW1lVHlwZTogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIHJhbmdlRmlsbE9wYWNpdHk6IG51bWJlcjtcclxuICBASW5wdXQoKSB4QXhpc1RpY2tGb3JtYXR0aW5nOiBhbnk7XHJcbiAgQElucHV0KCkgeUF4aXNUaWNrRm9ybWF0dGluZzogYW55O1xyXG4gIEBJbnB1dCgpIHhBeGlzVGlja3M6IGFueVtdO1xyXG4gIEBJbnB1dCgpIHlBeGlzVGlja3M6IGFueVtdO1xyXG4gIEBJbnB1dCgpIHJvdW5kRG9tYWluczogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHRvb2x0aXBEaXNhYmxlZDogYm9vbGVhbiA9IHRydWU7IC8vIGlmIG5lZWQgdG9vbHRpcCB0aGVuIHNldCB0b29sdGlwT2JqXHJcbiAgQElucHV0KCkgc2hvd1JlZkxpbmVzOiBib29sZWFuID0gZmFsc2U7IFxyXG4gIEBJbnB1dCgpIHJlZmVyZW5jZUxpbmVzOiBhbnk7XHJcbiAgQElucHV0KCkgc2hvd1JlZkxhYmVsczogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHhTY2FsZU1pbjogYW55O1xyXG4gIEBJbnB1dCgpIHhTY2FsZU1heDogYW55O1xyXG4gIEBJbnB1dCgpIHlTY2FsZU1pbjogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHlTY2FsZU1heDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHNlbGVjdGFibGU7XHJcbiAgQElucHV0KCkgaGVpZ2h0OiBudW1iZXI7XHJcbiAgQElucHV0KCkgd2lkdGg6IG51bWJlcjtcclxuICBASW5wdXQoKSBtYXJnaW46IG51bWJlcjtcclxuICBASW5wdXQoKSBjb2xvckRvbWFpbjogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSByZXN1bHRzOiBhbnlbXTtcclxuICBASW5wdXQoKSB0aWNrVmFsdWVzOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIGFjdGl2ZUVudHJpZXM6IGFueVtdID0gW107XHJcblxyXG4gIEBPdXRwdXQoKSBhY3RpdmF0ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgQE91dHB1dCgpIGRlYWN0aXZhdGU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICBAQ29udGVudENoaWxkKCd0b29sdGlwVGVtcGxhdGUnKSB0b29sdGlwVGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XHJcblxyXG4gIGRpbXM6IFZpZXdEaW1lbnNpb25zO1xyXG4gIHhTZXQ6IGFueTtcclxuICB4RG9tYWluOiBhbnk7XHJcbiAgeURvbWFpbjogYW55O1xyXG4gIHNlcmllc0RvbWFpbjogYW55O1xyXG4gIHlTY2FsZTogYW55O1xyXG4gIHhTY2FsZTogYW55O1xyXG4gIGNvbG9yczogQ29sb3JIZWxwZXI7XHJcbiAgc2NhbGVUeXBlOiBzdHJpbmc7XHJcbiAgdHJhbnNmb3JtOiBzdHJpbmc7XHJcbiAgY2xpcFBhdGg6IHN0cmluZztcclxuICBjbGlwUGF0aElkOiBzdHJpbmc7XHJcbiAgc2VyaWVzOiBhbnk7XHJcbiAgYXJlYVBhdGg6IGFueTtcclxuICBob3ZlcmVkVmVydGljYWw6IGFueTsgLy8gdGhlIHZhbHVlIG9mIHRoZSB4IGF4aXMgdGhhdCBpcyBob3ZlcmVkIG92ZXJcclxuICB4QXhpc0hlaWdodDogbnVtYmVyID0gMDtcclxuICB5QXhpc1dpZHRoOiBudW1iZXIgPSAwO1xyXG4gIGZpbHRlcmVkRG9tYWluOiBhbnk7XHJcbiAgbGVnZW5kT3B0aW9uczogYW55O1xyXG4gIGhhc1JhbmdlOiBib29sZWFuOyAvLyB3aGV0aGVyIHRoZSBsaW5lIGhhcyBhIG1pbi1tYXggcmFuZ2UgYXJvdW5kIGl0XHJcbiAgdGltZWxpbmVXaWR0aDogYW55O1xyXG4gIHRpbWVsaW5lSGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICB0aW1lbGluZVhTY2FsZTogYW55O1xyXG4gIHRpbWVsaW5lWVNjYWxlOiBhbnk7XHJcbiAgdGltZWxpbmVYRG9tYWluOiBhbnk7XHJcbiAgdGltZWxpbmVUcmFuc2Zvcm06IGFueTtcclxuICB0aW1lbGluZVBhZGRpbmc6IG51bWJlciA9IDEwO1xyXG4gIGN1c3RvbUNvbG9yczogYW55W107XHJcbiAgdG9vbHRpcE9iajogYW55ID0ge307XHJcblxyXG4gIGNvbnN0cnVjdG9yKGNoYXJ0RWxlbWVudDogRWxlbWVudFJlZiwgXHJcbiAgICAgICAgICAgICAgICAgICAgICB6b25lOiBOZ1pvbmUsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBkYXRlUGlwZTogRGF0ZVBpcGUpIHtcclxuICAgIHN1cGVyKGNoYXJ0RWxlbWVudCwgem9uZSwgY2QpO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlKCk6IHZvaWQge1xyXG5cclxuICAgIHRoaXMuZGltcyA9IGNhbGN1bGF0ZVZpZXdEaW1lbnNpb25zKHtcclxuICAgICAgd2lkdGg6IHRoaXMud2lkdGgsXHJcbiAgICAgIGhlaWdodDogdGhpcy5oZWlnaHQsXHJcbiAgICAgIG1hcmdpbnM6IHRoaXMubWFyZ2luLFxyXG4gICAgICB4QXhpc0hlaWdodDogdGhpcy54QXhpc0hlaWdodCxcclxuICAgICAgeUF4aXNXaWR0aDogdGhpcy55QXhpc1dpZHRoLFxyXG4gICAgICBzaG93WExhYmVsOiB0aGlzLnNob3dYQXhpc0xhYmVsLFxyXG4gICAgICBzaG93WUxhYmVsOiB0aGlzLnNob3dZQXhpc0xhYmVsLFxyXG4gICAgICBzaG93TGVnZW5kOiB0aGlzLmxlZ2VuZCxcclxuICAgICAgbGVnZW5kVHlwZTogdGhpcy5zY2hlbWVUeXBlLFxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKHRoaXMudGltZWxpbmUpIHtcclxuICAgICAgdGhpcy5kaW1zLmhlaWdodCAtPSAodGhpcy50aW1lbGluZUhlaWdodCArIHRoaXMubWFyZ2luWzJdICsgdGhpcy50aW1lbGluZVBhZGRpbmcpO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMueERvbWFpbiA9IHRoaXMuZ2V0WERvbWFpbigpO1xyXG4gICAgaWYgKHRoaXMuZmlsdGVyZWREb21haW4pIHtcclxuICAgICAgdGhpcy54RG9tYWluID0gdGhpcy5maWx0ZXJlZERvbWFpbjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnlEb21haW4gPSB0aGlzLmdldFlEb21haW4oKTtcclxuICAgIHRoaXMuc2VyaWVzRG9tYWluID0gdGhpcy5nZXRTZXJpZXNEb21haW4oKTtcclxuXHJcbiAgICB0aGlzLnhTY2FsZSA9IHRoaXMuZ2V0WFNjYWxlKHRoaXMueERvbWFpbiwgdGhpcy5kaW1zLndpZHRoKTtcclxuXHJcbiAgICB0aGlzLnlTY2FsZSA9IHRoaXMuZ2V0WVNjYWxlKHRoaXMueURvbWFpbiwgdGhpcy5kaW1zLmhlaWdodCk7XHJcblxyXG4gICAgdGhpcy5jdXN0b21Db2xvcnMgPSB0aGlzLnNldEN1c3RvbWNvbG9ycygpO1xyXG4gICAgdGhpcy5zZXRDb2xvcnMoKTtcclxuICAgIHRoaXMubGVnZW5kT3B0aW9ucyA9IHRoaXMuZ2V0TGVnZW5kT3B0aW9ucygpO1xyXG5cclxuICAgIHRoaXMudHJhbnNmb3JtID0gYHRyYW5zbGF0ZSgke3RoaXMuZGltcy54T2Zmc2V0fSAsICR7dGhpcy5tYXJnaW5bMF19KWA7XHJcblxyXG4gICAgdGhpcy5jbGlwUGF0aElkID0gJ2NsaXAnICsgaWQoKS50b1N0cmluZygpO1xyXG4gICAgdGhpcy5jbGlwUGF0aCA9IGB1cmwoIyR7dGhpcy5jbGlwUGF0aElkfSlgO1xyXG5cclxuICB9XHJcblxyXG5cclxuICBzZXRDdXN0b21jb2xvcnMoKTogYW55W10ge1xyXG4gICAgbGV0IGFyciA9IFtdO1xyXG4gICAgdGhpcy5yZXN1bHRzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIHRoaXMuY29sb3JEb21haW4uZm9yRWFjaChjb2xvciA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW1bJ25hbWUnXSA9PT0gY29sb3JbJ2Z1bmRUaWNrZXInXSkge1xyXG4gICAgICAgICAgbGV0IG9iaiA9IHtcclxuICAgICAgICAgICAgbmFtZTogY29sb3IuZnVuZFRpY2tlcixcclxuICAgICAgICAgICAgdmFsdWU6IGNvbG9yLmNvbG9yXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBhcnIucHVzaChvYmopXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gYXJyO1xyXG4gIH1cclxuXHJcbiAgZ2V0WERvbWFpbigpOiBhbnlbXSB7XHJcbiAgICBsZXQgdmFsdWVzID0gZ2V0VW5pcXVlWERvbWFpblZhbHVlcyh0aGlzLnJlc3VsdHMpO1xyXG4gICAgdGhpcy5zY2FsZVR5cGUgPSB0aGlzLmdldFNjYWxlVHlwZSh2YWx1ZXMpO1xyXG4gICAgbGV0IGRvbWFpbiA9IFtdO1xyXG5cclxuICAgIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgdmFsdWVzID0gdmFsdWVzLm1hcCh2ID0+IE51bWJlcih2KSk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1pbjtcclxuICAgIGxldCBtYXg7XHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICd0aW1lJyB8fCB0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgbWluID0gdGhpcy54U2NhbGVNaW5cclxuICAgICAgICA/IHRoaXMueFNjYWxlTWluXHJcbiAgICAgICAgOiBNYXRoLm1pbiguLi52YWx1ZXMpO1xyXG5cclxuICAgICAgbWF4ID0gdGhpcy54U2NhbGVNYXhcclxuICAgICAgICA/IHRoaXMueFNjYWxlTWF4XHJcbiAgICAgICAgOiBNYXRoLm1heCguLi52YWx1ZXMpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ3RpbWUnKSB7XHJcbiAgICAgIGRvbWFpbiA9IFtuZXcgRGF0ZShtaW4pLCBuZXcgRGF0ZShtYXgpXTtcclxuICAgICAgdGhpcy54U2V0ID0gWy4uLnZhbHVlc10uc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFEYXRlID0gYS5nZXRUaW1lKCk7XHJcbiAgICAgICAgY29uc3QgYkRhdGUgPSBiLmdldFRpbWUoKTtcclxuICAgICAgICBpZiAoYURhdGUgPiBiRGF0ZSkgcmV0dXJuIDE7XHJcbiAgICAgICAgaWYgKGJEYXRlID4gYURhdGUpIHJldHVybiAtMTtcclxuICAgICAgICByZXR1cm4gMDtcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAnbGluZWFyJykge1xyXG4gICAgICBkb21haW4gPSBbbWluLCBtYXhdO1xyXG4gICAgICAvLyBVc2UgY29tcGFyZSBmdW5jdGlvbiB0byBzb3J0IG51bWJlcnMgbnVtZXJpY2FsbHlcclxuICAgICAgdGhpcy54U2V0ID0gWy4uLnZhbHVlc10uc29ydCgoYSwgYikgPT4gKGEgLSBiKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb21haW4gPSB2YWx1ZXM7XHJcbiAgICAgIHRoaXMueFNldCA9IHZhbHVlcztcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZG9tYWluO1xyXG4gIH1cclxuXHJcbiAgZ2V0WURvbWFpbigpOiBhbnlbXSB7XHJcbiAgICBjb25zdCBkb21haW4gPSBbXTtcclxuICAgIGZvciAoY29uc3QgcmVzdWx0cyBvZiB0aGlzLnJlc3VsdHMpIHtcclxuICAgICAgZm9yIChjb25zdCBkIG9mIHJlc3VsdHMuc2VyaWVzKSB7XHJcbiAgICAgICAgaWYgKGQudmFsdWUgJiYgZG9tYWluLmluZGV4T2YoZC52YWx1ZSkgPCAwKSB7XHJcbiAgICAgICAgICBkb21haW4ucHVzaChkLnZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGQubWluICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgIHRoaXMuaGFzUmFuZ2UgPSB0cnVlO1xyXG4gICAgICAgICAgaWYgKGRvbWFpbi5pbmRleE9mKGQubWluKSA8IDApIHtcclxuICAgICAgICAgICAgZG9tYWluLnB1c2goZC5taW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZC5tYXggIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgdGhpcy5oYXNSYW5nZSA9IHRydWU7XHJcbiAgICAgICAgICBpZiAoZG9tYWluLmluZGV4T2YoZC5tYXgpIDwgMCkge1xyXG4gICAgICAgICAgICBkb21haW4ucHVzaChkLm1heCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdmFsdWVzID0gWy4uLmRvbWFpbl07XHJcbiAgICBpZiAoIXRoaXMuYXV0b1NjYWxlKSB7XHJcbiAgICAgIHZhbHVlcy5wdXNoKDApO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG1pbiA9IHRoaXMueVNjYWxlTWluXHJcbiAgICAgID8gdGhpcy55U2NhbGVNaW5cclxuICAgICAgOiBNYXRoLm1pbiguLi52YWx1ZXMpO1xyXG5cclxuICAgIGNvbnN0IG1heCA9IHRoaXMueVNjYWxlTWF4XHJcbiAgICAgID8gdGhpcy55U2NhbGVNYXhcclxuICAgICAgOiBNYXRoLm1heCguLi52YWx1ZXMpO1xyXG5cclxuICAgICAgaWYgKG1pbiAmJiBtYXgpIHtcclxuICAgICAgICByZXR1cm4gW21pbiwgbWF4XTtcclxuICAgICAgfWVsc2Uge1xyXG4gICAgICAgIHJldHVybiBbLTAuMSwgMC4xXTtcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0U2VyaWVzRG9tYWluKCk6IGFueVtdIHtcclxuICAgIHJldHVybiB0aGlzLnJlc3VsdHMubWFwKGQgPT4gZC5uYW1lKTtcclxuICB9XHJcblxyXG4gIGdldFhTY2FsZShkb21haW4sIHdpZHRoKTogYW55IHtcclxuICAgIGxldCBzY2FsZTtcclxuXHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICd0aW1lJykge1xyXG4gICAgICBzY2FsZSA9IHNjYWxlVGltZSgpXHJcbiAgICAgICAgLnJhbmdlKFswLCB3aWR0aF0pXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZUxpbmVhcigpXHJcbiAgICAgICAgLnJhbmdlKFswLCB3aWR0aF0pXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG5cclxuICAgICAgaWYgKHRoaXMucm91bmREb21haW5zKSB7XHJcbiAgICAgICAgc2NhbGUgPSBzY2FsZS5uaWNlKCk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBzY2FsZSA9IHNjYWxlUG9pbnQoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5wYWRkaW5nKDAuMSlcclxuICAgICAgICAuZG9tYWluKGRvbWFpbik7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHNjYWxlO1xyXG4gIH1cclxuXHJcbiAgZ2V0WVNjYWxlKGRvbWFpbiwgaGVpZ2h0KTogYW55IHtcclxuICAgIGNvbnN0IHNjYWxlID0gc2NhbGVMaW5lYXIoKVxyXG4gICAgICAucmFuZ2UoW2hlaWdodCwgMF0pXHJcbiAgICAgIC5kb21haW4oZG9tYWluKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5yb3VuZERvbWFpbnMgPyBzY2FsZS5uaWNlKCkgOiBzY2FsZTtcclxuICB9XHJcblxyXG4gIGdldFNjYWxlVHlwZSh2YWx1ZXMpOiBzdHJpbmcge1xyXG4gICAgbGV0IGRhdGUgPSB0cnVlO1xyXG4gICAgbGV0IG51bSA9IHRydWU7XHJcblxyXG4gICAgZm9yIChjb25zdCB2YWx1ZSBvZiB2YWx1ZXMpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzRGF0ZSh2YWx1ZSkpIHtcclxuICAgICAgICBkYXRlID0gZmFsc2U7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgbnVtID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0ZSkgcmV0dXJuICd0aW1lJztcclxuICAgIGlmIChudW0pIHJldHVybiAnbGluZWFyJztcclxuICAgIHJldHVybiAnb3JkaW5hbCc7XHJcbiAgfVxyXG5cclxuICBpc0RhdGUodmFsdWUpOiBib29sZWFuIHtcclxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlWUF4aXNXaWR0aCh7IHdpZHRoIH0pOiB2b2lkIHtcclxuICAgIHRoaXMueUF4aXNXaWR0aCA9IHdpZHRoO1xyXG4gICAgdGhpcy51cGRhdGUoKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVhBeGlzSGVpZ2h0KHsgaGVpZ2h0IH0pOiB2b2lkIHtcclxuICAgIHRoaXMueEF4aXNIZWlnaHQgPSBoZWlnaHQ7XHJcbiAgICB0aGlzLnVwZGF0ZSgpO1xyXG4gIH1cclxuXHJcbiAgdXBkYXRlSG92ZXJlZFZlcnRpY2FsKGl0ZW0pOiB2b2lkIHtcclxuICAgIHRoaXMuaG92ZXJlZFZlcnRpY2FsID0gaXRlbS52YWx1ZTtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZUFsbCgpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignbW91c2VsZWF2ZScpXHJcbiAgaGlkZUNpcmNsZXMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmhvdmVyZWRWZXJ0aWNhbCA9IG51bGw7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuICB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ21vdXNlZW50ZXInLCBbXCJzZXJpZXNcIl0pXHJcbiAgb25Nb3VzZUVudGVyKHNlcmllcyk6IHZvaWQge1xyXG4gICAgdGhpcy5hY3RpdmF0ZS5lbWl0KHNlcmllcyk7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCdtb3VzZWxlYXZlJywgW1wiJGV2ZW50XCJdKVxyXG4gIG9uTW91c2VMZWF2ZShzZXJpZXMpOiB2b2lkIHtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZS5lbWl0KHNlcmllcyk7XHJcbiAgfVxyXG5cclxuICBvbkNsaWNrKGRhdGEsIHNlcmllcz8pOiB2b2lkIHtcclxuICAgIGlmIChzZXJpZXMpIHtcclxuICAgICAgZGF0YS5zZXJpZXMgPSBzZXJpZXMubmFtZTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNlbGVjdC5lbWl0KGRhdGEpO1xyXG4gIH1cclxuXHJcbiAgdHJhY2tCeShpbmRleCwgaXRlbSk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gaXRlbS5uYW1lO1xyXG4gIH1cclxuXHJcbiAgc2V0Q29sb3JzKCk6IHZvaWQge1xyXG4gICAgbGV0IGRvbWFpbjtcclxuICAgIGlmICh0aGlzLnNjaGVtZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBkb21haW4gPSB0aGlzLnNlcmllc0RvbWFpbjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGRvbWFpbiA9IHRoaXMueURvbWFpbjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmNvbG9ycyA9IG5ldyBDb2xvckhlbHBlcih0aGlzLnNjaGVtZSwgdGhpcy5zY2hlbWVUeXBlLCBkb21haW4sIHRoaXMuY3VzdG9tQ29sb3JzKTtcclxuICB9XHJcblxyXG4gIGdldExlZ2VuZE9wdGlvbnMoKSB7XHJcbiAgICBjb25zdCBvcHRzID0ge1xyXG4gICAgICBzY2FsZVR5cGU6IHRoaXMuc2NoZW1lVHlwZSxcclxuICAgICAgY29sb3JzOiB1bmRlZmluZWQsXHJcbiAgICAgIGRvbWFpbjogW10sXHJcbiAgICAgIHRpdGxlOiB1bmRlZmluZWRcclxuICAgIH07XHJcbiAgICBpZiAob3B0cy5zY2FsZVR5cGUgPT09ICdvcmRpbmFsJykge1xyXG4gICAgICBvcHRzLmRvbWFpbiA9IHRoaXMuc2VyaWVzRG9tYWluO1xyXG4gICAgICBvcHRzLmNvbG9ycyA9IHRoaXMuY29sb3JzO1xyXG4gICAgICBvcHRzLnRpdGxlID0gdGhpcy5sZWdlbmRUaXRsZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG9wdHMuZG9tYWluID0gdGhpcy55RG9tYWluO1xyXG4gICAgICBvcHRzLmNvbG9ycyA9IHRoaXMuY29sb3JzLnNjYWxlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG9wdHM7XHJcbiAgfVxyXG5cclxuICBvbkFjdGl2YXRlKGl0ZW0pIHtcclxuICAgIHRoaXMuZGVhY3RpdmF0ZUFsbCgpO1xyXG5cclxuICAgIGNvbnN0IGlkeCA9IHRoaXMuYWN0aXZlRW50cmllcy5maW5kSW5kZXgoZCA9PiB7XHJcbiAgICAgIHJldHVybiBkLm5hbWUgPT09IGl0ZW0ubmFtZSAmJiBkLnZhbHVlID09PSBpdGVtLnZhbHVlO1xyXG4gICAgfSk7XHJcbiAgICBpZiAoaWR4ID4gLTEpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFtpdGVtXTtcclxuICAgIHRoaXMuYWN0aXZhdGUuZW1pdCh7IHZhbHVlOiBpdGVtLCBlbnRyaWVzOiB0aGlzLmFjdGl2ZUVudHJpZXMgfSk7XHJcblxyXG4gIH1cclxuXHJcbiAgb25EZWFjdGl2YXRlKGl0ZW0pIHtcclxuICAgIGNvbnN0IGlkeCA9IHRoaXMuYWN0aXZlRW50cmllcy5maW5kSW5kZXgoZCA9PiB7XHJcbiAgICAgIHJldHVybiBkLm5hbWUgPT09IGl0ZW0ubmFtZSAmJiBkLnZhbHVlID09PSBpdGVtLnZhbHVlO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzLnNwbGljZShpZHgsIDEpO1xyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gWy4uLnRoaXMuYWN0aXZlRW50cmllc107XHJcblxyXG4gICAgdGhpcy5kZWFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogaXRlbSwgZW50cmllczogdGhpcy5hY3RpdmVFbnRyaWVzIH0pO1xyXG4gIH1cclxuXHJcbiAgZGVhY3RpdmF0ZUFsbCgpIHtcclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFsuLi50aGlzLmFjdGl2ZUVudHJpZXNdO1xyXG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzLmFjdGl2ZUVudHJpZXMpIHtcclxuICAgICAgdGhpcy5kZWFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogZW50cnksIGVudHJpZXM6IFtdIH0pO1xyXG4gICAgfVxyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gW107XHJcbiAgfVxyXG59XHJcblxyXG5cclxuXHJcbiIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmLFxyXG4gIFZpZXdDaGlsZCxcclxuICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gIE9uSW5pdCxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1jb21tb24tZGF0YS10YWJsZScsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2ICpuZ0lmPVwiaXNEYXRhQXZhaWxhYmxlXCIgc3R5bGU9XCJoZWlnaHQ6NTBweFwiIGNsYXNzPVwibWFpbi1ib3hcIiAoY2xpY2tPdXRzaWRlKT1cIm9uQ2xpY2tlZE91dHNpZGUoJGV2ZW50KVwiPlxyXG5cclxuICA8ZGl2ICpuZ0lmPVwiaGVhZGVyU2V0dGluZ1wiIGNsYXNzPVwibW9yZS1pY29uXCI+XHJcbiAgICA8YnV0dG9uIG1hdC1pY29uLWJ1dHRvbiBbbWF0TWVudVRyaWdnZXJGb3JdPVwibWVudVwiPlxyXG4gICAgICA8bWF0LWljb24gc3ZnSWNvbj1cIm1vcmVcIj48L21hdC1pY29uPlxyXG4gICAgPC9idXR0b24+XHJcbiAgICA8bWF0LW1lbnUgI21lbnU9XCJtYXRNZW51XCIgW292ZXJsYXBUcmlnZ2VyXT0nZmFsc2UnPlxyXG4gICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gW21hdE1lbnVUcmlnZ2VyRm9yXT1cImFkanVzdFJvd0hlaWdodFwiPlxyXG4gICAgICAgIDxzcGFuPlJvdyBIZWlnaHQ8L3NwYW4+XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8YnV0dG9uICpuZ0lmPSchaXNEYXRhVGFibGVQYXVzZWQnIG1hdC1tZW51LWl0ZW0gKGNsaWNrKT1cInRvZ2dsZVBhdXNlRmxhZygpXCI+XHJcbiAgICAgICAgPHNwYW4+UGF1c2U8L3NwYW4+XHJcbiAgICAgIDwvYnV0dG9uPiAgXHJcbiAgICAgIDxidXR0b24gKm5nSWY9J2lzRGF0YVRhYmxlUGF1c2VkJyBtYXQtbWVudS1pdGVtIChjbGljayk9XCJ0b2dnbGVQYXVzZUZsYWcoKVwiPlxyXG4gICAgICAgIDxzcGFuPlVuLVBhdXNlPC9zcGFuPlxyXG4gICAgICA8L2J1dHRvbj4gICAgXHJcbiAgICA8L21hdC1tZW51PlxyXG5cclxuICAgIDxtYXQtbWVudSAjYWRqdXN0Um93SGVpZ2h0PVwibWF0TWVudVwiPlxyXG4gICAgICA8YnV0dG9uIG1hdC1tZW51LWl0ZW0gKGNsaWNrKT1cImdldFJvd0hlaWdodCgnc3RhbmRhcmQnKVwiPlN0YW5kYXJkXHJcbiAgICAgICAgPG1hdC1pY29uICpuZ0lmPSdyb3dIZWlnaHQ9PTUwJyBzdmdJY29uPVwiY2hlY2tcIiBjbGFzcz1cImNoZWNrLWljb25cIj48L21hdC1pY29uPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAgPGJ1dHRvbiBtYXQtbWVudS1pdGVtIChjbGljayk9XCJnZXRSb3dIZWlnaHQoJ3NtYWxsJylcIj5TbWFsbFxyXG4gICAgICAgIDxtYXQtaWNvbiAqbmdJZj0ncm93SGVpZ2h0PT00MCcgc3ZnSWNvbj1cImNoZWNrXCIgY2xhc3M9XCJjaGVjay1pY29uXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L21hdC1tZW51PlxyXG4gIDwvZGl2PlxyXG4gIDwhLS1yb3dIZWlnaHQgc2V0dGluZy0tPlxyXG5cclxuICA8IS0tY29sdW1uIG1lbnUgZHJvcGRvdy0tPlxyXG4gIDxkaXY+XHJcbiAgICA8bWF0LW1lbnUgI2NvbHVtbkhlYWRlck1lbnU9XCJtYXRNZW51XCIgW292ZXJsYXBUcmlnZ2VyXT0nZmFsc2UnPlxyXG4gICAgICA8c3BhbiAqbmdGb3I9XCJsZXQgaXRlbSBvZiBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nXCI+XHJcbiAgICAgICAgPGJ1dHRvbiBtYXQtbWVudS1pdGVtICpuZ0lmPVwiIWl0ZW0uaGFzU3ViTWVudVwiPlxyXG4gICAgICAgICAgPHNwYW4gKGNsaWNrKT1cImhhbmRsZU1lbnVJdGVtQ2xpY2soaXRlbS50eXBlKVwiPnt7Z2V0TWF0TWVudUl0ZW1EaXNwbGF5bmFtZShpdGVtLm5hbWUpfX08L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvbiBtYXQtbWVudS1pdGVtICpuZ0lmPVwiaXRlbS5oYXNTdWJNZW51XCIgW21hdE1lbnVUcmlnZ2VyRm9yXT1cImFkZGl0aW9uYWxGdW5jdGlvbnNcIj5cclxuICAgICAgICAgIDxzcGFuPnt7aXRlbS5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvbWF0LW1lbnU+XHJcblxyXG5cclxuICAgIDxtYXQtbWVudSAjYWRkaXRpb25hbEZ1bmN0aW9ucz1cIm1hdE1lbnVcIj5cclxuICAgICAgPGJ1dHRvbiAqbmdGb3I9XCJsZXQgY29sIG9mIG5vcm1hbENvbHVtbjtsZXQgaT1pbmRleDtcIiBtYXQtbWVudS1pdGVtIChjbGljayk9XCJyZW1vdmVPckFkZENvbHVtbihjb2wsIGkpXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJkcm9wZG93TWVudUxpc3RTdHlcIj57e2NvbC5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgPG1hdC1pY29uICpuZ0lmPScxPT09MScgc3ZnSWNvbj1cImNoZWNrXCIgY2xhc3M9XCJjaGVjay1pY29uXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L21hdC1tZW51PlxyXG4gIDwvZGl2PlxyXG5cclxuXHJcbiAgPG5neC1kYXRhdGFibGUgXHJcbiAgICAjbXlkYXRhdGFibGUgXHJcbiAgICBjbGFzcz1cIm1hdGVyaWFsIGV4cGFuZGFibGVcIiBcclxuICAgIFtoZWFkZXJIZWlnaHRdPVwiaGVhZGVySGVpZ2h0XCIgXHJcbiAgICBbbGltaXRdPVwibGltaXRcIlxyXG4gICAgW3Njcm9sbGJhckhdPSd0cnVlJyBcclxuICAgIFtjb2x1bW5Nb2RlXT1cIidmb3JjZSdcIiBcclxuICAgIFtmb290ZXJIZWlnaHRdPVwiZm9vdGVySGVpZ2h0XCIgXHJcbiAgICBbcm93SGVpZ2h0XT1cInJvd0hlaWdodFwiXHJcbiAgICBbdHJhY2tCeVByb3BdPVwiJ3VwZGF0ZWQnXCIgXHJcbiAgICBbcm93c109XCJyb3dzXCI+XHJcbiAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gKm5nSWY9XCJleHBhbmRDaGlsZFwiIFt3aWR0aF09XCIzMFwiIFtyZXNpemVhYmxlXT1cImZhbHNlXCIgW3NvcnRhYmxlXT1cImZhbHNlXCIgW2RyYWdnYWJsZV09XCJmYWxzZVwiXHJcbiAgICAgIFtmcm96ZW5MZWZ0XT1cInRydWVcIiBbY2FuQXV0b1Jlc2l6ZV09XCJmYWxzZVwiPlxyXG4gICAgICA8bmctdGVtcGxhdGUgbGV0LXJvdz1cInJvd1wiIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZT5cclxuICAgICAgICA8c3BhbiBjbGFzcz0nc2lkZUNvbG9yU3R5bGUnIFtzdHlsZS5iYWNrZ3JvdW5kXT0nZ2V0U2lkZUNvbG9yU3R5bGUocm93KSc+PC9zcGFuPlxyXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImV4cGFuZGVkLWljb25cIiAqbmdJZj1cImhhc0NoaWxkcmVuKHJvdylcIiBbc3ZnSWNvbl09XCJnZXRFeHBhbmRDb2xsYXBzZUljb24ocm93KVwiIChjbGljayk9XCJ0b2dnbGVFeHBhbmRSb3cocm93KVwiPlxyXG4gICAgICAgIDwvbWF0LWljb24+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxyXG4gICAgPG5neC1kYXRhdGFibGUtY29sdW1uICpuZ0lmPVwiaGVhZGVyQ2hlY2tCb3hcIiBbd2lkdGhdPVwiNTBcIiBbc29ydGFibGVdPVwiZmFsc2VcIiBbY2FuQXV0b1Jlc2l6ZV09XCJmYWxzZVwiXHJcbiAgICAgIFtkcmFnZ2FibGVdPVwiZmFsc2VcIiBbZnJvemVuTGVmdF09XCJ0cnVlXCIgW3Jlc2l6ZWFibGVdPVwiZmFsc2VcIj5cclxuICAgICAgPG5nLXRlbXBsYXRlIGxldC1yb3c9XCJyb3dcIiBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cclxuICAgICAgICA8c3BhbiAqbmdJZj1cIiFleHBhbmRDaGlsZFwiIGNsYXNzPSdzaWRlQ29sb3JTdHlsZScgW3N0eWxlLmJhY2tncm91bmRdPSdnZXRTaWRlQ29sb3JTdHlsZShyb3cpJz48L3NwYW4+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFtkaXNhYmxlZF09XCJnZXRBbGxSb3dzRGlzYWJsZWQoKVwiIFtjaGVja2VkXT1cImdldEFsbFJvd0NoZWNrZWQocm93cylcIlxyXG4gICAgICAgICAgKGNoYW5nZSk9XCJvblNlbGVjdEFsbCghYWxsUm93c1NlbGVjdGVkLCByb3dzKVwiIC8+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGUgbGV0LXJvdz1cInJvd1wiPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBbZGlzYWJsZWRdPVwiZ2V0U2luZ2xlUm93RGlzYWJsZWQocm93KVwiIFtjaGVja2VkXT1cImdldFNpbmdsZVJvd0NoZWNrZWQocm93WydmdW5kVGlja2VyJ10pXCJcclxuICAgICAgICAgIChjaGFuZ2UpPVwib25DaGVja2JveENoYW5nZShyb3dbJ2Z1bmRUaWNrZXInXSlcIiAvPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cclxuICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiAqbmdGb3I9XCJsZXQgY29sIG9mIGN1c3RvbUNvbHVtblwiIFxyXG4gICAgICBbd2lkdGhdPVwiNTVcIiBcclxuICAgICAgW3NvcnRhYmxlXT1cImZhbHNlXCIgXHJcbiAgICAgIFtjYW5BdXRvUmVzaXplXT1cImZhbHNlXCJcclxuICAgICAgW2RyYWdnYWJsZV09XCJmYWxzZVwiIFxyXG4gICAgICBbcmVzaXplYWJsZV09XCJmYWxzZVwiIFxyXG4gICAgICBbZnJvemVuTGVmdF09XCJ0cnVlXCI+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC50eXBlPT09J3JlZEFsZXJ0JyBcIiBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cclxuICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJhbGVydEhlYWRlclwiIHN2Z0ljb249XCJmbGFnXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLnR5cGU9PT0neWVsbG93QWxlcnQnIFwiIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxyXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImFsZXJ0SGVhZGVyXCIgc3ZnSWNvbj1cImZsYWdcIj48L21hdC1pY29uPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICA8bmctdGVtcGxhdGUgKm5nSWY9XCJjb2wudHlwZT09PSduZXdzJyBcIiBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cclxuICAgICAgICA8c3Bhbj5OZXdzPC9zcGFuPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICA8bmctdGVtcGxhdGUgKm5nSWY9XCJjb2wudHlwZT09PSdyZWRBbGVydCcgXCIgbGV0LXJvdz1cInJvd1wiIGxldC1jb2x1bW49XCJjb2xcIiBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwiYWxlcnRDbGFzc1wiIHN2Z0ljb249XCJjaXJjbGVfYWxlcnRcIlxyXG4gICAgICAgICAgW3N0eWxlLmRpc3BsYXldPVwic2hvd1JlZEFsZXJ0KHJvd1snZnVuZGlkJ10scm93WydjbGFzc0lEJ10pID8gJ2lubGluZS1mbGV4JyA6ICdub25lJyBcIlxyXG4gICAgICAgICAgKGNsaWNrKT1cIm9wZW5BbGVydE1vZGFsKHJvdyxjb2wudHlwZSlcIj5cclxuICAgICAgICA8L21hdC1pY29uPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICA8bmctdGVtcGxhdGUgKm5nSWY9XCJjb2wudHlwZT09PSd5ZWxsb3dBbGVydCcgXCIgbGV0LXJvdz1cInJvd1wiIGxldC1jb2x1bW49XCJjb2xcIiBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwiYWxlcnRDbGFzc1wiIHN2Z0ljb249XCJ0cmlhbmdsZWFsZXJ0XCJcclxuICAgICAgICAgIFtzdHlsZS5kaXNwbGF5XT1cInNob3dZZWxsb3dBbGVydChyb3dbJ2Z1bmRpZCddLHJvd1snY2xhc3NJRCddKSA/ICdpbmxpbmUtZmxleCcgOiAnbm9uZScgXCJcclxuICAgICAgICAgIChjbGljayk9XCJvcGVuQWxlcnRNb2RhbChyb3csY29sLnR5cGUpXCI+XHJcbiAgICAgICAgPC9tYXQtaWNvbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLnR5cGU9PT0nbmV3cycgXCIgbGV0LXJvdz1cInJvd1wiIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZT5cclxuICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJzaG93TmV3c0NsYXNzXCIgW3N0eWxlLmRpc3BsYXldPVwic2hvd05ld3Mocm93KSA/ICdpbmxpbmUtZmxleCcgOiAnbm9uZScgXCIgc3ZnSWNvbj1cImdsb2JlXCI+XHJcbiAgICAgICAgPC9tYXQtaWNvbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XHJcbiAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gKm5nRm9yPVwibGV0IGNvbCBvZiBub3JtYWxDb2x1bW5cIiBcclxuICAgICAgW3Byb3BdPVwiY29sLnByb3BcIiBcclxuICAgICAgW2RyYWdnYWJsZV09XCJjb2wuZHJhZ2dhYmxlXCJcclxuICAgICAgW2NhbkF1dG9SZXNpemVdPVwiY29sLmNhbkF1dG9SZXNpemVcIiBcclxuICAgICAgW3NvcnRhYmxlXT1cImZhbHNlXCIgXHJcbiAgICAgIFtmcm96ZW5MZWZ0XT1cImNvbC5mcm96ZW5MZWZ0XCJcclxuICAgICAgW3dpZHRoXT1cImdldENvbFNldHRpbmdXaWR0aChjb2wpXCI+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSBsZXQtY29sdW1uPVwiY29sXCIgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XHJcbiAgICAgICAgPGRpdiBbY2xhc3NdPVwiZ2V0SGVhZGVyQ2xhc3MoY29sKVwiICBcclxuICAgICAgICAoY2xpY2spPVwic2VsZWN0Q3VycmVudENvbCgkZXZlbnQsIGNvbC5wcm9wKVwiIChtZW51Q2xvc2VkKT1cImNsb3NlTWVudSgpXCIgIFttYXRNZW51VHJpZ2dlckZvcl09XCJjb2x1bW5IZWFkZXJNZW51XCJcclxuICAgICAgICAgICpuZ0lmPVwiKGNvbC5jb2x1bW5TZXR0aW5nICYmIGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmcubGVuZ3RoID4gMCkgZWxzZSBlbHNlQmxvY2tcIj5cclxuICAgICAgICAgIDwhLS0gc29ydCBpY29uIHN0YXJ0LS0+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzcz1cInNvcnRJY29uU3R5Q29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgIDxtYXQtaWNvbiBbY2xhc3NdPVwiZ2V0U29ydEljb25EaXNwbGF5U3R5KGNvbC5wcm9wKVwiIFtzdmdJY29uXT1cImdldFNvcnRJY29uKGNvbC5wcm9wKVwiXHJcbiAgICAgICAgICAgICAgKGNsaWNrKT1cImNoYW5nZUFzY0FuZERlc2NTb3J0KCRldmVudCwgY29sLnByb3ApXCI+PC9tYXQtaWNvbj5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICA8IS0tIHNvcnQgaWNvbiBlbmQtLT5cclxuXHJcbiAgICAgICAgICA8IS0tIGhlYWRlciBuYW1lIHN0YXJ0LS0+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImhlYWRlci1jZWxsLWxhYmVsLXN0eVwiPlxyXG4gICAgICAgICAgICB7e2NvbC5uYW1lfX1cclxuICAgICAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwiZHJvcGRvd0ljb25TdHlcIiBzdmdJY29uPVwiYXJyb3dfZG93blwiPjwvbWF0LWljb24+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICA8IS0tIGhlYWRlciBuYW1lIGVuZC0tPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZWxzZUJsb2NrPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2x1bW5IZWFkZXJcIj5cclxuICAgICAgICAgICAge3tjb2wubmFtZX19XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLmNlbGxUZW1wbGF0ZT09PSdoeXBlckxpbmsnIFwiIGxldC1yb3c9XCJyb3dcIiBsZXQtdmFsdWU9XCJ2YWx1ZVwiIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZT5cclxuICAgICAgICA8ZGl2IFtjbGFzc109XCJnZXRDZWxsQ2xhc3Mocm93LCBjb2wsIHZhbHVlKVwiPlxyXG4gICAgICAgICAgPHNwYW4gKm5nSWY9XCJyb3cuY2hpbGQgPT09ICdwYXJlbnQnXCIgY2xhc3M9XCJoeXBlckxpbmtDZWxsU3R5XCJcclxuICAgICAgICAgICAgKGNsaWNrKT1cImh5cGVyTGlua05hdmlnYXRlKHJvdylcIj57e3Jvdy5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiAqbmdJZj1cInJvdy5jaGlsZCA9PT0gJ2NoaWxkJ1wiPnt7cm93Lm5hbWV9fTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLmNlbGxUZW1wbGF0ZT09PSdudW1iZXJGb3JtYXRTaG9ydCcgXCIgbGV0LXJvdz1cInJvd1wiIGxldC12YWx1ZT1cInZhbHVlXCIgbGV0LWk9XCJpbmRleFwiXHJcbiAgICAgICAgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlPlxyXG4gICAgICAgIDxkaXYgW2NsYXNzXT1cImdldENlbGxDbGFzcyhyb3csIGNvbCwgdmFsdWUpXCI+XHJcbiAgICAgICAgICB7e3ZhbHVlIHwgbnVtYmVyUm91bmRVcDoyIHwgbnVtYmVyOiAnMS4yLTInfX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLmNlbGxUZW1wbGF0ZT09PSdudW1iZXJGb3JtYXRMb25nJyBcIiBsZXQtcm93PVwicm93XCIgbGV0LXZhbHVlPVwidmFsdWVcIiBsZXQtaT1cImluZGV4XCJcclxuICAgICAgICBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPGRpdiBbY2xhc3NdPVwiZ2V0Q2VsbENsYXNzKHJvdywgY29sLCB2YWx1ZSlcIj5cclxuICAgICAgICAgIHt7dmFsdWUgfCBudW1iZXJSb3VuZFVwOjUgfCBudW1iZXI6ICcxLjUtNSd9fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICA8bmctdGVtcGxhdGUgKm5nSWY9XCJjb2wuY2VsbFRlbXBsYXRlPT09J3BlcmNlbnRGb3JtYXQnIFwiIGxldC1yb3c9XCJyb3dcIiBsZXQtdmFsdWU9XCJ2YWx1ZVwiIGxldC1pPVwiaW5kZXhcIlxyXG4gICAgICAgIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZT5cclxuICAgICAgICA8ZGl2IFtjbGFzc109XCJnZXRDZWxsQ2xhc3Mocm93LCBjb2wsIHZhbHVlKVwiPlxyXG4gICAgICAgICAge3t2YWx1ZSB8IG51bWJlclJvdW5kVXA6NSB8IHBlcmNlbnQ6ICcxLjMtMycgfCBwZXJjZW50Rm9ybWF0fX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLmNlbGxUZW1wbGF0ZT09PSdkZWZhdWx0JyBcIiBsZXQtcm93PVwicm93XCIgbGV0LXZhbHVlPVwidmFsdWVcIiBsZXQtaT1cImluZGV4XCJcclxuICAgICAgICBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPGRpdiBbY2xhc3NdPVwiZ2V0Q2VsbENsYXNzKHJvdywgY29sLCB2YWx1ZSlcIj5cclxuICAgICAgICAgIHt7dmFsdWV9fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cclxuICA8L25neC1kYXRhdGFibGU+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnN0cmlwZWQgLmRhdGF0YWJsZS1yb3ctb2Rke2JhY2tncm91bmQ6I2VlZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzMwNGZmZTtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMTkzYWU0O2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMyMDQxZWY7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNlZWU7dHJhbnNpdGlvbi1wcm9wZXJ0eTpiYWNrZ3JvdW5kO3RyYW5zaXRpb24tZHVyYXRpb246LjNzO3RyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOmxpbmVhcn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmVtcHR5LXJvd3toZWlnaHQ6NTBweDt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouNXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAubG9hZGluZy1yb3d7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1yb3ctbGVmdHtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1wb3NpdGlvbjoxMDAlIDA7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJSFdQU2tOZVNCbUpoVFFWdGJpRE5DZ0FTYWdJSXVKWDhPZ0FBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LXJpZ2h0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0e2JhY2tncm91bmQtcG9zaXRpb246MCAwO2JhY2tncm91bmQtY29sb3I6I2ZmZjtiYWNrZ3JvdW5kLXJlcGVhdDpyZXBlYXQteTtiYWNrZ3JvdW5kLWltYWdlOnVybChkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFRQUFBQUJDQVlBQUFENVBBL05BQUFBRmtsRVFWUUkxMlBRa05kaTFWVFE1Z2JTd2tBc0RRQVJMQUlHdE9TRlVBQUFBQUJKUlU1RXJrSmdnZz09KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlcntib3gtc2hhZG93OjAgMnB4IDRweCAwIHJnYmEoMCwwLDAsLjE1KTtwb3NpdGlvbjpzdGlja3k7cG9zaXRpb246LXdlYmtpdC1zdGlja3k7dG9wOjA7ei1pbmRleDo5OTk7YmFja2dyb3VuZC1jb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGx7dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6cmdiYSgwLDAsMCwuNTQpO3ZlcnRpY2FsLWFsaWduOmJvdHRvbTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo1MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJ7cG9zaXRpb246cmVsYXRpdmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5sb25ncHJlc3MgLmRyYWdnYWJsZTo6YWZ0ZXJ7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjRzLG9wYWNpdHkgLjRzLC13ZWJraXQtdHJhbnNmb3JtIC40cztvcGFjaXR5Oi41Oy13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKDEpO3RyYW5zZm9ybTpzY2FsZSgxKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kcmFnZ2FibGU6OmFmdGVye2NvbnRlbnQ6XCIgXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjUwJTtsZWZ0OjUwJTttYXJnaW46LTMwcHggMCAwIC0zMHB4O2hlaWdodDo2MHB4O3dpZHRoOjYwcHg7YmFja2dyb3VuZDojZWVlO2JvcmRlci1yYWRpdXM6MTAwJTtvcGFjaXR5OjE7LXdlYmtpdC1maWx0ZXI6bm9uZTtmaWx0ZXI6bm9uZTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgwKTt0cmFuc2Zvcm06c2NhbGUoMCk7ei1pbmRleDo5OTk5O3BvaW50ZXItZXZlbnRzOm5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5kcmFnZ2luZyAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6bm9uZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWRldGFpbHtiYWNrZ3JvdW5kOiNmNWY1ZjU7cGFkZGluZzoxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWdyb3VwLWhlYWRlcntiYWNrZ3JvdW5kOiNmNWY1ZjU7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgI2Q5ZDhkOTtib3JkZXItdG9wOjFweCBzb2xpZCAjZDlkOGQ5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse3RleHQtYWxpZ246Y2VudGVyO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7bGluZS1oZWlnaHQ6NTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktZ3JvdXAtY2VsbHt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouOXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDtjb2xvcjojMzUzNTM1O3RyYW5zaXRpb246d2lkdGggLjNzO2ZvbnQtc2l6ZToxNHB4O2ZvbnQtd2VpZ2h0OjQwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLnByb2dyZXNzLWxpbmVhcntkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCU7aGVpZ2h0OjVweDtwYWRkaW5nOjA7bWFyZ2luOjA7cG9zaXRpb246YWJzb2x1dGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lcntkaXNwbGF5OmJsb2NrO3Bvc2l0aW9uOnJlbGF0aXZlO292ZXJmbG93OmhpZGRlbjt3aWR0aDoxMDAlO2hlaWdodDo1cHg7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTtiYWNrZ3JvdW5kLWNvbG9yOiNhYWQxZjl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lciAuYmFye3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXI7LXdlYmtpdC1hbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O2FuaW1hdGlvbjouOHMgY3ViaWMtYmV6aWVyKC4zOSwuNTc1LC41NjUsMSkgaW5maW5pdGUgcXVlcnk7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjJzIGxpbmVhciwtd2Via2l0LXRyYW5zZm9ybSAuMnMgbGluZWFyO2JhY2tncm91bmQtY29sb3I6IzEwNmNjODtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7dG9wOjA7Ym90dG9tOjA7d2lkdGg6MTAwJTtoZWlnaHQ6NXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVye2JvcmRlci10b3A6MXB4IHNvbGlkIHJnYmEoMCwwLDAsLjEyKTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo0MDA7Y29sb3I6cmdiYSgwLDAsMCwuNTQpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5wYWdlLWNvdW50e2xpbmUtaGVpZ2h0OjUwcHg7aGVpZ2h0OjUwcHg7cGFkZGluZzowIDEuMnJlbX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2Vye21hcmdpbjowIDEwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaXt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5kaXNhYmxlZCBhe2NvbG9yOnJnYmEoMCwwLDAsLjI2KSFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCFpbXBvcnRhbnR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5hY3RpdmUgYXtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpO2ZvbnQtd2VpZ2h0OjcwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIGF7aGVpZ2h0OjIycHg7bWluLXdpZHRoOjI0cHg7bGluZS1oZWlnaHQ6MjJweDtwYWRkaW5nOjAgNnB4O2JvcmRlci1yYWRpdXM6M3B4O21hcmdpbjo2cHggM3B4O3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt0ZXh0LWRlY29yYXRpb246bm9uZTt2ZXJ0aWNhbC1hbGlnbjpib3R0b219Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhOmhvdmVye2NvbG9yOnJnYmEoMCwwLDAsLjc1KTtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcHJldiwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1za2lwe2ZvbnQtc2l6ZToyMHB4O2xpbmUtaGVpZ2h0OjIwcHg7cGFkZGluZzowIDNweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3csLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVye2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWNlbGx7Zm9udC13ZWlnaHQ6NzAwfS5kYXRhdGFibGUtY2hlY2tib3h7cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjA7Y3Vyc29yOnBvaW50ZXI7dmVydGljYWwtYWxpZ246bWlkZGxlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO2JveC1zaXppbmc6Ym9yZGVyLWJveDtwYWRkaW5nOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XXtwb3NpdGlvbjpyZWxhdGl2ZTttYXJnaW46MCAxcmVtIDAgMDtjdXJzb3I6cG9pbnRlcjtvdXRsaW5lOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpiZWZvcmV7dHJhbnNpdGlvbjouM3MgZWFzZS1pbi1vdXQ7Y29udGVudDpcIlwiO3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MDt6LWluZGV4OjE7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtib3JkZXI6MnB4IHNvbGlkICNmMmYyZjJ9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkOmJlZm9yZXstd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTt0cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7aGVpZ2h0Oi41cmVtO2JvcmRlci1jb2xvcjojMDA5Njg4O2JvcmRlci10b3Atc3R5bGU6bm9uZTtib3JkZXItcmlnaHQtc3R5bGU6bm9uZX0uZGF0YXRhYmxlLWNoZWNrYm94IGlucHV0W3R5cGU9Y2hlY2tib3hdOmFmdGVye2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MDtsZWZ0OjA7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtiYWNrZ3JvdW5kOiNmZmY7Y3Vyc29yOnBvaW50ZXJ9QC13ZWJraXQta2V5ZnJhbWVzIHF1ZXJ5ezAle29wYWNpdHk6MTstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKX0xMDAle29wYWNpdHk6MDstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKX19QGtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy16ZXJve3RleHQtYWxpZ246cmlnaHQ7dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1uYWdldGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6I2I5MTIyNDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1wb3NpdGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzI4NzQzZTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1hbGlnbi1sZWZ0e3RleHQtYWxpZ246bGVmdDtjb2xvcjojMzUzNTM1fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1jZW50ZXJ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tcmlnaHR7dGV4dC1hbGlnbjpyaWdodDtjb2xvcjojMzUzNTM1fWJ1dHRvbi5tYXQtbWVudS1pdGVte2hlaWdodDozMHB4O2xpbmUtaGVpZ2h0OjMwcHg7Zm9udC1zaXplOjEzcHg7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWF0LW1lbnUtaXRlbTpob3Zlcjpub3QoW2Rpc2FibGVkXSl7YmFja2dyb3VuZDojZTFlY2YyfS5jaGVjay1pY29uLm1hdC1pY29ue3dpZHRoOjE0cHg7aGVpZ2h0OjE0cHg7bWFyZ2luLWxlZnQ6MjBweDtjb2xvcjojMDAwfS5uZ3gtZGF0YXRhYmxlLmZpeGVkLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1pbm5lcntoZWlnaHQ6MTAwJX1gLCBgLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFse2JhY2tncm91bmQ6I2ZmZn0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLnNob3dOZXdzQ2xhc3N7ZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MjBweDtoZWlnaHQ6MjBweDt0cmFuc2l0aW9uOndpZHRoIC4zc30ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3ZlciwubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNlMWVjZjI7Y3Vyc29yOnBvaW50ZXJ9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5hbGVydENsYXNze3RleHQtYWxpZ246Y2VudGVyO2Rpc3BsYXk6aW5saW5lLWJsb2NrO3dpZHRoOjIycHg7aGVpZ2h0OjIycHg7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Y3Vyc29yOnBvaW50ZXI7bWFyZ2luLWxlZnQ6LTEwcHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keS1jZWxsIC5leHBhbmRlZC1pY29ue3RleHQtYWxpZ246Y2VudGVyO2Rpc3BsYXk6aW5saW5lLWJsb2NrO3dpZHRoOjIwcHg7aGVpZ2h0OjIwcHg7Y3Vyc29yOnBvaW50ZXI7Y29sb3I6cmdiYSgwLDAsMCwuNTQpO2ZvbnQtc2l6ZToxMnB4O3RyYW5zaXRpb246d2lkdGggLjNzfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxse2xpbmUtaGVpZ2h0OjUwcHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC10ZW1wbGF0ZS13cmFwe2N1cnNvcjpwb2ludGVyO2hlaWdodDoxMDAlO2xpbmUtaGVpZ2h0OjUwcHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC10ZW1wbGF0ZS13cmFwIC5hbGVydEhlYWRlcntkaXNwbGF5OmlubGluZS1ibG9jazt3aWR0aDoyMHB4O2hlaWdodDoyMHB4O3RyYW5zaXRpb246d2lkdGggLjNzO21hcmdpbi1sZWZ0Oi0xMHB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwtdGVtcGxhdGUtd3JhcCAuY29sdW1uSGVhZGVye2NvbG9yOiMwMDA7cG9zaXRpb246cmVsYXRpdmU7cGFkZGluZy1yaWdodDo1cHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmhlYWRlci1hbGlnbi1jZW50ZXIsLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmhlYWRlci1hbGlnbi1sZWZ0LC5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5oZWFkZXItYWxpZ24tcmlnaHR7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuaGVhZGVyLWFsaWduLWxlZnR7anVzdGlmeS1jb250ZW50OmZsZXgtc3RhcnR9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmhlYWRlci1hbGlnbi1jZW50ZXJ7anVzdGlmeS1jb250ZW50OmNlbnRlcn0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuaGVhZGVyLWFsaWduLXJpZ2h0e2p1c3RpZnktY29udGVudDpmbGV4LWVuZH0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRyb3Bkb3dJY29uU3R5e3Zpc2liaWxpdHk6aGlkZGVufS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZHJvcGRvd0ljb25TdHksLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5zb3J0SWNvblN0eUNvbnRhaW5lciBzdmd7d2lkdGg6MTVweCFpbXBvcnRhbnQ7aGVpZ2h0OjE1cHghaW1wb3J0YW50O21pbi13aWR0aDoxNXB4IWltcG9ydGFudDttYXgtd2lkdGg6MTVweCFpbXBvcnRhbnR9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kcm9wZG93SWNvblN0eSBzdmcsLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5zb3J0SWNvblN0eUNvbnRhaW5lciBzdmd7dmVydGljYWwtYWxpZ246bWlkZGxlfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuY29sdW1uSGVhZGVyIC5oZWFkZXItY2VsbC1sYWJlbC1zdHl7cGFkZGluZy1sZWZ0OjNweH0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmNvbHVtbkhlYWRlciAuZHJvcGRvd0ljb25TdHl7dmlzaWJpbGl0eTpoaWRkZW59Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5jb2x1bW5IZWFkZXIuZHJvcC1pcy12aXNpYmxlIC5kcm9wZG93SWNvblN0eSwubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmNvbHVtbkhlYWRlcjpob3ZlciAuZHJvcGRvd0ljb25TdHl7dmlzaWJpbGl0eTp2aXNpYmxlfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuY29sdW1uSGVhZGVyLmRyb3AtaXMtdmlzaWJsZXtiYWNrZ3JvdW5kLWNvbG9yOiNlMWVjZjJ9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5jb2x1bW5IZWFkZXIgLnRydWV7dmlzaWJpbGl0eTp2aXNpYmxlfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuY29sdW1uSGVhZGVyIC5mYWxzZXt2aXNpYmlsaXR5OmhpZGRlbn0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5e292ZXJmbG93LXk6YXV0byFpbXBvcnRhbnR9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuYWxpZ24tcmlnaHR7cGFkZGluZy1yaWdodDoyNXB4O3RleHQtYWxpZ246cmlnaHR9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuYWxpZ24tbGVmdHt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZy1sZWZ0OjE5cHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuc2lkZUNvbG9yU3R5bGV7cG9zaXRpb246YWJzb2x1dGU7d2lkdGg6NHB4O2hlaWdodDo0NXB4O3RvcDozcHg7bGVmdDowfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmh5cGVyTGlua0NlbGxTdHl7Y3Vyc29yOnBvaW50ZXI7Y29sb3I6IzJmNzQ5MTt0ZXh0LWRlY29yYXRpb246bm9uZX0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1yb3ctbGVmdHtiYWNrZ3JvdW5kLWltYWdlOm5vbmU7ZGlzcGxheTpmbGV4fS5tYWluLWJveCAubW9yZS1pY29ue3Bvc2l0aW9uOmFic29sdXRlO3RvcDo2cHg7cmlnaHQ6NThweDtjdXJzb3I6cG9pbnRlcn0ubWFpbi1ib3ggLm1vcmUtaWNvbiAubWF0LWljb24tYnV0dG9ue2JhY2tncm91bmQtY29sb3I6I2ZmZjtjdXJzb3I6cG9pbnRlcn0udGFibGUtbGF5b3V0IC5hZGp1c3QtZm9yLXNob3ctaGVhZGVye292ZXJmbG93LXk6aGlkZGVuIWltcG9ydGFudH1gXSxcclxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lIC8vSWYgeW91IGFyZSB1c2luZyBQcmltZU5HIG9yIEFuZ3VsYXIgTWF0ZXJpYWwgaW4geW91ciBwcm9qZWN0IHRoYXQgc3R5bGVVcmwgd2lsbCBub3Qgd29yayBsaWtlIHRoaXMuIFlvdSBuZWVkIHRvIGltcG9ydCBWaWV3RW5jYXBzdWxhdGlvbiBhbmQgcHV0IGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUgaW4gdGhlIEBjb21wb25lbnQgZGVmaW5pdGlvbi5cclxufSlcclxuZXhwb3J0IGNsYXNzIENvbW1vbkRhdGFUYWJsZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBWaWV3Q2hpbGQoJ215ZGF0YXRhYmxlJykgbXlkYXRhdGFibGU6IGFueTtcclxuXHJcbiAgLy8gZGF0YVxyXG4gIEBJbnB1dCgpIGhlYWRlclNldHRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIEBJbnB1dCgpIGhlYWRlckhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgQElucHV0KCkgaXNEYXRhVGFibGVQYXVzZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSByb3dzOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIGNoaWxkUm93czogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSBhbGVydERhdGE6IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgcm93SGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICBASW5wdXQoKSBjdXN0b21Db2x1bW46IGFueSA9IFtdOyAvL3R5cGUgTm8uIERldGFpbHNcclxuICBASW5wdXQoKSBub3JtYWxDb2x1bW46IGFueSA9IFtdOyAvLyB3aWR0aCwgZHJhZ2dhYmxlLCBjYW5BdXRvUmVzaXplICBwcm9wIGhlYWRlckNsYXNzIGNlbGxDbGFzcyBoZWFkZXJUZW1wbGF0ZSBjZWxsVGVtcGxhdGUgY29sdW1uU2V0dGluZyBldGMuXHJcbiAgQElucHV0KCkgbGltaXQ6IG51bWJlciA9IDU7XHJcbiAgQElucHV0KCkgZm9vdGVySGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICBASW5wdXQoKSBoZWFkZXJDaGVja0JveDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmc6IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgYWxsUm93c1NlbGVjdGVkOiBib29sZWFuO1xyXG5cclxuICAvLyBmdW5jdGlvblxyXG4gIEBJbnB1dCgpIGdldEFsbFJvd3NEaXNhYmxlZDogYW55O1xyXG4gIEBJbnB1dCgpIGdldFNpbmdsZVJvd0Rpc2FibGVkOiBhbnk7XHJcbiAgQElucHV0KCkgZ2V0QWxsUm93Q2hlY2tlZDogYW55O1xyXG4gIEBJbnB1dCgpIGdldFNpbmdsZVJvd0NoZWNrZWQ6IGFueTtcclxuICBASW5wdXQoKSBvblNlbGVjdEFsbDogYW55O1xyXG4gIEBJbnB1dCgpIG9uQ2hlY2tib3hDaGFuZ2U6IGFueTtcclxuICBASW5wdXQoKSBkZWZhdWx0U29ydENvbDogc3RyaW5nO1xyXG5cclxuICBAT3V0cHV0KCkgbWVudUNsb3NlZDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgQE91dHB1dCgpIHRvZ2dsZVBhdXNlRmxhZ0V2ZW50OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcblxyXG4gIGV4cGFuZENoaWxkID0gZmFsc2U7XHJcbiAgc2VsZWN0ZWRDb2w6ICcnO1xyXG4gIGlzU2VsZWN0ZWRNYXA6IGFueVtdID0gW107XHJcbiAgZXhwYW5kQ29sbGFwc2VJY29uTWFwOiBhbnlbXSA9IFtdO1xyXG4gIGdldFNvcnRJY29uRGlzcGxheUZsYWc6IGFueSA9IHt9O1xyXG4gIGlzRGF0YUF2YWlsYWJsZSA9IGZhbHNlO1xyXG4gIGFzY0ZsYWcgPSAnYXNjJztcclxuXHJcbiAgcHJpdmF0ZSBpbnRlcnZhbDogYW55O1xyXG5cclxuICBoYXNDaGlsZHJlbihyb3cpIHsgICBcclxuICAgIHJldHVybiB0aGlzLmNoaWxkUm93cy5maW5kSW5kZXgoaXRlbSA9PiB7IHJldHVybiBpdGVtLmZ1bmRpZCA9PT0gcm93LmZ1bmRpZCB9KT09PS0xID8gZmFsc2UgOiB0cnVlO1xyXG4gIH1cclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICBwcml2YXRlIHZpZXdDb250YWluZXI6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50czogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsXHJcbiAgICBwdWJsaWMgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSkge1xyXG4gICAgc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmNsaWNrZWRPdXRTaWRlLnN1YnNjcmliZShlID0+IHtcclxuICAgICAvLyB0aGlzLnNlbGVjdGVkQ29sID0gJyc7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAgPSB0aGlzLnNldERlZmF1bHRFeHBhbmRDb2xsYXBzZU1hcHBpbmcodGhpcy5yb3dzKTtcclxuICAgIHRoaXMuZ2V0U29ydEljb25EaXNwbGF5RmxhZyA9IHRoaXMuc2V0RGVmYXVsdFNvcnRJY29uRGlzcGxheUZsYWcodGhpcy5ub3JtYWxDb2x1bW4pO1xyXG4gICAgdGhpcy5leHBhbmRDaGlsZCA9IHRoaXMuY2hpbGRSb3dzLmxlbmd0aCA+IDAgPyB0cnVlIDogZmFsc2U7XHJcbiAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IHRoaXMucm93cy5sZW5ndGggPiAwID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgbGV0IGRhdGEgPSB0aGlzLmdldFNvcnRDb2x1bW5EZXRhaWxzSW5mbygpO1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc29ydERhdGF0YWJsZUNvbHVtbi5lbWl0KGRhdGEpO1xyXG4gIH1cclxuXHJcbiAgbmdBZnRlclZpZXdJbml0KCkge1xyXG4gICAgY29uc3QgbGF5T3V0Q29tcCA9ZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnbGF5b3V0LWl0ZW0nKVsxXTtcclxuICAgIGlmKGxheU91dENvbXApIHtcclxuICAgICAgbGF5T3V0Q29tcC5jbGFzc0xpc3QuYWRkKCd0YWJsZS1sYXlvdXQnKVxyXG4gICAgICB0aGlzLm9uUmVzaXplKGV2ZW50KVxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHNldERlZmF1bHRFeHBhbmRDb2xsYXBzZU1hcHBpbmcoZGF0YSk6IGFueVtdIHtcclxuICAgIGxldCBtYXBwaW5nQXJyID0gW107XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgZnVuZGlkOiBpdGVtLmZ1bmRpZCxcclxuICAgICAgICBleHBhbmQ6IGZhbHNlXHJcbiAgICAgIH07XHJcbiAgICAgIG1hcHBpbmdBcnIucHVzaChvYmopO1xyXG4gICAgfSlcclxuICAgIHJldHVybiBtYXBwaW5nQXJyO1xyXG4gIH1cclxuXHJcbiAgc2V0RGVmYXVsdFNvcnRJY29uRGlzcGxheUZsYWcoY29sdW1uKTogYW55IHtcclxuICAgIGxldCB0ZW1wTWFwID0ge307XHJcbiAgICBjb2x1bW4uZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgbGV0IG9iaiA9IG5ldyBPYmplY3QoKTtcclxuICAgICAgb2JqW2l0ZW0ucHJvcF0gPSBmYWxzZTtcclxuICAgICAgdGVtcE1hcCA9IE9iamVjdC5hc3NpZ24oXy5jbG9uZURlZXAodGVtcE1hcCksIG9iaik7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBNYXA7XHJcbiAgfVxyXG5cclxuICBnZXRTb3J0Q29sdW1uRGV0YWlsc0luZm8oKSB7XHJcbiAgICBsZXQgb2JqID0ge1xyXG4gICAgICBtYXA6IHRoaXMuZXhwYW5kQ29sbGFwc2VJY29uTWFwLFxyXG4gICAgICBwcm9wOiB0aGlzLmRlZmF1bHRTb3J0Q29sLFxyXG4gICAgICBhc2NGbGFnOiB0cnVlXHJcbiAgICB9O1xyXG4gICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uc29ydENvbHVtbkFzY09yRGVzYykge1xyXG4gICAgICBvYmogPSB7XHJcbiAgICAgICAgbWFwOiB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcCxcclxuICAgICAgICBwcm9wOiBpdGVtLnByb3AsXHJcbiAgICAgICAgYXNjRmxhZzogaXRlbS5zb3J0Q29sdW1uQXNjT3JEZXNjID09PSAnYXNjJyA/IHRydWUgOiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gb2JqO1xyXG4gIH1cclxuXHJcbiAgZ2V0SGVhZGVyQ2xhc3MoY29sdW1uKTogYW55IHtcclxuICAgIHN3aXRjaCAoY29sdW1uLmhlYWRlckNsYXNzRm9ybWF0KSB7XHJcbiAgICAgIGNhc2UgJ2hlYWRlckxlZnQnOlxyXG4gICAgICAgIHJldHVybiAnY29sdW1uSGVhZGVyIGhlYWRlci1hbGlnbi1sZWZ0JztcclxuICAgICAgY2FzZSAnaGVhZGVyQ2VudGVyJzpcclxuICAgICAgICByZXR1cm4gJ2NvbHVtbkhlYWRlciBoZWFkZXItYWxpZ24tY2VudGVyJztcclxuICAgICAgY2FzZSAnaGVhZGVyUmlnaHQnOlxyXG4gICAgICAgIHJldHVybiAnY29sdW1uSGVhZGVyIGhlYWRlci1hbGlnbi1yaWdodCc7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuICdjb2x1bW5IZWFkZXInO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0Q2VsbENsYXNzKHJvdywgY29sdW1uLCB2YWx1ZSk6IGFueSB7XHJcbiAgICBzd2l0Y2ggKGNvbHVtbi5jZWxsQ2xhc3NGb3JtYXQpIHtcclxuICAgICAgY2FzZSAnY2VsbExlZnQnOlxyXG4gICAgICAgIHJldHVybiAnIGFsaWduLWxlZnQnXHJcbiAgICAgIGNhc2UgJ2NlbGxSaWdodCc6XHJcbiAgICAgICAgcmV0dXJuICcgYWxpZ24tcmlnaHQnO1xyXG4gICAgICBjYXNlICdjZWxsTnVtYmVyJzogIC8vIG5lZWQgbW9yZSBhbmx5emUgaGVyZVxyXG4gICAgICAgIGlmICh2YWx1ZSAhPT0gMCkge1xyXG4gICAgICAgICAgaWYgKHZhbHVlLnRvU3RyaW5nKCkuaW5kZXhPZignLScpICE9PSAtMSAmJiB2YWx1ZS50b1N0cmluZygpLmluZGV4T2YoJy0nKSA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1uYWdldGl2ZSc7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1wb3NpdGl2ZSc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChjb2x1bW4ucHJvcCA9PT0gJ25hdkNoYW5nZVBlcmNlbnQnKSB7XHJcbiAgICAgICAgICBpZiAocm93WyduYXZDaGFuZ2UnXS50b1N0cmluZygpLmluZGV4T2YoJy0nKSAhPT0gLTEgJiYgcm93WyduYXZDaGFuZ2UnXS50b1N0cmluZygpLmluZGV4T2YoJy0nKSA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1uYWdldGl2ZSc7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1wb3NpdGl2ZSc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChjb2x1bW4ucHJvcCA9PT0gJ2Z1bmRtdkNoYW5nZVBlcmNlbnQnKSB7XHJcbiAgICAgICAgICBpZiAocm93WydmdW5kbXZDaGFuZ2UnXS50b1N0cmluZygpLmluZGV4T2YoJy0nKSAhPT0gLTEgJiYgcm93WydmdW5kbXZDaGFuZ2UnXS50b1N0cmluZygpLmluZGV4T2YoJy0nKSA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1uYWdldGl2ZSc7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gJyBpcy1wb3NpdGl2ZSc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmKHZhbHVlID09PSAwKSB7XHJcbiAgICAgICAgICByZXR1cm4gJyBpcy16ZXJvJztcclxuICAgICAgICB9XHJcbiAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby1zd2l0Y2gtY2FzZS1mYWxsLXRocm91Z2hcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRDb2xTZXR0aW5nV2lkdGgoY29sKSB7XHJcbiAgICBpZiAoY29sICYmIGNvbC53aWR0aCAmJiAhaXNOYU4oTnVtYmVyKGNvbC53aWR0aCkpKSB7XHJcbiAgICAgIHJldHVybiBjb2wud2lkdGg7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gMTUwO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc2hvd1llbGxvd0FsZXJ0KGZ1bmQsIGNsYXNzSUQpOiBib29sZWFuIHtcclxuICAgIGxldCBzaG93ID0gZmFsc2U7XHJcbiAgICBzaG93ID0gdGhpcy5hbGVydERhdGEuZmluZChpdGVtID0+IGl0ZW0ubmFtZSA9PT0gZnVuZCAmJiBpdGVtLmNsYXNzSUQgPT09IGNsYXNzSUQgJiZpdGVtLmFsZXJ0VHlwZSA9PT0gMSlcclxuICAgIHJldHVybiBzaG93O1xyXG4gIH1cclxuXHJcbiAgc2hvd1JlZEFsZXJ0KGZ1bmQsIGNsYXNzSUQpOiBib29sZWFuIHtcclxuICAgIGxldCBzaG93ID0gZmFsc2U7XHJcbiAgICBzaG93ID0gdGhpcy5hbGVydERhdGEuZmluZChpdGVtID0+IGl0ZW0ubmFtZSA9PT0gZnVuZCAmJiBpdGVtLmNsYXNzSUQgPT09IGNsYXNzSUQgJiYgaXRlbS5hbGVydFR5cGUgPT09IDIpXHJcbiAgICByZXR1cm4gc2hvdztcclxuICB9XHJcblxyXG4gIHNob3dOZXdzKHJvdyk6IGJvb2xlYW4ge1xyXG4gICAgLy8gYWNjb3JkaW5nIHRvIHJvdyBpbmZvIHRvIGRldGVybWluZSBzaG93IG5ld3MgaWNvbiBvciBub3QgXHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcblxyXG4gIGdldFNpZGVDb2xvclN0eWxlKHJvdyk6IHN0cmluZyB7XHJcbiAgICBsZXQgYmFja2dyb3VuZENvbG9yID0gJyc7XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5jb2xvclNjaGVtYS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAocm93ICYmIHJvd1snZnVuZGlkJ10gJiYgaXRlbVsnZnVuZGlkJ10gPT09IHJvd1snZnVuZGlkJ10pIHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3IgPSBpdGVtWydjb2xvciddO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBiYWNrZ3JvdW5kQ29sb3I7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVFeHBhbmRSb3cocm93KSB7XHJcbiAgICBjb25zdCBwYXJlbnRGdW5kSWQgPSByb3cuZnVuZGlkO1xyXG4gICAgbGV0IGN1cnJlbnRFeHBhbmQ7XHJcbiAgICB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAocGFyZW50RnVuZElkID09PSBpdGVtLmZ1bmRpZCkge1xyXG4gICAgICAgIGl0ZW0uZXhwYW5kID0gIWl0ZW0uZXhwYW5kO1xyXG4gICAgICAgIGN1cnJlbnRFeHBhbmQgPSBpdGVtLmV4cGFuZDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBpbmRleCA9IHRoaXMucm93cy5maW5kSW5kZXgoaXRlbSA9PiB7IHJldHVybiBpdGVtLmZ1bmRpZCA9PT0gcGFyZW50RnVuZElkIH0pO1xyXG4gICAgdGhpcy5jaGlsZFJvd3MuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uZnVuZGlkID09PSBwYXJlbnRGdW5kSWQpIHtcclxuICAgICAgICBjdXJyZW50RXhwYW5kID8gdGhpcy5yb3dzLnNwbGljZShpbmRleCArIDEsIDAsIGl0ZW0pIDogdGhpcy5yb3dzLnNwbGljZShpbmRleCArIDEsIDEpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGdldEV4cGFuZENvbGxhcHNlSWNvbihyb3cpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgZnVuZGlkID0gcm93LmZ1bmRpZDtcclxuICAgIGxldCBleHBhbmRGbGFnID0gZmFsc2U7XHJcbiAgICB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoZnVuZGlkID09PSBpdGVtLmZ1bmRpZCkgZXhwYW5kRmxhZyA9IGl0ZW0uZXhwYW5kO1xyXG4gICAgfSlcclxuXHJcbiAgICByZXR1cm4gcm93LmNoaWxkID09PSBcImNoaWxkXCIgPyBcIlwiIDogZXhwYW5kRmxhZyA/IFwiYXJyb3dfZG93blwiIDogXCJhcnJvd19yaWdodFwiO1xyXG4gIH1cclxuXHJcbiAgZ2V0Um93SGVpZ2h0KHBhcmEpIHtcclxuICAgLy8gZGVidWdnZXI7XHJcbiAgICBwYXJhID09PSAnc3RhbmRhcmQnID8gdGhpcy5yb3dIZWlnaHQgPSA1MCA6IHRoaXMucm93SGVpZ2h0ID0gNDA7XHJcbiAgfVxyXG5cclxuICBvbkNsaWNrZWRPdXRzaWRlKGU6IEV2ZW50KSB7XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5jbGlja2VkT3V0U2lkZS5lbWl0KGUpO1xyXG4gIH1cclxuXHJcbiAgc2VsZWN0Q3VycmVudENvbChldmVudCwgcHJvcCkge1xyXG4gICAgdGhpcy5zZWxlY3RlZENvbCA9IHByb3A7XHJcbiAgICBldmVudC5jdXJyZW50VGFyZ2V0LmNsYXNzTGlzdC5hZGQoXCJkcm9wLWlzLXZpc2libGVcIik7XHJcbiAgfVxyXG5cclxuICBjbG9zZU1lbnUoKSB7XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiZHJvcC1pcy12aXNpYmxlXCIpWzBdLmNsYXNzTGlzdC5yZW1vdmUoXCJkcm9wLWlzLXZpc2libGVcIik7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICBvblJlc2l6ZShldmVudCkge1xyXG4gICAvL2NhbGN1dGUgIGRhdGF0YWJsZS1ib2R5IGhlaWdodCBhY2NvcmRpbmcgdG8gZ3JpZHN0ZXItaXRlbSBoZWlnaHQgXHJcbiAgIHZhciBoZWlnaHQ9TnVtYmVyKChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCd0YWJsZS1sYXlvdXQnKVswXSBhcyBIVE1MRWxlbWVudCkuc3R5bGUuaGVpZ2h0LnNsaWNlKDAsIGxlbmd0aC0yKSk7XHJcbiAgIHZhciB0YWJsZUJvZHlIZWlnaHQ9MjYwO1xyXG5cclxuICAgIGhlaWdodCA9IChoZWlnaHQtMTQ4ICk+IHRhYmxlQm9keUhlaWdodCA/IHRhYmxlQm9keUhlaWdodCA6IGhlaWdodC0xNDg7XHJcbiAgICBpZihkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdkYXRhdGFibGUtYm9keScpWzBdKXtcclxuICAgIChkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdkYXRhdGFibGUtYm9keScpWzBdIGFzIEhUTUxFbGVtZW50KS5zdHlsZS5oZWlnaHQgPSBoZWlnaHQgKyAncHgnO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0TWF0TWVudUl0ZW1EaXNwbGF5bmFtZShuYW1lKSB7XHJcbiAgICBzd2l0Y2ggKG5hbWUpIHtcclxuICAgICAgY2FzZSAnU29ydCBDb2x1bW4nOlxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWdbdGhpcy5zZWxlY3RlZENvbF0gPyAnRGlzYWJsZSBTb3J0JyA6ICdTb3J0IENvbHVtbic7XHJcbiAgICAgIGNhc2UgJ0ZyZWV6ZSBDb2x1bW4nOlxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldEZyb3plbkljb25EaXNwbGF5RmFsZyh0aGlzLnNlbGVjdGVkQ29sKSA/ICdVbmZyZWV6ZSBDb2x1bW4nIDogJ0ZyZWV6ZSBDb2x1bW4nXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuIG5hbWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRGcm96ZW5JY29uRGlzcGxheUZhbGcoY29sUHJvcCkge1xyXG4gICAgbGV0IGZyZWV6ZUZsYWcgPSBmYWxzZTtcclxuICAgIHRoaXMubm9ybWFsQ29sdW1uLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnByb3AgPT09IGNvbFByb3AgJiYgaXRlbS5mcm96ZW5MZWZ0KSB7XHJcbiAgICAgICAgZnJlZXplRmxhZyA9IHRydWVcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmcmVlemVGbGFnO1xyXG4gIH1cclxuXHJcbiAgaGFuZGxlTWVudUl0ZW1DbGljayh0eXBlKSB7XHJcbiAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgY2FzZSAncmVzaXplVG9GaXQnOlxyXG4gICAgICAgIHRoaXMucmVzaXplVG9GaXQoKTtcclxuICAgICAgICByZXR1cm5cclxuICAgICAgY2FzZSAnZnJlZXplQ29sdW1uJzpcclxuICAgICAgICB0aGlzLmZyZWV6ZUNvbHVtbigpO1xyXG4gICAgICAgIHJldHVyblxyXG4gICAgICBjYXNlICdzb3J0Q29sdW1uJzpcclxuICAgICAgICB0aGlzLnNvcnRDb2x1bW4oKTtcclxuICAgICAgICByZXR1cm5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL3RvZG8uLi5cclxuICByZXNpemVUb0ZpdCgpIHtcclxuICAgIGNvbnNvbGUubG9nKHRoaXMuc2VsZWN0ZWRDb2wpO1xyXG4gICAgdGhpcy5zZWxlY3RlZENvbCA9IFwiXCI7XHJcbiAgfVxyXG5cclxuICBmcmVlemVDb2x1bW4oKSB7XHJcbiAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKChpdGVtLCBpKSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnByb3AgPT0gdGhpcy5zZWxlY3RlZENvbCkge1xyXG4gICAgICAgIGl0ZW0uZnJvemVuTGVmdCA9ICFpdGVtLmZyb3plbkxlZnQ7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICB9XHJcblxyXG4gIHN5bmNDb2x1bW5TZXR0aW5nRm9yU29ydEZsYWcoc2VsZWN0ZWRDb2wpIHtcclxuICAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKChpdGVtLCBpKSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnByb3AgPT09IHNlbGVjdGVkQ29sICkge1xyXG4gICAgICAgIGl0ZW0uc29ydENvbHVtbkFzY09yRGVzYyA9IHRoaXMuYXNjRmxhZztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpdGVtLnNvcnRDb2x1bW5Bc2NPckRlc2MgPSAnJztcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzb3J0Q29sdW1uKCkge1xyXG4gICB0aGlzLnN5bmNDb2x1bW5TZXR0aW5nRm9yU29ydEZsYWcodGhpcy5zZWxlY3RlZENvbCk7XHJcbiAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5nZXRTb3J0SWNvbkRpc3BsYXlGbGFnKSB7XHJcbiAgICAgIGlmIChrZXkgPT09IHRoaXMuc2VsZWN0ZWRDb2wpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZ2V0U29ydEljb25EaXNwbGF5RmxhZ1trZXldKSB7XHJcbiAgICAgICAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgICAgICAgbWFwOiB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcCxcclxuICAgICAgICAgICAgcHJvcDogdGhpcy5zZWxlY3RlZENvbCxcclxuICAgICAgICAgICAgYXNjRmxhZzogdHJ1ZVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNvcnREYXRhdGFibGVDb2x1bW4uZW1pdChkYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8gdGhlIGRlZmF1bHQgb3JkZXIgaXMgc29ydGVkIGJ5IGZ1bmRpZC5cclxuICAgICAgICAgIGxldCBkYXRhID0ge1xyXG4gICAgICAgICAgICBtYXA6IHRoaXMuZXhwYW5kQ29sbGFwc2VJY29uTWFwLFxyXG4gICAgICAgICAgICBwcm9wOiB0aGlzLmRlZmF1bHRTb3J0Q29sLFxyXG4gICAgICAgICAgICBhc2NGbGFnOiB0cnVlXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc29ydERhdGF0YWJsZUNvbHVtbi5lbWl0KGRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWdba2V5XSA9ICF0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWdba2V5XTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWdba2V5XSA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aGlzLnNlbGVjdGVkQ29sID0gXCJcIjtcclxuICB9XHJcblxyXG4gIGNoYW5nZUFzY0FuZERlc2NTb3J0KGUsIHByb3ApIHtcclxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICBpZiAodGhpcy5hc2NGbGFnID09PSBcImFzY1wiKSB7XHJcbiAgICAgIHRoaXMuYXNjRmxhZyA9IFwiZGVzY1wiO1xyXG4gICAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgICBtYXA6IHRoaXMuZXhwYW5kQ29sbGFwc2VJY29uTWFwLFxyXG4gICAgICAgIHByb3A6IHByb3AsXHJcbiAgICAgICAgYXNjRmxhZzogZmFsc2VcclxuICAgICAgfTtcclxuICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc29ydERhdGF0YWJsZUNvbHVtbi5lbWl0KGRhdGEpO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLmFzY0ZsYWcgPT09IFwiZGVzY1wiKSB7XHJcbiAgICAgIHRoaXMuYXNjRmxhZyA9IFwiYXNjXCI7XHJcbiAgICAgIGxldCBkYXRhID0ge1xyXG4gICAgICAgIG1hcDogdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAsXHJcbiAgICAgICAgcHJvcDogcHJvcCxcclxuICAgICAgICBhc2NGbGFnOiB0cnVlXHJcbiAgICAgIH07XHJcbiAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNvcnREYXRhdGFibGVDb2x1bW4uZW1pdChkYXRhKTtcclxuICAgIH1cclxuICAgIHRoaXMuc3luY0NvbHVtblNldHRpbmdGb3JTb3J0RmxhZyhwcm9wKTtcclxuICAgIHRoaXMuc2VsZWN0ZWRDb2wgPSBcIlwiO1xyXG4gIH1cclxuXHJcbiAgZ2V0U29ydEljb25EaXNwbGF5U3R5KHByb3ApIHtcclxuICAgIGxldCB2aXNpYmlsaXR5ID0gZmFsc2U7XHJcbiAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5wcm9wID09PSBwcm9wICYmIGl0ZW0uc29ydENvbHVtbkFzY09yRGVzYykgdmlzaWJpbGl0eSA9IHRydWU7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHZpc2liaWxpdHk7XHJcbiAgfVxyXG5cclxuICBnZXRTb3J0SWNvbihwcm9wKSB7XHJcbiAgICBsZXQgaWNvbiA9ICcnO1xyXG4gICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0ucHJvcCA9PT0gcHJvcClcclxuICAgICAgaWNvbiA9IGl0ZW0uc29ydENvbHVtbkFzY09yRGVzY1xyXG4gICAgfSlcclxuICAgIGlmIChpY29uICE9PSAnJykge1xyXG4gICAgICByZXR1cm4gaWNvbiA9PT0gXCJhc2NcIiA/IFwiY2lyY2xlX2Fycm93X3VwXCIgOiBcImNpcmNsZV9hcnJvd19kb3duXCI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gdGhpcy5hc2NGbGFnID09PSBcImFzY1wiID8gXCJjaXJjbGVfYXJyb3dfdXBcIiA6IFwiY2lyY2xlX2Fycm93X2Rvd25cIjtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJlbW92ZU9yQWRkQ29sdW1uKGNvbCwgaW5kZXgpIHtcclxuICAgIGNvbnNvbGUubG9nKGNvbC5wcm9wICsgXCItLS1cIiArIGluZGV4ICsgXCItLVwiICsgdGhpcy5zZWxlY3RlZENvbCk7XHJcbiAgICB0aGlzLnNlbGVjdGVkQ29sID0gXCJcIjtcclxuICB9XHJcblxyXG4gIGh5cGVyTGlua05hdmlnYXRlKHJvdykge1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaHlwZXJMaW5rTmF2aWdhdGUuZW1pdChyb3cpO1xyXG4gIH1cclxuXHJcbiAgb3BlbkFsZXJ0TW9kYWwocm93LCB0eXBlKSB7XHJcbiAgICBsZXQgb2JqID0ge1xyXG4gICAgICByb3dEYXRhOiByb3csXHJcbiAgICAgIHR5cGU6IHR5cGVcclxuICAgIH07XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5vcGVuTW9kYWxEYXRhLmVtaXQob2JqKVxyXG4gIH1cclxuXHJcbiAgdG9nZ2xlUGF1c2VGbGFnKCkge1xyXG4gICAgdGhpcy5pc0RhdGFUYWJsZVBhdXNlZCA9ICF0aGlzLmlzRGF0YVRhYmxlUGF1c2VkO1xyXG4gICAgdGhpcy50b2dnbGVQYXVzZUZsYWdFdmVudC5lbWl0KCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJleHBvcnQgY29uc3QgY3VzdG9tQ29sdW1uID0gW1xyXG4gICAge1xyXG4gICAgICB0eXBlOiBcInJlZEFsZXJ0XCIsXHJcbiAgICAgIGRldGFpbHM6IFwiXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0eXBlOiBcInllbGxvd0FsZXJ0XCIsXHJcbiAgICAgIGRldGFpbHM6IFwiXCIsXHJcbiAgICB9XHJcbiAgXTtcclxuXHJcbiAgZXhwb3J0IGNvbnN0IG5vcm1hbENvbHVtbiA9ICBbXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICduYW1lJyxcclxuICAgICAgbmFtZTogJ0VudGl0eSBOYW1lJyxcclxuICAgICAgd2lkdGg6IDIwMCxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiBmYWxzZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnaHlwZXJMaW5rJyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJDZW50ZXInLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsQ2VudGVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdmdW5kaWQnLFxyXG4gICAgICBuYW1lOiAnRW50aXR5IElkIFJlZicsXHJcbiAgICAgIHdpZHRoOiAxMjAsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2RlZmF1bHQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlckxlZnQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTGVmdCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnZnVuZFRpY2tlcicsXHJcbiAgICAgIG5hbWU6ICdFbnRpdHkgVGlja2VyJyxcclxuICAgICAgd2lkdGg6IDEyMCxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiBmYWxzZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnZGVmYXVsdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyTGVmdCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxMZWZ0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdjbGFzc0lEJyxcclxuICAgICAgbmFtZTogJ0NsYXNzIElEJyxcclxuICAgICAgd2lkdGg6IDgwLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2RlZmF1bHQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlckxlZnQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTGVmdCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnc29kTmF2JyxcclxuICAgICAgbmFtZTogJ05BViBQcmV2aW91cycsXHJcbiAgICAgIHdpZHRoOiAxMjUsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0TG9uZycsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsUmlnaHQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ25hdicsXHJcbiAgICAgIG5hbWU6ICdOQVYgQ3VycmVudCcsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRMb25nJyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbmF2Q2hhbmdlJyxcclxuICAgICAgbmFtZTogJ05BViBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0TG9uZycsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICduYXZDaGFuZ2VQZXJjZW50JyxcclxuICAgICAgbmFtZTogJ05BViAlIENoYW5nZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdwZXJjZW50Rm9ybWF0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxOdW1iZXInLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ3NvZFRuYScsXHJcbiAgICAgIG5hbWU6ICdUTkEgUHJldmlvdXMnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICd0bmEnLFxyXG4gICAgICBuYW1lOiAnVE5BIEN1cnJlbnQnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICd0bmFDaGFuZ2UnLFxyXG4gICAgICBuYW1lOiAnVE5BIENoYW5nZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRTaG9ydCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICd0bmFDaGFuZ2VQZXJjZW50JyxcclxuICAgICAgbmFtZTogJ1ROQSAlIENoYW5nZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdwZXJjZW50Rm9ybWF0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxOdW1iZXInLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ3NvZE12JyxcclxuICAgICAgbmFtZTogJ01WIEFtdCBCYXNlIFByZXZpb3VzJyxcclxuICAgICAgd2lkdGg6ICcyMDAnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnZnVuZG12JyxcclxuICAgICAgbmFtZTogJ01WIEFtdCBCYXNlJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnZnVuZG12Q2hhbmdlJyxcclxuICAgICAgbmFtZTogJ01WIENoYW5nZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRTaG9ydCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdmdW5kbXZDaGFuZ2VQZXJjZW50JyxcclxuICAgICAgbmFtZTogJ01WICUgQ2hhbmdlJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ3BlcmNlbnRGb3JtYXQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbE51bWJlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9XHJcbiAgXTtcclxuXHJcbiAgZXhwb3J0IGNvbnN0IGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmcgPSBbXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IFwiUmVzaXplIHRvIEZpdFwiLFxyXG4gICAgLy8gICB0eXBlOiBcInJlc2l6ZVRvRml0XCIsXHJcbiAgICAvLyAgIGhhc1N1Yk1lbnU6IGZhbHNlLFxyXG4gICAgLy8gfSxcclxuICAgIHtcclxuICAgICAgbmFtZTogXCJGcmVlemUgQ29sdW1uXCIsXHJcbiAgICAgIHR5cGU6IFwiZnJlZXplQ29sdW1uXCIsXHJcbiAgICAgIGhhc1N1Yk1lbnU6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbmFtZTogXCJTb3J0IENvbHVtblwiLFxyXG4gICAgICB0eXBlOiBcInNvcnRDb2x1bW5cIixcclxuICAgICAgaGFzU3ViTWVudTogZmFsc2UsXHJcbiAgICB9LFxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBcIlZpZXcgTW9yZSBDb2x1bW5zXCIsXHJcbiAgICAvLyAgIHR5cGU6IFwidmlld01vcmVDb2x1bW5zXCIsXHJcbiAgICAvLyAgIGhhc1N1Yk1lbnU6IHRydWUsXHJcbiAgICAvLyB9LFxyXG4gIF07IiwiaW1wb3J0IHtcclxuICBDb21wb25lbnQsXHJcbiAgVmlld0NoaWxkLFxyXG4gIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gIENoYW5nZURldGVjdG9yUmVmLFxyXG4gIFZpZXdDb250YWluZXJSZWYsXHJcbiAgSG9zdExpc3RlbmVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJhc2VXaWRnZXRDb21wb25lbnQsIEFwcENvbnRleHQsIEFwcFJlZ2lzdHJ5IH0gZnJvbSAnQG9tbmlhL3VpLWNvbW1vbic7XHJcbmltcG9ydCB7IE5hdlNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9uYXYtc2VydmljZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2U29ja2V0U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zb2NrZXQuc2VydmljZSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTWF0RGlhbG9nIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyBDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi4vY3VzdG9tLWFsZXJ0LW1vZGFsL2N1c3RvbS1hbGVydC1tb2RhbC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvcmVzb3VyY2UtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgY3VzdG9tQ29sdW1uLCBub3JtYWxDb2x1bW4sIGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmcgfSBmcm9tICcuL2NvbHVtbi1kYXRhJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLW1haW4tZGF0YXRhYmxlJyxcclxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJkYXRhdGFibGVDb250YWluZXJcIiAqbmdJZj1cImlzRGF0YUF2YWlsYWJsZVwiIChjbGlja091dHNpZGUpPVwib25DbGlja2VkT3V0c2lkZSgkZXZlbnQpXCI+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJsaXZlLXRpbWUtZm9yLXRpdGxlXCI+XHJcbiAgICA8cCAqbmdJZj1cImNvbW1vblV0aWxzLmlzQWZ0ZXJNYXJrZXRDbG9zZSBlbHNlIGVsc2VCbG9ja1wiPkZpbmFsIERhdGEgKFxyXG4gICAgICB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTpcIk1NL2RkL3l5eXksIGg6bW0gYWFhYWEnbSdcIn19ICk8L3A+XHJcbiAgICA8bmctdGVtcGxhdGUgI2Vsc2VCbG9jaz5cclxuICAgICAgPHA+XHJcbiAgICAgICAgUmVhbCBUaW1lIERhdGEgKHt7Y29tbW9uVXRpbHMubGl2ZVRpbWUgfCBkYXRlOlwiTU0vZGQveXl5eSwgaDptbSBhYWFhYSdtJ1wifX0pXHJcbiAgICAgIDwvcD5cclxuICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgPC9kaXY+XHJcbiAgXHJcbjxsaWItY29tbW9uLWRhdGEtdGFibGVcclxuW2hlYWRlclNldHRpbmddPVwiaGVhZGVyU2V0dGluZ1wiXHJcbltpc0RhdGFUYWJsZVBhdXNlZF09XCJpc0RhdGFUYWJsZVBhdXNlZFwiXHJcbltoZWFkZXJIZWlnaHRdPVwiaGVhZGVySGVpZ2h0XCJcclxuW3Jvd3NdPVwicm93c1wiXHJcbltjaGlsZFJvd3NdPVwiY2hpbGRSb3dzXCJcclxuW2FsZXJ0RGF0YV09XCJhbGVydERhdGFcIlxyXG5bcm93SGVpZ2h0XT1cInJvd0hlaWdodFwiXHJcbltjdXN0b21Db2x1bW5dPVwiY3VzdG9tQ29sdW1uXCJcclxuW25vcm1hbENvbHVtbl09XCJub3JtYWxDb2x1bW5cIlxyXG5bbGltaXRdPVwibGltaXRcIlxyXG5bZm9vdGVySGVpZ2h0XT1cImZvb3RlckhlaWdodFwiXHJcbltoZWFkZXJDaGVja0JveF09XCJoZWFkZXJDaGVja0JveFwiXHJcbltnZXRBbGxSb3dzRGlzYWJsZWRdPVwiZ2V0QWxsUm93c0Rpc2FibGVkXCJcclxuW2dldFNpbmdsZVJvd0Rpc2FibGVkXT1cImdldFNpbmdsZVJvd0Rpc2FibGVkXCJcclxuW2dldEFsbFJvd0NoZWNrZWRdPVwiZ2V0QWxsUm93Q2hlY2tlZFwiXHJcbltnZXRTaW5nbGVSb3dDaGVja2VkXT1cImdldFNpbmdsZVJvd0NoZWNrZWRcIlxyXG5bb25TZWxlY3RBbGxdPVwib25TZWxlY3RBbGxcIlxyXG5bb25DaGVja2JveENoYW5nZV09XCJvbkNoZWNrYm94Q2hhbmdlXCJcclxuW2FsbFJvd3NTZWxlY3RlZF09XCJhbGxSb3dzU2VsZWN0ZWRcIlxyXG5bY29sdW1uTWVudURyb3BEb3duU2V0dGluZ109J2NvbHVtbk1lbnVEcm9wRG93blNldHRpbmcnXHJcbltkZWZhdWx0U29ydENvbF09XCInZnVuZGlkJ1wiXHJcbih0b2dnbGVQYXVzZUZsYWdFdmVudCk9XCJ0b2dnbGVQYXVzZUZsYWcoKVwiXHJcbj5cclxuPC9saWItY29tbW9uLWRhdGEtdGFibGU+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnN0cmlwZWQgLmRhdGF0YWJsZS1yb3ctb2Rke2JhY2tncm91bmQ6I2VlZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzMwNGZmZTtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMTkzYWU0O2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMyMDQxZWY7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNlZWU7dHJhbnNpdGlvbi1wcm9wZXJ0eTpiYWNrZ3JvdW5kO3RyYW5zaXRpb24tZHVyYXRpb246LjNzO3RyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uOmxpbmVhcn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbDpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmVtcHR5LXJvd3toZWlnaHQ6NTBweDt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouNXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAubG9hZGluZy1yb3d7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1yb3ctbGVmdHtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1wb3NpdGlvbjoxMDAlIDA7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJSFdQU2tOZVNCbUpoVFFWdGJpRE5DZ0FTYWdJSXVKWDhPZ0FBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LXJpZ2h0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0e2JhY2tncm91bmQtcG9zaXRpb246MCAwO2JhY2tncm91bmQtY29sb3I6I2ZmZjtiYWNrZ3JvdW5kLXJlcGVhdDpyZXBlYXQteTtiYWNrZ3JvdW5kLWltYWdlOnVybChkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFRQUFBQUJDQVlBQUFENVBBL05BQUFBRmtsRVFWUUkxMlBRa05kaTFWVFE1Z2JTd2tBc0RRQVJMQUlHdE9TRlVBQUFBQUJKUlU1RXJrSmdnZz09KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlcntib3gtc2hhZG93OjAgMnB4IDRweCAwIHJnYmEoMCwwLDAsLjE1KTtwb3NpdGlvbjpzdGlja3k7cG9zaXRpb246LXdlYmtpdC1zdGlja3k7dG9wOjA7ei1pbmRleDo5OTk7YmFja2dyb3VuZC1jb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGx7dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6cmdiYSgwLDAsMCwuNTQpO3ZlcnRpY2FsLWFsaWduOmJvdHRvbTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo1MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsLXdyYXBwZXJ7cG9zaXRpb246cmVsYXRpdmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5sb25ncHJlc3MgLmRyYWdnYWJsZTo6YWZ0ZXJ7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjRzLG9wYWNpdHkgLjRzLC13ZWJraXQtdHJhbnNmb3JtIC40cztvcGFjaXR5Oi41Oy13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKDEpO3RyYW5zZm9ybTpzY2FsZSgxKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kcmFnZ2FibGU6OmFmdGVye2NvbnRlbnQ6XCIgXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjUwJTtsZWZ0OjUwJTttYXJnaW46LTMwcHggMCAwIC0zMHB4O2hlaWdodDo2MHB4O3dpZHRoOjYwcHg7YmFja2dyb3VuZDojZWVlO2JvcmRlci1yYWRpdXM6MTAwJTtvcGFjaXR5OjE7LXdlYmtpdC1maWx0ZXI6bm9uZTtmaWx0ZXI6bm9uZTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgwKTt0cmFuc2Zvcm06c2NhbGUoMCk7ei1pbmRleDo5OTk5O3BvaW50ZXItZXZlbnRzOm5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC5kcmFnZ2luZyAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6bm9uZX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAucmVzaXplLWhhbmRsZXtib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtcm93LWRldGFpbHtiYWNrZ3JvdW5kOiNmNWY1ZjU7cGFkZGluZzoxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWdyb3VwLWhlYWRlcntiYWNrZ3JvdW5kOiNmNWY1ZjU7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgI2Q5ZDhkOTtib3JkZXItdG9wOjFweCBzb2xpZCAjZDlkOGQ5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse3RleHQtYWxpZ246Y2VudGVyO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7bGluZS1oZWlnaHQ6NTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktZ3JvdXAtY2VsbHt0ZXh0LWFsaWduOmxlZnQ7cGFkZGluZzouOXJlbSAxLjJyZW07dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDtjb2xvcjojMzUzNTM1O3RyYW5zaXRpb246d2lkdGggLjNzO2ZvbnQtc2l6ZToxNHB4O2ZvbnQtd2VpZ2h0OjQwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLnByb2dyZXNzLWxpbmVhcntkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCU7aGVpZ2h0OjVweDtwYWRkaW5nOjA7bWFyZ2luOjA7cG9zaXRpb246YWJzb2x1dGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lcntkaXNwbGF5OmJsb2NrO3Bvc2l0aW9uOnJlbGF0aXZlO292ZXJmbG93OmhpZGRlbjt3aWR0aDoxMDAlO2hlaWdodDo1cHg7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTtiYWNrZ3JvdW5kLWNvbG9yOiNhYWQxZjl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXIgLmNvbnRhaW5lciAuYmFye3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXI7LXdlYmtpdC1hbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O2FuaW1hdGlvbjouOHMgY3ViaWMtYmV6aWVyKC4zOSwuNTc1LC41NjUsMSkgaW5maW5pdGUgcXVlcnk7dHJhbnNpdGlvbjp0cmFuc2Zvcm0gLjJzIGxpbmVhciwtd2Via2l0LXRyYW5zZm9ybSAuMnMgbGluZWFyO2JhY2tncm91bmQtY29sb3I6IzEwNmNjODtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7dG9wOjA7Ym90dG9tOjA7d2lkdGg6MTAwJTtoZWlnaHQ6NXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVye2JvcmRlci10b3A6MXB4IHNvbGlkIHJnYmEoMCwwLDAsLjEyKTtmb250LXNpemU6MTJweDtmb250LXdlaWdodDo0MDA7Y29sb3I6cmdiYSgwLDAsMCwuNTQpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5wYWdlLWNvdW50e2xpbmUtaGVpZ2h0OjUwcHg7aGVpZ2h0OjUwcHg7cGFkZGluZzowIDEuMnJlbX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2Vye21hcmdpbjowIDEwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaXt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5kaXNhYmxlZCBhe2NvbG9yOnJnYmEoMCwwLDAsLjI2KSFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCFpbXBvcnRhbnR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBsaS5hY3RpdmUgYXtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpO2ZvbnQtd2VpZ2h0OjcwMH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIGF7aGVpZ2h0OjIycHg7bWluLXdpZHRoOjI0cHg7bGluZS1oZWlnaHQ6MjJweDtwYWRkaW5nOjAgNnB4O2JvcmRlci1yYWRpdXM6M3B4O21hcmdpbjo2cHggM3B4O3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt0ZXh0LWRlY29yYXRpb246bm9uZTt2ZXJ0aWNhbC1hbGlnbjpib3R0b219Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhOmhvdmVye2NvbG9yOnJnYmEoMCwwLDAsLjc1KTtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTU4LDE1OCwxNTgsLjIpfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLWxlZnQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcHJldiwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1za2lwe2ZvbnQtc2l6ZToyMHB4O2xpbmUtaGVpZ2h0OjIwcHg7cGFkZGluZzowIDNweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3csLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVye2JhY2tncm91bmQtY29sb3I6I2RkZH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLXN1bW1hcnktcm93IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWNlbGx7Zm9udC13ZWlnaHQ6NzAwfS5kYXRhdGFibGUtY2hlY2tib3h7cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjA7Y3Vyc29yOnBvaW50ZXI7dmVydGljYWwtYWxpZ246bWlkZGxlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO2JveC1zaXppbmc6Ym9yZGVyLWJveDtwYWRkaW5nOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XXtwb3NpdGlvbjpyZWxhdGl2ZTttYXJnaW46MCAxcmVtIDAgMDtjdXJzb3I6cG9pbnRlcjtvdXRsaW5lOjB9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpiZWZvcmV7dHJhbnNpdGlvbjouM3MgZWFzZS1pbi1vdXQ7Y29udGVudDpcIlwiO3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MDt6LWluZGV4OjE7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtib3JkZXI6MnB4IHNvbGlkICNmMmYyZjJ9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTpjaGVja2VkOmJlZm9yZXstd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTt0cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7aGVpZ2h0Oi41cmVtO2JvcmRlci1jb2xvcjojMDA5Njg4O2JvcmRlci10b3Atc3R5bGU6bm9uZTtib3JkZXItcmlnaHQtc3R5bGU6bm9uZX0uZGF0YXRhYmxlLWNoZWNrYm94IGlucHV0W3R5cGU9Y2hlY2tib3hdOmFmdGVye2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MDtsZWZ0OjA7d2lkdGg6MXJlbTtoZWlnaHQ6MXJlbTtiYWNrZ3JvdW5kOiNmZmY7Y3Vyc29yOnBvaW50ZXJ9QC13ZWJraXQta2V5ZnJhbWVzIHF1ZXJ5ezAle29wYWNpdHk6MTstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKX0xMDAle29wYWNpdHk6MDstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKX19QGtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy16ZXJve3RleHQtYWxpZ246cmlnaHQ7dmVydGljYWwtYWxpZ246dG9wO2JvcmRlci10b3A6MDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1uYWdldGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6I2I5MTIyNDt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLWJvZHktcm93IC5pcy1wb3NpdGl2ZXt0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzI4NzQzZTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDA7cGFkZGluZy1yaWdodDoyNXB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1hbGlnbi1sZWZ0e3RleHQtYWxpZ246bGVmdDtjb2xvcjojMzUzNTM1fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtY29sdW1uLWhlYWRlci1jZW50ZXJ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tcmlnaHR7dGV4dC1hbGlnbjpyaWdodDtjb2xvcjojMzUzNTM1fWJ1dHRvbi5tYXQtbWVudS1pdGVte2hlaWdodDozMHB4O2xpbmUtaGVpZ2h0OjMwcHg7Zm9udC1zaXplOjEzcHg7ZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWF0LW1lbnUtaXRlbTpob3Zlcjpub3QoW2Rpc2FibGVkXSl7YmFja2dyb3VuZDojZTFlY2YyfS5jaGVjay1pY29uLm1hdC1pY29ue3dpZHRoOjE0cHg7aGVpZ2h0OjE0cHg7bWFyZ2luLWxlZnQ6MjBweDtjb2xvcjojMDAwfS5uZ3gtZGF0YXRhYmxlLmZpeGVkLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1pbm5lcntoZWlnaHQ6MTAwJX1gLCBgLmRhdGF0YWJsZUNvbnRhaW5lciAubGl2ZS10aW1lLWZvci10aXRsZXtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MnB4O2xlZnQ6MTVweDtmb250LXNpemU6MTZweDtmb250LWZhbWlseTpESU5OZXh0TFRQcm8tTWVkaXVtO2NvbG9yOiM0NjQ2NDZ9YF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTWFpbkRhdGF0YWJsZUNvbXBvbmVudCBleHRlbmRzIEJhc2VXaWRnZXRDb21wb25lbnQge1xyXG5cclxuICBwcml2YXRlIHN1YnM6IFN1YnNjcmlwdGlvbltdO1xyXG4gIHJvd3M6IGFueVtdID0gW107XHJcbiAgY2hpbGRSb3dzOiBhbnlbXSA9IFtdO1xyXG4gIGlzRGF0YUF2YWlsYWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGlzRGF0YVRhYmxlUGF1c2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgcm93SGVpZ2h0Om51bWJlcj01MDtcclxuICBhbGVydERhdGE6IGFueVtdID0gW107XHJcbiAgYWxsUm93c1NlbGVjdGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgaXNTZWxlY3RlZE1hcDogYW55W10gPSBbXTtcclxuICBoZWFkZXJTZXR0aW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICBoZWFkZXJIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIC8vIHRlbXAgZGF0YSBzdHJ1Y3R1cmVcclxuICBjdXN0b21Db2x1bW46IGFueVtdID0gY3VzdG9tQ29sdW1uO1xyXG4gIG5vcm1hbENvbHVtbjogYW55W10gPSBub3JtYWxDb2x1bW47XHJcbiAgY29sdW1uTWVudURyb3BEb3duU2V0dGluZzogYW55W10gPSBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nO1xyXG4gIGxpbWl0OiBudW1iZXIgPSA1O1xyXG4gIGZvb3RlckhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgaGVhZGVyQ2hlY2tCb3g6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICBwcml2YXRlIGludGVydmFsOiBhbnk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2Q6IENoYW5nZURldGVjdG9yUmVmLCBwcml2YXRlIG5hdlNlcnZpY2U6IE5hdlNlcnZpY2UsXHJcbiAgICBwcml2YXRlIGFwcFJlZ2lzdHJ5OiBBcHBSZWdpc3RyeSwgcHJpdmF0ZSBhcHBDb250ZXh0OiBBcHBDb250ZXh0LFxyXG4gICAgcHJpdmF0ZSBuYXZTb2NrZXRTZXJ2aWNlOiBOYXZTb2NrZXRTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBkaWFsb2c6IE1hdERpYWxvZyxcclxuICAgIHByaXZhdGUgdmlld0NvbnRhaW5lcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgIHByaXZhdGUgc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzOiBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSxcclxuICAgIHB1YmxpYyBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSByZXNvdXJjZU1hbmdlcjogUmVzb3VyY2VNYW5hZ2VyU2VydmljZSkge1xyXG4gICAgc3VwZXIoKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgLy9yZXNldCBjb21wb25lbnQgZGF0YSBhbmQgdXNlciB2YWxpZGF0aW9uO1xyXG4gICAgdGhpcy5jb21tb25VdGlscy52YWxpZGF0ZVVzZXIoKTtcclxuICAgIHRoaXMuc3VicyA9IFtdO1xyXG4gICAgdGhpcy5yb3dzID0gW107XHJcbiAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IGZhbHNlO1xyXG4gICAgdGhpcy5zdWJzLnB1c2godGhpcy5uYXZTZXJ2aWNlLmdldEZ1bmRMaXN0KCkuc3Vic2NyaWJlKFxyXG4gICAgICBkYXRhID0+IHtcclxuICAgICAgICB0aGlzLnJvd3MgPSB0aGlzLmNvbW1vblV0aWxzLmV4dHJhY3RGdW5kTGV2ZWxEYXRhKGRhdGEpO1xyXG4gICAgICAgIHRoaXMuY2hpbGRSb3dzID0gdGhpcy5jb21tb25VdGlscy5leHRyYWN0Q2xhc3NMZXZlbERhdGEoZGF0YSk7XHJcbiAgICAgICAgaWYgKGRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgLy90aGlzLmFsZXJ0RGF0YSA9IFsuLi50aGlzLnVwZGF0ZUFsZXJ0RGF0YSh0aGlzLnJvd3MpXTtcclxuICAgICAgICAgIHRoaXMuYWxlcnREYXRhID0gWy4uLnRoaXMudXBkYXRlQWxlcnREYXRhQXRDbGFzc0xldmVsKGRhdGEpXTtcclxuICAgICAgICAgIHRoaXMuaXNEYXRhQXZhaWxhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgIC8vIHNldGluZyBwb3NpdGlvbiBwYWdlIGRlZmF1bHQgZnVuZCBpbmZvIGlmIGZ1bmRJbmZvIGlzIG51bGxcclxuICAgICAgICAgIGlmICh0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5mdW5kSW5mby5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgY29uc3QgZnVuZEluZm8gPSBbXTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRpZCk7XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5uYW1lKTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRUaWNrZXIpXHJcbiAgICAgICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNhdmVQb3NpdGlvbkRldGFpbHNGdW5kSW5mbyhmdW5kSW5mbyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucm93cyA9IFsuLi50aGlzLnJvd3NdO1xyXG4gICAgICAgIHRoaXMucm93cy5mb3JFYWNoKHJvdyA9PiB7XHJcbiAgICAgICAgICB0aGlzLm5hdlNvY2tldFNlcnZpY2UucmVnaXN0ZXJGdW5kcyhbcm93WydmdW5kaWQnXV0pO1xyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICkpO1xyXG4gICAgdGhpcy5zdWJzLnB1c2godGhpcy5uYXZTb2NrZXRTZXJ2aWNlLmdldE5hdigpLnN1YnNjcmliZShcclxuICAgICAgKGRhdGEpID0+IHtcclxuICAgICAgICBpZiAoZGF0YVsnZXZlbnRUeXBlJ10gPT09ICdmdW5kQ2hhbmdlJykge1xyXG4gICAgICAgICAgY29uc3QgZnVuZExldmVsUm93ID0gdGhpcy5jb21tb25VdGlscy5leHRyYWN0V1NEYXRhKGRhdGFbXCJldmVudERhdGFcIl0sIGZhbHNlKTtcclxuICAgICAgICAgIGNvbnN0IGNoaWxkTGV2ZWxSb3cgPSB0aGlzLmNvbW1vblV0aWxzLmV4dHJhY3RXU0RhdGEoZGF0YVtcImV2ZW50RGF0YVwiXSwgdHJ1ZSk7XHJcbiAgICAgICAgICB0aGlzLnVwZGF0ZVJvdyhmdW5kTGV2ZWxSb3cpO1xyXG4gICAgICAgICAgY2hpbGRMZXZlbFJvdy5mb3JFYWNoKHJvdyA9PiB0aGlzLnVwZGF0ZVJvdyhyb3cpKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGRhdGFbJ2V2ZW50VHlwZSddID09PSAnc29kQ2hhbmdlJykge1xyXG4gICAgICAgICAgdGhpcy5kb3VwZGF0ZShkYXRhW1wiZXZlbnREYXRhXCJdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICkpO1xyXG4gICAgdGhpcy5yZXNvdXJjZU1hbmdlci5yZWdpc3RJbnRlcnZhbCgoKSA9PiB7IHRoaXMucm93cyA9IFsuLi50aGlzLnJvd3NdOyB9LCAzMDApO1xyXG5cclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmh5cGVyTGlua05hdmlnYXRlLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJoeXBlcmxpbmsgbmF2aWdhdGVcIik7XHJcbiAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG4gICAgICB0aGlzLmh5cGVyTGlua05hdmlnYXRlVG8oZGF0YSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5vcGVuTW9kYWxEYXRhLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgdGhpcy5vcGVuQWxlcnRNb2RhbChkYXRhLnJvd0RhdGEsIGRhdGEudHlwZSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zb3J0RGF0YXRhYmxlQ29sdW1uLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgdGhpcy5yb3dzID0gWy4uLnRoaXMuY29tbW9uVXRpbHMuc29ydENvbHVtbkJ5UHJvcCh0aGlzLnJvd3MsIHRoaXMuY2hpbGRSb3dzLCBkYXRhLm1hcCwgZGF0YS5wcm9wLCBkYXRhLmFzY0ZsYWcpXTtcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBuZ09uRGVzdHJveSgpIHtcclxuICAgIHRoaXMucm93cy5mb3JFYWNoKHJvdyA9PiB7XHJcbiAgICAgIHRoaXMubmF2U29ja2V0U2VydmljZS51blJlZ2lzdGVyRnVuZHMoW3Jvd1snZnVuZGlkJ11dKTtcclxuICAgIH0pXHJcbiAgICB0aGlzLnN1YnMuZm9yRWFjaChzdWIgPT4gc3ViLnVuc3Vic2NyaWJlKCkpO1xyXG4gICAgdGhpcy5yZXNvdXJjZU1hbmdlci5jbGVhblJlc291cmNlcygpO1xyXG5cclxuICB9XHJcblxyXG4gIHVwZGF0ZVJvdyhkYXRhKSB7XHJcbiAgICBpZiAoZGF0YSAmJiAhdGhpcy5pc0RhdGFUYWJsZVBhdXNlZCAmJiB0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKSkpIHtcclxuICAgICAgaWYgKGRhdGFbJ2FsZXJ0VHlwZSddICYmIChkYXRhWydhbGVydFR5cGUnXSA9PSAxIHx8IGRhdGFbJ2FsZXJ0VHlwZSddID09PSAyKSkge1xyXG4gICAgICAgIGNvbnN0IGFsZXJ0T2JqID0ge1xyXG4gICAgICAgICAgXCJuYW1lXCI6IGRhdGFbJ2Z1bmRpZCddLFxyXG4gICAgICAgICAgXCJjbGFzc0lEXCI6ZGF0YVsnY2xhc3NJRCddLFxyXG4gICAgICAgICAgXCJhbGVydFR5cGVcIjogZGF0YVsnYWxlcnRUeXBlJ10sXHJcbiAgICAgICAgICBcIm5hdlwiOiBkYXRhWyduYXYnXSxcclxuICAgICAgICAgIFwibWFya2V0dmFsXCI6IGRhdGFbJ2Z1bmRtdiddLFxyXG4gICAgICAgICAgXCJ2YWx1ZVwiOiBkYXRhWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcImZ1bmRtdkNoYW5nZVBlcmNlbnRcIjogZGF0YVsnZnVuZG12Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJwcmljZXRpbWVcIjogZGF0YVsncHJpY2V0aW1lJ10sXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuYWxlcnREYXRhLnB1c2goYWxlcnRPYmopO1xyXG4gICAgICAgIHRoaXMuYWxlcnREYXRhID0gWy4uLnRoaXMuYWxlcnREYXRhXTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmRvdXBkYXRlKGRhdGEpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZG91cGRhdGUoZGF0YSkge1xyXG4gICAgaWYgKHRoaXMucm93cy5sZW5ndGgpIHtcclxuICAgICAgY29uc3QgZnVuZElkID0gZGF0YVsnZnVuZGlkJ107XHJcbiAgICAgIGNvbnN0IGZ1bmRUaWNrZXIgPSBkYXRhWydmdW5kVGlja2VyJ107XHJcbiAgICAgIGNvbnN0IGNsYXNzSUQgPSBkYXRhWydjbGFzc0lEJ107XHJcbiAgICAgIHRoaXMucm93cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgIGlmIChpdGVtWydmdW5kaWQnXSA9PT0gZnVuZElkICYmIGl0ZW1bJ2Z1bmRUaWNrZXInXSA9PT0gZnVuZFRpY2tlciAmJiBpdGVtWydjbGFzc0lEJ10gPT09IGNsYXNzSUQpIHtcclxuICAgICAgICAgIHRoaXMubm9ybWFsQ29sdW1uLmZvckVhY2goY29sSXRlbSA9PiB7IGlmIChudWxsICE9IGRhdGFbY29sSXRlbS5wcm9wXSAmJiAoWydmdW5kaWQnLCAnbmFtZScsICdmdW5kVGlja2VyJywgJ2NsYXNzSUQnXS5pbmRleE9mKGNvbEl0ZW0ucHJvcCkgPT09IC0xKSkgeyBpdGVtW2NvbEl0ZW0ucHJvcF0gPSBkYXRhW2NvbEl0ZW0ucHJvcF0gfSB9KTtcclxuICAgICAgICAgIGNvbnN0IGNvdW50cyA9IHRoaXMuZ2V0QWxlcnRDb3VudHMoZnVuZElkLCBjbGFzc0lELCB0aGlzLmFsZXJ0RGF0YSk7XHJcbiAgICAgICAgICBpdGVtWydyZWRBbGVydCddID0gY291bnRzWzBdO1xyXG4gICAgICAgICAgaXRlbVsneWVsbG93QWxlcnQnXSA9IGNvdW50c1sxXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBnZXRBbGVydENvdW50cyhmdW5kaWQ6IHN0cmluZywgY2xhc3NJRDogc3RyaW5nICxhbGVydHM6IGFueVtdKTogYW55W10ge1xyXG4gICAgbGV0IGNvdW50cyA9IFswLCAwXTtcclxuICAgIGFsZXJ0cy5mb3JFYWNoKGFsZXJ0ID0+IHtcclxuICAgICAgaWYgKGFsZXJ0WyduYW1lJ10gPT09IGZ1bmRpZCAmJiBhbGVydFsnY2xhc3NJRCddID09PSBjbGFzc0lEKSB7XHJcbiAgICAgICAgaWYgKGFsZXJ0WydhbGVydFR5cGUnXSA9PT0gMikge1xyXG4gICAgICAgICAgY291bnRzWzBdICs9IDE7XHJcbiAgICAgICAgfSBpZiAoYWxlcnRbJ2FsZXJ0VHlwZSddID09PSAxKSB7XHJcbiAgICAgICAgICBjb3VudHNbMV0gKz0gMTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgLy9jb25zb2xlLmxvZyhcImFsZXJ0IGNvdW50cyBmb3IgZnVuZCA6XCIrZnVuZGlkK1wiIGNsYXNzOlwiK2NsYXNzSUQrXCIgY291bnRzIGZvciB0eXBlIDE6XCIrY291bnRzWzBdICtcIiBjb3VudHMgZm9yIHR5cGUgMTpcIitjb3VudHNbMV0pO1xyXG4gICAgcmV0dXJuIGNvdW50cztcclxuICB9XHJcbiAgXHJcbiAgIHVwZGF0ZUFsZXJ0RGF0YUF0Q2xhc3NMZXZlbChkYXRhKSA6IGFueVtdIHtcclxuICAgIGxldCBhbGVydEFyeSA9IFtdO1xyXG4gICAgY29uc3QgZnVuZExldmVsRGF0YSA9IChkYXRhIGFzIGFueVtdKS5tYXAoZCA9PiB7XHJcbiAgICAgIGZvcihsZXQga2V5IGluIGQuY2xhc3NMZXZlbFRyaWFsRGF0YSkge1xyXG4gICAgICAgIGFsZXJ0QXJ5ID0gYWxlcnRBcnkuY29uY2F0KHRoaXMuZmlsdGVyQWxlcnREYXRhQnlDbGFzcyhkLmZ1bmRpZCwga2V5ICxkLmNsYXNzTGV2ZWxUcmlhbERhdGFba2V5XS5wcmljZUNoYW5nZXMpKTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBhbGVydEFyeTtcclxuICB9XHJcbiAgLy8gY29sbGxlY3RzIHRoZSBhbGVydCBkYXRhIGZyb20gZ2V0RnVuZExpc3QgY2FsbFxyXG4gIHVwZGF0ZUFsZXJ0RGF0YShkYXRhKTogYW55W10ge1xyXG4gICAgbGV0IGFsZXJ0QXJ5ID0gW107XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGFsZXJ0QXJ5ID0gYWxlcnRBcnkuY29uY2F0KHRoaXMuZmlsdGVyQWxlcnREYXRhKGl0ZW1bJ2Z1bmRpZCddLCBpdGVtWydwcmljZUNoYW5nZXMnXSkpO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gYWxlcnRBcnk7XHJcbiAgfVxyXG5cclxuICBmaWx0ZXJBbGVydERhdGFCeUNsYXNzKGZ1bmRJRCwgY2xhc3NJRCwgZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcEFsZXJ0Q3JpY2xlRGF0YSA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSkpIFxyXG4gICAgICAgICYmIGl0ZW1bJ2FsZXJ0VHlwZSddICYmIChpdGVtWydhbGVydFR5cGUnXSA9PSAxIHx8IGl0ZW1bJ2FsZXJ0VHlwZSddID09PSAyKSkge1xyXG4gICAgICAgIGNvbnN0IGFsZXJ0T2JqID0ge1xyXG4gICAgICAgICAgXCJuYW1lXCI6IGZ1bmRJRCxcclxuICAgICAgICAgIFwiY2xhc3NJRFwiOiBjbGFzc0lELCBcclxuICAgICAgICAgIFwiYWxlcnRUeXBlXCI6IGl0ZW1bJ2FsZXJ0VHlwZSddLFxyXG4gICAgICAgICAgXCJuYXZcIjogaXRlbVsnbmF2J10sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBpdGVtWydmdW5kbXYnXSxcclxuICAgICAgICAgIFwidmFsdWVcIjogaXRlbVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJmdW5kbXZDaGFuZ2VQZXJjZW50XCI6IGl0ZW1bJ2Z1bmRtdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgIFwicHJpY2V0aW1lXCI6IGl0ZW1bJ3ByaWNldGltZSddLFxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wQWxlcnRDcmljbGVEYXRhLnB1c2goYWxlcnRPYmopO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBBbGVydENyaWNsZURhdGE7XHJcbiAgfVxyXG5cclxuICBmaWx0ZXJBbGVydERhdGEoZnVuZElELCBkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wQWxlcnRDcmljbGVEYXRhID0gW107XHJcbiAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSkgJiYgaXRlbVsnYWxlcnRUeXBlJ10gJiYgKGl0ZW1bJ2FsZXJ0VHlwZSddID09IDEgfHwgaXRlbVsnYWxlcnRUeXBlJ10gPT09IDIpKSB7XHJcbiAgICAgICAgY29uc3QgYWxlcnRPYmogPSB7XHJcbiAgICAgICAgICBcIm5hbWVcIjogZnVuZElELFxyXG4gICAgICAgICAgXCJhbGVydFR5cGVcIjogaXRlbVsnYWxlcnRUeXBlJ10sXHJcbiAgICAgICAgICBcIm5hdlwiOiBpdGVtWyduYXYnXSxcclxuICAgICAgICAgIFwibWFya2V0dmFsXCI6IGl0ZW1bJ2Z1bmRtdiddLFxyXG4gICAgICAgICAgXCJ2YWx1ZVwiOiBpdGVtWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcImZ1bmRtdkNoYW5nZVBlcmNlbnRcIjogaXRlbVsnZnVuZG12Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJwcmljZXRpbWVcIjogaXRlbVsncHJpY2V0aW1lJ10sXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRlbXBBbGVydENyaWNsZURhdGEucHVzaChhbGVydE9iaik7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gdGVtcEFsZXJ0Q3JpY2xlRGF0YTtcclxuICB9XHJcblxyXG4gIG9wZW5BbGVydE1vZGFsKHJvdywgdHlwZSkge1xyXG4gICAgY29uc3QgZGlhbG9nUmVmID0gdGhpcy5kaWFsb2cub3BlbihDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50LCB7XHJcbiAgICAgIHdpZHRoOiAnNjgwcHgnLFxyXG4gICAgICBkYXRhOiB7XHJcbiAgICAgICAgXCJ0eXBlXCI6IHR5cGUgPT09ICd5ZWxsb3dBbGVydCcgPyAnJyA6ICdDcml0aWNhbCcsXHJcbiAgICAgICAgXCJub3dcIjogbmV3IERhdGUoKSA+IHRoaXMuY29tbW9uVXRpbHMuZW5kVGltZSA/IHRoaXMuY29tbW9uVXRpbHMuZW5kVGltZSA6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgXCJ0aXRsZVwiOiByb3dbJ25hbWUnXStcIiBjbGFzcy1cIiArcm93WydjbGFzc0lEJ10sXHJcbiAgICAgICAgXCJmdW5kSWRcIjogcm93WydmdW5kaWQnXSxcclxuICAgICAgICBcImFsZXJ0RGF0YVwiOiB0aGlzLmdldEFsZXJ0RGF0YUZvckZ1bmRCeUNsYXNzKHJvd1snZnVuZGlkJ10sIHJvd1snY2xhc3NJRCddLCB0eXBlID09PSAneWVsbG93QWxlcnQnID8gMSA6IDIpXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4vLyAgICBjb25zb2xlLmxvZyhcImxlbmd0aCBmdW5kOlwiK3JvdytcImNsYXNzOiBhbGVydHR5cGU6XCIpOyAgXHJcbiAgICBkaWFsb2dSZWYuYWZ0ZXJDbG9zZWQoKS5zdWJzY3JpYmUocmVzdWx0ID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ1RoZSBkaWFsb2cgd2FzIGNsb3NlZCcpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBnZXRBbGVydERhdGFGb3JGdW5kQnlDbGFzcyhmdW5kSWQsIGNsYXNzSUQsIGFsZXJ0VHlwZSkge1xyXG4gICAgY29uc3QgYWxlcnREYXRhRm9yRnVuZDogYW55W10gPSBbXTtcclxuICAgIHRoaXMuYWxlcnREYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtWyduYW1lJ10gPT09IGZ1bmRJZCBcclxuICAgICAgICAgICAgJiYgaXRlbVsnY2xhc3NJRCddID09PSBjbGFzc0lEXHJcbiAgICAgICAgICAgICYmIGl0ZW1bJ2FsZXJ0VHlwZSddID09PSBhbGVydFR5cGUpIHtcclxuICAgICAgICBhbGVydERhdGFGb3JGdW5kLnB1c2goaXRlbSk7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICBjb25zb2xlLmxvZyhcIkZ1bmQ6XCIrZnVuZElkK1wiLGNsYXNzOlwiK2NsYXNzSUQrXCIsY291bnQ6XCIrYWxlcnREYXRhRm9yRnVuZC5sZW5ndGgpO1xyXG4gICAgcmV0dXJuIGFsZXJ0RGF0YUZvckZ1bmQucmV2ZXJzZSgpO1xyXG4gIH1cclxuXHJcbiAgZ2V0QWxlcnREYXRhRm9yRnVuZChmdW5kSWQsIGFsZXJ0VHlwZSkge1xyXG4gICAgY29uc3QgYWxlcnREYXRhRm9yRnVuZDogYW55W10gPSBbXTtcclxuICAgIHRoaXMuYWxlcnREYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtWyduYW1lJ10gPT09IGZ1bmRJZCAmJiBpdGVtWydhbGVydFR5cGUnXSA9PT0gYWxlcnRUeXBlKSB7XHJcbiAgICAgICAgYWxlcnREYXRhRm9yRnVuZC5wdXNoKGl0ZW0pO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGFsZXJ0RGF0YUZvckZ1bmQucmV2ZXJzZSgpO1xyXG4gIH1cclxuXHJcbiAgaHlwZXJMaW5rTmF2aWdhdGVUbyhyb3cpIHtcclxuICAgIGNvbnN0IGZ1bmRJbmZvID0gW107XHJcbiAgICBjb25zdCBmdW5kSUQgPSByb3dbJ2Z1bmRpZCddO1xyXG4gICAgZnVuZEluZm8ucHVzaChmdW5kSUQpO1xyXG4gICAgY29uc3QgZnVuZE5hbWUgPSByb3dbJ25hbWUnXTtcclxuICAgIGZ1bmRJbmZvLnB1c2goZnVuZE5hbWUpO1xyXG4gICAgZnVuZEluZm8ucHVzaChyb3dbJ2Z1bmRUaWNrZXInXSk7XHJcbiAgICB0aGlzLm5hZ2F0aXZhdGVUb1Bvc2l0aW9uKGZ1bmRJbmZvKTtcclxuICB9XHJcblxyXG4gIG5hZ2F0aXZhdGVUb1Bvc2l0aW9uKGZ1bmRJbmZvKTogdm9pZCB7XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zYXZlUG9zaXRpb25EZXRhaWxzRnVuZEluZm8oZnVuZEluZm8pO1xyXG4gICAgdGhpcy5hcHBDb250ZXh0LmN1cnJlbnREYXNoYm9hcmQgPSB0aGlzLmFwcFJlZ2lzdHJ5LmdldERhc2hib2FyZCgnUU5BVi0wMDInKTtcclxuICB9XHJcblxyXG4gIGdldEFsbFJvd3NEaXNhYmxlZCgpIHtcclxuICAgIGNvbnN0IGxpc3QgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgbGV0IGRpc2FibGVBbGwgPSB0cnVlO1xyXG4gICAgbGlzdC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jaGVja2VkKSBkaXNhYmxlQWxsID0gZmFsc2U7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGRpc2FibGVBbGw7XHJcbiAgfVxyXG5cclxuICBnZXRTaW5nbGVSb3dEaXNhYmxlZChyb3cpIHtcclxuICAgIGNvbnN0IGxpc3QgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgbGV0IGRpc2FibGVTaW5nbGVSb3cgPSB0cnVlO1xyXG4gICAgbGlzdC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jaGVja2VkICYmIGl0ZW0uZnVuZElEID09PSByb3dbJ2Z1bmRpZCddICYmIHJvdy5jaGlsZCA9PT0gXCJwYXJlbnRcIikgZGlzYWJsZVNpbmdsZVJvdyA9IGZhbHNlO1xyXG4gICAgfSlcclxuICAgIHJldHVybiBkaXNhYmxlU2luZ2xlUm93O1xyXG4gIH1cclxuXHJcbiAgZ2V0QWxsUm93Q2hlY2tlZChyb3dzKTogYm9vbGVhbiB7XHJcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5maWx0ZXIoaXRlbSA9PiBpdGVtLmNoZWNrZWQpO1xyXG4gICAgbGV0IHRlbXBGbGFnID0gdHJ1ZTtcclxuICAgIGxldCBub0Z1bmRTaG93SW5DaGFydCA9IGxpc3QubGVuZ3RoID09PSAwID8gdHJ1ZSA6IGZhbHNlO1xyXG5cclxuICAgIGlmIChsaXN0Lmxlbmd0aCA+IHRoaXMuaXNTZWxlY3RlZE1hcC5sZW5ndGgpIHtcclxuICAgICAgdGVtcEZsYWcgPSBmYWxzZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxpc3QuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICB0aGlzLmlzU2VsZWN0ZWRNYXAuZm9yRWFjaChzID0+IHtcclxuICAgICAgICAgIGlmIChpdGVtLmZ1bmRUaWNrZXIgPT09IHMubmFtZSAmJiAhcy5jaGVja2VkKSB7XHJcbiAgICAgICAgICAgIHRlbXBGbGFnID0gZmFsc2VcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIGlmICh0aGlzLmlzU2VsZWN0ZWRNYXAubGVuZ3RoID09PSAwKSB0ZW1wRmxhZyA9IGZhbHNlO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmFsbFJvd3NTZWxlY3RlZCA9IG5vRnVuZFNob3dJbkNoYXJ0ID8gIW5vRnVuZFNob3dJbkNoYXJ0IDogdGVtcEZsYWc7XHJcbiAgICByZXR1cm4gdGhpcy5hbGxSb3dzU2VsZWN0ZWQ7XHJcbiAgfVxyXG5cclxuICBnZXRTaW5nbGVSb3dDaGVja2VkKGZ1bmQpIHtcclxuICAgIGxldCBpc0NoZWNrZWQgPSBmYWxzZTtcclxuICAgIHRoaXMuaXNTZWxlY3RlZE1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5uYW1lID09PSBmdW5kKSB7XHJcbiAgICAgICAgaXNDaGVja2VkID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5maW5kKGxpc3QgPT4gKGxpc3QuZnVuZFRpY2tlciA9PT0gZnVuZCAmJiBsaXN0LmNoZWNrZWQpKSA/IGl0ZW0uY2hlY2tlZCA6IGZhbHNlO1xyXG4gICAgICAgIGl0ZW0uY2hlY2tlZCA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmluZChsaXN0ID0+IChsaXN0LmZ1bmRUaWNrZXIgPT09IGZ1bmQgJiYgbGlzdC5jaGVja2VkKSkgPyBpdGVtLmNoZWNrZWQgOiBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBpc0NoZWNrZWQ7XHJcbiAgfVxyXG5cclxuICBvblNlbGVjdEFsbChjaGVja2VkLCByb3dzKSB7XHJcbiAgICB0aGlzLmFsbFJvd3NTZWxlY3RlZCA9IGNoZWNrZWQ7XHJcbiAgICByb3dzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgbmFtZTogaXRlbS5mdW5kVGlja2VyLFxyXG4gICAgICAgIGNoZWNrZWQ6IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmluZChsaXN0ID0+IChsaXN0LmZ1bmRJRCA9PT0gaXRlbS5mdW5kaWQgJiYgbGlzdC5jaGVja2VkKSkgPyBjaGVja2VkIDogZmFsc2VcclxuICAgICAgfVxyXG4gICAgICBpZiAoIXRoaXMuaXNTZWxlY3RlZE1hcC5maW5kKHMgPT4gcy5uYW1lID09PSBpdGVtLmZ1bmRUaWNrZXIpKSB7XHJcbiAgICAgICAgdGhpcy5pc1NlbGVjdGVkTWFwLnB1c2gob2JqKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGkgPSB0aGlzLmlzU2VsZWN0ZWRNYXAuZmluZEluZGV4KHMgPT4gcy5uYW1lID09PSBpdGVtLmZ1bmRUaWNrZXIpO1xyXG4gICAgICAgIHRoaXMuaXNTZWxlY3RlZE1hcFtpXVsnY2hlY2tlZCddID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5maW5kKGxpc3QgPT4gKGxpc3QuZnVuZElEID09PSBpdGVtLmZ1bmRpZCAmJiBsaXN0LmNoZWNrZWQpKSA/IGNoZWNrZWQgOiBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuXHJcbiAgICAvLyB0aGlzLnNldEhpZ2hMaWdodEFjdGl2ZUVudHJpZXModGhpcy5pc1NlbGVjdGVkTWFwKTtcclxuICAgIGNvbnN0IGFjdGl2ZUVudHJpZXMgPSBbXTtcclxuICAgIHRoaXMuaXNTZWxlY3RlZE1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jaGVja2VkKSB7XHJcbiAgICAgICAgYWN0aXZlRW50cmllcy5wdXNoKHsgbmFtZTogaXRlbS5uYW1lIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaGlnaExpZ2h0QWN0aXZlRW50cmllcy5lbWl0KGFjdGl2ZUVudHJpZXMpO1xyXG4gIH1cclxuXHJcbiAgb25DaGVja2JveENoYW5nZShmdW5kKSB7XHJcbiAgICBpZiAodGhpcy5pc1NlbGVjdGVkTWFwLmxlbmd0aCA+IDAgJiYgdGhpcy5pc1NlbGVjdGVkTWFwLmZpbmQocyA9PiBzLm5hbWUgPT09IGZ1bmQpKSB7XHJcbiAgICAgIGNvbnN0IGkgPSB0aGlzLmlzU2VsZWN0ZWRNYXAuZmluZEluZGV4KHMgPT4gcy5uYW1lID09PSBmdW5kKTtcclxuICAgICAgdGhpcy5pc1NlbGVjdGVkTWFwW2ldWydjaGVja2VkJ10gPSAhdGhpcy5pc1NlbGVjdGVkTWFwW2ldWydjaGVja2VkJ107XHJcbiAgICAgIGlmICh0aGlzLmlzU2VsZWN0ZWRNYXBbaV1bJ2NoZWNrZWQnXSkge1xyXG4gICAgICAgIHRoaXMuYWxsUm93c1NlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgbmFtZTogZnVuZCxcclxuICAgICAgICBjaGVja2VkOiB0cnVlXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5pc1NlbGVjdGVkTWFwLnB1c2gob2JqKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHRoaXMuc2V0SGlnaExpZ2h0QWN0aXZlRW50cmllcyh0aGlzLmlzU2VsZWN0ZWRNYXApO1xyXG4gICAgY29uc3QgYWN0aXZlRW50cmllcyA9IFtdO1xyXG4gICAgdGhpcy5pc1NlbGVjdGVkTWFwLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLmNoZWNrZWQpIHtcclxuICAgICAgICBhY3RpdmVFbnRyaWVzLnB1c2goeyBuYW1lOiBpdGVtLm5hbWUgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5oaWdoTGlnaHRBY3RpdmVFbnRyaWVzLmVtaXQoYWN0aXZlRW50cmllcyk7XHJcbiAgfVxyXG5cclxuICBzZXRIaWdoTGlnaHRBY3RpdmVFbnRyaWVzKHNlbGVjdGVkTWFwKSB7XHJcbiAgICBjb25zdCBhY3RpdmVFbnRyaWVzID0gW107XHJcbiAgICBzZWxlY3RlZE1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jaGVja2VkKSB7XHJcbiAgICAgICAgYWN0aXZlRW50cmllcy5wdXNoKHsgbmFtZTogaXRlbS5uYW1lIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaGlnaExpZ2h0QWN0aXZlRW50cmllcy5lbWl0KGFjdGl2ZUVudHJpZXMpO1xyXG4gIH1cclxuXHJcbiAgb25DbGlja2VkT3V0c2lkZShlOiBFdmVudCkge1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuY2xpY2tlZE91dFNpZGUuZW1pdChlKTtcclxuICB9XHJcblxyXG4gIHRvZ2dsZVBhdXNlRmxhZygpIHtcclxuICAgIHRoaXMuaXNEYXRhVGFibGVQYXVzZWQgPSAhdGhpcy5pc0RhdGFUYWJsZVBhdXNlZDtcclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7IE5nTW9kdWxlICwgSW5qZWN0aW9uVG9rZW59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBcHBSZWdpc3RyeSwgQXBwQ29udGV4dCwgVWlDb21tb25Nb2R1bGUgfSBmcm9tICdAb21uaWEvdWktY29tbW9uJztcclxuaW1wb3J0IHsgRHluYW1pY01vZHVsZSB9IGZyb20gJ25nLWR5bmFtaWMtY29tcG9uZW50JztcclxuaW1wb3J0IHsgTmd4RGF0YXRhYmxlTW9kdWxlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1kYXRhdGFibGUnO1xyXG5pbXBvcnQgeyBOZ3hDaGFydHNNb2R1bGUgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XHJcbmltcG9ydCB7IExpbmVDaGFydENvbXBvbmVudCB9IGZyb20gJy4vbGluZS1jaGFydC9saW5lLWNoYXJ0LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEN1c3RvbUxlZ2VuZENvbXBvbmVudCB9IGZyb20gJy4vY3VzdG9tLWxlZ2VuZC9jdXN0b20tbGVnZW5kLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IE1hdENoaXBzTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvY2hpcHMnO1xyXG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlLCBNYXRCdXR0b25Nb2R1bGUsIE1hdENoZWNrYm94TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwnO1xyXG5pbXBvcnQge01hdE1lbnVNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL21lbnUnO1xyXG5pbXBvcnQge0Jyb3dzZXJBbmltYXRpb25zTW9kdWxlfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyL2FuaW1hdGlvbnMnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50SW5NZW1vcnlXZWJBcGlNb2R1bGUgfSBmcm9tICdhbmd1bGFyLWluLW1lbW9yeS13ZWItYXBpJztcclxuLy9pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3NyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQnXHJcbi8vIGltcG9ydCB7IFFuYXZMaW5lQ2hhcnRDb21wb25lbnQgfSBmcm9tICcuL3FuYXYtbGluZS1jaGFydC9xbmF2LWxpbmUtY2hhcnQuY29tcG9uZW50JztcclxuaW1wb3J0IHsgUW5hdlBvc2l0aW9uQ29tcG9uZW50IH0gZnJvbSAnLi9xbmF2LXBvc2l0aW9uL3FuYXYtcG9zaXRpb24uY29tcG9uZW50JztcclxuaW1wb3J0IHsgUW5hdkxpbmVDaGFydENvbXBvbmVudCB9IGZyb20gJy4vcW5hdi1saW5lLWNoYXJ0LW9sZC9xbmF2LWxpbmUtY2hhcnQuY29tcG9uZW50JztcclxuaW1wb3J0IHsgUGVyY2VudEZvcm1hdFBpcGUgfSBmcm9tICcuL3BpcGUvcGVyY2VudC1mb3JtYXQucGlwZSc7XHJcbmltcG9ydCB7IE51bWJlclJvdW5kVXBQaXBlIH0gZnJvbSAnLi9waXBlL251bWJlci1yb3VuZHVwLnBpcGUnO1xyXG5pbXBvcnQgeyBDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi9jdXN0b20tYWxlcnQtbW9kYWwvY3VzdG9tLWFsZXJ0LW1vZGFsLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFJlc291cmNlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZSc7XHJcbmltcG9ydCB7IENsaWNrT3V0c2lkZU1vZHVsZSB9IGZyb20gJ25nLWNsaWNrLW91dHNpZGUnO1xyXG5pbXBvcnQgeyBBZGRGdW5kTW9kYWxDb21wb25lbnQgfSBmcm9tICcuL2FkZC1mdW5kLW1vZGFsL2FkZC1mdW5kLW1vZGFsLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IE1hdERpYWxvZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2RpYWxvZyc7XHJcbmltcG9ydCB7IERhdGVQaXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50IH0gZnJvbSAnLi9wb3NpdGlvbi1oZWF0LW1hcC9wb3NpdGlvbi1oZWF0LW1hcC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBIZWF0TWFwQ29tcG9uZW50IH0gZnJvbSAnLi9oZWF0LW1hcC9oZWF0LW1hcC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBQb3NpdGlvbkZ1bmRTdW1tYXJ5Q29tcG9uZW50IH0gZnJvbSAnLi9wb3NpdGlvbi1mdW5kLXN1bW1hcnkvcG9zaXRpb24tZnVuZC1zdW1tYXJ5LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFNpbmdsZUxpbmVDaGFydENvbXBvbmVudCB9IGZyb20gJy4vc2luZ2xlLWxpbmUtY2hhcnQvc2luZ2xlLWxpbmUtY2hhcnQuY29tcG9uZW50JztcclxuaW1wb3J0IHsgQ29tbW9uRGF0YVRhYmxlQ29tcG9uZW50IH0gZnJvbSAnLi9jb21tb24tZGF0YS10YWJsZS9jb21tb24tZGF0YS10YWJsZS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBNYWluRGF0YXRhYmxlQ29tcG9uZW50IH0gZnJvbSAnLi9tYWluLWRhdGF0YWJsZS9tYWluLWRhdGF0YWJsZS5jb21wb25lbnQnO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBCcm93c2VyQW5pbWF0aW9uc01vZHVsZSxcclxuICAgIE1hdEJ1dHRvbk1vZHVsZSxcclxuICAgIE1hdENoZWNrYm94TW9kdWxlLFxyXG4gICAgVWlDb21tb25Nb2R1bGUsXHJcbiAgICBEeW5hbWljTW9kdWxlLndpdGhDb21wb25lbnRzKFtcclxuICAgICAgUW5hdkxpbmVDaGFydENvbXBvbmVudCwgXHJcbiAgICAgIE1haW5EYXRhdGFibGVDb21wb25lbnQsXHJcbiAgICAgIFFuYXZQb3NpdGlvbkNvbXBvbmVudCxcclxuICAgICAgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50LFxyXG4gICAgICBQb3NpdGlvbkZ1bmRTdW1tYXJ5Q29tcG9uZW50XHJcbiAgICAgIF0pLFxyXG4gICAgTmd4RGF0YXRhYmxlTW9kdWxlLFxyXG4gICAgTmd4Q2hhcnRzTW9kdWxlLFxyXG4gICAgTWF0Q2hpcHNNb2R1bGUsXHJcbiAgICBNYXRJY29uTW9kdWxlLFxyXG4gICAgSHR0cENsaWVudE1vZHVsZSxcclxuICAgIE1hdERpYWxvZ01vZHVsZSxcclxuICAgIE1hdE1lbnVNb2R1bGUsXHJcbiAgICBDbGlja091dHNpZGVNb2R1bGVcclxuICBdLFxyXG4gIGRlY2xhcmF0aW9uczogW1xyXG4gICAgUW5hdkxpbmVDaGFydENvbXBvbmVudCxcclxuICAgIExpbmVDaGFydENvbXBvbmVudCxcclxuICAgIEN1c3RvbUxlZ2VuZENvbXBvbmVudCxcclxuICAgIFFuYXZQb3NpdGlvbkNvbXBvbmVudCxcclxuICAgIFBlcmNlbnRGb3JtYXRQaXBlLFxyXG4gICAgTnVtYmVyUm91bmRVcFBpcGUsXHJcbiAgICBDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50LFxyXG4gICAgQWRkRnVuZE1vZGFsQ29tcG9uZW50LFxyXG4gICAgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50LFxyXG4gICAgSGVhdE1hcENvbXBvbmVudCxcclxuICAgIFBvc2l0aW9uRnVuZFN1bW1hcnlDb21wb25lbnQsXHJcbiAgICBTaW5nbGVMaW5lQ2hhcnRDb21wb25lbnQsXHJcbiAgICBDb21tb25EYXRhVGFibGVDb21wb25lbnQsXHJcbiAgICBNYWluRGF0YXRhYmxlQ29tcG9uZW50XHJcbiAgXSxcclxuICBwcm92aWRlcnM6W0RhdGVQaXBlLCBBcHBSZWdpc3RyeV0sXHJcbiAgZXhwb3J0czogW1xyXG4gICAgUW5hdkxpbmVDaGFydENvbXBvbmVudCwgXHJcbiAgICBRbmF2UG9zaXRpb25Db21wb25lbnQsIFxyXG4gICAgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50LFxyXG4gICAgUG9zaXRpb25GdW5kU3VtbWFyeUNvbXBvbmVudCxcclxuICAgIE1haW5EYXRhdGFibGVDb21wb25lbnRcclxuICBdLFxyXG4gIGVudHJ5Q29tcG9uZW50czogW1xyXG4gICAgUW5hdkxpbmVDaGFydENvbXBvbmVudCwgXHJcbiAgICBRbmF2UG9zaXRpb25Db21wb25lbnQsXHJcbiAgICBDdXN0b21BbGVydE1vZGFsQ29tcG9uZW50LFxyXG4gICAgQWRkRnVuZE1vZGFsQ29tcG9uZW50LFxyXG4gICAgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50LFxyXG4gICAgUG9zaXRpb25GdW5kU3VtbWFyeUNvbXBvbmVudCxcclxuICAgIE1haW5EYXRhdGFibGVDb21wb25lbnRcclxuICAgIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIFVpUU5hdk1vZHVsZSB7XHJcbiAgc3RhdGljIGZvclJvb3QoZW52aXJvbm1lbnQ6IGFueSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbmdNb2R1bGUgOiBVaVFOYXZNb2R1bGUsXHJcbiAgICAgIHByb3ZpZGVyczpbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcHJvdmlkZTogJ2VudicsXHJcbiAgICAgICAgICB1c2VWYWx1ZTogZW52aXJvbm1lbnRcclxuICAgICAgICB9XHJcbiAgICAgIF1cclxuICAgIH1cclxuICB9XHJcbiAgcGVybWlzc2lvbnM6IHN0cmluZ1tdID0gWydBcHBsaWNhdGlvbi9uYXZkZXZlbG9wZXInLCdBcHBsaWNhdGlvbi9uYXZhbmFseXN0J107XHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIGFwcFJlZ2lzdHJ5OiBBcHBSZWdpc3RyeVxyXG4gICkge1xyXG5cclxuICAgIGFwcFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tcG9uZW50KCdsaW5lQ2hhcnQnLCBRbmF2TGluZUNoYXJ0Q29tcG9uZW50KTtcclxuICAgIGFwcFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tcG9uZW50KCdsaXZlRGF0YVRhYmxlJywgTWFpbkRhdGF0YWJsZUNvbXBvbmVudCk7XHJcbiAgICBhcHBSZWdpc3RyeS5yZWdpc3RlckNvbXBvbmVudCgnbGl2ZVBvc2l0aW9uJywgUW5hdlBvc2l0aW9uQ29tcG9uZW50KTtcclxuICAgIGFwcFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tcG9uZW50KCdwb3NpdGlvbkhlYXRNYXAnLCBQb3NpdGlvbkhlYXRNYXBDb21wb25lbnQpO1xyXG4gICAgYXBwUmVnaXN0cnkucmVnaXN0ZXJDb21wb25lbnQoJ3Bvc2l0aW9uRnVuZFN1bW1hcnknLCBQb3NpdGlvbkZ1bmRTdW1tYXJ5Q29tcG9uZW50KTtcclxuXHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gXHJcblxyXG4gICAgYXBwUmVnaXN0cnkucmVnaXN0ZXJEYXNoYm9hcmQoJ1FOQVYtMDAxJywgJ1FOQVYgRW50aXR5IExpc3QnLFxyXG4gICAgICBbXHJcbiAgICAgICAgeyB4OiAwLCB5OiAwLCByb3dzOiAxLCBjb2xzOiAxLCBjb25maWc6IHt9LCBjb21wOiAnbGluZUNoYXJ0JywgdGl0bGU6IG51bGwsIHNob3dIZWFkZXI6IHRydWUgfSxcclxuICAgICAgICB7IHg6IDAsIHk6IDEsIHJvd3M6IDEsIGNvbHM6IDEsIGNvbmZpZzoge30sIGNvbXA6ICdsaXZlRGF0YVRhYmxlJywgdGl0bGU6IG51bGwsIHNob3dIZWFkZXI6IHRydWUgfVxyXG4gICAgICBdLCB0cnVlLCB0cnVlLCAncW5mJywnUU5BVicsIHRoaXMucGVybWlzc2lvbnNcclxuICAgIClcclxuXHJcbiAgICBhcHBSZWdpc3RyeS5yZWdpc3RlckRhc2hib2FyZCgnUU5BVi0wMDInLCAnUU5BViBQb3NpdGlvbicsXHJcbiAgICAgIFtcclxuICAgICAgICB7IHg6IDAsIHk6IDAsIHJvd3M6IDEsIGNvbHM6IDEsIGNvbmZpZzoge30sIGNvbXA6ICdwb3NpdGlvbkhlYXRNYXAnLCB0aXRsZTogbnVsbCwgc2hvd0hlYWRlcjogdHJ1ZSB9LFxyXG4gICAgICAgIC8vIHsgeDogMCwgeTogMSwgcm93czogMSwgY29sczogMSwgY29uZmlnOiB7fSwgY29tcDogJ3Bvc2l0aW9uRnVuZFN1bW1hcnknLCB0aXRsZTogbnVsbCwgc2hvd0hlYWRlcjogdHJ1ZSB9LFxyXG4gICAgICAgIHsgeDogMCwgeTogMSwgcm93czogMSwgY29sczogMSwgY29uZmlnOiB7fSwgY29tcDogJ2xpdmVQb3NpdGlvbicsIHRpdGxlOiBudWxsLCBzaG93SGVhZGVyOiB0cnVlIH1cclxuICAgICAgXSwgdHJ1ZSwgdHJ1ZSwgJ3FucCcsJ1FOQVYnLHRoaXMucGVybWlzc2lvbnNcclxuICAgIClcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iXSwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwiSW5qZWN0YWJsZSIsInRzbGliXzEuX192YWx1ZXMiLCJ0c2xpYl8xLl9fZXh0ZW5kcyIsImN1cnZlTGluZWFyIiwiY2FsY3VsYXRlVmlld0RpbWVuc2lvbnMiLCJpZCIsImdldFVuaXF1ZVhEb21haW5WYWx1ZXMiLCJ0c2xpYl8xLl9fc3ByZWFkIiwic2NhbGVUaW1lIiwic2NhbGVMaW5lYXIiLCJzY2FsZVBvaW50IiwiQ29sb3JIZWxwZXIiLCJDb21wb25lbnQiLCJWaWV3RW5jYXBzdWxhdGlvbiIsIkNoYW5nZURldGVjdGlvblN0cmF0ZWd5IiwidHJpZ2dlciIsInRyYW5zaXRpb24iLCJzdHlsZSIsImFuaW1hdGUiLCJFbGVtZW50UmVmIiwiTmdab25lIiwiQ2hhbmdlRGV0ZWN0b3JSZWYiLCJEYXRlUGlwZSIsIklucHV0IiwiT3V0cHV0IiwiQ29udGVudENoaWxkIiwiSG9zdExpc3RlbmVyIiwiQmFzZUNoYXJ0Q29tcG9uZW50IiwiQmVoYXZpb3JTdWJqZWN0IiwiSHR0cENsaWVudCIsIndlYlNvY2tldCIsIkFwcENvbnRleHQiLCJCYXNlV2lkZ2V0Q29tcG9uZW50IiwiTWF0RGlhbG9nUmVmIiwiSW5qZWN0IiwiTUFUX0RJQUxPR19EQVRBIiwiZGlhbG9nIiwiZm9ybWF0RGF0ZSIsIk1hdERpYWxvZyIsIlZpZXdDb250YWluZXJSZWYiLCJQaXBlIiwiZm9ybWF0TnVtYmVyIiwidHJlZW1hcCIsInN0cmF0aWZ5IiwiVmlld0NoaWxkIiwiY3VzdG9tQ29sdW1uIiwibm9ybWFsQ29sdW1uIiwiY29sdW1uTWVudURyb3BEb3duU2V0dGluZyIsIkFwcFJlZ2lzdHJ5IiwiTmdNb2R1bGUiLCJCcm93c2VyQW5pbWF0aW9uc01vZHVsZSIsIk1hdEJ1dHRvbk1vZHVsZSIsIk1hdENoZWNrYm94TW9kdWxlIiwiVWlDb21tb25Nb2R1bGUiLCJEeW5hbWljTW9kdWxlIiwiTmd4RGF0YXRhYmxlTW9kdWxlIiwiTmd4Q2hhcnRzTW9kdWxlIiwiTWF0Q2hpcHNNb2R1bGUiLCJNYXRJY29uTW9kdWxlIiwiSHR0cENsaWVudE1vZHVsZSIsIk1hdERpYWxvZ01vZHVsZSIsIk1hdE1lbnVNb2R1bGUiLCJDbGlja091dHNpZGVNb2R1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0lBQUE7Ozs7Ozs7Ozs7Ozs7O0lBY0E7SUFFQSxJQUFJLGFBQWEsR0FBRyxVQUFTLENBQUMsRUFBRSxDQUFDO1FBQzdCLGFBQWEsR0FBRyxNQUFNLENBQUMsY0FBYzthQUNoQyxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsWUFBWSxLQUFLLElBQUksVUFBVSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUM1RSxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUFFLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7b0JBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDL0UsT0FBTyxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQztBQUVGLHVCQUEwQixDQUFDLEVBQUUsQ0FBQztRQUMxQixhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BCLGdCQUFnQixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxFQUFFO1FBQ3ZDLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxLQUFLLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDekYsQ0FBQztBQUVELHNCQTZFeUIsQ0FBQztRQUN0QixJQUFJLENBQUMsR0FBRyxPQUFPLE1BQU0sS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4QixPQUFPO1lBQ0gsSUFBSSxFQUFFO2dCQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtvQkFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7Z0JBQ25DLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO2FBQzNDO1NBQ0osQ0FBQztJQUNOLENBQUM7QUFFRCxvQkFBdUIsQ0FBQyxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLEdBQUcsT0FBTyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLENBQUM7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqQyxJQUFJO1lBQ0EsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSTtnQkFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5RTtRQUNELE9BQU8sS0FBSyxFQUFFO1lBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO1NBQUU7Z0JBQy9CO1lBQ0osSUFBSTtnQkFDQSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO29CQUNPO2dCQUFFLElBQUksQ0FBQztvQkFBRSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFBRTtTQUNwQztRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztBQUVEO1FBQ0ksS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7WUFDOUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekMsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDOzs7Ozs7QUMxSUQ7UUFrQkU7WUFWTyxhQUFRLEdBQVMsRUFBRSxDQUFDO1lBQ25CLHFCQUFnQixHQUFRLEVBQUUsQ0FBQztZQUM1QixnQkFBVyxHQUFVLEVBQUUsQ0FBQztZQUN4QiwyQkFBc0IsR0FBc0IsSUFBS0EsZUFBWSxFQUFPLENBQUM7WUFDckUsbUJBQWMsR0FBc0IsSUFBS0EsZUFBWSxFQUFPLENBQUM7O1lBRTdELHNCQUFpQixHQUFzQixJQUFJQSxlQUFZLEVBQU8sQ0FBQztZQUMvRCxrQkFBYSxHQUFzQixJQUFJQSxlQUFZLEVBQU8sQ0FBQztZQUMzRCx3QkFBbUIsR0FBc0IsSUFBSUEsZUFBWSxFQUFPLENBQUM7U0FFdkQ7Ozs7O1FBRVYsc0VBQTJCOzs7O1lBQWxDLFVBQW1DLFFBQVE7Z0JBQ3pDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2FBQzFCOzs7OztRQUVNLDhEQUFtQjs7OztZQUExQixVQUEyQixJQUFJO2dCQUM3QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO2FBQzlCOzs7OztRQUVNLHlEQUFjOzs7O1lBQXJCLFVBQXNCLFdBQW1CO2dCQUN2QyxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQzthQUNoQzs7OztRQUVNLHNEQUFXOzs7WUFBbEI7Z0JBQ0UsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7YUFDOUI7Ozs7UUFDTSxnREFBSzs7O1lBQVo7Z0JBQ0UsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7Z0JBQ25CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2dCQUN0QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBS0EsZUFBWSxFQUFPLENBQUM7Z0JBQ3ZELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJQSxlQUFZLEVBQU8sQ0FBQztnQkFDakQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJQSxlQUFZLEVBQU8sQ0FBQztnQkFDN0MsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUlBLGVBQVksRUFBTyxDQUFDO2FBQ3BEOztvQkF4Q0ZDLGFBQVUsU0FBQzt3QkFDVixVQUFVLEVBQUUsTUFBTTtxQkFDbkI7Ozs7K0NBTEQ7S0E0Q0M7Ozs7Ozs7UUMvQkMsNEJBQW9CLDJCQUE2RDtZQUFqRixpQkFjQztZQWRtQixnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQWtDO1lBTGpGLGNBQVMsR0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzdCLFlBQU8sR0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLGlCQUFZLEdBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNoQyxhQUFRLEdBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUM1Qix1QkFBa0IsR0FBWSxLQUFLLENBQUM7WUFHbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7O2dCQUNyQyxRQUFRLEdBQUcsV0FBVyxDQUFDO2dCQUN6QixJQUFJLElBQUksSUFBSSxFQUFFLEdBQUcsS0FBSSxDQUFDLE9BQU8sRUFBRTtvQkFDN0IsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO2lCQUMzQjtxQkFBTTtvQkFDTCxLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxPQUFPLENBQUM7b0JBQzdCLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDekI7YUFDRixFQUFFLElBQUksQ0FBQztZQUNSLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ2xFOzs7OztRQUNELCtDQUFrQjs7OztZQUFsQixVQUFtQixJQUFVO2dCQUMzQixJQUFLLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUN6QixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFDRCxPQUFPLElBQUksQ0FBQzthQUNiOzs7OztRQUNELCtDQUFrQjs7OztZQUFsQixVQUFtQixJQUFVO2dCQUMzQixJQUFLLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO29CQUMzQixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFDRCxPQUFPLElBQUksQ0FBQzthQUNiOzs7OztRQUVELHdDQUFXOzs7O1lBQVgsVUFBWSxJQUFVO2dCQUVwQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNsRCxPQUFPLElBQUksQ0FBQztpQkFDYjtnQkFDRCxPQUFPLEtBQUssQ0FBQzthQUNkOzs7OztRQUVNLDZDQUFnQjs7OztZQUF2QixVQUF3QixJQUFVO2dCQUNoQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO29CQUM3QixPQUFPLElBQUksQ0FBQztpQkFDYjtnQkFDRCxPQUFPLEtBQUssQ0FBQzthQUNkOzs7O1FBRU0sMkNBQWM7OztZQUFyQjs7b0JBQ1EsT0FBTyxHQUFHLGtCQUFrQjs7b0JBQzlCLEtBQUssR0FBRyxHQUFHO2dCQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzFCLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbEQ7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDZDs7Ozs7UUFFTSw0Q0FBZTs7OztZQUF0QixVQUF1QixNQUFjO2dCQUNuQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUM7O29CQUMvQixLQUFpQixJQUFBLEtBQUFDLFNBQUEsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsQ0FBQSxnQkFBQTt3QkFBeEQsSUFBSSxJQUFJLFdBQUE7d0JBQ1gsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssU0FBUyxFQUFFOzRCQUNoQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsTUFBTSxDQUFDOzRCQUN4QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzt5QkFDdEI7cUJBQ0Y7Ozs7Ozs7Ozs7Ozs7OztnQkFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzs7YUFFOUI7Ozs7O1FBQ00sOENBQWlCOzs7O1lBQXhCLFVBQXlCLE1BQWM7O29CQUNyQyxLQUFpQixJQUFBLEtBQUFBLFNBQUEsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsQ0FBQSxnQkFBQTt3QkFBeEQsSUFBSSxJQUFJLFdBQUE7d0JBQ1gsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSxFQUFFOzRCQUM3QixJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsU0FBUyxDQUFDO3lCQUM1QjtxQkFDRjs7Ozs7Ozs7Ozs7Ozs7OzthQUNGOzs7Ozs7UUFFTSw2Q0FBZ0I7Ozs7O1lBQXZCLFVBQXdCLE1BQWMsRUFBRSxTQUFrQjs7b0JBQ2xELEtBQUssR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsT0FBTyxJQUFJLE9BQUEsT0FBTyxDQUFDLE1BQU0sS0FBSyxNQUFNLEdBQUEsQ0FBQztnQkFDNUcsSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFO29CQUNsRixPQUFPO2lCQUNSO2dCQUNELElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUM7O2dCQUU3RSxJQUFJLFNBQVMsS0FBSyxLQUFLLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDaEM7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDOUI7YUFFRjs7Ozs7UUFFTSx1Q0FBVTs7OztZQUFqQixVQUFrQixJQUFVOztvQkFDdEIsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQzs7b0JBQ2xCLE1BQU0sR0FBRyxJQUFJO2dCQUNqQixJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUU7b0JBQ3hCLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQ2Y7cUJBQU0sSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUU7b0JBQ3RELE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQ2Y7cUJBQU07b0JBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQztpQkFDZjtnQkFDRCxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUM7YUFDL0Y7Ozs7O1FBQ00sMkNBQWM7Ozs7WUFBckIsVUFBc0IsSUFBSTs7b0JBQ3BCLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7Z0JBRXRCLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsRUFBRTtvQkFDeEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdEI7cUJBQU0sSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUU7b0JBQ3RELENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ2pCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNMLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ2pCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3RCO2dCQUNELE9BQU8sQ0FBQyxDQUFDO2FBQ1Y7Ozs7OztRQUVNLHlDQUFZOzs7OztZQUFuQjtnQkFDRSxJQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7b0JBQy9DLElBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsS0FBSyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFO3dCQUMxRixPQUFPLElBQUksQ0FBQztxQkFDYjtpQkFDRjtnQkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ3pDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDdEYsT0FBTyxLQUFLLENBQUM7YUFDZDs7Ozs7UUFFTSxpREFBb0I7Ozs7WUFBM0IsVUFBNEIsSUFBSTs7b0JBQ3hCLGFBQWEsR0FBRyxHQUFDLElBQUksSUFBVyxHQUFHLENBQUMsVUFBQSxDQUFDOzt3QkFDL0IsT0FBTyxHQUFHOzt3QkFFWixNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU07d0JBQ2hCLFFBQVEsRUFBRSxDQUFDLENBQUMsUUFBUTt3QkFDcEIsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJO3dCQUNaLE9BQU8sRUFBRSxHQUFHO3dCQUNaLEtBQUssRUFBRSxRQUFRO3FCQUNoQjs7d0JBQ0ssY0FBYyxHQUFHLENBQUMsQ0FBQyxtQkFBbUI7O3dCQUN0QyxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQztvQkFDcEQsT0FBTyxHQUFHLENBQUM7aUJBQ1osQ0FBQztnQkFDUixPQUFPLGFBQWEsQ0FBQzthQUN0Qjs7Ozs7UUFFTSxrREFBcUI7Ozs7WUFBNUIsVUFBNkIsSUFBSTs7b0JBQ3pCLGNBQWMsR0FBRyxFQUFFO2dCQUN6QixHQUFDLElBQUksSUFBVyxPQUFPLENBQUMsVUFBQSxDQUFDOzt3QkFDWixPQUFPLEdBQUc7O3dCQUVmLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTTt3QkFDaEIsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRO3dCQUNwQixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7d0JBQ1osS0FBSyxFQUFFLE9BQU87cUJBQ2Y7O3dCQUNLLGNBQWMsR0FBRyxDQUFDLENBQUMsbUJBQW1CO29CQUM1QyxLQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsRUFBRTt3QkFDN0IsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFOztnQ0FDVCxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUMsT0FBTyxFQUFFLEdBQUcsRUFBQyxDQUFDOzRCQUM1RSxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt5QkFDNUM7cUJBQ0Y7aUJBRUYsQ0FBQyxDQUFDO2dCQUNILE9BQU8sY0FBYyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ3JDOzs7Ozs7UUFFTSwwQ0FBYTs7Ozs7WUFBcEIsVUFBcUIsSUFBSSxFQUFDLFVBQVU7O29CQUM5QixVQUFVLEdBQUcsRUFBRTs7b0JBQ2IsSUFBSSxHQUFHO29CQUNYLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZOztvQkFFL0IsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO29CQUNuQixrQkFBa0IsRUFBRSxJQUFJLENBQUMsa0JBQWtCO29CQUMzQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7b0JBQ1gsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO29CQUN2QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7b0JBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGtCQUFrQjtvQkFDM0MsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7b0JBQ3ZCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtpQkFDNUI7Z0JBQ0QsSUFBSSxVQUFVLEVBQUU7b0JBQ1osS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUU7d0JBQ3RCLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFOztnQ0FDVCxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUMsT0FBTyxFQUFFLEdBQUcsRUFBQyxDQUFDOzRCQUMxRCxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzt5QkFDbkM7cUJBQ0Y7aUJBQ0Y7cUJBQU07b0JBQ0wsVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDdkIsVUFBVSxHQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUMsQ0FBQyxDQUFDO2lCQUMvRDtnQkFDRCxPQUFPLFVBQVUsQ0FBQzthQUNuQjs7Ozs7Ozs7O1FBRU0sNkNBQWdCOzs7Ozs7OztZQUF2QixVQUF3QixJQUFJLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxPQUFPOztvQkFDckUsS0FBSyxHQUFHLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNmLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxHQUFHO3dCQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzNDLElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxDQUFDO3dCQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzlDLENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3pGLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJOzt3QkFDZCxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07b0JBQzFCLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFBLFVBQVU7d0JBQ3RDLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxNQUFNLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTs7Z0NBQy9DLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQUEsS0FBSyxJQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUEsRUFBQyxDQUFDOzRCQUN4RSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFBO3lCQUNqQztxQkFDRixDQUFDLENBQUE7aUJBQ0gsQ0FBQyxDQUFDO2dCQUNILE9BQU8sS0FBSyxDQUFDO2FBQ2Q7Ozs7O1FBRU8sMkNBQWM7Ozs7WUFBdEIsVUFBdUIsSUFBSTtnQkFDekIsT0FBTyxVQUFVLElBQUksRUFBRSxJQUFJOzt3QkFDckIsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7O3dCQUNmLEVBQUUsR0FBSSxJQUFJLENBQUMsSUFBSSxDQUFDO29CQUNwQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO3dCQUM1QyxFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUNoQixFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO3FCQUNqQjtvQkFFRCxJQUFJLEVBQUUsS0FBSyxTQUFTLElBQUksRUFBRSxHQUFHLEVBQUUsRUFBRTt3QkFDL0IsT0FBTyxDQUFDLENBQUMsQ0FBQTtxQkFDVjt5QkFBTSxJQUFJLEVBQUUsS0FBSyxTQUFTLElBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTt3QkFDdkMsT0FBTyxDQUFDLENBQUM7cUJBQ1Y7eUJBQU07d0JBQ0wsT0FBTyxDQUFDLENBQUE7cUJBQ1Q7aUJBQ0YsQ0FBQTthQUNGOzs7OztRQUVPLDRDQUFlOzs7O1lBQXZCLFVBQXdCLElBQUk7Z0JBQzFCLE9BQU8sVUFBVSxJQUFJLEVBQUUsSUFBSTs7d0JBQ3JCLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOzt3QkFDZixFQUFFLEdBQUksSUFBSSxDQUFDLElBQUksQ0FBQztvQkFDcEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRTt3QkFDNUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDaEIsRUFBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztxQkFDakI7b0JBQ0QsSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FBRyxFQUFHLEVBQUU7d0JBQ2hDLE9BQU8sQ0FBQyxDQUFBO3FCQUNUO3lCQUFNLElBQUksRUFBRSxLQUFLLFNBQVMsSUFBSSxFQUFFLEdBQUcsRUFBRSxFQUFFO3dCQUN0QyxPQUFPLENBQUMsQ0FBQyxDQUFDO3FCQUNYO3lCQUFNO3dCQUNMLE9BQU8sQ0FBQyxDQUFBO3FCQUNUO2lCQUNGLENBQUE7YUFDRjs7b0JBbFFGRCxhQUFVLFNBQUM7d0JBQ1YsVUFBVSxFQUFFLE1BQU07cUJBQ25COzs7O3dCQUxRLGdDQUFnQzs7OztpQ0FEekM7S0F3UUM7Ozs7Ozs7UUN6RHVDRSxzQ0FBa0I7UUFnRnhELDRCQUFZLFlBQXdCLEVBQ2hCLElBQVksRUFDWixFQUFxQixFQUNiLFdBQStCLEVBQy9CLFFBQWtCO1lBSjlDLFlBS0Usa0JBQU0sWUFBWSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsU0FDOUI7WUFIMkIsaUJBQVcsR0FBWCxXQUFXLENBQW9CO1lBQy9CLGNBQVEsR0FBUixRQUFRLENBQVU7WUFsRnJDLGlCQUFXLEdBQVcsUUFBUSxDQUFDO1lBUS9CLG1CQUFhLEdBQVksSUFBSSxDQUFDO1lBQzlCLFdBQUssR0FBUUMsbUJBQVcsQ0FBQztZQU96QixrQkFBWSxHQUFZLEtBQUssQ0FBQztZQUM5QixxQkFBZSxHQUFZLEtBQUssQ0FBQztZQUNqQyxrQkFBWSxHQUFZLEtBQUssQ0FBQztZQUM5QixvQkFBYyxHQUFRLEVBQUUsQ0FBQztZQUN6QixtQkFBYSxHQUFZLEtBQUssQ0FBQztZQVMvQixpQkFBVyxHQUFVLEVBQUUsQ0FBQztZQUV4QixnQkFBVSxHQUFVLEVBQUUsQ0FBQztZQUV2QixnQkFBVSxHQUFVLEVBQUUsQ0FBQztZQUV2QixtQkFBYSxHQUFVLEVBQUUsQ0FBQztZQUMxQiw0QkFBc0IsR0FBVSxFQUFFLENBQUM7WUFFbEMsY0FBUSxHQUFzQixJQUFJSixlQUFZLEVBQUUsQ0FBQztZQUNqRCxnQkFBVSxHQUFzQixJQUFJQSxlQUFZLEVBQUUsQ0FBQztZQW1CN0QsaUJBQVcsR0FBVyxDQUFDLENBQUM7WUFDeEIsZ0JBQVUsR0FBVyxDQUFDLENBQUM7WUFLdkIsb0JBQWMsR0FBVyxFQUFFLENBQUM7WUFLNUIscUJBQWUsR0FBVyxFQUFFLENBQUM7WUFHN0Isa0JBQVksR0FBVyxDQUFDLENBQUM7WUFDekIsZ0JBQVUsR0FBUSxFQUFFLENBQUM7WUFHckIseUJBQW1CLEdBQVUsRUFBRSxDQUFDOztTQVEvQjs7OztRQUVELG1DQUFNOzs7WUFBTjtnQkFFRSxJQUFJLENBQUMsSUFBSSxHQUFHSyxpQ0FBdUIsQ0FBQztvQkFDbEMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07b0JBQ25CLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTTtvQkFDcEIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO29CQUM3QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7b0JBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsY0FBYztvQkFDL0IsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjO29CQUMvQixVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU07b0JBQ3ZCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtpQkFDNUIsQ0FBQyxDQUFDO2dCQUVILElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztpQkFDbkY7Z0JBRUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2pDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDdkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO2lCQUNwQztnQkFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBRTNDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRTVELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTdELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUMzQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2pCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBRTdDLElBQUksQ0FBQyxTQUFTLEdBQUcsZUFBYSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sV0FBTSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFHLENBQUM7Z0JBRXZFLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxHQUFHQyxRQUFFLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxVQUFRLElBQUksQ0FBQyxVQUFVLE1BQUcsQ0FBQzs7Z0JBRzNDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7YUFFbEQ7Ozs7O1FBR0Qsc0NBQVM7Ozs7WUFBVCxVQUFVLFVBQVU7Z0JBQXBCLGlCQXNCQzs7b0JBckJLLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTTs7b0JBQ3BCLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTTs7b0JBQ3BCLEdBQUcsR0FBRyxFQUFFO2dCQUVaLFVBQVUsQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUUsS0FBSzs7d0JBQ3pCLEdBQUcsR0FBRzt3QkFDUixDQUFDLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLElBQUksRUFBRSxLQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFDLG1CQUFtQixDQUFDO3dCQUNqRSxLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7d0JBQ3pCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTt3QkFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQzt3QkFDckQsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN6QixTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUs7d0JBQ3JCLFFBQVEsRUFBRSxJQUFJLENBQUMsbUJBQW1CO3dCQUNsQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7cUJBQzFCO29CQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ2YsQ0FBQyxDQUFDO2dCQUVILE9BQU8sR0FBRyxDQUFDO2FBQ1o7Ozs7UUFFRCw0Q0FBZTs7O1lBQWY7Z0JBQUEsaUJBY0M7O29CQWJLLEdBQUcsR0FBRyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDdkIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBQSxLQUFLO3dCQUM1QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7O2dDQUNoQyxHQUFHLEdBQUc7Z0NBQ1IsSUFBSSxFQUFFLEtBQUssQ0FBQyxNQUFNO2dDQUNsQixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7NkJBQ25COzRCQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7eUJBQ2Q7cUJBQ0YsQ0FBQyxDQUFBO2lCQUNILENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsQ0FBQzthQUNaOzs7O1FBRUQsdUNBQVU7OztZQUFWOztvQkFDTSxNQUFNLEdBQUdDLG9DQUFzQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7b0JBQ3ZDLE1BQU0sR0FBRyxFQUFFO2dCQUVmLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUU7b0JBQy9CLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFBLENBQUMsQ0FBQztpQkFDckM7O29CQUVHLEdBQUc7O29CQUNILEdBQUc7Z0JBQ1AsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtvQkFDNUQsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTOzBCQUNoQixJQUFJLENBQUMsU0FBUzswQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUMsQ0FBQztvQkFFeEIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTOzBCQUNoQixJQUFJLENBQUMsU0FBUzswQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUMsQ0FBQztpQkFDekI7Z0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtvQkFDN0IsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDeEMsSUFBSSxDQUFDLElBQUksR0FBR0MsU0FBSSxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUM7OzRCQUMxQixLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7NEJBQ25CLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFO3dCQUN6QixJQUFJLEtBQUssR0FBRyxLQUFLOzRCQUFFLE9BQU8sQ0FBQyxDQUFDO3dCQUM1QixJQUFJLEtBQUssR0FBRyxLQUFLOzRCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxDQUFDO3FCQUNWLENBQUMsQ0FBQztpQkFDSjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO29CQUN0QyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7O29CQUVwQixJQUFJLENBQUMsSUFBSSxHQUFHQSxTQUFJLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQyxJQUFLLFFBQUMsQ0FBQyxHQUFHLENBQUMsSUFBQyxDQUFDLENBQUM7aUJBQ2pEO3FCQUFNO29CQUNMLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO2lCQUNwQjtnQkFFRCxPQUFPLE1BQU0sQ0FBQzthQUNmOzs7O1FBRUQsdUNBQVU7OztZQUFWOztvQkFDUSxNQUFNLEdBQUcsRUFBRTs7b0JBQ2pCLEtBQXNCLElBQUEsS0FBQU4sU0FBQSxJQUFJLENBQUMsT0FBTyxDQUFBLGdCQUFBO3dCQUE3QixJQUFNLE9BQU8sV0FBQTs7NEJBQ2hCLEtBQWdCLElBQUEsS0FBQUEsU0FBQSxPQUFPLENBQUMsTUFBTSxDQUFBLGdCQUFBO2dDQUF6QixJQUFNLENBQUMsV0FBQTtnQ0FDVixJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29DQUMxQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQ0FDdEI7Z0NBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQ0FDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0NBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQ0FDcEI7aUNBQ0Y7Z0NBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQ0FDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0NBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQ0FDcEI7aUNBQ0Y7NkJBQ0Y7Ozs7Ozs7Ozs7Ozs7OztxQkFDRjs7Ozs7Ozs7Ozs7Ozs7OztvQkFFSyxNQUFNLFlBQU8sTUFBTSxDQUFDO2dCQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDaEI7O29CQUVLLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUztzQkFDdEIsSUFBSSxDQUFDLFNBQVM7c0JBQ2QsSUFBSSxDQUFDLEdBQUcsT0FBUixJQUFJLFdBQVEsTUFBTSxFQUFDOztvQkFFakIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO3NCQUN0QixJQUFJLENBQUMsU0FBUztzQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUM7Z0JBRXJCLElBQUksR0FBRyxLQUFLLFNBQVMsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO29CQUMxQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUNuQjtxQkFBSztvQkFDSixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7aUJBQ3BCOzthQUNKOzs7O1FBRUQsNENBQWU7OztZQUFmO2dCQUNFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsSUFBSSxHQUFBLENBQUMsQ0FBQzthQUN0Qzs7Ozs7O1FBRUQsc0NBQVM7Ozs7O1lBQVQsVUFBVSxNQUFNLEVBQUUsS0FBSzs7b0JBQ2pCLEtBQUs7Z0JBRVQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtvQkFDN0IsS0FBSyxHQUFHTyxpQkFBUyxFQUFFO3lCQUNoQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDbkI7cUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtvQkFDdEMsS0FBSyxHQUFHQyxtQkFBVyxFQUFFO3lCQUNsQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFbEIsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO3dCQUNyQixLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO3FCQUN0QjtpQkFDRjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFO29CQUN2QyxLQUFLLEdBQUdDLGtCQUFVLEVBQUU7eUJBQ2pCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzt5QkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQzt5QkFDWixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ25CO2dCQUVELE9BQU8sS0FBSyxDQUFDO2FBQ2Q7Ozs7OztRQUVELHNDQUFTOzs7OztZQUFULFVBQVUsTUFBTSxFQUFFLE1BQU07O29CQUNoQixLQUFLLEdBQUdELG1CQUFXLEVBQUU7cUJBQ3hCLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDbEIsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFFakIsT0FBTyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUM7YUFDakQ7Ozs7O1FBRUQseUNBQVk7Ozs7WUFBWixVQUFhLE1BQU07O29CQUNiLElBQUksR0FBRyxJQUFJOztvQkFDWCxHQUFHLEdBQUcsSUFBSTs7b0JBRWQsS0FBb0IsSUFBQSxXQUFBUixTQUFBLE1BQU0sQ0FBQSw4QkFBQTt3QkFBckIsSUFBTSxLQUFLLG1CQUFBO3dCQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFOzRCQUN2QixJQUFJLEdBQUcsS0FBSyxDQUFDO3lCQUNkO3dCQUVELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFOzRCQUM3QixHQUFHLEdBQUcsS0FBSyxDQUFDO3lCQUNiO3FCQUNGOzs7Ozs7Ozs7Ozs7Ozs7Z0JBRUQsSUFBSSxJQUFJO29CQUFFLE9BQU8sTUFBTSxDQUFDO2dCQUN4QixJQUFJLEdBQUc7b0JBQUUsT0FBTyxRQUFRLENBQUM7Z0JBQ3pCLE9BQU8sU0FBUyxDQUFDOzthQUNsQjs7Ozs7UUFFRCxtQ0FBTTs7OztZQUFOLFVBQU8sS0FBSztnQkFDVixJQUFJLEtBQUssWUFBWSxJQUFJLEVBQUU7b0JBQ3pCLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUVELE9BQU8sS0FBSyxDQUFDO2FBQ2Q7Ozs7O1FBRUQsNkNBQWdCOzs7O1lBQWhCLFVBQWlCLEVBQVM7b0JBQVAsZ0JBQUs7Z0JBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDZjs7Ozs7UUFFRCw4Q0FBaUI7Ozs7WUFBakIsVUFBa0IsRUFBVTtvQkFBUixrQkFBTTtnQkFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUNmOzs7OztRQUVELGtEQUFxQjs7OztZQUFyQixVQUFzQixJQUFJO2dCQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQTtnQkFFdEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUNsQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDdEI7Ozs7UUFHRCx3Q0FBVzs7O1lBRFg7Z0JBRUUsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUM7YUFDbEQ7Ozs7O1FBR0QseUNBQVk7Ozs7WUFEWixVQUNhLE1BQU07Z0JBQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzVCOzs7OztRQUdELHlDQUFZOzs7O1lBRFosVUFDYSxNQUFNO2dCQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUM5Qjs7Ozs7O1FBRUQsb0NBQU87Ozs7O1lBQVAsVUFBUSxJQUFJLEVBQUUsTUFBTztnQkFDbkIsSUFBSSxNQUFNLEVBQUU7b0JBQ1YsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO2lCQUMzQjtnQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN4Qjs7Ozs7O1FBRUQsb0NBQU87Ozs7O1lBQVAsVUFBUSxLQUFLLEVBQUUsSUFBSTtnQkFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2xCOzs7O1FBRUQsc0NBQVM7OztZQUFUOztvQkFDTSxNQUFNO2dCQUNWLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUU7b0JBQ2pDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO2lCQUM1QjtxQkFBTTtvQkFDTCxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztpQkFDdkI7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJVSxxQkFBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQ3hGOzs7O1FBRUQsNkNBQWdCOzs7WUFBaEI7O29CQUNRLElBQUksR0FBRztvQkFDWCxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVU7b0JBQzFCLE1BQU0sRUFBRSxTQUFTO29CQUNqQixNQUFNLEVBQUUsRUFBRTtvQkFDVixLQUFLLEVBQUUsU0FBUztpQkFDakI7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRTtvQkFDaEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUNoQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7b0JBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztpQkFDL0I7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUMzQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2lCQUNqQztnQkFDRCxPQUFPLElBQUksQ0FBQzthQUNiOzs7OztRQUVELHVDQUFVOzs7O1lBQVYsVUFBVyxJQUFJO2dCQUNiLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzs7b0JBRWYsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFVBQUEsQ0FBQztvQkFDeEMsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUN2RCxDQUFDO2dCQUNGLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUNaLE9BQU87aUJBQ1I7Z0JBRUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO2dCQUVqRSxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQTtnQkFDdEQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzthQUN2Qjs7Ozs7UUFFRCx5Q0FBWTs7OztZQUFaLFVBQWEsSUFBSTs7b0JBQ1QsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFVBQUEsQ0FBQztvQkFDeEMsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUN2RCxDQUFDO2dCQUVGLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLGFBQWEsWUFBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7YUFDcEU7Ozs7UUFFRCwwQ0FBYTs7O1lBQWI7Z0JBQ0UsSUFBSSxDQUFDLGFBQWEsWUFBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7O29CQUM3QyxLQUFvQixJQUFBLEtBQUFWLFNBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQSxnQkFBQTt3QkFBakMsSUFBTSxLQUFLLFdBQUE7d0JBQ2QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUNyRDs7Ozs7Ozs7Ozs7Ozs7O2dCQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDOzthQUN6Qjs7OztRQUVELDJDQUFjOzs7WUFBZDs7b0JBQ00sU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO2dCQUM1QyxJQUFJLFNBQVMsRUFBRTtvQkFDYixJQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUU7d0JBQ2xCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUE7cUJBQ25DO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUE7cUJBQ25DO2lCQUNGO2FBRUY7Ozs7UUFFRCw4Q0FBaUI7OztZQUFqQjs7b0JBQ00sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPOztvQkFDbEIsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDOztvQkFDbEMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOztvQkFDbkMsVUFBVSxHQUFHLEVBQUU7O29CQUNmLEdBQUc7Z0JBRVAsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ25DLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDL0IsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUMvQyxNQUFNO3FCQUNQO2lCQUNGOztvQkFFRyxNQUFNLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQztnQkFFakMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3RDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDbEMsR0FBRyxHQUFHOzRCQUNKLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDOzRCQUN2QixXQUFXLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQzt5QkFDcEMsQ0FBQTt3QkFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQTt3QkFDckQsTUFBTTtxQkFDUDtpQkFDRjthQUNGOzs7Ozs7O1FBR0EsK0NBQWtCOzs7Ozs7WUFBbEIsVUFBbUIsSUFBSTtnQkFDdEIsSUFBSSxJQUFJLEVBQUU7O3dCQUNKLGtCQUFnQixHQUFHLEtBQUs7b0JBQzVCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO3dCQUNuQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7NEJBQ2hELGtCQUFnQixHQUFHLElBQUksQ0FBQzs0QkFDeEIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7eUJBQ3hCOzZCQUFNOzRCQUNMLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO3lCQUNuQjtxQkFDRixDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLGtCQUFnQixFQUFDOzs0QkFDaEIsR0FBRyxHQUFHOzRCQUNSLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDVCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7NEJBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJO3lCQUMxQzt3QkFDRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNwQztpQkFDRjthQUNGOzs7OztRQUVELGdEQUFtQjs7OztZQUFuQixVQUFvQixJQUFJOztvQkFDbEIsU0FBUyxHQUFHLEtBQUs7Z0JBQ3JCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNuQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7d0JBQ2hELFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO3FCQUN2QjtpQkFDRixDQUFDLENBQUM7Z0JBQ0gsT0FBTyxTQUFTLENBQUM7YUFDbEI7Ozs7O1FBRUQsNkNBQWdCOzs7O1lBQWhCLFVBQWlCLE1BQU07O29CQUNqQixTQUFTLEdBQUcsQ0FBQztnQkFDZixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7b0JBQ25FLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxHQUFFLEdBQUcsQ0FBQTtpQkFDMUI7cUJBQU07b0JBQ0wsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUUsRUFBRSxDQUFBO2lCQUN6QjtnQkFDRCxPQUFPLFNBQVMsQ0FBQzthQUNsQjs7Ozs7UUFFRCw2Q0FBZ0I7Ozs7WUFBaEIsVUFBaUIsTUFBTTs7b0JBQ2pCLFNBQVMsR0FBRyxDQUFDO2dCQUNqQixJQUFHLE1BQU0sQ0FBQyxTQUFTLElBQUcsQ0FBQyxFQUFFO29CQUN2QixTQUFTLEdBQUcsTUFBTSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUE7aUJBQzlCO3FCQUFNO29CQUNMLFNBQVMsR0FBRyxNQUFNLENBQUMsS0FBSyxHQUFFLEdBQUcsQ0FBQTtpQkFDOUI7Z0JBQ0QsT0FBTyxTQUFTLENBQUE7YUFDakI7O29CQWhzQkZXLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUscUJBQXFCO3dCQUMvQixRQUFRLEVBQUUsb3ZNQWdLTDt3QkFDTCxNQUFNLEVBQUUsQ0FBQywrOUxBQSs5TCxDQUFDO3dCQUN6K0wsYUFBYSxFQUFFQyxvQkFBaUIsQ0FBQyxTQUFTO3dCQUMxQyxlQUFlLEVBQUVDLDBCQUF1QixDQUFDLE1BQU07d0JBQy9DLFVBQVUsRUFBRTs0QkFDVkMsa0JBQU8sQ0FBQyxnQkFBZ0IsRUFBRTtnQ0FDeEJDLHFCQUFVLENBQUMsUUFBUSxFQUFFO29DQUNuQkMsZ0JBQUssQ0FBQzt3Q0FDSixPQUFPLEVBQUUsQ0FBQztxQ0FDWCxDQUFDO29DQUNGQyxrQkFBTyxDQUFDLEdBQUcsRUFBRUQsZ0JBQUssQ0FBQzt3Q0FDakIsT0FBTyxFQUFFLENBQUM7cUNBQ1gsQ0FBQyxDQUFDO2lDQUNKLENBQUM7NkJBQ0gsQ0FBQzt5QkFDSDtxQkFDRjs7Ozt3QkE3TUNFLGFBQVU7d0JBQUVDLFNBQU07d0JBQUVDLG9CQUFpQjt3QkF5QjlCLGtCQUFrQjt3QkFSbEJDLGVBQVE7Ozs7NkJBOExkQyxRQUFLO2tDQUNMQSxRQUFLO3FDQUNMQSxRQUFLO3FDQUNMQSxRQUFLO2lDQUNMQSxRQUFLO2lDQUNMQSxRQUFLO2dDQUNMQSxRQUFLOytCQUNMQSxRQUFLOytCQUNMQSxRQUFLO29DQUNMQSxRQUFLOzRCQUNMQSxRQUFLO2lDQUNMQSxRQUFLO3VDQUNMQSxRQUFLOzBDQUNMQSxRQUFLOzBDQUNMQSxRQUFLO2lDQUNMQSxRQUFLO2lDQUNMQSxRQUFLO21DQUNMQSxRQUFLO3NDQUNMQSxRQUFLO21DQUNMQSxRQUFLO3FDQUNMQSxRQUFLO29DQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2lDQUNMQSxRQUFLOzZCQUNMQSxRQUFLOzRCQUNMQSxRQUFLOzZCQUNMQSxRQUFLO2tDQUNMQSxRQUFLOzhCQUNMQSxRQUFLO2lDQUNMQSxRQUFLO3NDQUNMQSxRQUFLO2lDQUNMQSxRQUFLO3NDQUNMQSxRQUFLO29DQUNMQSxRQUFLOzZDQUNMQSxRQUFLOytCQUVMQyxTQUFNO2lDQUNOQSxTQUFNO3NDQUVOQyxlQUFZLFNBQUMsaUJBQWlCOzRDQUM5QkEsZUFBWSxTQUFDLHVCQUF1QjtrQ0F1U3BDQyxlQUFZLFNBQUMsWUFBWTttQ0FPekJBLGVBQVksU0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLENBQUM7bUNBS3JDQSxlQUFZLFNBQUMsWUFBWSxFQUFFLENBQUMsUUFBUSxDQUFDOztRQStLeEMseUJBQUM7S0FBQSxDQTlnQnVDQyw0QkFBa0I7Ozs7OztBQy9NMUQ7UUErQkUsK0JBQXdCLDJCQUE4RCxFQUMzRSxXQUFnQztZQURuQixnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQW1DO1lBQzNFLGdCQUFXLEdBQVgsV0FBVyxDQUFxQjtTQUN2Qzs7OztRQUVKLHdDQUFROzs7WUFBUjthQUVDOzs7O1FBRUQsMkNBQVc7OztZQUFYO2FBQ0M7Ozs7O1FBRUQsMERBQTBCOzs7O1lBQTFCLFVBQTJCLElBQUk7Z0JBRTdCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUU7b0JBQ3BCLE9BQU8sS0FBSyxDQUFBO2lCQUNiO3FCQUFNOzt3QkFDQyxJQUFJLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTs7d0JBQ3ZELE1BQUksR0FBRyxLQUFLO29CQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTt3QkFDZixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFOzRCQUM3QyxNQUFJLEdBQUcsSUFBSSxDQUFDO3lCQUNiO3FCQUNGLENBQUMsQ0FBQTtvQkFDRixPQUFPLE1BQUksQ0FBQTtpQkFDWjthQUNGOzs7OztRQUNELG1EQUFtQjs7OztZQUFuQixVQUFvQixJQUFJOztvQkFDbEIsUUFBUSxHQUFHLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDM0IsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUNuQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO3FCQUMxQjtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxRQUFRLENBQUM7YUFDakI7Ozs7O1FBR0Qsc0NBQU07Ozs7WUFBTixVQUFPLElBQUk7Z0JBQ1QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7O29CQUNyRCxTQUFTLEdBQUcsQ0FBQyxDQUFDO2dCQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBRSxLQUFLO29CQUMvQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ2pDLFNBQVMsR0FBRyxLQUFLLENBQUM7cUJBQ25CO2lCQUNGLENBQUMsQ0FBQztnQkFFSCxJQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbkM7Z0JBRUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNwQzs7b0JBOUVGZixZQUFTLFNBQUM7d0JBQ1QsUUFBUSxFQUFFLG1CQUFtQjt3QkFDN0IsUUFBUSxFQUFFLGdrQkFjSzt3QkFDZixNQUFNLEVBQUUsQ0FBQyxnVkFBZ1YsQ0FBQztxQkFDM1Y7Ozs7d0JBcEJRLGdDQUFnQzt3QkFEaEMsa0JBQWtCOzs7OzhCQXVCeEJXLFFBQUs7aUNBQ0xBLFFBQUs7Z0NBQ0xBLFFBQUs7a0NBQ0xBLFFBQUs7NEJBQ0xBLFFBQUs7eUNBQ0xBLFFBQUs7O1FBdURSLDRCQUFDO0tBQUE7Ozs7OztBQ3BGRDtBQUtBOzs7UUFTRSxvQkFBb0IsSUFBZ0I7WUFBaEIsU0FBSSxHQUFKLElBQUksQ0FBWTtZQUo1QixTQUFJLEdBQTRCLElBQUlLLG9CQUFlLEdBQUMsRUFBRSxHQUFVLENBQUM7U0FJaEM7Ozs7O1FBR3pDLGdDQUFXOzs7O1lBQVgsVUFBWSxLQUFLO2dCQUNmLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQVEsWUFBWSxDQUFDLENBQUM7YUFDM0M7Ozs7OztRQUVELGtDQUFhOzs7OztZQUFiO2dCQUFBLGlCQVVDOztnQkFSQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUlBLG9CQUFlLEdBQUMsRUFBRSxHQUFVLENBQUM7Z0JBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFRLG9EQUFvRCxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUMvRyxTQUFTLENBQUMsVUFBQSxDQUFDO29CQUNWLEtBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsR0FBVSxDQUFBO2lCQUMzQixFQUNDLFVBQUEsS0FBSztvQkFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO2lCQUNuQixDQUFDLENBQUM7YUFDUjs7Ozs7O1FBRUQsZ0NBQVc7Ozs7O1lBQVg7Z0JBQ0ksT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQ25DOzs7OztRQUNELHVDQUFrQjs7OztZQUFsQixVQUFtQixJQUFZOztnQkFFN0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBUSw4Q0FBOEMsR0FBQyxJQUFJLENBQUMsQ0FBQzthQUNsRjs7b0JBbENGNUIsYUFBVSxTQUFDO3dCQUNWLFVBQVUsRUFBRSxNQUFNO3FCQUNuQjs7Ozt3QkFOUTZCLGFBQVU7Ozs7eUJBRG5CO0tBeUNDOzs7Ozs7OztRQ3hDRyxVQUFXLFVBQVU7UUFDckIsUUFBUyxRQUFRO1FBQ2pCLGVBQWdCLGVBQWU7UUFDL0IsV0FBWSxXQUFXOzs7Ozs7O0FDSjNCO0FBTUE7Ozs7O1FBZUk7WUFQUSxRQUFHLEdBQStCLElBQUlELG9CQUFlLEdBQUMsRUFBRSxHQUFhLENBQUM7WUFRdEUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUM5Qjs7OztRQUVNLHFDQUFVOzs7WUFBakI7Z0JBQUEsaUJBU0M7Z0JBUkcsSUFBSSxDQUFDLE9BQU8sR0FBR0UsbUJBQVMsQ0FBQyxRQUFRLEdBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEdBQUMsR0FBRyxHQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFDLDJCQUEyQixDQUFDLENBQUM7O2dCQUVqSCxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FDbEIsVUFBQyxHQUFHLElBQU0sS0FBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUMsR0FBRyxHQUFhLENBQUMsRUFBQyxFQUMxQyxVQUFDLEdBQUcsSUFBSyxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFDLEdBQUcsQ0FBQyxHQUFBLEVBQ3JDLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLEdBQUEsQ0FDakQsQ0FBQzs7YUFFTDs7OztRQUVNLGlDQUFNOzs7WUFBYjtnQkFDSSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDbEM7Ozs7O1FBQ00sK0JBQUk7Ozs7WUFBWCxVQUFZLE9BQWdCO2dCQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUM5Qjs7Ozs7UUFFTSx3Q0FBYTs7OztZQUFwQixVQUFxQixLQUFZO2dCQUFqQyxpQkFLQztnQkFIRyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDaEIsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFDLFFBQVEsRUFBQyxNQUFNLENBQUMsU0FBUyxFQUFDLFFBQVEsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFBO2lCQUNyRCxDQUFDLENBQUM7YUFDTjs7Ozs7UUFDTSwwQ0FBZTs7OztZQUF0QixVQUF1QixLQUFZO2dCQUFuQyxpQkFJQztnQkFIRyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDaEIsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFDLFFBQVEsRUFBQyxNQUFNLENBQUMsYUFBYSxFQUFDLFFBQVEsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFBO2lCQUN6RCxDQUFDLENBQUM7YUFDTjs7OztRQUNNLDBDQUFlOzs7WUFBdEI7Z0JBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLE1BQU0sRUFBQyxNQUFNLENBQUMsUUFBUSxFQUFDLFNBQVMsRUFBQyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsRUFBQyxjQUFjLEVBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO2FBQzlIOztvQkFuREo5QixhQUFVLFNBQUM7d0JBQ1IsVUFBVSxFQUFFLE1BQU07cUJBQ3JCOzs7OytCQVJEO0tBMERDOzs7Ozs7QUMxREQ7UUFTRTtZQUFBLGlCQVVFO1lBRU0sc0JBQWlCLEdBQVUsRUFBRSxDQUFDO1lBQzlCLGtCQUFhLEdBQVUsRUFBRSxDQUFDOzs7WUFWOUIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixFQUFDLFVBQUMsS0FBSztnQkFDL0MsSUFBRyxRQUFRLENBQUMsTUFBTSxFQUFFO29CQUNsQixLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN0QjtxQkFBTTtvQkFDTCxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUNwQjthQUNGLENBQUMsQ0FBQTtTQUNKOzs7OztRQUlNLHlDQUFROzs7O1lBQWhCLFVBQWlCLEtBQVU7O2dCQUV4QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7YUFDcEI7Ozs7UUFDTywyQ0FBVTs7O1lBQWxCO2dCQUNJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUcsVUFBQSxJQUFJOzt3QkFDL0IsSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFO29CQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLDBDQUF3QyxJQUFJLFVBQUssSUFBTSxDQUFDLENBQUM7b0JBQ3JFLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDdkIsQ0FBQyxDQUFBO2FBQ0g7Ozs7O1FBQ08sdUNBQU07Ozs7WUFBZCxVQUFlLEtBQVU7Z0JBQXpCLGlCQU9DOztnQkFMQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBRSxVQUFBLElBQUk7O29CQUc5QixLQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDMUUsQ0FBQyxDQUFBO2FBQ0g7Ozs7OztRQUNELCtDQUFjOzs7OztZQUFkLFVBQWUsWUFBWSxFQUFFLFFBQWdCOztvQkFDdkMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDO2dCQUNsRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFDLE1BQU0sRUFBQyxZQUFZLEVBQUUsVUFBVSxFQUFDLFFBQVEsRUFBQyxDQUFDLENBQUM7YUFDckU7Ozs7OztRQUVELCtDQUFjOzs7OztZQUFkO2dCQUNFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7YUFDekI7O29CQWhERkEsYUFBVSxTQUFDO3dCQUNWLFVBQVUsRUFBRSxNQUFNO3FCQUNuQjs7OztxQ0FORDtLQXFEQzs7Ozs7OztBQ3JERCxRQUFhLFlBQVksR0FBRyxFQUFFOztBQUU1QixRQUFhLFlBQVksR0FBSTtRQUMzQjtZQUNFLElBQUksRUFBRSxPQUFPO1lBQ2IsSUFBSSxFQUFFLG1CQUFtQjtZQUN6QixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLEtBQUs7WUFDcEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLFNBQVM7WUFDdkIsaUJBQWlCLEVBQUUsWUFBWTtZQUMvQixlQUFlLEVBQUUsVUFBVTtZQUMzQixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLG9CQUFvQjtZQUMxQixJQUFJLEVBQUUsWUFBWTtZQUNsQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLEtBQUs7WUFDcEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLFNBQVM7WUFDdkIsaUJBQWlCLEVBQUUsWUFBWTtZQUMvQixlQUFlLEVBQUUsVUFBVTtZQUMzQixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLFVBQVU7WUFDaEIsSUFBSSxFQUFFLE9BQU87WUFDYixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLEtBQUs7WUFDcEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtZQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1lBQ2hDLGVBQWUsRUFBRSxXQUFXO1lBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxVQUFVLEVBQUUsS0FBSztZQUNqQixtQkFBbUIsRUFBRSxFQUFFO1NBQ3hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsVUFBVTtZQUNoQixJQUFJLEVBQUUsZ0JBQWdCO1lBQ3RCLEtBQUssRUFBRSxFQUFFO1lBQ1QsU0FBUyxFQUFFLElBQUk7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsbUJBQW1CO1lBQ2pDLGlCQUFpQixFQUFFLGFBQWE7WUFDaEMsZUFBZSxFQUFFLFdBQVc7WUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxPQUFPO1lBQ2IsSUFBSSxFQUFFLGVBQWU7WUFDckIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxtQkFBbUI7WUFDakMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsV0FBVztZQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLElBQUk7WUFDVixJQUFJLEVBQUUsY0FBYztZQUNwQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLElBQUk7WUFDbkIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtZQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1lBQ2hDLGVBQWUsRUFBRSxXQUFXO1lBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxVQUFVLEVBQUUsS0FBSztZQUNqQixtQkFBbUIsRUFBRSxFQUFFO1NBQ3hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsb0JBQW9CO1lBQzFCLElBQUksRUFBRSxnQkFBZ0I7WUFDdEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxlQUFlO1lBQzdCLGlCQUFpQixFQUFFLGFBQWE7WUFDaEMsZUFBZSxFQUFFLFlBQVk7WUFDN0Isa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxXQUFXO1lBQ2pCLElBQUksRUFBRSxZQUFZO1lBQ2xCLEtBQUssRUFBRSxFQUFFO1lBQ1QsU0FBUyxFQUFFLElBQUk7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsa0JBQWtCO1lBQ2hDLGlCQUFpQixFQUFFLGFBQWE7WUFDaEMsZUFBZSxFQUFFLFlBQVk7WUFDN0Isa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7S0FDRjs7QUFFRCxRQUFhLHlCQUF5QixHQUFHOzs7Ozs7UUFNdkM7WUFDRSxJQUFJLEVBQUUsZUFBZTtZQUNyQixJQUFJLEVBQUUsY0FBYztZQUNwQixVQUFVLEVBQUUsS0FBSztTQUNsQjtRQUNEO1lBQ0UsSUFBSSxFQUFFLGFBQWE7WUFDbkIsSUFBSSxFQUFFLFlBQVk7WUFDbEIsVUFBVSxFQUFFLEtBQUs7U0FDbEI7S0FNRjs7Ozs7OztRQ3hGd0NFLHlDQUFtQjtRQXFCNUQsK0JBQW9CLFVBQXNCLEVBRWQsVUFBc0IsRUFDdEIsZ0JBQWtDLEVBQ2xDLGdDQUFrRSxFQUNsRSxXQUErQixFQUMvQixjQUFzQztZQU5sRSxZQU9FLGlCQUFPLFNBQ1I7WUFSbUIsZ0JBQVUsR0FBVixVQUFVLENBQVk7WUFFZCxnQkFBVSxHQUFWLFVBQVUsQ0FBWTtZQUN0QixzQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1lBQ2xDLHNDQUFnQyxHQUFoQyxnQ0FBZ0MsQ0FBa0M7WUFDbEUsaUJBQVcsR0FBWCxXQUFXLENBQW9CO1lBQy9CLG9CQUFjLEdBQWQsY0FBYyxDQUF3QjtZQXhCbEUsVUFBSSxHQUFVLEVBQUUsQ0FBQztZQUNqQixlQUFTLEdBQVUsRUFBRSxDQUFDO1lBQ3RCLHFCQUFlLEdBQVksS0FBSyxDQUFDO1lBQ2pDLGVBQVMsR0FBUSxFQUFFLENBQUM7WUFDcEIsZUFBUyxHQUFVLEVBQUUsQ0FBQztZQUN0QixxQkFBZSxHQUFZLEtBQUssQ0FBQztZQUNqQyxtQkFBYSxHQUFVLEVBQUUsQ0FBQztZQUMxQixtQkFBYSxHQUFZLElBQUksQ0FBQztZQUM5QixrQkFBWSxHQUFXLEVBQUUsQ0FBQzs7WUFFMUIsdUJBQWlCLEdBQVcsS0FBSyxDQUFDO1lBQ2xDLGtCQUFZLEdBQVUsWUFBWSxDQUFDO1lBQ25DLGtCQUFZLEdBQVUsWUFBWSxDQUFDO1lBQ25DLCtCQUF5QixHQUFVLHlCQUF5QixDQUFDO1lBQzdELFdBQUssR0FBVyxDQUFDLENBQUM7WUFDbEIsa0JBQVksR0FBVyxFQUFFLENBQUM7WUFDMUIsb0JBQWMsR0FBWSxLQUFLLENBQUM7WUFDaEMsY0FBUSxHQUFRLEVBQUUsQ0FBQzs7U0FTbEI7Ozs7UUFFRCx3Q0FBUTs7O1lBQVI7Z0JBQUEsaUJBK0JDOztnQkE3QkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0JBRTdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGdDQUFnQyxDQUFDLFFBQVEsQ0FBQztnQkFDL0QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQzdCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2lCQUM3QjtxQkFDRzs7b0JBRUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQ3JDLFVBQUEsSUFBSTt3QkFDRCxJQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOztnQ0FFYixRQUFRLEdBQUcsRUFBRTs0QkFDbkIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7NEJBQzlCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUM1QixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQTs0QkFDakMsS0FBSSxDQUFDLGdDQUFnQyxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUM1RSxLQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQzt5QkFDOUI7cUJBRUYsQ0FBQyxDQUFDO2lCQUNOO2dCQUNELElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29CQUN0RSxPQUFPLENBQUMsR0FBRyxVQUFLLEtBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsS0FBSSxDQUFDLElBQUksRUFBRSxLQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztvQkFDbEgsS0FBSSxDQUFDLElBQUksWUFBTyxLQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7aUJBQ2xILENBQUMsQ0FBQzthQUNKOzs7O1FBSUQscURBQXFCOzs7WUFBckI7Z0JBQUEsaUJBMkJDO2dCQTFCQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxRQUFRLENBQUM7Z0JBQy9ELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNFLFVBQUEsSUFBSTt3QkFDRixLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzt3QkFDNUIsS0FBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzdCLEtBQUksQ0FBQyxJQUFJLFlBQU8sS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM1QixDQUNGLENBQUMsQ0FBQztvQkFFSCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxVQUFDLElBQUk7d0JBQ0gsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssWUFBWSxFQUFFOztnQ0FDaEMsWUFBWSxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLENBQUM7NEJBQzdFLEtBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUE7eUJBQzdCOzZCQUFNOzRCQUNMLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUE7eUJBQ3JCO3FCQUNGLENBQ0YsQ0FDQSxDQUFDO29CQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFMUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsY0FBUSxLQUFJLENBQUMsSUFBSSxZQUFPLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxDQUFDLENBQUM7aUJBQzdFO2FBQ0Y7Ozs7UUFHRCwyQ0FBVzs7O1lBQVg7Z0JBQ0UsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUUsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsV0FBVyxFQUFFLEdBQUEsQ0FBQyxDQUFDO2lCQUM5QztnQkFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ3RDOzs7OztRQUVELHlDQUFTOzs7O1lBQVQsVUFBVSxJQUFJO2dCQUFkLGlCQXFCQztnQkFwQkMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDaEcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUU7OzRCQUN0QixRQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7NEJBQ3ZCLE9BQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDOzs0QkFDckIsb0JBQWtCLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDO3dCQUNyRCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7NEJBQ3BCLElBQUksS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLE9BQUssSUFBSSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxvQkFBa0IsRUFBRTtnQ0FDL0csS0FBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBQSxPQUFPO29DQUFNLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7d0NBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO3FDQUFFO2lDQUFDLENBQUMsQ0FBQzs2QkFDckg7eUJBQ0YsQ0FBQyxDQUFDO3FCQUNKO2lCQUNGO2dCQUNELElBQUcsSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsVUFBQSxJQUFJO3dCQUNELEtBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUM3QixLQUFJLENBQUMsSUFBSSxZQUFPLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDNUIsQ0FDSCxDQUFBO2lCQUNGO2FBQ0Y7Ozs7Ozs7Ozs7UUFLRCwrQ0FBZTs7Ozs7OztZQUFmO2dCQUNFLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQzthQUNsRDs7b0JBM0tGVSxZQUFTLFNBQUM7d0JBQ1QsUUFBUSxFQUFFLG1CQUFtQjt3QkFDN0IsUUFBUSxFQUFFLDBuQ0FpQ0w7d0JBQ0wsTUFBTSxFQUFFLENBQUMsZ2dWQUEwL1UsRUFBRSw4Y0FBOGMsQ0FBQztxQkFFcjlWOzs7O3dCQS9DUSxVQUFVO3dCQURXbUIsbUJBQVU7d0JBRS9CLGdCQUFnQjt3QkFHaEIsZ0NBQWdDO3dCQUZoQyxrQkFBa0I7d0JBSWxCLHNCQUFzQjs7O1FBK0svQiw0QkFBQztLQUFBLENBckkwQ0MsNEJBQW1COzs7Ozs7QUNsRDlEO1FBMkNHLCtCQUNVLFdBQStCLEVBQ2pDLFNBQThDLEVBQ3JCLElBQVM7WUFGaEMsZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1lBQ2pDLGNBQVMsR0FBVCxTQUFTLENBQXFDO1lBQ3JCLFNBQUksR0FBSixJQUFJLENBQUs7WUFDdkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQzlDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1NBQzNDOzs7O1FBRUQsd0NBQVE7OztZQUFSO2FBQ0Q7Ozs7O1FBRUQsZ0RBQWdCOzs7O1lBQWhCLFVBQWlCLElBQUk7O29CQUNiLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ3BFOzs7O1FBRUQsb0RBQW9COzs7WUFBcEI7Z0JBQUEsaUJBYUM7O29CQVpPLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxHQUFBLENBQUM7O29CQUNyRSxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUksR0FBQSxDQUFDO2dCQUN2RSxjQUFjLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDeEIsS0FBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNuQyxDQUFDLENBQUM7Z0JBRUgsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ3RCLEtBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDbkMsQ0FBQyxDQUFDO2dCQUVILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNuQjs7Ozs7UUFFRCxzREFBc0I7Ozs7WUFBdEIsVUFBdUIsSUFBSTtnQkFFekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7YUFDbkU7Ozs7UUFFRCx5Q0FBUzs7O1lBQVQ7Z0JBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUN4Qjs7b0JBNUVGcEIsWUFBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSxvQkFBb0I7d0JBQzlCLFFBQVEsRUFBRSxpaENBNEJMO3dCQUNMLE1BQU0sRUFBRSxDQUFDLHFZQUFxWSxDQUFDO3FCQUNoWjs7Ozt3QkFuQ1Esa0JBQWtCO3dCQURuQnFCLHFCQUFZO3dEQTZDZkMsU0FBTSxTQUFDQyx3QkFBZTs7O1FBcUMzQiw0QkFBQztLQUFBOzs7Ozs7OztBQ2xGRCxRQUFhLHNCQUFzQixHQUFHO1FBQ2xDO1lBQ0ksTUFBTSxFQUFFLFNBQVM7WUFDakIsS0FBSyxFQUFDLFNBQVM7U0FDbEI7UUFDRDtZQUNJLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLEtBQUssRUFBQyxTQUFTO1NBQ2xCO1FBQ0Q7WUFDSSxNQUFNLEVBQUUsU0FBUztZQUNqQixLQUFLLEVBQUMsU0FBUztTQUNsQjtRQUNEO1lBQ0ksTUFBTSxFQUFFLFNBQVM7WUFDakIsS0FBSyxFQUFDLFNBQVM7U0FDbEI7S0FDSjs7O0FBT0QsUUFBYSxtQkFBbUIsR0FBRztRQUMvQjtZQUNJLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDVCxLQUFLLEVBQUUsU0FBUztTQUNuQjtRQUNEO1lBQ0ksS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNULEtBQUssRUFBRSxTQUFTO1NBQ25CO1FBQ0Q7WUFDSSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQ1QsS0FBSyxFQUFFLFNBQVM7U0FDbkI7UUFDRDtZQUNJLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSyxFQUFFLFNBQVM7U0FDbkI7UUFDRDtZQUNJLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSyxFQUFFLFNBQVM7U0FDbkI7UUFDRDtZQUNJLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSyxFQUFFLFNBQVM7U0FDbkI7S0FDSjs7QUFFRCxRQUFhLGtCQUFrQixHQUFHO1FBQzlCLE1BQU0sRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxTQUFTLEVBQUMsU0FBUyxDQUFDO0tBQ3pFOzs7Ozs7O0FDdERILFFBQWEsZUFBZSxHQUFHO1FBRTdCO1lBQ0UsTUFBTSxFQUFFLEVBQUU7WUFDVixRQUFRLEVBQUU7Z0JBQ1I7b0JBQ0UsTUFBTSxFQUFFLFVBQVU7b0JBQ2xCLE9BQU8sRUFBRSxHQUFHO29CQUNaLEtBQUssRUFBRSxLQUFLO29CQUNaLFdBQVcsRUFBRSxLQUFLO2lCQUNuQjthQUNGO1NBQ0Y7S0FDRjs7QUFFRCxRQUFhLFVBQVUsR0FBRztRQUN0QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztLQUM3Qjs7Ozs7OztRQ2dEdUNqQywwQ0FBbUI7UUE0QjdELGdDQUFZLFlBQXdCLEVBQUUsSUFBWSxFQUFFLEVBQXFCLEVBQy9ELFVBQXNCLEVBQVUsZ0JBQWtDLEVBQ2xFa0MsU0FBaUIsRUFDakIsYUFBK0IsRUFDL0IsMkJBQThELEVBQy9ELFdBQStCLEVBQzlCLGNBQXNDO1lBTmhELFlBT0UsaUJBQU8sU0FhUjtZQW5CUyxnQkFBVSxHQUFWLFVBQVUsQ0FBWTtZQUFVLHNCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7WUFDbEUsWUFBTSxHQUFOQSxTQUFNLENBQVc7WUFDakIsbUJBQWEsR0FBYixhQUFhLENBQWtCO1lBQy9CLGlDQUEyQixHQUEzQiwyQkFBMkIsQ0FBbUM7WUFDL0QsaUJBQVcsR0FBWCxXQUFXLENBQW9CO1lBQzlCLG9CQUFjLEdBQWQsY0FBYyxDQUF3QjtZQWpDaEQsZUFBUyxHQUFZLElBQUksQ0FBQztZQUMxQixnQkFBVSxHQUFZLEtBQUssQ0FBQztZQUU1QixhQUFPLEdBQVUsRUFBRSxDQUFDO1lBQ3BCLHNCQUFnQixHQUFVLEVBQUUsQ0FBQztZQUM3QixxQkFBZSxHQUFZLEtBQUssQ0FBQztZQUNqQyxZQUFNLEdBQVcsR0FBRyxDQUFDO1lBQ3JCLFlBQU0sR0FBVSxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ25DLGlCQUFXLEdBQVUsRUFBRSxDQUFDO1lBRXhCLGdCQUFVLEdBQVUsVUFBVSxDQUFDO1lBRy9CLGdCQUFVLEdBQVUsRUFBRSxDQUFDO1lBQ3ZCLHlCQUFtQixHQUFVLEVBQUUsQ0FBQztZQUloQyxvQkFBYyxHQUFHLElBQUksQ0FBQztZQUN0QixnQkFBVSxHQUFHLGNBQWMsQ0FBQTtZQUMzQixrQkFBWSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7WUFDMUIsbUJBQWEsR0FBVSxFQUFFLENBQUM7WUFDMUIsNEJBQXNCLEdBQVUsRUFBRSxDQUFDO1lBRW5DLGdCQUFVLEdBQXVCLElBQUtyQyxlQUFZLEVBQU8sQ0FBQztZQUMxRCxrQkFBWSxHQUFVLEVBQUUsQ0FBQztZQVV2QixLQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDNUYsS0FBSSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDO1lBQ3ZDLEtBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQztZQUNyQyxLQUFJLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUM7WUFFN0MsS0FBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUM7Z0JBQ2pDLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsT0FBTyxFQUFFO29CQUNwQyxLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7aUJBQ2xDO3FCQUFNO29CQUNMLEtBQUksQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQztpQkFDNUM7YUFDRixFQUFDLElBQUksQ0FBQyxDQUFDOztTQUNUOzs7O1FBRUQseUNBQVE7OztZQUFSO2dCQUFBLGlCQTBFQzs7Z0JBeEVDLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUM7O2dCQUVoQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLHNCQUFzQixDQUFDLENBQUM7Z0JBQ3hFLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO2dCQUM3QixJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDZixJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDbEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO2dCQUNyQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO2dCQUM5QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzs7Z0JBRTVCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUNwRCxVQUFBLElBQUk7b0JBQ0YsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7NEJBQ2IsYUFBYSxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO3dCQUNqRSxLQUFJLENBQUMsZ0JBQWdCLFlBQU8sS0FBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7d0JBQ2xFLEtBQUksQ0FBQyxtQkFBbUIsWUFBTyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQzt3QkFDckUsS0FBSSxDQUFDLFdBQVcsWUFBTyxLQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7d0JBQzVELEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3dCQUNsRSxLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzt3QkFDNUIsS0FBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO3dCQUNqQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFVBQUEsQ0FBQzs7Z0NBQ3pCLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDOzRCQUN4QixLQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzs0QkFDNUUsS0FBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLElBQUksQ0FBQyxLQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUN0RSxDQUFDLENBQUM7d0JBQ0gsS0FBSSxDQUFDLE9BQU8sR0FBRyxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUN6RCxLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztxQkFDbkU7aUJBQ0YsQ0FDRixDQUFDLENBQUM7Z0JBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FDckQsVUFBQyxJQUFJO29CQUNILElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTs7NEJBQ3ZCLG1CQUFtQixHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLENBQUM7d0JBQ3BGLEtBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQztxQkFDdkM7aUJBQ0YsQ0FDRixDQUFDLENBQUM7Z0JBRUgsSUFBSSxDQUFDLDJCQUEyQixDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7O3dCQUM5RCxrQkFBa0IsR0FBRyxFQUFFOzt3QkFDdkIsS0FBSyxHQUFHLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7b0JBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO3dCQUNmLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBSSxRQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFDLENBQUMsRUFBRTs0QkFDbkUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUMvQjtxQkFDRixDQUFDLENBQUE7b0JBQ0YsS0FBSSxDQUFDLHNCQUFzQixHQUFHLGtCQUFrQixDQUFDO29CQUNqRCxLQUFJLENBQUMsYUFBYSxHQUFHLGtCQUFrQixDQUFDO2lCQUN6QyxDQUFDLENBQUE7Z0JBRUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO29CQUM1QixLQUFJLENBQUMsMkJBQTJCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO29CQUMxRixLQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDbEIsS0FBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUUsVUFBQSxJQUFJO3dCQUMxRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFFLFVBQUEsTUFBTTs0QkFDbkMsSUFBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQ0FDdkQsS0FBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7NkJBQzNCO3lCQUNGLENBQUMsQ0FBQzt3QkFDSCxLQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFVBQUEsTUFBTTs0QkFDckMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQ0FDeEQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7NkJBQzlCO3lCQUNGLENBQUMsQ0FBQTtxQkFDSCxDQUFDLENBQUM7aUJBQ0osQ0FBQyxDQUFDO2FBQ047Ozs7O1FBRUQsOENBQWE7Ozs7WUFBYixVQUFjLGNBQWM7Z0JBQTVCLGlCQVVDOztvQkFUSyxlQUFlLEdBQUcsRUFBRTtnQkFDdkIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFBLE1BQU07b0JBQzNCLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO3dCQUN6RCxJQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFOzRCQUNoRCxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3lCQUM5QjtxQkFDSCxDQUFDLENBQUE7aUJBQ0gsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sZUFBZSxDQUFDO2FBQ3hCOzs7OztRQUVELGlEQUFnQjs7OztZQUFoQixVQUFpQixtQkFBbUI7Z0JBQXBDLGlCQVVDOztvQkFUSyxrQkFBa0IsR0FBRyxFQUFFO2dCQUMxQixtQkFBbUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxNQUFNO29CQUNoQyxLQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTt3QkFDekQsSUFBSyxNQUFNLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTs0QkFDaEQsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3lCQUNqQztxQkFDSCxDQUFDLENBQUE7aUJBQ0gsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sa0JBQWtCLENBQUM7YUFDM0I7Ozs7O1FBRUQsZ0RBQWU7Ozs7WUFBZixVQUFnQixJQUFJO2dCQUFwQixpQkF1QkM7O29CQXRCTyxJQUFJLEdBQUcsRUFBRTs7b0JBQ1QsS0FBSyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJOzt3QkFDWCxRQUFRLEdBQUcsS0FBSztvQkFDcEIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7d0JBQ2pCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxPQUFPOzRCQUFFLFFBQVEsR0FBRyxJQUFJLENBQUM7cUJBQ2pFLENBQUMsQ0FBQTtvQkFDRCxJQUFJLFFBQVEsRUFBRTs7NEJBQ04sR0FBRyxHQUFHOzRCQUNYLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTs0QkFDbkIsS0FBSyxFQUFFLEtBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7eUJBQ3JEO3dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7cUJBQ2Q7eUJBQU07OzRCQUNDLEdBQUcsR0FBRzs0QkFDWCxNQUFNLEVBQUUsU0FBUzs0QkFDakIsS0FBSyxFQUFFLEtBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7eUJBQ3JEO3dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7cUJBQ2Q7aUJBQ0gsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sSUFBSSxDQUFDO2FBQ2I7Ozs7OztRQUlELDRDQUFXOzs7OztZQUFYO2dCQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFdBQVcsRUFBRSxHQUFBLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDdEM7Ozs7O1FBRUQsOENBQWE7Ozs7WUFBYixVQUFjLEtBQUs7Z0JBQ2pCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDO2FBQzVDOzs7OztRQUVPLDJDQUFVOzs7O1lBQWxCLFVBQW1CLE9BQWM7Z0JBQy9CLElBQUcsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ3JCLE9BQU8sZUFBZSxDQUFDO2lCQUMxQjtxQkFBTTtvQkFDTCxPQUFPLE9BQU8sQ0FBQztpQkFDaEI7YUFDRjs7Ozs7UUFFRCw0Q0FBVzs7OztZQUFYLFVBQVksSUFBSTtnQkFBaEIsaUJBZ0VDO2dCQS9EQyxJQUFJLElBQUksRUFBRTs7d0JBQ0YsUUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7O3dCQUN6QixNQUFJOzt3QkFDSixhQUFpQjtvQkFDckIsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3JCLGFBQVcsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxhQUFXLENBQUMsRUFBRTs0QkFDN0MsTUFBSSxHQUFHLGFBQVcsQ0FBQzt5QkFDcEI7cUJBQ0Y7b0JBQ0QsSUFBSSxhQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUU7d0JBQzFDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUM7cUJBQ2pEOztvQkFFRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFOzs0QkFDbkksUUFBUSxHQUFHOzRCQUNmLE1BQU0sRUFBRSxRQUFNOzRCQUNkLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NEJBQ2hDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDOzRCQUM5QixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDOzRCQUNqQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7NEJBQ2xELEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzs0QkFDM0IsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7eUJBQy9CO3dCQUNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7O3dCQUV4QyxJQUFJLENBQUMsVUFBVSxZQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO3FCQUN4RTtvQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTt3QkFDaEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssUUFBTSxFQUFFOzs0QkFFM0IsSUFBSSxNQUFJLEVBQUU7Z0NBQ1IsSUFBSSxhQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLENBQUMsS0FBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsUUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxLQUFLLEVBQUU7b0NBQ3pGLEtBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7O3dDQUM3QyxHQUFHLEdBQUc7d0NBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7O3dDQUMzQixNQUFNLEVBQUUsS0FBSSxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsZUFBZSxFQUFFLFFBQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7d0NBQzdFLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO3dDQUNsQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO3dDQUNqQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztxQ0FDL0I7b0NBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQ0FDMUI7cUNBQU0sSUFBRyxhQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBRyxJQUFJLEVBQUM7b0NBQ25FLEtBQUksQ0FBQyxZQUFZLEdBQUcsYUFBVyxDQUFDOzs7d0NBRTFCLEdBQUcsR0FBRzt3Q0FDVixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzt3Q0FDM0IsTUFBTSxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFFBQU0sQ0FBQyxDQUFDO3dDQUNsRCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzt3Q0FDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzt3Q0FDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7cUNBQy9COztvQ0FFRCxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7b0NBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7aUNBQzFCOzZCQUNGO3lCQUNGO3FCQUNGLENBQUMsQ0FBQTtpQkFFSDthQUVGOzs7Ozs7O1FBRUQsaURBQWdCOzs7Ozs7WUFBaEIsVUFBaUIsSUFBVztnQkFBNUIsaUJBc0JDOztvQkFyQk8sT0FBTyxHQUFVLEVBQUU7O29CQUNuQixnQkFBZ0IsR0FBVSxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFO2dCQUM5RSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTs7b0JBRWYsSUFBSSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNLEdBQUEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO3dCQUN4RSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7NEJBQ3RCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUN4QixZQUFZLEVBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQzs0QkFDL0IsU0FBUyxFQUFFLElBQUk7eUJBQ2hCLENBQUMsQ0FBQTtxQkFDSDs7d0JBQ0ssR0FBRyxHQUFHO3dCQUNWLE1BQU0sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO3dCQUN0QixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzt3QkFDeEIsWUFBWSxFQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7d0JBQy9CLFFBQVEsRUFBRSxLQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztxQkFDbEM7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbkIsQ0FBQyxDQUFBO2dCQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUN2RSxPQUFPLE9BQU8sQ0FBQzthQUNoQjs7Ozs7UUFDRCw2Q0FBWTs7OztZQUFaLFVBQWEsSUFBUztnQkFBdEIsaUJBMEJDOztvQkF6Qk8sTUFBTSxHQUFVLEVBQUU7Z0JBQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUMvQixJQUFJLEtBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUU7OzRCQUN2RCxHQUFHLEdBQUc7NEJBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7OzRCQUMzQixNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUNuQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7eUJBQy9CO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ2xCO2lCQUNGLENBQ0EsQ0FBQTtnQkFDRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFOzt3QkFDaEIsR0FBRyxHQUFHO3dCQUNWLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDOzt3QkFDM0IsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTO3dCQUN0QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzt3QkFDbEIsT0FBTyxFQUFFLENBQUM7d0JBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUztxQkFDeEM7b0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbEI7Z0JBQ0QsT0FBTyxNQUFNLENBQUM7YUFDZjs7Ozs7OztRQUdELGlEQUFnQjs7Ozs7O1lBQWhCLFVBQWlCLElBQUk7Z0JBQXJCLGlCQU1DOztvQkFMSyxVQUFVLEdBQUcsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ2YsVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDNUYsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sVUFBVSxDQUFDO2FBQ25COzs7Ozs7UUFFRCxnREFBZTs7Ozs7WUFBZixVQUFnQixNQUFNLEVBQUUsSUFBSTtnQkFBNUIsaUJBa0JDOztvQkFqQk8sbUJBQW1CLEdBQUcsRUFBRTtnQkFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ2YsSUFBSSxLQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7NEJBQ25JLFFBQVEsR0FBRzs0QkFDZixNQUFNLEVBQUUsTUFBTTs0QkFDZCxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUNoQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQzs0QkFDOUIsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDakMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLHFCQUFxQixFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQzs0QkFDbEQsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7NEJBQzNCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO3lCQUMvQjt3QkFDRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ3BDO2lCQUNGLENBQUMsQ0FBQTtnQkFDRixPQUFPLG1CQUFtQixDQUFDO2FBQzVCOzs7Ozs7Ozs7UUFJRCxnREFBZTs7Ozs7Ozs7WUFBZixVQUFnQixlQUFrQyxFQUFFLE1BQWMsRUFBRSxJQUFJO2dCQUN0RSxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbEMsT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN2Qjs7Ozs7UUFFRCxpREFBZ0I7Ozs7WUFBaEIsVUFBaUIsS0FBSzs7b0JBQ2QsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFO29CQUN4RCxLQUFLLEVBQUUsT0FBTztvQkFDZCxJQUFJLEVBQUU7d0JBQ0YsVUFBVSxFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7d0JBQzFELFlBQVksRUFBRSxJQUFJLENBQUMsVUFBVTtxQkFDOUI7aUJBQ0osQ0FBQztnQkFDRixTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsTUFBTTtvQkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2lCQUN0QyxDQUFDLENBQUM7YUFDSjs7Ozs7UUFFRCxvREFBbUI7Ozs7WUFBbkIsVUFBb0IsQ0FBQzs7b0JBQ2QsUUFBUSxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDNUIsT0FBT3NDLGlCQUFVLENBQUMsUUFBUSxFQUFDLGVBQWUsRUFBQyxPQUFPLENBQUMsQ0FBQzthQUNyRDs7b0JBeFpEekIsWUFBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSxxQkFBcUI7d0JBQy9CLFFBQVEsRUFBRSw4cERBdUNYO3dCQUNDLE1BQU0sRUFBRSxDQUFDLHduQkFBd25CLENBQUM7cUJBQ25vQjs7Ozt3QkF0RUNPLGFBQVU7d0JBQUVDLFNBQU07d0JBQUVDLG9CQUFpQjt3QkFnQjlCLFVBQVU7d0JBQ1YsZ0JBQWdCO3dCQUhqQmlCLGtCQUFTO3dCQUpmQyxtQkFBZ0I7d0JBWVQsZ0NBQWdDO3dCQUpoQyxrQkFBa0I7d0JBT2xCLHNCQUFzQjs7O1FBNFovQiw2QkFBQztLQUFBLENBOVcyQ1AsNEJBQW1COzs7Ozs7QUN4RS9EO1FBRUE7U0FpQkM7Ozs7O1FBWkMscUNBQVM7Ozs7WUFBVCxVQUFVLEtBQVU7Z0JBQ2xCLElBQUksS0FBSyxJQUFJLENBQUMsRUFBRTtvQkFDZCxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUN2QyxPQUFPLEtBQUssQ0FBQztxQkFDZDt5QkFBTTt3QkFDTCxPQUFPLEdBQUcsR0FBRyxLQUFLLENBQUM7cUJBQ3BCO2lCQUNGO3FCQUFNO29CQUNMLE9BQU8sUUFBUSxDQUFDO2lCQUNqQjthQUNGOztvQkFmRlEsT0FBSSxTQUFDO3dCQUNKLElBQUksRUFBRSxlQUFlO3FCQUN0Qjs7UUFlRCx3QkFBQztLQUFBOzs7Ozs7QUNuQkQ7UUFFQTtTQVNDOzs7Ozs7UUFKQyxxQ0FBUzs7Ozs7WUFBVCxVQUFVLEtBQVUsRUFBRSxpQkFBeUI7Z0JBQzdDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFBLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQSxHQUFDLEtBQUssQ0FBQyxHQUFDLFNBQUEsRUFBRSxFQUFFLGlCQUFpQixDQUFBLENBQUM7YUFDdEU7O29CQVBGQSxPQUFJLFNBQUM7d0JBQ0osSUFBSSxFQUFFLGVBQWU7cUJBQ3RCOztRQU9ELHdCQUFDO0tBQUE7Ozs7OztBQ1hEO1FBb0RFLG1DQUNXLFdBQStCLEVBQ2pDLFNBQWtELEVBQ3pCLElBQVM7WUFGaEMsZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1lBQ2pDLGNBQVMsR0FBVCxTQUFTLENBQXlDO1lBQ3pCLFNBQUksR0FBSixJQUFJLENBQUs7WUFMM0MsY0FBUyxHQUFXLEVBQUUsQ0FBQztZQU1yQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUNwQzs7OztRQUVELDRDQUFROzs7WUFBUjthQUNDOzs7O1FBRUQsNkNBQVM7OztZQUFUO2dCQUNFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDeEI7O29CQTVERjVCLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsd0JBQXdCO3dCQUNsQyxRQUFRLEVBQUUsODNDQXVDTDt3QkFDTCxNQUFNLEVBQUUsQ0FBQyw2bUJBQTZtQixDQUFDO3FCQUN4bkI7Ozs7d0JBN0NRLGtCQUFrQjt3QkFEbkJxQixxQkFBWTt3REFzRGZDLFNBQU0sU0FBQ0Msd0JBQWU7OztRQVczQixnQ0FBQztLQUFBOzs7Ozs7O1FDZ0I2Q2pDLDRDQUFtQjtRQWMvRCxrQ0FBWSxZQUF3QixFQUNoQixJQUFZLEVBQ1osRUFBcUIsRUFDYixnQkFBa0MsRUFDbEMsZ0NBQWtFLEVBQ2xFLFdBQStCLEVBQy9CLFVBQXNCLEVBQ3RCLGNBQXNDO1lBUGxFLFlBUUUsaUJBQU8sU0FFUDtZQVAwQixzQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1lBQ2xDLHNDQUFnQyxHQUFoQyxnQ0FBZ0MsQ0FBa0M7WUFDbEUsaUJBQVcsR0FBWCxXQUFXLENBQW9CO1lBQy9CLGdCQUFVLEdBQVYsVUFBVSxDQUFZO1lBQ3RCLG9CQUFjLEdBQWQsY0FBYyxDQUF3QjtZQWxCcEUsaUJBQVcsR0FBVSxFQUFFLENBQUM7WUFDeEIsb0JBQWMsR0FBRyxFQUFFLENBQUM7WUFDcEIsWUFBTSxHQUFXLEdBQUcsQ0FBQztZQUVyQixZQUFNLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUMxQixxQkFBZSxHQUFZLEtBQUssQ0FBQztZQUNqQyx5QkFBbUIsR0FBVSxtQkFBbUIsQ0FBQztZQUNqRCxhQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNyQixpQkFBVyxHQUFHLGtCQUFrQixDQUFDO1lBQ2pDLGNBQVEsR0FBUSxFQUFFLENBQUM7WUFXZixLQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7O1NBQzVGOzs7O1FBRUYsMkNBQVE7OztZQUFSO2dCQUFBLGlCQTBCQztnQkF6QkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2dCQUN6QixJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDZixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQkFFN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsUUFBUSxDQUFDO2dCQUMvRCxJQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDM0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7aUJBQzFCO3FCQUFJO29CQUNILElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUNyQyxVQUFBLElBQUk7d0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDbkIsSUFBRyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBRTs0QkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7Z0NBQ1gsUUFBUSxHQUFHLEVBQUU7NEJBQ3BCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUE7NEJBQ2pDLEtBQUksQ0FBQyxnQ0FBZ0MsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDNUUsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7eUJBQzFCO3FCQUVGLENBQUMsQ0FBQztpQkFDTjthQUNGOzs7O1FBR0Qsb0RBQWlCOzs7WUFBakI7Z0JBQUEsaUJBb0JDO2dCQW5CQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxRQUFRLENBQUM7Z0JBQy9ELElBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNFLFVBQUEsSUFBSTt3QkFDRixLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzt3QkFDNUIsS0FBSSxDQUFDLFdBQVcsR0FBRyxLQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7d0JBQ2xFLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO3FCQUN0RSxDQUNGLENBQUMsQ0FBQTtvQkFDRixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxVQUFBLElBQUk7d0JBQ0YsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7cUJBQ3BDLENBQUMsQ0FBQyxDQUFDO29CQUVMLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFeEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsY0FBUSxLQUFJLENBQUMsV0FBVyxZQUFPLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQSxFQUFDLEVBQUMsR0FBRyxDQUFDLENBQUM7aUJBRTFGO2FBQ0Y7Ozs7O1FBRUQsMERBQXVCOzs7O1lBQXZCLFVBQXdCLElBQUk7O29CQUNwQixXQUFXLEdBQUcsRUFBRTtnQkFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7O3dCQUNULEdBQUcsR0FBRzt3QkFDVixNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUs7d0JBQ2xCLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7d0JBQ2pDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUztxQkFDNUI7b0JBQ0QsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkIsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sV0FBVyxDQUFDO2FBQ3BCOzs7OztRQUVELDBEQUF1Qjs7OztZQUF2QixVQUF3QixJQUFJOztvQkFDcEIsV0FBVyxHQUFHLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBQyxLQUFLLEVBQUUsS0FBSztvQkFDckIsT0FBTyxLQUFLLENBQUMsU0FBUyxHQUFJLEtBQUssQ0FBQyxTQUFTLENBQUM7O2lCQUUzQyxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ2YsSUFBSSxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7NEJBQ3RCLEdBQUcsR0FBRzs0QkFDUixNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJOzRCQUMzQyxPQUFPLEVBQUV1QyxtQkFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQzt5QkFDeEQ7d0JBQ0QsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDdkI7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sV0FBVyxDQUFDO2FBQ3BCOzs7OztRQUVELGdEQUFhOzs7O1lBQWIsVUFBYyxJQUFJO2dCQUNoQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNyRSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7d0JBQzNCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFFOzRCQUM1QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUN0QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUE7eUJBQ2hDO3FCQUNGLENBQUMsQ0FBQztpQkFDSjthQUNGOzs7OztRQUVELGtEQUFlOzs7O1lBQWYsVUFBZ0IsS0FBSztnQkFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7YUFDNUM7Ozs7Ozs7UUFHRCx5REFBc0I7Ozs7OztZQUF0QixVQUF1QixLQUFLOzs7Z0JBRzFCLE9BQU87YUFDUjs7Ozs7UUFFRCx5REFBc0I7Ozs7WUFBdEIsVUFBdUIsR0FBRzs7b0JBQ2xCLFdBQVcsR0FBSUEsbUJBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUM7Z0JBQzlELE9BQVUsR0FBRyxDQUFDLEtBQUssaUJBQWMsSUFBTSxXQUFXLGFBQVUsQ0FBQSxDQUFDOzthQUU5RDs7OztRQUVBLDhDQUFXOzs7WUFBWDtnQkFDQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxRCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBRSxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBQSxDQUFDLENBQUM7aUJBQzlDO2dCQUNELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDdEM7O29CQXpNRjdCLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsdUJBQXVCO3dCQUNqQyxRQUFRLEVBQUUscWlEQXNEWDt3QkFDQyxNQUFNLEVBQUUsQ0FBQyx3M0RBQXczRCxDQUFDO3FCQUNuNEQ7Ozs7d0JBaEZDTyxhQUFVO3dCQUFFQyxTQUFNO3dCQUFFQyxvQkFBaUI7d0JBaUI5QixnQkFBZ0I7d0JBRmhCLGdDQUFnQzt3QkFHaEMsa0JBQWtCO3dCQUZsQixVQUFVO3dCQUlWLHNCQUFzQjs7O1FBNk0vQiwrQkFBQztLQUFBLENBaEo2Q1csNEJBQW1COzs7Ozs7O1FDM0MzQjlCLG9DQUFrQjtRQXpCeEQ7WUFBQSxxRUF3SUM7WUE1R1UscUJBQWUsR0FBWSxLQUFLLENBQUM7WUFHakMsY0FBUSxHQUFZLEtBQUssQ0FBQztZQUcxQixZQUFNLEdBQVEsRUFBRSxDQUFDO1lBRWpCLGdCQUFVLEdBQVksSUFBSSxDQUFDO1lBRTFCLFlBQU0sR0FBRyxJQUFJSCxlQUFZLEVBQUUsQ0FBQzs7U0FrR3ZDOzs7O1FBckZDLGlDQUFNOzs7WUFBTjtnQkFDRSxpQkFBTSxNQUFNLFdBQUUsQ0FBQztnQkFFZixJQUFJLENBQUMsSUFBSSxHQUFHSyxpQ0FBdUIsQ0FBQztvQkFDbEMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixNQUFNLEVBQUUsR0FBRztvQkFDWCxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07aUJBQ3JCLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztnQkFFbEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBRS9CLElBQUksQ0FBQyxPQUFPLEdBQUdzQyxtQkFBTyxFQUFPO3FCQUMxQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7O29CQUV2QyxRQUFRLEdBQUc7b0JBQ2YsSUFBSSxFQUFFLE1BQU07b0JBQ1osS0FBSyxFQUFFLENBQUM7b0JBQ1IsTUFBTSxFQUFFLElBQUk7aUJBQ2I7O29CQUVLLElBQUksR0FBR0Msb0JBQVEsRUFBTztxQkFDekIsRUFBRSxDQUFDLFVBQUEsQ0FBQzs7d0JBQ0MsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJO29CQUVsQixJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTt3QkFDckMsS0FBSyxHQUFHLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO3FCQUNwQzt5QkFBTTt3QkFDTCxLQUFLLEdBQUcsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO3FCQUNoQztvQkFDRCxPQUFPLEtBQUssQ0FBQztpQkFDZCxDQUFDO3FCQUNELFFBQVEsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBQSxDQUFDLFdBQ3RDLFFBQVEsR0FBSyxJQUFJLENBQUMsV0FBVyxFQUFFO3FCQUNoQyxHQUFHLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsS0FBSyxHQUFBLENBQUM7Z0JBRXBCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBRTNDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFFakIsSUFBSSxDQUFDLFNBQVMsR0FBRyxlQUFjLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxXQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQUksQ0FBQzthQUM1RTs7OztRQUVELDBDQUFlOzs7WUFBZjs7b0JBQ1EsR0FBRyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJOzt3QkFDdkIsS0FBSyxHQUFXLEVBQUU7b0JBQ3RCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTt3QkFDeEIsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDbkI7eUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLEVBQUU7d0JBQ3RELEtBQUssR0FBRyxTQUFTLENBQUM7cUJBQ25CO3lCQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsRUFBRTt3QkFDckQsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDbkI7eUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRTt3QkFDcEQsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDbkI7eUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRTt3QkFDcEQsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDbkI7eUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsRUFBRTt3QkFDOUIsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDbkI7eUJBQU07d0JBQ0wsS0FBSyxHQUFHLEVBQUUsQ0FBQztxQkFDWjs7d0JBQ0csR0FBRyxHQUFHO3dCQUNSLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTt3QkFDZixLQUFLLEVBQUUsS0FBSztxQkFDYjtvQkFDRCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNmLENBQUMsQ0FBQTtnQkFDRixPQUFPLEdBQUcsQ0FBQzthQUNaOzs7O1FBRUQsb0NBQVM7OztZQUFUO2dCQUNFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsSUFBSSxHQUFBLENBQUMsQ0FBQzthQUMxQzs7Ozs7UUFFRCxrQ0FBTzs7OztZQUFQLFVBQVEsSUFBSTtnQkFDVixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN4Qjs7OztRQUVELG9DQUFTOzs7WUFBVDtnQkFDRSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUloQyxxQkFBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQ3ZGOztvQkF0SUZDLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUseUJBQXlCO3dCQUNuQyxRQUFRLEVBQUUsOHFCQWtCWTt3QkFDdEIsTUFBTSxFQUFFLENBQUMsOEtBQThLLENBQUM7d0JBQ3hMLGFBQWEsRUFBRUMsb0JBQWlCLENBQUMsSUFBSTt3QkFDckMsZUFBZSxFQUFFQywwQkFBdUIsQ0FBQyxNQUFNO3FCQUNoRDs7O2tDQUdFUyxRQUFLO3NDQUNMQSxRQUFLO3NDQUNMQSxRQUFLO3NDQUNMQSxRQUFLOytCQUNMQSxRQUFLOzZCQUNMQSxRQUFLOzRCQUNMQSxRQUFLOzZCQUNMQSxRQUFLOzZCQUNMQSxRQUFLO2lDQUNMQSxRQUFLOzZCQUVMQyxTQUFNO3NDQUVOQyxlQUFZLFNBQUMsaUJBQWlCOztRQWdHakMsdUJBQUM7S0FBQSxDQS9HcUNFLDRCQUFrQjs7Ozs7OztBQ3ZDeEQsUUFBYSxvQkFBb0IsR0FBRztRQUNoQyxJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUM1Qjs7Ozs7OztRQ2tHNkN6QixnREFBbUI7UUErRW5FLHNDQUNFLFlBQXdCLEVBQUUsSUFBWSxFQUN0QyxFQUFxQixFQUNiLFdBQStCLEVBQzlCLFVBQXNCLEVBQ3RCLDJCQUE4RDtZQUx6RSxZQU1FLGlCQUFPLFNBSVI7WUFQUyxpQkFBVyxHQUFYLFdBQVcsQ0FBb0I7WUFDOUIsZ0JBQVUsR0FBVixVQUFVLENBQVk7WUFDdEIsaUNBQTJCLEdBQTNCLDJCQUEyQixDQUFtQztZQWxGekUsYUFBTyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7O1lBRXJCLHdCQUFrQixHQUFHO2dCQUNuQjtvQkFDRSxLQUFLLEVBQUUsdUJBQXVCO29CQUM5QixLQUFLLEVBQUUsT0FBTztpQkFDZjtnQkFDRDtvQkFDRSxLQUFLLEVBQUUsbUJBQW1CO29CQUMxQixLQUFLLEVBQUUsT0FBTztpQkFDZjthQUNGLENBQUM7WUFDRix1QkFBaUIsR0FBVTtnQkFDekI7b0JBQ0UsR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFO29CQUNmLE9BQU8sRUFBRTt3QkFDUDs0QkFDRSxLQUFLLEVBQUUsV0FBVzs0QkFDbEIsS0FBSyxFQUFFLElBQUk7eUJBQ1o7d0JBQ0Q7NEJBQ0UsS0FBSyxFQUFFLGNBQWM7NEJBQ3JCLEtBQUssRUFBRSxNQUFNO3lCQUNkO3dCQUNEOzRCQUNFLEtBQUssRUFBRSxZQUFZOzRCQUNuQixLQUFLLEVBQUUsUUFBUTt5QkFDaEI7cUJBQ0Y7b0JBQ0QsS0FBSyxFQUFFLEVBQUU7aUJBQ1Y7Z0JBQ0Q7b0JBQ0UsR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFO29CQUNmLE9BQU8sRUFBRTt3QkFDUDs0QkFDRSxLQUFLLEVBQUUsV0FBVzs0QkFDbEIsS0FBSyxFQUFFLEtBQUs7eUJBQ2I7d0JBQ0Q7NEJBQ0UsS0FBSyxFQUFFLGNBQWM7NEJBQ3JCLEtBQUssRUFBRSxPQUFPO3lCQUNmO3dCQUNEOzRCQUNFLEtBQUssRUFBRSxZQUFZOzRCQUNuQixLQUFLLEVBQUUsUUFBUTt5QkFDaEI7cUJBQ0Y7b0JBQ0QsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCO2dCQUNEO29CQUNFLEdBQUcsRUFBRSxJQUFJLElBQUksRUFBRTtvQkFDZixPQUFPLEVBQUU7d0JBQ1A7NEJBQ0UsS0FBSyxFQUFFLFdBQVc7NEJBQ2xCLEtBQUssRUFBRSxLQUFLO3lCQUNiO3dCQUNEOzRCQUNFLEtBQUssRUFBRSxjQUFjOzRCQUNyQixLQUFLLEVBQUUsT0FBTzt5QkFDZjt3QkFDRDs0QkFDRSxLQUFLLEVBQUUsWUFBWTs0QkFDbkIsS0FBSyxFQUFFLE9BQU87eUJBQ2Y7cUJBQ0Y7b0JBQ0QsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCO2FBQ0YsQ0FBQztZQUNGLGFBQU8sR0FBVSxFQUFFLENBQUM7WUFDcEIsWUFBTSxHQUFXLEdBQUcsQ0FBQztZQUVyQixZQUFNLEdBQVUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNsQyxpQkFBVyxHQUFVLEVBQUUsQ0FBQztZQUN4QixnQkFBVSxHQUFVLG9CQUFvQixDQUFDO1lBV3ZDLEtBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztZQUM3RixLQUFJLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUM7WUFDdkMsS0FBSSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDOztTQUN0Qzs7OztRQUVELCtDQUFROzs7WUFBUjtnQkFBQSxpQkFRQztnQkFQQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7b0JBQzFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ25CLEtBQUksQ0FBQyxPQUFPLFlBQU8sS0FBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO3FCQUM5QztpQkFDRixDQUFDLENBQUM7Z0JBRUgsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQzthQUNuRDs7OztRQUVELDhEQUF1Qjs7O1lBQXZCOzs7b0JBRVEsS0FBSyxHQUFHLEVBQUU7O29CQUNWLGtCQUFrQixHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDOztvQkFDakUsR0FBRyxHQUFHO29CQUNWLFVBQVUsRUFBRSxrQkFBa0I7b0JBQzlCLEtBQUssRUFBRSxTQUFTO2lCQUNqQjtnQkFDRCxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNoQixPQUFPLEtBQUssQ0FBQzthQUNkOzs7Ozs7O1FBR0QscURBQWM7Ozs7OztZQUFkLFVBQWUsSUFBVztnQkFBMUIsaUJBY0M7O29CQWJPLE9BQU8sR0FBVSxFQUFFOztvQkFDbkIsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNmLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLGtCQUFrQixFQUFFOzs0QkFDdkMsR0FBRyxHQUFHOzRCQUNWLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDOzRCQUMxQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzs0QkFDeEIsUUFBUSxFQUFFLEtBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO3lCQUNsQzt3QkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNuQjtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxPQUFPLENBQUM7YUFDaEI7Ozs7O1FBRUQsbURBQVk7Ozs7WUFBWixVQUFhLElBQVM7Z0JBQXRCLGlCQTBCQzs7b0JBekJPLE1BQU0sR0FBVSxFQUFFO2dCQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDL0IsSUFBSSxLQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFOzs0QkFDdkQsR0FBRyxHQUFHOzRCQUNWLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUMzQixNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzRCQUNuQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs0QkFDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7eUJBQy9CO3dCQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ2xCO2lCQUNGLENBQ0EsQ0FBQTtnQkFDRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFOzt3QkFDaEIsR0FBRyxHQUFHO3dCQUNWLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO3dCQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVM7d0JBQ3RCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO3dCQUNsQixPQUFPLEVBQUUsQ0FBQzt3QkFDVixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTO3FCQUN4QztvQkFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNsQjtnQkFDRCxPQUFPLE1BQU0sQ0FBQzthQUNmOzs7OztRQUVBLDBEQUFtQjs7OztZQUFuQixVQUFvQixDQUFDOztvQkFDZixRQUFRLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM1QixPQUFPbUMsaUJBQVUsQ0FBQyxRQUFRLEVBQUMsZUFBZSxFQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3JEOzs7OztRQUVELGtEQUFXOzs7O1lBQVgsVUFBWSxLQUFLOztvQkFDWCxLQUFLLEdBQUcsRUFBRTtnQkFDZCxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7b0JBQ3hDLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDakMsS0FBSyxHQUFHLFNBQVMsQ0FBQTtxQkFDbEI7eUJBQU07d0JBQ0wsS0FBSyxHQUFDLFNBQVMsQ0FBQTtxQkFDaEI7aUJBQ0Y7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDZDs7OztRQUVELGtEQUFXOzs7WUFBWDtnQkFDRyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzthQUN2Qjs7Ozs7UUFFRCw4REFBdUI7Ozs7WUFBdkIsVUFBd0IsS0FBSztnQkFDM0IsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7YUFDN0M7O29CQXhRRnpCLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsMkJBQTJCO3dCQUNyQyxRQUFRLEVBQUUsNjNFQThFTDt3QkFDTCxNQUFNLEVBQUUsQ0FBQywrK0dBQSsrRyxDQUFDO3FCQUMxL0c7Ozs7d0JBckdDTyxhQUFVO3dCQUFFQyxTQUFNO3dCQUFFQyxvQkFBaUI7d0JBZTlCLGtCQUFrQjt3QkFDbEIsVUFBVTt3QkFDVixnQ0FBZ0M7OztRQTRRekMsbUNBQUM7S0FBQSxDQXZMaURXLDRCQUFtQjs7Ozs7OztRQ29DdkI5Qiw0Q0FBa0I7UUF1RTlELGtDQUFZLFlBQXdCLEVBQ2hCLElBQVksRUFDWixFQUFxQixFQUNiLFdBQStCLEVBQy9CLFFBQWtCO1lBSjlDLFlBS0Usa0JBQU0sWUFBWSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsU0FDOUI7WUFIMkIsaUJBQVcsR0FBWCxXQUFXLENBQW9CO1lBQy9CLGNBQVEsR0FBUixRQUFRLENBQVU7WUF6RXJDLGlCQUFXLEdBQVcsUUFBUSxDQUFDO1lBUS9CLG1CQUFhLEdBQVksSUFBSSxDQUFDO1lBQzlCLFdBQUssR0FBUUMsbUJBQVcsQ0FBQztZQU96QixrQkFBWSxHQUFZLEtBQUssQ0FBQztZQUM5QixxQkFBZSxHQUFZLElBQUksQ0FBQztZQUNoQyxrQkFBWSxHQUFZLEtBQUssQ0FBQztZQUU5QixtQkFBYSxHQUFZLEtBQUssQ0FBQztZQVMvQixpQkFBVyxHQUFVLEVBQUUsQ0FBQztZQUV4QixnQkFBVSxHQUFVLEVBQUUsQ0FBQztZQUN2QixtQkFBYSxHQUFVLEVBQUUsQ0FBQztZQUV6QixjQUFRLEdBQXNCLElBQUlKLGVBQVksRUFBRSxDQUFDO1lBQ2pELGdCQUFVLEdBQXNCLElBQUlBLGVBQVksRUFBRSxDQUFDO1lBbUI3RCxpQkFBVyxHQUFXLENBQUMsQ0FBQztZQUN4QixnQkFBVSxHQUFXLENBQUMsQ0FBQztZQUt2QixvQkFBYyxHQUFXLEVBQUUsQ0FBQztZQUs1QixxQkFBZSxHQUFXLEVBQUUsQ0FBQztZQUU3QixnQkFBVSxHQUFRLEVBQUUsQ0FBQzs7U0FRcEI7Ozs7UUFFRCx5Q0FBTTs7O1lBQU47Z0JBRUUsSUFBSSxDQUFDLElBQUksR0FBR0ssaUNBQXVCLENBQUM7b0JBQ2xDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO29CQUNuQixPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07b0JBQ3BCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztvQkFDN0IsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO29CQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWM7b0JBQy9CLFVBQVUsRUFBRSxJQUFJLENBQUMsY0FBYztvQkFDL0IsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNO29CQUN2QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7aUJBQzVCLENBQUMsQ0FBQztnQkFFSCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7aUJBQ25GO2dCQUVELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztpQkFDcEM7Z0JBRUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUUzQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUU1RCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNqQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUU3QyxJQUFJLENBQUMsU0FBUyxHQUFHLGVBQWEsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLFdBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBRyxDQUFDO2dCQUV2RSxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sR0FBR0MsUUFBRSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBUSxJQUFJLENBQUMsVUFBVSxNQUFHLENBQUM7YUFFNUM7Ozs7UUFHRCxrREFBZTs7O1lBQWY7Z0JBQUEsaUJBY0M7O29CQWJLLEdBQUcsR0FBRyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDdkIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBQSxLQUFLO3dCQUM1QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUU7O2dDQUNwQyxHQUFHLEdBQUc7Z0NBQ1IsSUFBSSxFQUFFLEtBQUssQ0FBQyxVQUFVO2dDQUN0QixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7NkJBQ25COzRCQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7eUJBQ2Q7cUJBQ0YsQ0FBQyxDQUFBO2lCQUNILENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsQ0FBQzthQUNaOzs7O1FBRUQsNkNBQVU7OztZQUFWOztvQkFDTSxNQUFNLEdBQUdDLG9DQUFzQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7b0JBQ3ZDLE1BQU0sR0FBRyxFQUFFO2dCQUVmLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUU7b0JBQy9CLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFBLENBQUMsQ0FBQztpQkFDckM7O29CQUVHLEdBQUc7O29CQUNILEdBQUc7Z0JBQ1AsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtvQkFDNUQsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTOzBCQUNoQixJQUFJLENBQUMsU0FBUzswQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUMsQ0FBQztvQkFFeEIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTOzBCQUNoQixJQUFJLENBQUMsU0FBUzswQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUMsQ0FBQztpQkFDekI7Z0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtvQkFDN0IsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDeEMsSUFBSSxDQUFDLElBQUksR0FBR0MsU0FBSSxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUM7OzRCQUMxQixLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7NEJBQ25CLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFO3dCQUN6QixJQUFJLEtBQUssR0FBRyxLQUFLOzRCQUFFLE9BQU8sQ0FBQyxDQUFDO3dCQUM1QixJQUFJLEtBQUssR0FBRyxLQUFLOzRCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7d0JBQzdCLE9BQU8sQ0FBQyxDQUFDO3FCQUNWLENBQUMsQ0FBQztpQkFDSjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO29CQUN0QyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7O29CQUVwQixJQUFJLENBQUMsSUFBSSxHQUFHQSxTQUFJLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQyxJQUFLLFFBQUMsQ0FBQyxHQUFHLENBQUMsSUFBQyxDQUFDLENBQUM7aUJBQ2pEO3FCQUFNO29CQUNMLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO2lCQUNwQjtnQkFFRCxPQUFPLE1BQU0sQ0FBQzthQUNmOzs7O1FBRUQsNkNBQVU7OztZQUFWOztvQkFDUSxNQUFNLEdBQUcsRUFBRTs7b0JBQ2pCLEtBQXNCLElBQUEsS0FBQU4sU0FBQSxJQUFJLENBQUMsT0FBTyxDQUFBLGdCQUFBO3dCQUE3QixJQUFNLE9BQU8sV0FBQTs7NEJBQ2hCLEtBQWdCLElBQUEsS0FBQUEsU0FBQSxPQUFPLENBQUMsTUFBTSxDQUFBLGdCQUFBO2dDQUF6QixJQUFNLENBQUMsV0FBQTtnQ0FDVixJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29DQUMxQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQ0FDdEI7Z0NBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQ0FDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0NBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQ0FDcEI7aUNBQ0Y7Z0NBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQ0FDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0NBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dDQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQ0FDcEI7aUNBQ0Y7NkJBQ0Y7Ozs7Ozs7Ozs7Ozs7OztxQkFDRjs7Ozs7Ozs7Ozs7Ozs7OztvQkFFSyxNQUFNLFlBQU8sTUFBTSxDQUFDO2dCQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDaEI7O29CQUVLLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUztzQkFDdEIsSUFBSSxDQUFDLFNBQVM7c0JBQ2QsSUFBSSxDQUFDLEdBQUcsT0FBUixJQUFJLFdBQVEsTUFBTSxFQUFDOztvQkFFakIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO3NCQUN0QixJQUFJLENBQUMsU0FBUztzQkFDZCxJQUFJLENBQUMsR0FBRyxPQUFSLElBQUksV0FBUSxNQUFNLEVBQUM7Z0JBRXJCLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRTtvQkFDZCxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUNuQjtxQkFBSztvQkFDSixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7aUJBQ3BCOzthQUNKOzs7O1FBRUQsa0RBQWU7OztZQUFmO2dCQUNFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsSUFBSSxHQUFBLENBQUMsQ0FBQzthQUN0Qzs7Ozs7O1FBRUQsNENBQVM7Ozs7O1lBQVQsVUFBVSxNQUFNLEVBQUUsS0FBSzs7b0JBQ2pCLEtBQUs7Z0JBRVQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtvQkFDN0IsS0FBSyxHQUFHTyxpQkFBUyxFQUFFO3lCQUNoQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDbkI7cUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtvQkFDdEMsS0FBSyxHQUFHQyxtQkFBVyxFQUFFO3lCQUNsQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFbEIsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO3dCQUNyQixLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO3FCQUN0QjtpQkFDRjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFO29CQUN2QyxLQUFLLEdBQUdDLGtCQUFVLEVBQUU7eUJBQ2pCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzt5QkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQzt5QkFDWixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ25CO2dCQUVELE9BQU8sS0FBSyxDQUFDO2FBQ2Q7Ozs7OztRQUVELDRDQUFTOzs7OztZQUFULFVBQVUsTUFBTSxFQUFFLE1BQU07O29CQUNoQixLQUFLLEdBQUdELG1CQUFXLEVBQUU7cUJBQ3hCLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDbEIsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFFakIsT0FBTyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUM7YUFDakQ7Ozs7O1FBRUQsK0NBQVk7Ozs7WUFBWixVQUFhLE1BQU07O29CQUNiLElBQUksR0FBRyxJQUFJOztvQkFDWCxHQUFHLEdBQUcsSUFBSTs7b0JBRWQsS0FBb0IsSUFBQSxXQUFBUixTQUFBLE1BQU0sQ0FBQSw4QkFBQTt3QkFBckIsSUFBTSxLQUFLLG1CQUFBO3dCQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFOzRCQUN2QixJQUFJLEdBQUcsS0FBSyxDQUFDO3lCQUNkO3dCQUVELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFOzRCQUM3QixHQUFHLEdBQUcsS0FBSyxDQUFDO3lCQUNiO3FCQUNGOzs7Ozs7Ozs7Ozs7Ozs7Z0JBRUQsSUFBSSxJQUFJO29CQUFFLE9BQU8sTUFBTSxDQUFDO2dCQUN4QixJQUFJLEdBQUc7b0JBQUUsT0FBTyxRQUFRLENBQUM7Z0JBQ3pCLE9BQU8sU0FBUyxDQUFDOzthQUNsQjs7Ozs7UUFFRCx5Q0FBTTs7OztZQUFOLFVBQU8sS0FBSztnQkFDVixJQUFJLEtBQUssWUFBWSxJQUFJLEVBQUU7b0JBQ3pCLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUVELE9BQU8sS0FBSyxDQUFDO2FBQ2Q7Ozs7O1FBRUQsbURBQWdCOzs7O1lBQWhCLFVBQWlCLEVBQVM7b0JBQVAsZ0JBQUs7Z0JBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDZjs7Ozs7UUFFRCxvREFBaUI7Ozs7WUFBakIsVUFBa0IsRUFBVTtvQkFBUixrQkFBTTtnQkFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUNmOzs7OztRQUVELHdEQUFxQjs7OztZQUFyQixVQUFzQixJQUFJO2dCQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN0Qjs7OztRQUdELDhDQUFXOzs7WUFEWDtnQkFFRSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztnQkFDNUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCOzs7OztRQUdELCtDQUFZOzs7O1lBRFosVUFDYSxNQUFNO2dCQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUM1Qjs7Ozs7UUFHRCwrQ0FBWTs7OztZQURaLFVBQ2EsTUFBTTtnQkFDakIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDOUI7Ozs7OztRQUVELDBDQUFPOzs7OztZQUFQLFVBQVEsSUFBSSxFQUFFLE1BQU87Z0JBQ25CLElBQUksTUFBTSxFQUFFO29CQUNWLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztpQkFDM0I7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDeEI7Ozs7OztRQUVELDBDQUFPOzs7OztZQUFQLFVBQVEsS0FBSyxFQUFFLElBQUk7Z0JBQ2pCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQzthQUNsQjs7OztRQUVELDRDQUFTOzs7WUFBVDs7b0JBQ00sTUFBTTtnQkFDVixJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFO29CQUNqQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztpQkFDNUI7cUJBQU07b0JBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7aUJBQ3ZCO2dCQUVELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSVUscUJBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUN4Rjs7OztRQUVELG1EQUFnQjs7O1lBQWhCOztvQkFDUSxJQUFJLEdBQUc7b0JBQ1gsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVO29CQUMxQixNQUFNLEVBQUUsU0FBUztvQkFDakIsTUFBTSxFQUFFLEVBQUU7b0JBQ1YsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCO2dCQUNELElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxTQUFTLEVBQUU7b0JBQ2hDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztvQkFDaEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUMxQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7aUJBQy9CO3FCQUFNO29CQUNMLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDM0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztpQkFDakM7Z0JBQ0QsT0FBTyxJQUFJLENBQUM7YUFDYjs7Ozs7UUFFRCw2Q0FBVTs7OztZQUFWLFVBQVcsSUFBSTtnQkFDYixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7O29CQUVmLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxVQUFBLENBQUM7b0JBQ3hDLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztpQkFDdkQsQ0FBQztnQkFDRixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRTtvQkFDWixPQUFPO2lCQUNSO2dCQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQzthQUVsRTs7Ozs7UUFFRCwrQ0FBWTs7OztZQUFaLFVBQWEsSUFBSTs7b0JBQ1QsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFVBQUEsQ0FBQztvQkFDeEMsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUN2RCxDQUFDO2dCQUVGLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLGFBQWEsWUFBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7YUFDcEU7Ozs7UUFFRCxnREFBYTs7O1lBQWI7Z0JBQ0UsSUFBSSxDQUFDLGFBQWEsWUFBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7O29CQUM3QyxLQUFvQixJQUFBLEtBQUFWLFNBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQSxnQkFBQTt3QkFBakMsSUFBTSxLQUFLLFdBQUE7d0JBQ2QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUNyRDs7Ozs7Ozs7Ozs7Ozs7O2dCQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDOzthQUN6Qjs7b0JBcGZGVyxZQUFTLFNBQUM7d0JBQ1QsUUFBUSxFQUFFLHVCQUF1Qjt3QkFDakMsUUFBUSxFQUFFLHk1R0E0Rkw7d0JBQ0wsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDO3dCQUNaLGFBQWEsRUFBRUMsb0JBQWlCLENBQUMsU0FBUzt3QkFDMUMsZUFBZSxFQUFFQywwQkFBdUIsQ0FBQyxNQUFNO3dCQUMvQyxVQUFVLEVBQUU7NEJBQ1ZDLGtCQUFPLENBQUMsZ0JBQWdCLEVBQUU7Z0NBQ3hCQyxxQkFBVSxDQUFDLFFBQVEsRUFBRTtvQ0FDbkJDLGdCQUFLLENBQUM7d0NBQ0osT0FBTyxFQUFFLENBQUM7cUNBQ1gsQ0FBQztvQ0FDRkMsa0JBQU8sQ0FBQyxHQUFHLEVBQUVELGdCQUFLLENBQUM7d0NBQ2pCLE9BQU8sRUFBRSxDQUFDO3FDQUNYLENBQUMsQ0FBQztpQ0FDSixDQUFDOzZCQUNILENBQUM7eUJBQ0g7cUJBQ0Y7Ozs7d0JBeklDRSxhQUFVO3dCQUFFQyxTQUFNO3dCQUFFQyxvQkFBaUI7d0JBeUI5QixrQkFBa0I7d0JBUmxCQyxlQUFROzs7OzZCQTBIZEMsUUFBSztrQ0FDTEEsUUFBSztxQ0FDTEEsUUFBSztxQ0FDTEEsUUFBSztpQ0FDTEEsUUFBSztpQ0FDTEEsUUFBSztnQ0FDTEEsUUFBSzsrQkFDTEEsUUFBSzsrQkFDTEEsUUFBSztvQ0FDTEEsUUFBSzs0QkFDTEEsUUFBSztpQ0FDTEEsUUFBSzt1Q0FDTEEsUUFBSzswQ0FDTEEsUUFBSzswQ0FDTEEsUUFBSztpQ0FDTEEsUUFBSztpQ0FDTEEsUUFBSzttQ0FDTEEsUUFBSztzQ0FDTEEsUUFBSzttQ0FDTEEsUUFBSztxQ0FDTEEsUUFBSztvQ0FDTEEsUUFBSztnQ0FDTEEsUUFBSztnQ0FDTEEsUUFBSztnQ0FDTEEsUUFBSztnQ0FDTEEsUUFBSztpQ0FDTEEsUUFBSzs2QkFDTEEsUUFBSzs0QkFDTEEsUUFBSzs2QkFDTEEsUUFBSztrQ0FDTEEsUUFBSzs4QkFDTEEsUUFBSztpQ0FDTEEsUUFBSztvQ0FDTEEsUUFBSzsrQkFFTEMsU0FBTTtpQ0FDTkEsU0FBTTtzQ0FFTkMsZUFBWSxTQUFDLGlCQUFpQjtrQ0FxUTlCQyxlQUFZLFNBQUMsWUFBWTttQ0FNekJBLGVBQVksU0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLENBQUM7bUNBS3JDQSxlQUFZLFNBQUMsWUFBWSxFQUFFLENBQUMsUUFBUSxDQUFDOztRQStFeEMsK0JBQUM7S0FBQSxDQXRZNkNDLDRCQUFrQjs7Ozs7O0FDM0loRTtRQTRQRSxrQ0FBb0IsRUFBcUIsRUFDL0IsYUFBK0IsRUFDL0IsMkJBQTZELEVBQzlELFdBQStCO1lBSHBCLE9BQUUsR0FBRixFQUFFLENBQW1CO1lBQy9CLGtCQUFhLEdBQWIsYUFBYSxDQUFrQjtZQUMvQixnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQWtDO1lBQzlELGdCQUFXLEdBQVgsV0FBVyxDQUFvQjs7WUE3Qy9CLGtCQUFhLEdBQVksSUFBSSxDQUFDO1lBQzlCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1lBQzFCLHNCQUFpQixHQUFZLEtBQUssQ0FBQztZQUNuQyxTQUFJLEdBQVUsRUFBRSxDQUFDO1lBQ2pCLGNBQVMsR0FBVSxFQUFFLENBQUM7WUFDdEIsY0FBUyxHQUFVLEVBQUUsQ0FBQztZQUN0QixjQUFTLEdBQVcsRUFBRSxDQUFDO1lBQ3ZCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1lBQ3ZCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1lBQ3ZCLFVBQUssR0FBVyxDQUFDLENBQUM7WUFDbEIsaUJBQVksR0FBVyxFQUFFLENBQUM7WUFDMUIsbUJBQWMsR0FBWSxLQUFLLENBQUM7WUFDaEMsOEJBQXlCLEdBQVUsRUFBRSxDQUFDO1lBWXJDLGVBQVUsR0FBc0IsSUFBSTVCLGVBQVksRUFBRSxDQUFDO1lBQ25ELHlCQUFvQixHQUFzQixJQUFJQSxlQUFZLEVBQUUsQ0FBQztZQUd2RSxnQkFBVyxHQUFHLEtBQUssQ0FBQztZQUVwQixrQkFBYSxHQUFVLEVBQUUsQ0FBQztZQUMxQiwwQkFBcUIsR0FBVSxFQUFFLENBQUM7WUFDbEMsMkJBQXNCLEdBQVEsRUFBRSxDQUFDO1lBQ2pDLG9CQUFlLEdBQUcsS0FBSyxDQUFDO1lBQ3hCLFlBQU8sR0FBRyxLQUFLLENBQUM7WUFZZCwyQkFBMkIsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLFVBQUEsQ0FBQzs7YUFFckQsQ0FBQyxDQUFDO1NBQ0o7Ozs7O1FBWEQsOENBQVc7Ozs7WUFBWCxVQUFZLEdBQUc7Z0JBQ2IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUksSUFBTSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRyxDQUFDLE1BQU0sQ0FBQSxFQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDO2FBQ3BHOzs7O1FBV0QsMkNBQVE7OztZQUFSO2dCQUNFLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsK0JBQStCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3RSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDcEYsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQztnQkFDNUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQzs7b0JBQ3ZELElBQUksR0FBRyxJQUFJLENBQUMsd0JBQXdCLEVBQUU7Z0JBQzFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDakU7Ozs7UUFFRCxrREFBZTs7O1lBQWY7O29CQUNRLFVBQVUsR0FBRSxRQUFRLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxJQUFHLFVBQVUsRUFBRTtvQkFDYixVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtvQkFDeEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtpQkFDckI7YUFDRjs7Ozs7UUFFRCxrRUFBK0I7Ozs7WUFBL0IsVUFBZ0MsSUFBSTs7b0JBQzlCLFVBQVUsR0FBRyxFQUFFO2dCQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTs7d0JBQ1gsR0FBRyxHQUFHO3dCQUNSLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTt3QkFDbkIsTUFBTSxFQUFFLEtBQUs7cUJBQ2Q7b0JBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdEIsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sVUFBVSxDQUFDO2FBQ25COzs7OztRQUVELGdFQUE2Qjs7OztZQUE3QixVQUE4QixNQUFNOztvQkFDOUIsT0FBTyxHQUFHLEVBQUU7Z0JBQ2hCLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJOzt3QkFDYixHQUFHLEdBQUcsSUFBSSxNQUFNLEVBQUU7b0JBQ3RCLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDO29CQUN2QixPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUNwRCxDQUFDLENBQUE7Z0JBQ0YsT0FBTyxPQUFPLENBQUM7YUFDaEI7Ozs7UUFFRCwyREFBd0I7OztZQUF4QjtnQkFBQSxpQkFnQkM7O29CQWZLLEdBQUcsR0FBRztvQkFDUixHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtvQkFDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjO29CQUN6QixPQUFPLEVBQUUsSUFBSTtpQkFDZDtnQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQzVCLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO3dCQUM5QixHQUFHLEdBQUc7NEJBQ0osR0FBRyxFQUFFLEtBQUksQ0FBQyxxQkFBcUI7NEJBQy9CLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTs0QkFDZixPQUFPLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixLQUFLLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSzt5QkFDM0QsQ0FBQTtxQkFDQTtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxHQUFHLENBQUM7YUFDWjs7Ozs7UUFFRCxpREFBYzs7OztZQUFkLFVBQWUsTUFBTTtnQkFDbkIsUUFBUSxNQUFNLENBQUMsaUJBQWlCO29CQUM5QixLQUFLLFlBQVk7d0JBQ2YsT0FBTyxnQ0FBZ0MsQ0FBQztvQkFDMUMsS0FBSyxjQUFjO3dCQUNqQixPQUFPLGtDQUFrQyxDQUFDO29CQUM1QyxLQUFLLGFBQWE7d0JBQ2hCLE9BQU8saUNBQWlDLENBQUM7b0JBQzNDO3dCQUNFLE9BQU8sY0FBYyxDQUFDO2lCQUN6QjthQUNGOzs7Ozs7O1FBRUQsK0NBQVk7Ozs7OztZQUFaLFVBQWEsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLO2dCQUM3QixRQUFRLE1BQU0sQ0FBQyxlQUFlO29CQUM1QixLQUFLLFVBQVU7d0JBQ2IsT0FBTyxhQUFhLENBQUE7b0JBQ3RCLEtBQUssV0FBVzt3QkFDZCxPQUFPLGNBQWMsQ0FBQztvQkFDeEIsS0FBSyxZQUFZO3dCQUNmLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTs0QkFDZixJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0NBQy9FLE9BQU8sY0FBYyxDQUFDOzZCQUN2QjtpQ0FBTTtnQ0FDTCxPQUFPLGNBQWMsQ0FBQzs2QkFDdkI7eUJBQ0Y7NkJBQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLGtCQUFrQixFQUFFOzRCQUM3QyxJQUFJLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0NBQ3JHLE9BQU8sY0FBYyxDQUFDOzZCQUN2QjtpQ0FBTTtnQ0FDTCxPQUFPLGNBQWMsQ0FBQzs2QkFDdkI7eUJBQ0Y7NkJBQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLHFCQUFxQixFQUFFOzRCQUNoRCxJQUFJLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0NBQzNHLE9BQU8sY0FBYyxDQUFDOzZCQUN2QjtpQ0FBTTtnQ0FDTCxPQUFPLGNBQWMsQ0FBQzs2QkFDdkI7eUJBQ0Y7NkJBQU0sSUFBRyxLQUFLLEtBQUssQ0FBQyxFQUFFOzRCQUNyQixPQUFPLFVBQVUsQ0FBQzt5QkFDbkI7O29CQUVIO3dCQUNFLE9BQU87aUJBQ1Y7YUFDRjs7Ozs7UUFFRCxxREFBa0I7Ozs7WUFBbEIsVUFBbUIsR0FBRztnQkFDcEIsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7b0JBQ2pELE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQztpQkFDbEI7cUJBQU07b0JBQ0wsT0FBTyxHQUFHLENBQUM7aUJBQ1o7YUFDRjs7Ozs7O1FBRUQsa0RBQWU7Ozs7O1lBQWYsVUFBZ0IsSUFBSSxFQUFFLE9BQU87O29CQUN2QixJQUFJLEdBQUcsS0FBSztnQkFDaEIsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxPQUFPLElBQUcsSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLEdBQUEsQ0FBQyxDQUFBO2dCQUN6RyxPQUFPLElBQUksQ0FBQzthQUNiOzs7Ozs7UUFFRCwrQ0FBWTs7Ozs7WUFBWixVQUFhLElBQUksRUFBRSxPQUFPOztvQkFDcEIsSUFBSSxHQUFHLEtBQUs7Z0JBQ2hCLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssT0FBTyxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssQ0FBQyxHQUFBLENBQUMsQ0FBQTtnQkFDMUcsT0FBTyxJQUFJLENBQUM7YUFDYjs7Ozs7UUFFRCwyQ0FBUTs7OztZQUFSLFVBQVMsR0FBRzs7Z0JBRVYsT0FBTyxJQUFJLENBQUM7YUFDYjs7Ozs7UUFFRCxvREFBaUI7Ozs7WUFBakIsVUFBa0IsR0FBRzs7b0JBQ2YsZUFBZSxHQUFHLEVBQUU7Z0JBQ3hCLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDdkQsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQzVELGVBQWUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ2pDO2lCQUNGLENBQUMsQ0FBQztnQkFDSCxPQUFPLGVBQWUsQ0FBQzthQUN4Qjs7Ozs7UUFFRCxrREFBZTs7OztZQUFmLFVBQWdCLEdBQUc7Z0JBQW5CLGlCQWVDOztvQkFkTyxZQUFZLEdBQUcsR0FBRyxDQUFDLE1BQU07O29CQUMzQixhQUFhO2dCQUNqQixJQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDckMsSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRTt3QkFDaEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7d0JBQzNCLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO3FCQUM3QjtpQkFDRixDQUFDLENBQUM7O29CQUNHLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUksSUFBTSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUFBLEVBQUUsQ0FBQztnQkFDbEYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUN6QixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssWUFBWSxFQUFFO3dCQUNoQyxhQUFhLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDdkY7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7Ozs7O1FBRUQsd0RBQXFCOzs7O1lBQXJCLFVBQXNCLEdBQUc7O29CQUNqQixNQUFNLEdBQUcsR0FBRyxDQUFDLE1BQU07O29CQUNyQixVQUFVLEdBQUcsS0FBSztnQkFDdEIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ3JDLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNO3dCQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO2lCQUN0RCxDQUFDLENBQUE7Z0JBRUYsT0FBTyxHQUFHLENBQUMsS0FBSyxLQUFLLE9BQU8sR0FBRyxFQUFFLEdBQUcsVUFBVSxHQUFHLFlBQVksR0FBRyxhQUFhLENBQUM7YUFDL0U7Ozs7O1FBRUQsK0NBQVk7Ozs7WUFBWixVQUFhLElBQUk7O2dCQUVmLElBQUksS0FBSyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7YUFDakU7Ozs7O1FBRUQsbURBQWdCOzs7O1lBQWhCLFVBQWlCLENBQVE7Z0JBQ3ZCLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3pEOzs7Ozs7UUFFRCxtREFBZ0I7Ozs7O1lBQWhCLFVBQWlCLEtBQUssRUFBRSxJQUFJO2dCQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDeEIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7YUFDdEQ7Ozs7UUFFRCw0Q0FBUzs7O1lBQVQ7Z0JBQ0UsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO2FBQzNGOzs7OztRQUdELDJDQUFROzs7O1lBRFIsVUFDUyxLQUFLOzs7b0JBRVQsTUFBTSxHQUFDLE1BQU0sQ0FBQyxHQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBaUIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQzs7b0JBQ2xILGVBQWUsR0FBQyxHQUFHO2dCQUV0QixNQUFNLEdBQUcsQ0FBQyxNQUFNLEdBQUMsR0FBRyxJQUFJLGVBQWUsR0FBRyxlQUFlLEdBQUcsTUFBTSxHQUFDLEdBQUcsQ0FBQztnQkFDdkUsSUFBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztvQkFDeEQsR0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBaUIsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLEdBQUcsSUFBSSxDQUFDO2lCQUNsRzthQUNGOzs7OztRQUVELDREQUF5Qjs7OztZQUF6QixVQUEwQixJQUFJO2dCQUM1QixRQUFRLElBQUk7b0JBQ1YsS0FBSyxhQUFhO3dCQUNoQixPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsY0FBYyxHQUFHLGFBQWEsQ0FBQztvQkFDeEYsS0FBSyxlQUFlO3dCQUNsQixPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsaUJBQWlCLEdBQUcsZUFBZSxDQUFBO29CQUM5Rjt3QkFDRSxPQUFPLElBQUksQ0FBQztpQkFDZjthQUNGOzs7OztRQUVELDJEQUF3Qjs7OztZQUF4QixVQUF5QixPQUFPOztvQkFDMUIsVUFBVSxHQUFHLEtBQUs7Z0JBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO3dCQUM1QyxVQUFVLEdBQUcsSUFBSSxDQUFBO3FCQUNsQjtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxVQUFVLENBQUM7YUFDbkI7Ozs7O1FBRUQsc0RBQW1COzs7O1lBQW5CLFVBQW9CLElBQUk7Z0JBQ3RCLFFBQVEsSUFBSTtvQkFDVixLQUFLLGFBQWE7d0JBQ2hCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3QkFDbkIsT0FBTTtvQkFDUixLQUFLLGNBQWM7d0JBQ2pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzt3QkFDcEIsT0FBTTtvQkFDUixLQUFLLFlBQVk7d0JBQ2YsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO3dCQUNsQixPQUFNO29CQUNSO3dCQUNFLE9BQU87aUJBQ1Y7YUFDRjs7Ozs7O1FBR0QsOENBQVc7Ozs7O1lBQVg7Z0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQ3ZCOzs7O1FBRUQsK0NBQVk7OztZQUFaO2dCQUFBLGlCQU9DO2dCQU5DLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2hDLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxLQUFJLENBQUMsV0FBVyxFQUFFO3dCQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztxQkFDcEM7aUJBQ0YsQ0FBQyxDQUFDO2FBRUo7Ozs7O1FBRUQsK0RBQTRCOzs7O1lBQTVCLFVBQTZCLFdBQVc7Z0JBQXhDLGlCQVFDO2dCQVBFLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxXQUFZLEVBQUU7d0JBQzlCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFJLENBQUMsT0FBTyxDQUFDO3FCQUN6Qzt5QkFBTTt3QkFDTCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO3FCQUMvQjtpQkFDRixDQUFDLENBQUM7YUFDSjs7OztRQUVELDZDQUFVOzs7WUFBVjtnQkFDQyxJQUFJLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNuRCxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtvQkFDM0MsSUFBSSxHQUFHLEtBQUssSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7Z0NBQ2pDLElBQUksR0FBRztnQ0FDVCxHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtnQ0FDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXO2dDQUN0QixPQUFPLEVBQUUsSUFBSTs2QkFDZDs0QkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUNqRTs2QkFBTTs7O2dDQUVELElBQUksR0FBRztnQ0FDVCxHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtnQ0FDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjO2dDQUN6QixPQUFPLEVBQUUsSUFBSTs2QkFDZDs0QkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUNqRTt3QkFDRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ3RFO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7cUJBQzFDO2lCQUNGO2dCQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQ3ZCOzs7Ozs7UUFFRCx1REFBb0I7Ozs7O1lBQXBCLFVBQXFCLENBQUMsRUFBRSxJQUFJO2dCQUMxQixDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ3BCLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7b0JBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDOzt3QkFDbEIsSUFBSSxHQUFHO3dCQUNULEdBQUcsRUFBRSxJQUFJLENBQUMscUJBQXFCO3dCQUMvQixJQUFJLEVBQUUsSUFBSTt3QkFDVixPQUFPLEVBQUUsS0FBSztxQkFDZjtvQkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNqRTtxQkFBTSxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssTUFBTSxFQUFFO29CQUNsQyxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQzs7d0JBQ2pCLElBQUksR0FBRzt3QkFDVCxHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjt3QkFDL0IsSUFBSSxFQUFFLElBQUk7d0JBQ1YsT0FBTyxFQUFFLElBQUk7cUJBQ2Q7b0JBQ0QsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDakU7Z0JBQ0QsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzthQUN2Qjs7Ozs7UUFFRCx3REFBcUI7Ozs7WUFBckIsVUFBc0IsSUFBSTs7b0JBQ3BCLFVBQVUsR0FBRyxLQUFLO2dCQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQzVCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLG1CQUFtQjt3QkFBRSxVQUFVLEdBQUcsSUFBSSxDQUFDO2lCQUN2RSxDQUFDLENBQUE7Z0JBQ0YsT0FBTyxVQUFVLENBQUM7YUFDbkI7Ozs7O1FBRUQsOENBQVc7Ozs7WUFBWCxVQUFZLElBQUk7O29CQUNWLElBQUksR0FBRyxFQUFFO2dCQUNiLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUk7d0JBQ3RCLElBQUksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUE7aUJBQ2hDLENBQUMsQ0FBQTtnQkFDRixJQUFJLElBQUksS0FBSyxFQUFFLEVBQUU7b0JBQ2YsT0FBTyxJQUFJLEtBQUssS0FBSyxHQUFHLGlCQUFpQixHQUFHLG1CQUFtQixDQUFDO2lCQUNqRTtxQkFBTTtvQkFDTCxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxHQUFHLGlCQUFpQixHQUFHLG1CQUFtQixDQUFDO2lCQUN6RTthQUNGOzs7Ozs7UUFFRCxvREFBaUI7Ozs7O1lBQWpCLFVBQWtCLEdBQUcsRUFBRSxLQUFLO2dCQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNoRSxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzthQUN2Qjs7Ozs7UUFFRCxvREFBaUI7Ozs7WUFBakIsVUFBa0IsR0FBRztnQkFDbkIsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM5RDs7Ozs7O1FBRUQsaURBQWM7Ozs7O1lBQWQsVUFBZSxHQUFHLEVBQUUsSUFBSTs7b0JBQ2xCLEdBQUcsR0FBRztvQkFDUixPQUFPLEVBQUUsR0FBRztvQkFDWixJQUFJLEVBQUUsSUFBSTtpQkFDWDtnQkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTthQUN6RDs7OztRQUVELGtEQUFlOzs7WUFBZjtnQkFDRSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNsQzs7b0JBaGxCRmEsWUFBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSx1QkFBdUI7d0JBQ2pDLFFBQVEsRUFBRSw2aVJBb0xMO3dCQUNMLE1BQU0sRUFBRSxDQUFDLGdnVkFBMC9VLEVBQUUsOG1IQUE4bUgsQ0FBQzt3QkFDcG5jLGFBQWEsRUFBRUMsb0JBQWlCLENBQUMsSUFBSTtxQkFDdEM7Ozs7d0JBM01xQlEsb0JBQWlCO3dCQVdyQ2tCLG1CQUFnQjt3QkFJVCxnQ0FBZ0M7d0JBRGhDLGtCQUFrQjs7OztrQ0FnTXhCSyxZQUFTLFNBQUMsYUFBYTtvQ0FHdkJyQixRQUFLO21DQUNMQSxRQUFLO3dDQUNMQSxRQUFLOzJCQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2dDQUNMQSxRQUFLO2dDQUNMQSxRQUFLO21DQUNMQSxRQUFLO21DQUNMQSxRQUFLOzRCQUNMQSxRQUFLO21DQUNMQSxRQUFLO3FDQUNMQSxRQUFLO2dEQUNMQSxRQUFLO3NDQUNMQSxRQUFLO3lDQUdMQSxRQUFLOzJDQUNMQSxRQUFLO3VDQUNMQSxRQUFLOzBDQUNMQSxRQUFLO2tDQUNMQSxRQUFLO3VDQUNMQSxRQUFLO3FDQUNMQSxRQUFLO2lDQUVMQyxTQUFNOzJDQUNOQSxTQUFNOytCQWtOTkUsZUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQzs7UUF3SzNDLCtCQUFDO0tBQUE7Ozs7Ozs7QUNybUJELFFBQWFtQixjQUFZLEdBQUc7UUFDeEI7WUFDRSxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUsRUFBRTtTQUNaO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsYUFBYTtZQUNuQixPQUFPLEVBQUUsRUFBRTtTQUNaO0tBQ0Y7O0FBRUQsUUFBYUMsY0FBWSxHQUFJO1FBQzNCO1lBQ0UsSUFBSSxFQUFFLE1BQU07WUFDWixJQUFJLEVBQUUsYUFBYTtZQUNuQixLQUFLLEVBQUUsR0FBRztZQUNWLFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLEtBQUs7WUFDcEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLFdBQVc7WUFDekIsaUJBQWlCLEVBQUUsY0FBYztZQUNqQyxlQUFlLEVBQUUsWUFBWTtZQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLFFBQVE7WUFDZCxJQUFJLEVBQUUsZUFBZTtZQUNyQixLQUFLLEVBQUUsR0FBRztZQUNWLFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLEtBQUs7WUFDcEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLFNBQVM7WUFDdkIsaUJBQWlCLEVBQUUsWUFBWTtZQUMvQixlQUFlLEVBQUUsVUFBVTtZQUMzQixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLFlBQVk7WUFDbEIsSUFBSSxFQUFFLGVBQWU7WUFDckIsS0FBSyxFQUFFLEdBQUc7WUFDVixTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxLQUFLO1lBQ3BCLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxTQUFTO1lBQ3ZCLGlCQUFpQixFQUFFLFlBQVk7WUFDL0IsZUFBZSxFQUFFLFVBQVU7WUFDM0Isa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxTQUFTO1lBQ2YsSUFBSSxFQUFFLFVBQVU7WUFDaEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxTQUFTO1lBQ3ZCLGlCQUFpQixFQUFFLFlBQVk7WUFDL0IsZUFBZSxFQUFFLFVBQVU7WUFDM0Isa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxRQUFRO1lBQ2QsSUFBSSxFQUFFLGNBQWM7WUFDcEIsS0FBSyxFQUFFLEdBQUc7WUFDVixTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxrQkFBa0I7WUFDaEMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsV0FBVztZQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLEtBQUs7WUFDWCxJQUFJLEVBQUUsYUFBYTtZQUNuQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLElBQUk7WUFDbkIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLGtCQUFrQjtZQUNoQyxpQkFBaUIsRUFBRSxhQUFhO1lBQ2hDLGVBQWUsRUFBRSxXQUFXO1lBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxVQUFVLEVBQUUsS0FBSztZQUNqQixtQkFBbUIsRUFBRSxFQUFFO1NBQ3hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsV0FBVztZQUNqQixJQUFJLEVBQUUsWUFBWTtZQUNsQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLElBQUk7WUFDbkIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLGtCQUFrQjtZQUNoQyxpQkFBaUIsRUFBRSxhQUFhO1lBQ2hDLGVBQWUsRUFBRSxZQUFZO1lBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxVQUFVLEVBQUUsS0FBSztZQUNqQixtQkFBbUIsRUFBRSxFQUFFO1NBQ3hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsa0JBQWtCO1lBQ3hCLElBQUksRUFBRSxjQUFjO1lBQ3BCLEtBQUssRUFBRSxFQUFFO1lBQ1QsU0FBUyxFQUFFLElBQUk7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsZUFBZTtZQUM3QixpQkFBaUIsRUFBRSxhQUFhO1lBQ2hDLGVBQWUsRUFBRSxZQUFZO1lBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtZQUN0QyxVQUFVLEVBQUUsS0FBSztZQUNqQixtQkFBbUIsRUFBRSxFQUFFO1NBQ3hCO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsUUFBUTtZQUNkLElBQUksRUFBRSxjQUFjO1lBQ3BCLEtBQUssRUFBRSxFQUFFO1lBQ1QsU0FBUyxFQUFFLElBQUk7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsbUJBQW1CO1lBQ2pDLGlCQUFpQixFQUFFLGFBQWE7WUFDaEMsZUFBZSxFQUFFLFdBQVc7WUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxLQUFLO1lBQ1gsSUFBSSxFQUFFLGFBQWE7WUFDbkIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxtQkFBbUI7WUFDakMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsV0FBVztZQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLFdBQVc7WUFDakIsSUFBSSxFQUFFLFlBQVk7WUFDbEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxtQkFBbUI7WUFDakMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsWUFBWTtZQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLGtCQUFrQjtZQUN4QixJQUFJLEVBQUUsY0FBYztZQUNwQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLElBQUk7WUFDbkIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLGVBQWU7WUFDN0IsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsWUFBWTtZQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLE9BQU87WUFDYixJQUFJLEVBQUUsc0JBQXNCO1lBQzVCLEtBQUssRUFBRSxLQUFLO1lBQ1osU0FBUyxFQUFFLElBQUk7WUFDZixhQUFhLEVBQUUsSUFBSTtZQUNuQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsbUJBQW1CO1lBQ2pDLGlCQUFpQixFQUFFLGFBQWE7WUFDaEMsZUFBZSxFQUFFLFdBQVc7WUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1lBQ3RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLG1CQUFtQixFQUFFLEVBQUU7U0FDeEI7UUFDRDtZQUNFLElBQUksRUFBRSxRQUFRO1lBQ2QsSUFBSSxFQUFFLGFBQWE7WUFDbkIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxtQkFBbUI7WUFDakMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsV0FBVztZQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLGNBQWM7WUFDcEIsSUFBSSxFQUFFLFdBQVc7WUFDakIsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsSUFBSTtZQUNmLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGFBQWEsRUFBRSxJQUFJO1lBQ25CLFlBQVksRUFBRSxtQkFBbUI7WUFDakMsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsWUFBWTtZQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtRQUNEO1lBQ0UsSUFBSSxFQUFFLHFCQUFxQjtZQUMzQixJQUFJLEVBQUUsYUFBYTtZQUNuQixLQUFLLEVBQUUsRUFBRTtZQUNULFNBQVMsRUFBRSxJQUFJO1lBQ2YsYUFBYSxFQUFFLElBQUk7WUFDbkIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLGVBQWU7WUFDN0IsaUJBQWlCLEVBQUUsYUFBYTtZQUNoQyxlQUFlLEVBQUUsWUFBWTtZQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7WUFDdEMsVUFBVSxFQUFFLEtBQUs7WUFDakIsbUJBQW1CLEVBQUUsRUFBRTtTQUN4QjtLQUNGOztBQUVELFFBQWFDLDJCQUF5QixHQUFHOzs7Ozs7UUFNdkM7WUFDRSxJQUFJLEVBQUUsZUFBZTtZQUNyQixJQUFJLEVBQUUsY0FBYztZQUNwQixVQUFVLEVBQUUsS0FBSztTQUNsQjtRQUNEO1lBQ0UsSUFBSSxFQUFFLGFBQWE7WUFDbkIsSUFBSSxFQUFFLFlBQVk7WUFDbEIsVUFBVSxFQUFFLEtBQUs7U0FDbEI7S0FNRjs7Ozs7OztRQ3JNeUM3QywwQ0FBbUI7UUF1QjdELGdDQUFvQixFQUFxQixFQUFVLFVBQXNCLEVBQy9ELFdBQXdCLEVBQVUsVUFBc0IsRUFDeEQsZ0JBQWtDLEVBQ2xDa0MsU0FBaUIsRUFDakIsYUFBK0IsRUFDL0IsMkJBQTZELEVBQzlELFdBQStCLEVBQzlCLGNBQXNDO1lBUGhELFlBUUUsaUJBQU8sU0FDUjtZQVRtQixRQUFFLEdBQUYsRUFBRSxDQUFtQjtZQUFVLGdCQUFVLEdBQVYsVUFBVSxDQUFZO1lBQy9ELGlCQUFXLEdBQVgsV0FBVyxDQUFhO1lBQVUsZ0JBQVUsR0FBVixVQUFVLENBQVk7WUFDeEQsc0JBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtZQUNsQyxZQUFNLEdBQU5BLFNBQU0sQ0FBVztZQUNqQixtQkFBYSxHQUFiLGFBQWEsQ0FBa0I7WUFDL0IsaUNBQTJCLEdBQTNCLDJCQUEyQixDQUFrQztZQUM5RCxpQkFBVyxHQUFYLFdBQVcsQ0FBb0I7WUFDOUIsb0JBQWMsR0FBZCxjQUFjLENBQXdCO1lBM0JoRCxVQUFJLEdBQVUsRUFBRSxDQUFDO1lBQ2pCLGVBQVMsR0FBVSxFQUFFLENBQUM7WUFDdEIscUJBQWUsR0FBWSxLQUFLLENBQUM7WUFDakMsdUJBQWlCLEdBQVksS0FBSyxDQUFDO1lBQ25DLGVBQVMsR0FBUSxFQUFFLENBQUM7WUFDcEIsZUFBUyxHQUFVLEVBQUUsQ0FBQztZQUN0QixxQkFBZSxHQUFZLEtBQUssQ0FBQztZQUNqQyxtQkFBYSxHQUFVLEVBQUUsQ0FBQztZQUMxQixtQkFBYSxHQUFZLElBQUksQ0FBQztZQUM5QixrQkFBWSxHQUFXLEVBQUUsQ0FBQzs7WUFFMUIsa0JBQVksR0FBVVMsY0FBWSxDQUFDO1lBQ25DLGtCQUFZLEdBQVVDLGNBQVksQ0FBQztZQUNuQywrQkFBeUIsR0FBVUMsMkJBQXlCLENBQUM7WUFDN0QsV0FBSyxHQUFXLENBQUMsQ0FBQztZQUNsQixrQkFBWSxHQUFXLEVBQUUsQ0FBQztZQUMxQixvQkFBYyxHQUFZLElBQUksQ0FBQzs7U0FhOUI7Ozs7UUFFRCx5Q0FBUTs7O1lBQVI7Z0JBQUEsaUJBd0RDOztnQkF0REMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUNwRCxVQUFBLElBQUk7b0JBQ0YsS0FBSSxDQUFDLElBQUksR0FBRyxLQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN4RCxLQUFJLENBQUMsU0FBUyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzlELElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7O3dCQUVuQixLQUFJLENBQUMsU0FBUyxZQUFPLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUM3RCxLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQzs7d0JBRTVCLElBQUksS0FBSSxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFOztnQ0FDcEQsUUFBUSxHQUFHLEVBQUU7NEJBQ25CLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUE7NEJBQ2pDLEtBQUksQ0FBQywyQkFBMkIsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDeEU7cUJBQ0Y7b0JBQ0QsS0FBSSxDQUFDLElBQUksWUFBTyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzNCLEtBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRzt3QkFDbkIsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3RELENBQUMsQ0FBQTtpQkFDSCxDQUNGLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxVQUFDLElBQUk7b0JBQ0gsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssWUFBWSxFQUFFOzs0QkFDaEMsWUFBWSxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLENBQUM7OzRCQUN2RSxhQUFhLEdBQUcsS0FBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQzt3QkFDN0UsS0FBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDN0IsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEtBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUEsQ0FBQyxDQUFDO3FCQUNuRDt5QkFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxXQUFXLEVBQUU7d0JBQzVDLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7cUJBQ2xDO2lCQUNGLENBQ0YsQ0FBQyxDQUFDO2dCQUNILElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLGNBQVEsS0FBSSxDQUFDLElBQUksWUFBTyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUUvRSxJQUFJLENBQUMsMkJBQTJCLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQkFDL0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO29CQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNsQixLQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2hDLENBQUMsQ0FBQztnQkFFSCxJQUFJLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7b0JBQzNELEtBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzlDLENBQUMsQ0FBQztnQkFFSCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtvQkFDakUsS0FBSSxDQUFDLElBQUksWUFBTyxLQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7aUJBQ2xILENBQUMsQ0FBQTthQUNIOzs7O1FBRUQsNENBQVc7OztZQUFYO2dCQUFBLGlCQU9DO2dCQU5DLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztvQkFDbkIsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3hELENBQUMsQ0FBQTtnQkFDRixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBQSxDQUFDLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7YUFFdEM7Ozs7O1FBRUQsMENBQVM7Ozs7WUFBVCxVQUFVLElBQUk7Z0JBQ1osSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDaEcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7OzRCQUN0RSxRQUFRLEdBQUc7NEJBQ2YsTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7NEJBQ3RCLFNBQVMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUN6QixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQzs0QkFDOUIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7NEJBQ2xCLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDOzRCQUNqQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7NEJBQ2xELFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO3lCQUMvQjt3QkFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDOUIsSUFBSSxDQUFDLFNBQVMsWUFBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7cUJBQ3RDO29CQUNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JCO2FBQ0Y7Ozs7O1FBRUQseUNBQVE7Ozs7WUFBUixVQUFTLElBQUk7Z0JBQWIsaUJBY0M7Z0JBYkMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTs7d0JBQ2QsUUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7O3dCQUN2QixZQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQzs7d0JBQy9CLFNBQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7d0JBQ3BCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFFBQU0sSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssWUFBVSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFPLEVBQUU7NEJBQ2pHLEtBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQUEsT0FBTztnQ0FBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO29DQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtpQ0FBRTs2QkFBRSxDQUFDLENBQUM7O2dDQUM5TCxNQUFNLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxRQUFNLEVBQUUsU0FBTyxFQUFFLEtBQUksQ0FBQyxTQUFTLENBQUM7NEJBQ25FLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ2pDO3FCQUNGLENBQUMsQ0FBQztpQkFDSjthQUNGOzs7Ozs7O1FBRU8sK0NBQWM7Ozs7OztZQUF0QixVQUF1QixNQUFjLEVBQUUsT0FBZSxFQUFFLE1BQWE7O29CQUMvRCxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNuQixNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsS0FBSztvQkFDbEIsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxPQUFPLEVBQUU7d0JBQzVELElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTs0QkFDNUIsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt5QkFDaEI7d0JBQUMsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFOzRCQUM5QixNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUNoQjtxQkFDRjtpQkFDRixDQUFDLENBQUM7O2dCQUVILE9BQU8sTUFBTSxDQUFDO2FBQ2Y7Ozs7O1FBRUEsNERBQTJCOzs7O1lBQTNCLFVBQTRCLElBQUk7Z0JBQWhDLGlCQVVBOztvQkFUSyxRQUFRLEdBQUcsRUFBRTs7b0JBQ1gsYUFBYSxHQUFHLEdBQUMsSUFBSSxJQUFXLEdBQUcsQ0FBQyxVQUFBLENBQUM7b0JBQ3pDLEtBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLG1CQUFtQixFQUFFO3dCQUNwQyxRQUFRLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7cUJBQ2pIO2lCQUVGLENBQUM7Z0JBRUYsT0FBTyxRQUFRLENBQUM7YUFDakI7Ozs7Ozs7UUFFRCxnREFBZTs7Ozs7O1lBQWYsVUFBZ0IsSUFBSTtnQkFBcEIsaUJBTUM7O29CQUxLLFFBQVEsR0FBRyxFQUFFO2dCQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDZixRQUFRLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN4RixDQUFDLENBQUM7Z0JBQ0gsT0FBTyxRQUFRLENBQUM7YUFDakI7Ozs7Ozs7UUFFRCx1REFBc0I7Ozs7OztZQUF0QixVQUF1QixNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUk7Z0JBQTVDLGlCQW1CQzs7b0JBbEJPLG1CQUFtQixHQUFHLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNmLElBQUksS0FBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7MkJBQ3hELElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7NEJBQ3ZFLFFBQVEsR0FBRzs0QkFDZixNQUFNLEVBQUUsTUFBTTs0QkFDZCxTQUFTLEVBQUUsT0FBTzs0QkFDbEIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7NEJBQzlCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzs0QkFDM0IsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDakMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDOzRCQUNsRCxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQzt5QkFDL0I7d0JBQ0QsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUNwQztpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxtQkFBbUIsQ0FBQzthQUM1Qjs7Ozs7O1FBRUQsZ0RBQWU7Ozs7O1lBQWYsVUFBZ0IsTUFBTSxFQUFFLElBQUk7Z0JBQTVCLGlCQWlCQzs7b0JBaEJPLG1CQUFtQixHQUFHLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNmLElBQUksS0FBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7OzRCQUNuSSxRQUFRLEdBQUc7NEJBQ2YsTUFBTSxFQUFFLE1BQU07NEJBQ2QsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7NEJBQzlCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzRCQUNsQixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzs0QkFDM0IsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzs0QkFDakMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDOzRCQUNsRCxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQzt5QkFDL0I7d0JBQ0QsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUNwQztpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxtQkFBbUIsQ0FBQzthQUM1Qjs7Ozs7O1FBRUQsK0NBQWM7Ozs7O1lBQWQsVUFBZSxHQUFHLEVBQUUsSUFBSTs7b0JBQ2hCLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtvQkFDNUQsS0FBSyxFQUFFLE9BQU87b0JBQ2QsSUFBSSxFQUFFO3dCQUNKLE1BQU0sRUFBRSxJQUFJLEtBQUssYUFBYSxHQUFHLEVBQUUsR0FBRyxVQUFVO3dCQUNoRCxLQUFLLEVBQUUsSUFBSSxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksRUFBRTt3QkFDcEYsT0FBTyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBQyxTQUFTLEdBQUUsR0FBRyxDQUFDLFNBQVMsQ0FBQzt3QkFDOUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUM7d0JBQ3ZCLFdBQVcsRUFBRSxJQUFJLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLEtBQUssYUFBYSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQzVHO2lCQUNGLENBQUM7O2dCQUVGLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxNQUFNO29CQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7aUJBQ3RDLENBQUMsQ0FBQzthQUNKOzs7Ozs7O1FBRUQsMkRBQTBCOzs7Ozs7WUFBMUIsVUFBMkIsTUFBTSxFQUFFLE9BQU8sRUFBRSxTQUFTOztvQkFDN0MsZ0JBQWdCLEdBQVUsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUN6QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxNQUFNOzJCQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssT0FBTzsyQkFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFNBQVMsRUFBRTt3QkFDeEMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM3QjtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUMsTUFBTSxHQUFDLFNBQVMsR0FBQyxPQUFPLEdBQUMsU0FBUyxHQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNoRixPQUFPLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ25DOzs7Ozs7UUFFRCxvREFBbUI7Ozs7O1lBQW5CLFVBQW9CLE1BQU0sRUFBRSxTQUFTOztvQkFDN0IsZ0JBQWdCLEdBQVUsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUN6QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFNBQVMsRUFBRTt3QkFDOUQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM3QjtpQkFDRixDQUFDLENBQUE7Z0JBQ0YsT0FBTyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUNuQzs7Ozs7UUFFRCxvREFBbUI7Ozs7WUFBbkIsVUFBb0IsR0FBRzs7b0JBQ2YsUUFBUSxHQUFHLEVBQUU7O29CQUNiLE1BQU0sR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDO2dCQUM1QixRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDOztvQkFDaEIsUUFBUSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7Z0JBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUNyQzs7Ozs7UUFFRCxxREFBb0I7Ozs7WUFBcEIsVUFBcUIsUUFBUTtnQkFDM0IsSUFBSSxDQUFDLDJCQUEyQixDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQzlFOzs7O1FBRUQsbURBQWtCOzs7WUFBbEI7O29CQUNRLElBQUksR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFOztvQkFDdkQsVUFBVSxHQUFHLElBQUk7Z0JBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUNmLElBQUksSUFBSSxDQUFDLE9BQU87d0JBQUUsVUFBVSxHQUFHLEtBQUssQ0FBQztpQkFDdEMsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sVUFBVSxDQUFDO2FBQ25COzs7OztRQUVELHFEQUFvQjs7OztZQUFwQixVQUFxQixHQUFHOztvQkFDaEIsSUFBSSxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7O29CQUN2RCxnQkFBZ0IsR0FBRyxJQUFJO2dCQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTtvQkFDZixJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxRQUFRO3dCQUFFLGdCQUFnQixHQUFHLEtBQUssQ0FBQztpQkFDdkcsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sZ0JBQWdCLENBQUM7YUFDekI7Ozs7O1FBRUQsaURBQWdCOzs7O1lBQWhCLFVBQWlCLElBQUk7Z0JBQXJCLGlCQW9CQzs7b0JBbkJPLElBQUksR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLE9BQU8sR0FBQSxDQUFDOztvQkFDcEYsUUFBUSxHQUFHLElBQUk7O29CQUNmLGlCQUFpQixHQUFHLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLO2dCQUV4RCxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUU7b0JBQzNDLFFBQVEsR0FBRyxLQUFLLENBQUM7aUJBQ2xCO3FCQUFNO29CQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO3dCQUNmLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFVBQUEsQ0FBQzs0QkFDMUIsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFO2dDQUM1QyxRQUFRLEdBQUcsS0FBSyxDQUFBOzZCQUNqQjt5QkFDRixDQUFDLENBQUE7d0JBQ0YsSUFBSSxLQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDOzRCQUFFLFFBQVEsR0FBRyxLQUFLLENBQUM7cUJBQ3ZELENBQUMsQ0FBQztpQkFDSjtnQkFFRCxJQUFJLENBQUMsZUFBZSxHQUFHLGlCQUFpQixHQUFHLENBQUMsaUJBQWlCLEdBQUcsUUFBUSxDQUFDO2dCQUN6RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7YUFDN0I7Ozs7O1FBRUQsb0RBQW1COzs7O1lBQW5CLFVBQW9CLElBQUk7Z0JBQXhCLGlCQVNDOztvQkFSSyxTQUFTLEdBQUcsS0FBSztnQkFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUM3QixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO3dCQUN0QixTQUFTLEdBQUcsS0FBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBSSxRQUFDLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO3dCQUMzSSxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQSxJQUFJLElBQUksUUFBQyxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztxQkFDL0k7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sU0FBUyxDQUFDO2FBQ2xCOzs7Ozs7UUFFRCw0Q0FBVzs7Ozs7WUFBWCxVQUFZLE9BQU8sRUFBRSxJQUFJO2dCQUF6QixpQkF1QkM7Z0JBdEJDLElBQUksQ0FBQyxlQUFlLEdBQUcsT0FBTyxDQUFDO2dCQUMvQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTs7d0JBQ1gsR0FBRyxHQUFHO3dCQUNSLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVTt3QkFDckIsT0FBTyxFQUFFLEtBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQSxJQUFJLElBQUksUUFBQyxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBQyxDQUFDLEdBQUcsT0FBTyxHQUFHLEtBQUs7cUJBQ3RJO29CQUNELElBQUksQ0FBQyxLQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFVBQVUsR0FBQSxDQUFDLEVBQUU7d0JBQzdELEtBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO3FCQUM3Qjt5QkFBTTs7NEJBQ0MsQ0FBQyxHQUFHLEtBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsVUFBVSxHQUFBLENBQUM7d0JBQ3ZFLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFBLElBQUksSUFBSSxRQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFDLENBQUMsR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDO3FCQUNqSztpQkFDRixDQUFDLENBQUE7OztvQkFHSSxhQUFhLEdBQUcsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO29CQUM3QixJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7d0JBQ2hCLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7cUJBQ3pDO2lCQUNGLENBQUMsQ0FBQTtnQkFDRixJQUFJLENBQUMsMkJBQTJCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQzdFOzs7OztRQUVELGlEQUFnQjs7OztZQUFoQixVQUFpQixJQUFJO2dCQUNuQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxHQUFBLENBQUMsRUFBRTs7d0JBQzVFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxHQUFBLENBQUM7b0JBQzVELElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNyRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQ3BDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO3FCQUM5QjtpQkFDRjtxQkFBTTs7d0JBQ0QsR0FBRyxHQUFHO3dCQUNSLElBQUksRUFBRSxJQUFJO3dCQUNWLE9BQU8sRUFBRSxJQUFJO3FCQUNkO29CQUNELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2lCQUM3Qjs7O29CQUdLLGFBQWEsR0FBRyxFQUFFO2dCQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQzdCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTt3QkFDaEIsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztxQkFDekM7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDN0U7Ozs7O1FBRUQsMERBQXlCOzs7O1lBQXpCLFVBQTBCLFdBQVc7O29CQUM3QixhQUFhLEdBQUcsRUFBRTtnQkFDeEIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7b0JBQ3RCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTt3QkFDaEIsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztxQkFDekM7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDN0U7Ozs7O1FBRUQsaURBQWdCOzs7O1lBQWhCLFVBQWlCLENBQVE7Z0JBQ3ZCLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3pEOzs7O1FBRUQsZ0RBQWU7OztZQUFmO2dCQUNFLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQzthQUNsRDs7b0JBM2FGbkMsWUFBUyxTQUFDO3dCQUNULFFBQVEsRUFBRSxvQkFBb0I7d0JBQzlCLFFBQVEsRUFBRSw4eUNBcUNMO3dCQUNMLE1BQU0sRUFBRSxDQUFDLGdnVkFBMC9VLEVBQUUsNElBQTRJLENBQUM7d0JBQ2xwVixhQUFhLEVBQUVDLG9CQUFpQixDQUFDLElBQUk7cUJBQ3RDOzs7O3dCQXpEQ1Esb0JBQWlCO3dCQUtWLFVBQVU7d0JBRHVCMkIsb0JBQVc7d0JBQXZCakIsbUJBQVU7d0JBRS9CLGdCQUFnQjt3QkFFaEJPLGtCQUFTO3dCQVBoQkMsbUJBQWdCO3dCQVNULGdDQUFnQzt3QkFIaEMsa0JBQWtCO3dCQUtsQixzQkFBc0I7OztRQWdiL0IsNkJBQUM7S0FBQSxDQWxZMkNQLDRCQUFtQjs7Ozs7O0FDOUQvRDtRQXFHRSxzQkFDVSxXQUF3QjtZQUF4QixnQkFBVyxHQUFYLFdBQVcsQ0FBYTtZQUZsQyxnQkFBVyxHQUFhLENBQUMsMEJBQTBCLEVBQUMsd0JBQXdCLENBQUMsQ0FBQztZQUs1RSxXQUFXLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLHNCQUFzQixDQUFDLENBQUM7WUFDbkUsV0FBVyxDQUFDLGlCQUFpQixDQUFDLGVBQWUsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3ZFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUscUJBQXFCLENBQUMsQ0FBQztZQUNyRSxXQUFXLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztZQUMzRSxXQUFXLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLEVBQUUsNEJBQTRCLENBQUMsQ0FBQztZQUtuRixXQUFXLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFFLGtCQUFrQixFQUMxRDtnQkFDRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRTtnQkFDOUYsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7YUFDbkcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FDOUMsQ0FBQTtZQUVELFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsZUFBZSxFQUN2RDtnQkFDRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFOztnQkFFcEcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7YUFDbEcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLFdBQVcsQ0FDN0MsQ0FBQTtTQUVGOzs7OztRQXhDTSxvQkFBTzs7OztZQUFkLFVBQWUsV0FBZ0I7Z0JBQzdCLE9BQU87b0JBQ0wsUUFBUSxFQUFHLFlBQVk7b0JBQ3ZCLFNBQVMsRUFBQzt3QkFDUjs0QkFDRSxPQUFPLEVBQUUsS0FBSzs0QkFDZCxRQUFRLEVBQUUsV0FBVzt5QkFDdEI7cUJBQ0Y7aUJBQ0YsQ0FBQTthQUNGOztvQkFuRUZpQixXQUFRLFNBQUM7d0JBQ1IsT0FBTyxFQUFFOzRCQUNQQyxvQ0FBdUI7NEJBQ3ZCQyx3QkFBZTs0QkFDZkMsMEJBQWlCOzRCQUNqQkMsdUJBQWM7NEJBQ2RDLGdDQUFhLENBQUMsY0FBYyxDQUFDO2dDQUMzQixzQkFBc0I7Z0NBQ3RCLHNCQUFzQjtnQ0FDdEIscUJBQXFCO2dDQUNyQix3QkFBd0I7Z0NBQ3hCLDRCQUE0Qjs2QkFDM0IsQ0FBQzs0QkFDSkMsK0JBQWtCOzRCQUNsQkMseUJBQWU7NEJBQ2ZDLG9CQUFjOzRCQUNkQyxzQkFBYTs0QkFDYkMsbUJBQWdCOzRCQUNoQkMsc0JBQWU7NEJBQ2ZDLGtCQUFhOzRCQUNiQyxpQ0FBa0I7eUJBQ25CO3dCQUNELFlBQVksRUFBRTs0QkFDWixzQkFBc0I7NEJBQ3RCLGtCQUFrQjs0QkFDbEIscUJBQXFCOzRCQUNyQixxQkFBcUI7NEJBQ3JCLGlCQUFpQjs0QkFDakIsaUJBQWlCOzRCQUNqQix5QkFBeUI7NEJBQ3pCLHFCQUFxQjs0QkFDckIsd0JBQXdCOzRCQUN4QixnQkFBZ0I7NEJBQ2hCLDRCQUE0Qjs0QkFDNUIsd0JBQXdCOzRCQUN4Qix3QkFBd0I7NEJBQ3hCLHNCQUFzQjt5QkFDdkI7d0JBQ0QsU0FBUyxFQUFDLENBQUN4QyxlQUFRLEVBQUUwQixvQkFBVyxDQUFDO3dCQUNqQyxPQUFPLEVBQUU7NEJBQ1Asc0JBQXNCOzRCQUN0QixxQkFBcUI7NEJBQ3JCLHdCQUF3Qjs0QkFDeEIsNEJBQTRCOzRCQUM1QixzQkFBc0I7eUJBQ3ZCO3dCQUNELGVBQWUsRUFBRTs0QkFDZixzQkFBc0I7NEJBQ3RCLHFCQUFxQjs0QkFDckIseUJBQXlCOzRCQUN6QixxQkFBcUI7NEJBQ3JCLHdCQUF3Qjs0QkFDeEIsNEJBQTRCOzRCQUM1QixzQkFBc0I7eUJBQ3JCO3FCQUNKOzs7O3dCQXRGUUEsb0JBQVc7OztRQWtJcEIsbUJBQUM7S0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=