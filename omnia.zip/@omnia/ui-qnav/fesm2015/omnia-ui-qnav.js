import { Injectable, EventEmitter, Pipe, Component, Inject, Input, Output, ViewEncapsulation, ChangeDetectionStrategy, ContentChild, ElementRef, NgZone, ChangeDetectorRef, HostListener, ViewContainerRef, NgModule, ViewChild, defineInjectable, inject } from '@angular/core';
import _ from 'lodash';
import { trigger, style, animate, transition } from '@angular/animations';
import { DatePipe, formatDate, formatNumber } from '@angular/common';
import { scaleLinear, scaleTime, scalePoint } from 'd3-scale';
import { curveLinear } from 'd3-shape';
import { id } from '@swimlane/ngx-charts/release/utils';
import { getUniqueXDomainValues } from '@swimlane/ngx-charts/release/common/domain.helper';
import { calculateViewDimensions, BaseChartComponent, ColorHelper, NgxChartsModule } from '@swimlane/ngx-charts';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { webSocket } from 'rxjs/webSocket';
import { BaseWidgetComponent, AppContext, AppRegistry, UiCommonModule } from '@omnia/ui-common';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';
import { treemap, stratify } from 'd3-hierarchy';
import { DynamicModule } from 'ng-dynamic-component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ClickOutsideModule } from 'ng-click-outside';
import { MatDialogModule } from '@angular/material/dialog';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class ShareInfoBeweenComponentsService {
    constructor() {
        this.fundInfo = [];
        this.variableFundList = [];
        this.colorSchema = [];
        this.highLightActiveEntries = new EventEmitter();
        this.clickedOutSide = new EventEmitter();
        // data-table components data communication
        this.hyperLinkNavigate = new EventEmitter();
        this.openModalData = new EventEmitter();
        this.sortDatatableColumn = new EventEmitter();
    }
    /**
     * @param {?} fundInfo
     * @return {?}
     */
    savePositionDetailsFundInfo(fundInfo) {
        this.fundInfo = fundInfo;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    setVariableFundList(data) {
        this.variableFundList = data;
    }
    /**
     * @param {?} colorSchema
     * @return {?}
     */
    setColorSchema(colorSchema) {
        this.colorSchema = colorSchema;
    }
    /**
     * @return {?}
     */
    getFundList() {
        return this.variableFundList;
    }
    /**
     * @return {?}
     */
    reset() {
        this.fundInfo = [];
        this.variableFundList = [];
        this.colorSchema = [];
        this.highLightActiveEntries = new EventEmitter();
        this.hyperLinkNavigate = new EventEmitter();
        this.openModalData = new EventEmitter();
        this.sortDatatableColumn = new EventEmitter();
    }
}
ShareInfoBeweenComponentsService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
ShareInfoBeweenComponentsService.ctorParameters = () => [];
/** @nocollapse */ ShareInfoBeweenComponentsService.ngInjectableDef = defineInjectable({ factory: function ShareInfoBeweenComponentsService_Factory() { return new ShareInfoBeweenComponentsService(); }, token: ShareInfoBeweenComponentsService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CommonUtilsService {
    /**
     * @param {?} shareInforBewteenComponents
     */
    constructor(shareInforBewteenComponents) {
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.startTime = new Date();
        this.endTime = new Date();
        this.timeDivision = new Date();
        this.liveTime = new Date();
        this.isAfterMarketClose = false;
        this.startTime.setHours(9, 30, 0, 0);
        this.endTime.setHours(16, 30, 0, 0);
        this.timeDivision.setHours(15, 30, 0, 0);
        /** @type {?} */
        let instance = setInterval(() => {
            if (new Date() < this.endTime) {
                this.liveTime = new Date();
            }
            else {
                this.liveTime = this.endTime;
                clearInterval(instance);
            }
        }, 1000);
        this.isAfterMarketClose = this.isAfterMarketColse(this.liveTime);
    }
    /**
     * @param {?} time
     * @return {?}
     */
    isAfterMarketColse(time) {
        if (time <= this.endTime) {
            return false;
        }
        return true;
    }
    /**
     * @param {?} time
     * @return {?}
     */
    isBeforeMarketOpen(time) {
        if (time >= this.startTime) {
            return false;
        }
        return true;
    }
    /**
     * @param {?} time
     * @return {?}
     */
    isValidTime(time) {
        if (time >= this.startTime && time <= this.endTime) {
            return true;
        }
        return false;
    }
    /**
     * @param {?} time
     * @return {?}
     */
    isBeyondDivision(time) {
        if (time >= this.timeDivision) {
            return true;
        }
        return false;
    }
    /**
     * @return {?}
     */
    getRandomColor() {
        /** @type {?} */
        const letters = '0123456789ABCDEF';
        /** @type {?} */
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
    /**
     * @param {?} fundid
     * @return {?}
     */
    getColorForFund(fundid) {
        this.resetColorForFund(fundid);
        for (let item of this.shareInforBewteenComponents.colorSchema) {
            if (item['fundid'] === undefined) {
                item['fundid'] = fundid;
                return item['color'];
            }
        }
        return this.getRandomColor();
    }
    /**
     * @param {?} fundid
     * @return {?}
     */
    resetColorForFund(fundid) {
        for (let item of this.shareInforBewteenComponents.colorSchema) {
            if (item['fundid'] === fundid) {
                item['fundid'] = undefined;
            }
        }
    }
    /**
     * @param {?} fundid
     * @param {?} isChecked
     * @return {?}
     */
    updateFundStatus(fundid, isChecked) {
        /** @type {?} */
        const index = this.shareInforBewteenComponents.getFundList().findIndex(element => element.fundID === fundid);
        if (isChecked === this.shareInforBewteenComponents.getFundList()[index]['checked']) {
            return;
        }
        this.shareInforBewteenComponents.getFundList()[index]['checked'] = isChecked;
        //remove the color for the fund as well
        if (isChecked === false) {
            this.resetColorForFund(fundid);
        }
        else {
            this.getColorForFund(fundid);
        }
    }
    /**
     * @param {?} time
     * @return {?}
     */
    formatTime(time) {
        /** @type {?} */
        let t = new Date(time);
        /** @type {?} */
        let second = '00';
        if (t.getSeconds() <= 20) {
            second = '00';
        }
        else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
            second = '20';
        }
        else {
            second = '40';
        }
        return ("0" + t.getHours()).slice(-2) + ':' + ("0" + t.getMinutes()).slice(-2) + ':' + second;
    }
    /**
     * @param {?} time
     * @return {?}
     */
    formatDateTime(time) {
        /** @type {?} */
        let t = new Date(time);
        if (t.getSeconds() <= 20) {
            t.setSeconds(0);
            t.setMilliseconds(0);
        }
        else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
            t.setSeconds(20);
            t.setMilliseconds(0);
        }
        else {
            t.setSeconds(40);
            t.setMilliseconds(0);
        }
        return t;
    }
    //rest component shared information if login user/authorized token changed
    /**
     * @return {?}
     */
    validateUser() {
        if (this.shareInforBewteenComponents.accessToken) {
            if (sessionStorage.getItem('access_token') === this.shareInforBewteenComponents.accessToken) {
                return true;
            }
        }
        this.shareInforBewteenComponents.reset();
        this.shareInforBewteenComponents.accessToken = sessionStorage.getItem('access_token');
        return false;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    extractFundLevelData(data) {
        /** @type {?} */
        const fundLevelData = ((/** @type {?} */ (data))).map(d => {
            /** @type {?} */
            const rowTemp = {
                //fundid: d.fundid,
                fundid: d.fundid,
                maskedId: d.maskedId,
                name: d.name,
                classID: "A",
                child: "parent",
            };
            /** @type {?} */
            const multiClassData = d.classLevelTrialData;
            /** @type {?} */
            const row = Object.assign(rowTemp, multiClassData.A);
            return row;
        });
        return fundLevelData;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    extractClassLevelData(data) {
        /** @type {?} */
        const classLevelData = [];
        ((/** @type {?} */ (data))).forEach(d => {
            /** @type {?} */
            const rowTemp = {
                //fundid: d.fundid,
                fundid: d.fundid,
                maskedId: d.maskedId,
                name: d.name,
                child: "child",
            };
            /** @type {?} */
            const multiClassData = d.classLevelTrialData;
            for (let key in multiClassData) {
                if (key !== "A") {
                    /** @type {?} */
                    const childRow = Object.assign(rowTemp, multiClassData[key], { classID: key });
                    classLevelData.push(_.cloneDeep(childRow));
                }
            }
        });
        return classLevelData.reverse();
    }
    /**
     * @param {?} data
     * @param {?} childOrNot
     * @return {?}
     */
    extractWSData(data, childOrNot) {
        /** @type {?} */
        let returnData = [];
        /** @type {?} */
        const temp = {
            cusip: data.cusip,
            exchangeRate: data.exchangeRate,
            //fundid: data.fundid,
            fundid: data.fundid,
            longShortIndicator: data.longShortIndicator,
            mv: data.mv,
            mvChange: data.mvChange,
            navImpact: data.navImpact,
            price: data.price,
            priceChangePercent: data.priceChangePercent,
            sodMv: data.sodMv,
            sodPrice: data.sodPrice,
            updatetime: data.updatetime
        };
        if (childOrNot) {
            for (let key in data) {
                if (Number(key)) {
                    /** @type {?} */
                    const row = Object.assign(temp, data[key], { classID: key });
                    returnData.push(_.cloneDeep(row));
                }
            }
        }
        else {
            returnData = data["A"];
            returnData = Object.assign(temp, returnData, { classID: "A" });
        }
        return returnData;
    }
    /**
     * @param {?} rows
     * @param {?} childRows
     * @param {?} expandCollapseIconMap
     * @param {?} prop
     * @param {?} ascFlag
     * @return {?}
     */
    sortColumnByProp(rows, childRows, expandCollapseIconMap, prop, ascFlag) {
        /** @type {?} */
        const pRows = [];
        rows.forEach(item => {
            if (item.classID === "A")
                pRows.push(item);
            if (childRows.length === 0)
                pRows.push(item);
        });
        ascFlag ? pRows.sort(this.sortCompareAsc(prop)) : pRows.sort(this.sortCompareDesc(prop));
        childRows.forEach(item => {
            /** @type {?} */
            const fundid = item.fundid;
            expandCollapseIconMap.forEach(expandItem => {
                if (expandItem.fundid === fundid && expandItem.expand) {
                    /** @type {?} */
                    const index = pRows.findIndex(pitem => { return pitem.fundid === fundid; });
                    pRows.splice(index + 1, 0, item);
                }
            });
        });
        return pRows;
    }
    /**
     * @param {?} prop
     * @return {?}
     */
    sortCompareAsc(prop) {
        return function (obj1, obj2) {
            /** @type {?} */
            let v1 = obj1[prop];
            /** @type {?} */
            let v2 = obj2[prop];
            if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
                v1 = Number(v1);
                v2 = Number(v2);
            }
            if (v1 === undefined || v1 < v2) {
                return -1;
            }
            else if (v2 === undefined || v1 > v2) {
                return 1;
            }
            else {
                return 0;
            }
        };
    }
    /**
     * @param {?} prop
     * @return {?}
     */
    sortCompareDesc(prop) {
        return function (obj1, obj2) {
            /** @type {?} */
            let v1 = obj1[prop];
            /** @type {?} */
            let v2 = obj2[prop];
            if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
                v1 = Number(v1);
                v2 = Number(v2);
            }
            if (v1 === undefined || v1 < v2) {
                return 1;
            }
            else if (v2 === undefined || v1 > v2) {
                return -1;
            }
            else {
                return 0;
            }
        };
    }
}
CommonUtilsService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
CommonUtilsService.ctorParameters = () => [
    { type: ShareInfoBeweenComponentsService }
];
/** @nocollapse */ CommonUtilsService.ngInjectableDef = defineInjectable({ factory: function CommonUtilsService_Factory() { return new CommonUtilsService(inject(ShareInfoBeweenComponentsService)); }, token: CommonUtilsService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class LineChartComponent extends BaseChartComponent {
    /**
     * @param {?} chartElement
     * @param {?} zone
     * @param {?} cd
     * @param {?} commonUtils
     * @param {?} datePipe
     */
    constructor(chartElement, zone, cd, commonUtils, datePipe) {
        super(chartElement, zone, cd);
        this.commonUtils = commonUtils;
        this.datePipe = datePipe;
        this.legendTitle = 'Legend';
        this.showGridLines = true;
        this.curve = curveLinear;
        this.roundDomains = false;
        this.tooltipDisabled = false;
        this.showRefLines = false; // if don't show grid line in x-axis level we can use refLine to customize x-axis level lines..
        this.referenceLines = []; //[{ value: 0.1, name: 'Maximum' }, { value: 0.0, name: 'Average' }, { value: -0.1, name: 'Minimum' }];
        this.showRefLabels = false;
        this.colorDomain = [];
        this.circleData = [];
        this.tickValues = [];
        this.activeEntries = [];
        this.highLightActiveEntries = [];
        this.activate = new EventEmitter();
        this.deactivate = new EventEmitter();
        this.xAxisHeight = 0;
        this.yAxisWidth = 0;
        this.timelineHeight = 50;
        this.timelinePadding = 10;
        this.circleRadius = 5;
        this.tooltipObj = {};
        this.showAlertDetailsMap = [];
    }
    /**
     * @return {?}
     */
    update() {
        this.dims = calculateViewDimensions({
            width: this.width,
            height: this.height,
            margins: this.margin,
            xAxisHeight: this.xAxisHeight,
            yAxisWidth: this.yAxisWidth,
            showXLabel: this.showXAxisLabel,
            showYLabel: this.showYAxisLabel,
            showLegend: this.legend,
            legendType: this.schemeType,
        });
        if (this.timeline) {
            this.dims.height -= (this.timelineHeight + this.margin[2] + this.timelinePadding);
        }
        this.xDomain = this.getXDomain();
        if (this.filteredDomain) {
            this.xDomain = this.filteredDomain;
        }
        this.yDomain = this.getYDomain();
        this.seriesDomain = this.getSeriesDomain();
        this.xScale = this.getXScale(this.xDomain, this.dims.width);
        this.yScale = this.getYScale(this.yDomain, this.dims.height);
        this.customColors = this.setCustomcolors();
        this.setColors();
        this.legendOptions = this.getLegendOptions();
        this.transform = `translate(${this.dims.xOffset} , ${this.margin[0]})`;
        this.clipPathId = 'clip' + id().toString();
        this.clipPath = `url(#${this.clipPathId})`;
        //map circle
        this.circleSeries = this.mapCircle(this.circleData);
        this.lastDataX = this.xScale(this.currentLineTime);
    }
    /**
     * @param {?} circleData
     * @return {?}
     */
    mapCircle(circleData) {
        /** @type {?} */
        let xscale = this.xScale;
        /** @type {?} */
        let yscale = this.yScale;
        /** @type {?} */
        let arr = [];
        circleData.forEach((item, index) => {
            /** @type {?} */
            let obj = {
                x: xscale(item.x),
                time: this.datePipe.transform(item.pricetime, "hh:mm:ss aaaaa'm'"),
                value: yscale(item.value),
                name: item.name,
                fill: item.alertType == 1 ? ['#ffbc06'] : ['#b91224'],
                alertType: item.alertType,
                navChange: item.value,
                mvChange: item.fundmvChangePercent,
                pricetime: item.pricetime,
            };
            arr.push(obj);
        });
        return arr;
    }
    /**
     * @return {?}
     */
    setCustomcolors() {
        /** @type {?} */
        let arr = [];
        this.results.forEach(item => {
            this.colorDomain.forEach(color => {
                if (item['name'] === color['fundid']) {
                    /** @type {?} */
                    let obj = {
                        name: color.fundid,
                        value: color.color
                    };
                    arr.push(obj);
                }
            });
        });
        return arr;
    }
    /**
     * @return {?}
     */
    getXDomain() {
        /** @type {?} */
        let values = getUniqueXDomainValues(this.results);
        this.scaleType = this.getScaleType(values);
        /** @type {?} */
        let domain = [];
        if (this.scaleType === 'linear') {
            values = values.map(v => Number(v));
        }
        /** @type {?} */
        let min;
        /** @type {?} */
        let max;
        if (this.scaleType === 'time' || this.scaleType === 'linear') {
            min = this.xScaleMin
                ? this.xScaleMin
                : Math.min(...values);
            max = this.xScaleMax
                ? this.xScaleMax
                : Math.max(...values);
        }
        if (this.scaleType === 'time') {
            domain = [new Date(min), new Date(max)];
            this.xSet = [...values].sort((a, b) => {
                /** @type {?} */
                const aDate = a.getTime();
                /** @type {?} */
                const bDate = b.getTime();
                if (aDate > bDate)
                    return 1;
                if (bDate > aDate)
                    return -1;
                return 0;
            });
        }
        else if (this.scaleType === 'linear') {
            domain = [min, max];
            // Use compare function to sort numbers numerically
            this.xSet = [...values].sort((a, b) => (a - b));
        }
        else {
            domain = values;
            this.xSet = values;
        }
        return domain;
    }
    /**
     * @return {?}
     */
    getYDomain() {
        /** @type {?} */
        const domain = [];
        for (const results of this.results) {
            for (const d of results.series) {
                if (d.value && domain.indexOf(d.value) < 0) {
                    domain.push(d.value);
                }
                if (d.min !== undefined) {
                    this.hasRange = true;
                    if (domain.indexOf(d.min) < 0) {
                        domain.push(d.min);
                    }
                }
                if (d.max !== undefined) {
                    this.hasRange = true;
                    if (domain.indexOf(d.max) < 0) {
                        domain.push(d.max);
                    }
                }
            }
        }
        /** @type {?} */
        const values = [...domain];
        if (!this.autoScale) {
            values.push(0);
        }
        /** @type {?} */
        const min = this.yScaleMin
            ? this.yScaleMin
            : Math.min(...values);
        /** @type {?} */
        const max = this.yScaleMax
            ? this.yScaleMax
            : Math.max(...values);
        if (min !== undefined && max !== undefined) {
            return [min, max];
        }
        else {
            return [-0.1, 0.1];
        }
    }
    /**
     * @return {?}
     */
    getSeriesDomain() {
        return this.results.map(d => d.name);
    }
    /**
     * @param {?} domain
     * @param {?} width
     * @return {?}
     */
    getXScale(domain, width) {
        /** @type {?} */
        let scale;
        if (this.scaleType === 'time') {
            scale = scaleTime()
                .range([0, width])
                .domain(domain);
        }
        else if (this.scaleType === 'linear') {
            scale = scaleLinear()
                .range([0, width])
                .domain(domain);
            if (this.roundDomains) {
                scale = scale.nice();
            }
        }
        else if (this.scaleType === 'ordinal') {
            scale = scalePoint()
                .range([0, width])
                .padding(0.1)
                .domain(domain);
        }
        return scale;
    }
    /**
     * @param {?} domain
     * @param {?} height
     * @return {?}
     */
    getYScale(domain, height) {
        /** @type {?} */
        const scale = scaleLinear()
            .range([height, 0])
            .domain(domain);
        return this.roundDomains ? scale.nice() : scale;
    }
    /**
     * @param {?} values
     * @return {?}
     */
    getScaleType(values) {
        /** @type {?} */
        let date = true;
        /** @type {?} */
        let num = true;
        for (const value of values) {
            if (!this.isDate(value)) {
                date = false;
            }
            if (typeof value !== 'number') {
                num = false;
            }
        }
        if (date)
            return 'time';
        if (num)
            return 'linear';
        return 'ordinal';
    }
    /**
     * @param {?} value
     * @return {?}
     */
    isDate(value) {
        if (value instanceof Date) {
            return true;
        }
        return false;
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    updateYAxisWidth({ width }) {
        this.yAxisWidth = width;
        this.update();
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    updateXAxisHeight({ height }) {
        this.xAxisHeight = height;
        this.update();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    updateHoveredVertical(item) {
        this.tooltipObj = Object.assign(this.tooltipObj, item);
        this.hoveredVertical = item.value;
        this.deactivateAll();
    }
    /**
     * @return {?}
     */
    hideCircles() {
        this.hoveredVertical = null;
        this.deactivateAll();
        this.activeEntries = this.highLightActiveEntries;
    }
    /**
     * @param {?} series
     * @return {?}
     */
    onMouseEnter(series) {
        this.activate.emit(series);
    }
    /**
     * @param {?} series
     * @return {?}
     */
    onMouseLeave(series) {
        this.deactivate.emit(series);
    }
    /**
     * @param {?} data
     * @param {?=} series
     * @return {?}
     */
    onClick(data, series) {
        if (series) {
            data.series = series.name;
        }
        this.select.emit(data);
    }
    /**
     * @param {?} index
     * @param {?} item
     * @return {?}
     */
    trackBy(index, item) {
        return item.name;
    }
    /**
     * @return {?}
     */
    setColors() {
        /** @type {?} */
        let domain;
        if (this.schemeType === 'ordinal') {
            domain = this.seriesDomain;
        }
        else {
            domain = this.yDomain;
        }
        this.colors = new ColorHelper(this.scheme, this.schemeType, domain, this.customColors);
    }
    /**
     * @return {?}
     */
    getLegendOptions() {
        /** @type {?} */
        const opts = {
            scaleType: this.schemeType,
            colors: undefined,
            domain: [],
            title: undefined
        };
        if (opts.scaleType === 'ordinal') {
            opts.domain = this.seriesDomain;
            opts.colors = this.colors;
            opts.title = this.legendTitle;
        }
        else {
            opts.domain = this.yDomain;
            opts.colors = this.colors.scale;
        }
        return opts;
    }
    /**
     * @param {?} item
     * @return {?}
     */
    onActivate(item) {
        this.deactivateAll();
        /** @type {?} */
        const idx = this.activeEntries.findIndex(d => {
            return d.name === item.name && d.value === item.value;
        });
        if (idx > -1) {
            return;
        }
        this.activeEntries = [item];
        this.activate.emit({ value: item, entries: this.activeEntries });
        this.tooltipObj = Object.assign(this.tooltipObj, item);
        this.findOtherProperty();
        this.setCustomClass();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    onDeactivate(item) {
        /** @type {?} */
        const idx = this.activeEntries.findIndex(d => {
            return d.name === item.name && d.value === item.value;
        });
        this.activeEntries.splice(idx, 1);
        this.activeEntries = [...this.activeEntries];
        this.deactivate.emit({ value: item, entries: this.activeEntries });
    }
    /**
     * @return {?}
     */
    deactivateAll() {
        this.activeEntries = [...this.activeEntries];
        for (const entry of this.activeEntries) {
            this.deactivate.emit({ value: entry, entries: [] });
        }
        this.activeEntries = [];
    }
    /**
     * @return {?}
     */
    setCustomClass() {
        /** @type {?} */
        let alertType = this.tooltipObj["alertType"];
        if (alertType) {
            if (alertType == 1) {
                this.customTooltipClass = 'alert1';
            }
            else {
                this.customTooltipClass = 'alert2';
            }
        }
    }
    /**
     * @return {?}
     */
    findOtherProperty() {
        /** @type {?} */
        let arr = this.results;
        /** @type {?} */
        let fundName = this.tooltipObj["name"];
        /** @type {?} */
        let timeName = this.tooltipObj["value"];
        /** @type {?} */
        let findSeries = {};
        /** @type {?} */
        let obj;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i]["name"] === fundName) {
                findSeries = Object.assign(findSeries, arr[i]);
                break;
            }
        }
        /** @type {?} */
        let series = findSeries["series"];
        for (var j = 0; j < series.length; j++) {
            if (series[j]["name"] === timeName) {
                obj = {
                    "nav": series[j]["nav"],
                    "marketval": series[j]["marketval"]
                };
                this.tooltipObj = Object.assign(this.tooltipObj, obj);
                break;
            }
        }
    }
    // below is for custom alert details rect logic
    /**
     * @param {?} data
     * @return {?}
     */
    onClickAlertCircle(data) {
        if (data) {
            /** @type {?} */
            let alreadyInShowMap = false;
            this.showAlertDetailsMap.forEach(item => {
                if (data.x === item.x && data.name === item.name) {
                    alreadyInShowMap = true;
                    item.show = !item.show;
                }
                else {
                    item.show = false;
                }
            });
            if (!alreadyInShowMap) {
                /** @type {?} */
                let obj = {
                    x: data.x,
                    name: data.name,
                    show: data['show'] ? !data['show'] : true
                };
                this.showAlertDetailsMap.push(obj);
            }
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    getShowAlertDetails(data) {
        /** @type {?} */
        let showOrNot = false;
        this.showAlertDetailsMap.forEach(item => {
            if (data.x === item.x && data.name === item.name) {
                showOrNot = item.show;
            }
        });
        return showOrNot;
    }
    /**
     * @param {?} circle
     * @return {?}
     */
    getRectLoactionX(circle) {
        /** @type {?} */
        let xLocation = 0;
        if (this.commonUtils.isBeyondDivision(new Date(circle.pricetime))) {
            xLocation = circle.x - 220;
        }
        else {
            xLocation = circle.x + 10;
        }
        return xLocation;
    }
    /**
     * @param {?} circle
     * @return {?}
     */
    getRectLoactionY(circle) {
        /** @type {?} */
        let yLocation = 0;
        if (circle.navChange >= 0) {
            yLocation = circle.value + 10;
        }
        else {
            yLocation = circle.value - 110;
        }
        return yLocation;
    }
}
LineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-fine-line-chart',
                template: `<div class="custom-chart">
  <ngx-charts-chart 
      [view]="[width, height]"
      [showLegend]="false"
      [legendOptions]="legendOptions"
      [activeEntries]="activeEntries"
      [animations]="animations"
      (legendLabelClick)="onClick($event)"
      (legendLabelActivate)="onActivate($event)"
      (legendLabelDeactivate)="onDeactivate($event)">
      <svg:defs>
        <svg:clipPath [attr.id]="clipPathId">
          <svg:rect
            [attr.width]="dims.width + 10"
            [attr.height]="dims.height + 10"
            [attr.transform]="'translate(-5, -5)'"/>
        </svg:clipPath>
      </svg:defs>
      <svg:g [attr.transform]="transform" class="line-chart chart">
        <svg:g ngx-charts-x-axis 
          [xScale]="xScale"
          [dims]="dims"
          [showLabel]="showXAxisLabel"
          [showGridLines]="showGridLines"
          [labelText]="xAxisLabel"
          [ticks]="tickValues"
          [tickFormatting]="xAxisTickFormatting"
          (dimensionsChanged)="updateXAxisHeight($event)">
        </svg:g>
        <svg:g ngx-charts-y-axis
          [yScale]="yScale"
          [dims]="dims"
          [showLabel]="showYAxisLabel"
          [labelText]="yAxisLabel"
          [referenceLines]="referenceLines"
          [showRefLines]="showRefLines"
          [showGridLines]="showGridLines"
          [showRefLabels]="showRefLabels"
          (dimensionsChanged)="updateYAxisWidth($event)">
        </svg:g>
        <svg:line
        [attr.x1]="lastDataX"
        [attr.y1]="0"
        [attr.x2]="lastDataX"
        [attr.y2]="height"
        [attr.class]="'end-line'"
      />
      <svg:foreignObject
        [attr.x]="lastDataX - 40"
        [attr.y]="height - 15"
        [attr.width]="80 + 'px'"
        [attr.height]="30 + 'px'"
        [style.pointer-events]="'none'">
        <xhtml:div
          class='last-time'
          [style.width]="80 + 'px'"
          [style.height]="20 + 'px'"
          >
          <xhtml:span> {{displayLiveTime | date: "h:mm:ss aaaaa'm'"}}
          </xhtml:span>
        </xhtml:div>
      </svg:foreignObject>
        <svg:g [attr.clip-path]="clipPath">
          <svg:g *ngFor="let series of results; trackBy:trackBy" [@animationState]="'active'">
            <svg:g ngx-charts-line-series
              [xScale]="xScale"
              [yScale]="yScale"
              [colors]="colors"
              [data]="series"
              [activeEntries]="activeEntries"
              [scaleType]="scaleType"
              [curve]="curve"
              [rangeFillOpacity]="rangeFillOpacity"
              [hasRange]="hasRange"
              [animations]="animations"
            />
          </svg:g>
          <svg:g *ngIf="!tooltipDisabled" (mouseleave)="hideCircles()">
            <svg:g ngx-charts-tooltip-area
              [dims]="dims"
              [xSet]="xSet"
              [xScale]="xScale"
              [yScale]="yScale"
              [results]="results"
              [colors]="colors"
              [tooltipDisabled]="!tooltipDisabled"
              (hover)="updateHoveredVertical($event)"
            />
          
            <svg:g *ngFor="let series of results">
              <svg:g ngx-charts-circle-series
                [xScale]="xScale"
                [yScale]="yScale"
                [colors]="colors"
                [data]="series"
                [scaleType]="scaleType"
                [visibleValue]="hoveredVertical"
                [activeEntries]="activeEntries"
                (select)="onClick($event, series)"
                (activate)="onActivate($event)"
                (deactivate)="onDeactivate($event)"
                [tooltipTemplate]="tooltipTemplate"
              />
            </svg:g>
            
            <svg:g *ngFor="let circle of circleSeries">
                <svg:g ngx-charts-circle
                  [cx]="circle.x"
                  [cy]="circle.value"
                  [r]="circleRadius"
                  [data]="circle"
                  [fill]="circle.fill"
                  (select)="onClickAlertCircle($event)"
                />
            </svg:g>
          </svg:g>
        </svg:g>
        <svg:g *ngFor="let circle of circleSeries">
            <svg:foreignObject
                  *ngIf="getShowAlertDetails(circle)"
                  [attr.x]="getRectLoactionX(circle)"
                  [attr.y]="getRectLoactionY(circle)"
                  [attr.width]="210 + 'px'"
                  [attr.height]="140 + 'px'"
                  [style.pointer-events]="'none'">
                    <xhtml:div
                      class='alert-details-sty'
                      [style.border-color]="circle.fill"
                      >
                      <xhtml:span> {{circle.name}}
                      </xhtml:span>
                      <xhtml:span> {{circle.time}}
                      </xhtml:span>
                       <xhtml:label> 
                          NAV diverging from market value
                      </xhtml:label>
                      <xhtml:table>
                        <xhtml:tr>NAV Change:<xhtml:td>{{circle.navChange | percent: '1.2-2'}}</xhtml:td>
                        </xhtml:tr>
                        <xhtml:tr>MV Change:<xhtml:td>{{circle.mvChange | percent: '1.2-2'}}</xhtml:td>
                        </xhtml:tr>
                      </xhtml:table>
                    </xhtml:div>
                </svg:foreignObject>
        </svg:g>
      </svg:g>
  </ngx-charts-chart>
  <ng-template #tooltipTemplate>
      <div class="line-tooltip">
          <div class="top">
              <span class="fund-name">{{tooltipObj.name}} </span>
              <span> - </span>
              <span class="time">{{tooltipObj.value | date: "h:mm:ss aaaaa'm'"}}</span>
          </div>
          <table>
            <tr align='right'>NAV<td>{{tooltipObj.nav | number: '1.2-2'}}</td></tr>
            <tr align='right'>MV Amt Base<td>{{tooltipObj.marketval | number: '1.2-2'}}</td></tr>
          </table>
      </div>
  </ng-template>
</div>`,
                styles: [`.custom-chart{position:relative}.custom-chart .custom-tooltip{background-color:#ddd;border:2px solid grey;position:absolute;z-index:99}.custom-chart .custom-tooltip table{border-spacing:0;border-collapse:collapse;width:100%}.custom-chart .ngx-charts{float:left;overflow:visible}.custom-chart .ngx-charts .custom-axis-line{stroke:#eee;stroke-width:2}.custom-chart .ngx-charts .end-line{stroke:#6c757d;stroke-width:1}.custom-chart .ngx-charts .last-time{background-color:#eee;box-shadow:0 0 2px 0 rgba(0,0,0,.15);display:flex;justify-content:center;align-items:center;font-weight:700;font-size:14px;border-radius:5px}.custom-chart .ngx-charts .alert-details-sty{color:#6c757d;border:2px solid;background-color:rgba(255,255,255,.9);width:200px;height:95px;padding-left:5px}.custom-chart .ngx-charts .alert-details-sty span{text-align:center;display:inline-flex;width:80px;font-size:14px;font-weight:700}.custom-chart .ngx-charts .alert-details-sty label{display:inline-block;font-size:12px;padding:5px 0 5px 2px}.custom-chart .ngx-charts .alert-details-sty table{font-size:12px}.custom-chart .ngx-charts .arc,.custom-chart .ngx-charts .bar,.custom-chart .ngx-charts .circle{cursor:pointer}.custom-chart .ngx-charts .arc.active,.custom-chart .ngx-charts .arc:hover,.custom-chart .ngx-charts .bar.active,.custom-chart .ngx-charts .bar:hover,.custom-chart .ngx-charts .card.active,.custom-chart .ngx-charts .card:hover,.custom-chart .ngx-charts .cell.active,.custom-chart .ngx-charts .cell:hover{opacity:.8;transition:opacity .1s ease-in-out}.custom-chart .ngx-charts .arc:focus,.custom-chart .ngx-charts .bar:focus,.custom-chart .ngx-charts .card:focus,.custom-chart .ngx-charts .cell:focus,.custom-chart .ngx-charts g:focus{outline:0}.custom-chart .ngx-charts .area-series.inactive,.custom-chart .ngx-charts .line-series-range.inactive,.custom-chart .ngx-charts .line-series.inactive,.custom-chart .ngx-charts .polar-series-area.inactive,.custom-chart .ngx-charts .polar-series-path.inactive{transition:opacity .1s ease-in-out;opacity:.2}.custom-chart .ngx-charts .line-highlight{display:none}.custom-chart .ngx-charts .line-highlight.active{display:block}.custom-chart .ngx-charts .area{opacity:.6}.custom-chart .ngx-charts .circle:hover{cursor:pointer}.custom-chart .ngx-charts .label{font-size:18px;font-weight:400}.custom-chart .ngx-charts .tooltip-anchor{fill:#000}.custom-chart .ngx-charts .gridline-path{stroke:#ddd;stroke-width:1;fill:none}.custom-chart .ngx-charts .refline-path{stroke:#a8b2c7;stroke-width:1;stroke-dasharray:5;stroke-dashoffset:5}.custom-chart .ngx-charts .refline-label{font-size:9px}.custom-chart .ngx-charts .reference-area{fill-opacity:.05;fill:#000}.custom-chart .ngx-charts .gridline-path-dotted{stroke:#ddd;stroke-width:1;fill:none;stroke-dasharray:1,20;stroke-dashoffset:3}.custom-chart .ngx-charts .grid-panel rect{fill:none}.custom-chart .ngx-charts .grid-panel.odd rect{fill:rgba(170,35,35,.05)}.type-tooltip.ngx-charts-tooltip-content{position:fixed;border-radius:3px;z-index:5000;display:block;font-weight:400;opacity:0;pointer-events:none!important;font-size:14px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top{border-bottom:1px solid grey;padding-bottom:5px;margin-bottom:0;overflow:auto}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top .fund-name{float:left;font-weight:700}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .top .time{float:right;font-weight:700}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .description{clear:both;font-size:14px;margin-top:10px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip td{padding:2px 20px;text-align:right}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .bth-group{float:right;margin-right:-10px;margin-top:15px}.type-tooltip.ngx-charts-tooltip-content .line-tooltip .bth-group button{background-color:#fff;padding:8px;border:2px solid #ddd;width:85px;font-size:12px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip{color:#000;background:#eee;font-size:14px;padding:15px 18px;text-align:left;pointer-events:auto;width:220px;height:115px;border:2px solid #ddd}.type-tooltip.ngx-charts-tooltip-content.type-tooltip.alert1{border:2px solid #ffbc06;height:150px;width:249px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip.alert2{border:2px solid #b91224;height:150px;width:249px}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-left{border-top:7px solid transparent;border-bottom:7px solid transparent;border-left:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-top{border-left:7px solid transparent;border-right:7px solid transparent;border-top:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-right{border-top:7px solid transparent;border-bottom:7px solid transparent;border-right:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content.type-tooltip .tooltip-caret.position-bottom{border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:7px solid #eee}.type-tooltip.ngx-charts-tooltip-content .tooltip-caret{position:absolute;z-index:5001;width:0;height:0}.type-tooltip.ngx-charts-tooltip-content.position-right{-webkit-transform:translate3d(10px,0,0);transform:translate3d(10px,0,0)}.type-tooltip.ngx-charts-tooltip-content.position-left{-webkit-transform:translate3d(-10px,0,0);transform:translate3d(-10px,0,0)}.type-tooltip.ngx-charts-tooltip-content.position-top{-webkit-transform:translate3d(0,-10px,0);transform:translate3d(0,-10px,0)}.type-tooltip.ngx-charts-tooltip-content.position-bottom{-webkit-transform:translate3d(0,10px,0);transform:translate3d(0,10px,0)}.type-tooltip.ngx-charts-tooltip-content.animate{opacity:1;transition:opacity .3s,transform .3s,-webkit-transform .3s;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);pointer-events:auto}.area-tooltip-container{padding:5px 0;pointer-events:none}.tooltip-item{text-align:left;line-height:1.2em;padding:5px 0}.tooltip-item .tooltip-item-color{display:inline-block;height:12px;width:12px;margin-right:5px;color:#5b646b;border-radius:3px}`],
                encapsulation: ViewEncapsulation.ShadowDom,
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('animationState', [
                        transition(':leave', [
                            style({
                                opacity: 1,
                            }),
                            animate(500, style({
                                opacity: 0
                            }))
                        ])
                    ])
                ]
            },] },
];
LineChartComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: ChangeDetectorRef },
    { type: CommonUtilsService },
    { type: DatePipe }
];
LineChartComponent.propDecorators = {
    legend: [{ type: Input }],
    legendTitle: [{ type: Input }],
    showXAxisLabel: [{ type: Input }],
    showYAxisLabel: [{ type: Input }],
    xAxisLabel: [{ type: Input }],
    yAxisLabel: [{ type: Input }],
    autoScale: [{ type: Input }],
    timeline: [{ type: Input }],
    gradient: [{ type: Input }],
    showGridLines: [{ type: Input }],
    curve: [{ type: Input }],
    schemeType: [{ type: Input }],
    rangeFillOpacity: [{ type: Input }],
    xAxisTickFormatting: [{ type: Input }],
    yAxisTickFormatting: [{ type: Input }],
    xAxisTicks: [{ type: Input }],
    yAxisTicks: [{ type: Input }],
    roundDomains: [{ type: Input }],
    tooltipDisabled: [{ type: Input }],
    showRefLines: [{ type: Input }],
    referenceLines: [{ type: Input }],
    showRefLabels: [{ type: Input }],
    xScaleMin: [{ type: Input }],
    xScaleMax: [{ type: Input }],
    yScaleMin: [{ type: Input }],
    yScaleMax: [{ type: Input }],
    selectable: [{ type: Input }],
    height: [{ type: Input }],
    width: [{ type: Input }],
    margin: [{ type: Input }],
    colorDomain: [{ type: Input }],
    results: [{ type: Input }],
    circleData: [{ type: Input }],
    currentLineTime: [{ type: Input }],
    tickValues: [{ type: Input }],
    displayLiveTime: [{ type: Input }],
    activeEntries: [{ type: Input }],
    highLightActiveEntries: [{ type: Input }],
    activate: [{ type: Output }],
    deactivate: [{ type: Output }],
    tooltipTemplate: [{ type: ContentChild, args: ['tooltipTemplate',] }],
    seriesTooltipTemplate: [{ type: ContentChild, args: ['seriesTooltipTemplate',] }],
    hideCircles: [{ type: HostListener, args: ['mouseleave',] }],
    onMouseEnter: [{ type: HostListener, args: ['mouseenter', ["series"],] }],
    onMouseLeave: [{ type: HostListener, args: ['mouseleave', ["$event"],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CustomLegendComponent {
    /**
     * @param {?} shareInforBewteenComponents
     * @param {?} commonUtils
     */
    constructor(shareInforBewteenComponents, commonUtils) {
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.commonUtils = commonUtils;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    getShowLegendAndConsistent(fund) {
        if (fund.name === "") {
            return false;
        }
        else {
            /** @type {?} */
            const list = this.shareInforBewteenComponents.getFundList();
            /** @type {?} */
            let show = false;
            list.forEach(item => {
                if (item.fundID === fund.name && item.checked) {
                    show = true;
                }
            });
            return show;
        }
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    getFundRelatedColor(fund) {
        /** @type {?} */
        let colorStr = '';
        this.colorDomain.forEach(item => {
            if (item['fundid'] === fund['name']) {
                colorStr = item['color'];
            }
        });
        return colorStr;
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    remove(fund) {
        this.commonUtils.updateFundStatus(fund['fundID'], false);
        /** @type {?} */
        let fundIndex = -1;
        this.results.forEach((item, index) => {
            if (item['name'] === fund['name']) {
                fundIndex = index;
            }
        });
        if (fundIndex >= 0) {
            this.results.splice(fundIndex, 1);
        }
        this.selectedFundChange.emit(fund);
    }
}
CustomLegendComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-custom-legend',
                template: `<mat-chip-list class="mat-chip-list">
  <ng-container
  *ngFor="let fund of results;let i=index;trackBy:index" 
  >
     <mat-basic-chip
      *ngIf="getShowLegendAndConsistent(fund)"
      [selectable]="selectable" 
      [removable]="removable" 
      [style.borderColor]="getFundRelatedColor(fund)"
      disableRipple>
        {{fund.fundTicker ? fund.fundTicker : fund.fundID }}
         <mat-icon class="removeIcon" svgIcon="close" matChipRemove (click)="remove(fund)"></mat-icon> 
  </mat-basic-chip>
  </ng-container>
</mat-chip-list>`,
                styles: [`.mat-basic-chip{margin:10px 10px 15px;border-top:1px solid;border-bottom:1px solid;border-right:1px solid;border-left:5px solid;display:inline-flex;padding:3px 0 0 10px;font-size:14px}.mat-basic-chip .removeIcon{width:10px!important;height:10px!important;margin:0 8px;cursor:pointer;min-height:10px!important;min-width:10px!important}`]
            },] },
];
CustomLegendComponent.ctorParameters = () => [
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService }
];
CustomLegendComponent.propDecorators = {
    results: [{ type: Input }],
    selectable: [{ type: Input }],
    removable: [{ type: Input }],
    colorDomain: [{ type: Input }],
    index: [{ type: Input }],
    selectedFundChange: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
//import { dev, prod } from '../lib-env';
class NavService {
    //baseUrl = this.env.production? prod.service_base_url: dev.service_base_url;
    //constructor(private http: HttpClient, @Inject('env') private env) { }
    /**
     * @param {?} http
     */
    constructor(http) {
        this.http = http;
        this.data = new BehaviorSubject((/** @type {?} */ ([])));
    }
    /**
     * @param {?} funds
     * @return {?}
     */
    getTodayNav(funds) {
        return this.http.get('/api/today'); // demo api, can be removed after merge qnav-line-chart
    }
    // call this one from chart component only to avoid multiple call request by different component
    /**
     * @return {?}
     */
    fetchFundList() {
        //return this.http.get<any[]>('/api/fundList').subscribe(d => this.data.next(d as any[]));
        this.data = new BehaviorSubject((/** @type {?} */ ([]))); //reset data as the getFundList subcription may still get the old data if new call hasn't returned yet.
        this.http.get('/qnav-web-multiclass/data/fundlist?timeZoneOffset=' + new Date().getTimezoneOffset() * (-1))
            .subscribe(d => {
            this.data.next((/** @type {?} */ (d)));
        }, error => {
            console.log(error);
        });
    }
    // call this one for all components to get fundlist if it's already fetched.
    /**
     * @return {?}
     */
    getFundList() {
        return this.data.asObservable();
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    getPositionDetails(fund) {
        //return this.http.get('api/positionDetails')
        return this.http.get('/qnav-web-multiclass/data/fundDetail?fundId=' + fund);
    }
}
NavService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
NavService.ctorParameters = () => [
    { type: HttpClient }
];
/** @nocollapse */ NavService.ngInjectableDef = defineInjectable({ factory: function NavService_Factory() { return new NavService(inject(HttpClient)); }, token: NavService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @enum {string} */
const Action = {
    REGISTER: "register",
    SENDTO: "sendTo",
    STOPWATCHFUND: "stopWatchFund",
    WATCHFUND: "watchFund",
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
//import { dev, prod } from '../lib-env';
class NavSocketService {
    // constructor(@Inject('env') private env) {
    //     this.initSocket();
    //     this.registerService();
    // }
    constructor() {
        this.nav = new BehaviorSubject((/** @type {?} */ ({})));
        this.initSocket();
        this.registerService();
    }
    /**
     * @return {?}
     */
    initSocket() {
        this.subject = webSocket('wss://' + window.location.hostname + ":" + window.location.port + '/qnav-web-multiclass/conn'); //  proxy won't be able to function if the port not match with start port
        //return this.subject;
        this.subject.subscribe((msg) => { this.nav.next((/** @type {?} */ (msg))); }, (err) => console.log("ERROR!!!!" + err), () => console.log("NAV Socket COMPLETED....."));
        // console.log(new Date(1524823809200431));
    }
    /**
     * @return {?}
     */
    getNav() {
        return this.nav.asObservable();
    }
    /**
     * @param {?} request
     * @return {?}
     */
    send(request) {
        this.subject.next(request);
    }
    /**
     * @param {?} funds
     * @return {?}
     */
    registerFunds(funds) {
        funds.forEach(fund => {
            this.send({ "action": Action.WATCHFUND, "fundId": fund });
        });
    }
    /**
     * @param {?} funds
     * @return {?}
     */
    unRegisterFunds(funds) {
        funds.forEach(fund => {
            this.send({ "action": Action.STOPWATCHFUND, "fundId": fund });
        });
    }
    /**
     * @return {?}
     */
    registerService() {
        this.send({ action: Action.REGISTER, sessionId: new Date().valueOf() + '', timeZoneOffset: new Date().getTimezoneOffset() * (-1) });
    }
}
NavSocketService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
NavSocketService.ctorParameters = () => [];
/** @nocollapse */ NavSocketService.ngInjectableDef = defineInjectable({ factory: function NavSocketService_Factory() { return new NavSocketService(); }, token: NavSocketService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class ResourceManagerService {
    constructor() {
        this.intervalInstances = [];
        this.intervalFuncs = [];
        //window.addEventListener('blur',(event)=>{this.deactive(event)});
        //window.addEventListener('focus',(event)=>{this.active(event)});
        window.addEventListener('visibilitychange', (event) => {
            if (document.hidden) {
                this.deactive(event);
            }
            else {
                this.active(event);
            }
        });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    deactive(event) {
        //console.log(event);
        this.doDeactive();
    }
    /**
     * @return {?}
     */
    doDeactive() {
        this.intervalInstances.forEach(item => {
            /** @type {?} */
            let time = new Date();
            console.log(`clear the setinterval for component: ${item}, ${time}`);
            clearInterval(item);
        });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    active(event) {
        //console.log(event);
        this.intervalFuncs.forEach(item => {
            //console.log(`active the setinterval for component: ${item['func']}, interval:${item['interval']}, ${time}`);
            this.intervalInstances.push(setInterval(item['func'], item['interval']));
        });
    }
    /**
     * @param {?} intervalFunc
     * @param {?} interval
     * @return {?}
     */
    registInterval(intervalFunc, interval) {
        /** @type {?} */
        let instance = setInterval(intervalFunc, interval);
        this.intervalInstances.push(instance);
        this.intervalFuncs.push({ 'func': intervalFunc, 'interval': interval });
    }
    //need call in component ngOnDestroy() to clear resources for current component
    /**
     * @return {?}
     */
    cleanResources() {
        this.doDeactive();
        this.intervalInstances = [];
        this.intervalFuncs = [];
    }
}
ResourceManagerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] },
];
ResourceManagerService.ctorParameters = () => [];
/** @nocollapse */ ResourceManagerService.ngInjectableDef = defineInjectable({ factory: function ResourceManagerService_Factory() { return new ResourceManagerService(); }, token: ResourceManagerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const customColumn = [];
/** @type {?} */
const normalColumn = [
    {
        prop: 'cusip',
        name: 'Instrument Id Ref',
        width: '',
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'default',
        headerClassFormat: 'headerLeft',
        cellClassFormat: 'cellLeft',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'longShortIndicator',
        name: 'Long/Short',
        width: '',
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'default',
        headerClassFormat: 'headerLeft',
        cellClassFormat: 'cellLeft',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'parShare',
        name: 'Units',
        width: '',
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'sodPrice',
        name: 'Price Previous',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'price',
        name: 'Price Current',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'mv',
        name: 'Market Value',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'priceChangePercent',
        name: 'Price % Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'percentFormat',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'navImpact',
        name: 'NAV Impact',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatLong',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    }
];
/** @type {?} */
const columnMenuDropDownSetting = [
    // {
    //   name: "Resize to Fit",
    //   type: "resizeToFit",
    //   hasSubMenu: false,
    // },
    {
        name: "Freeze Column",
        type: "freezeColumn",
        hasSubMenu: false,
    },
    {
        name: "Sort Column",
        type: "sortColumn",
        hasSubMenu: false,
    },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class QnavPositionComponent extends BaseWidgetComponent {
    /**
     * @param {?} navService
     * @param {?} appContext
     * @param {?} navSocketService
     * @param {?} shareInfoBeweenComponentsService
     * @param {?} commonUtils
     * @param {?} resourceManger
     */
    constructor(navService, appContext, navSocketService, shareInfoBeweenComponentsService, commonUtils, resourceManger) {
        super();
        this.navService = navService;
        this.appContext = appContext;
        this.navSocketService = navSocketService;
        this.shareInfoBeweenComponentsService = shareInfoBeweenComponentsService;
        this.commonUtils = commonUtils;
        this.resourceManger = resourceManger;
        this.rows = [];
        this.childRows = [];
        this.isDataAvailable = false;
        this.rowHeight = 50;
        this.alertData = [];
        this.allRowsSelected = false;
        this.isSelectedMap = [];
        this.headerSetting = true;
        this.headerHeight = 50;
        // temp data structure
        this.isDataTablePaused = false;
        this.customColumn = customColumn;
        this.normalColumn = normalColumn;
        this.columnMenuDropDownSetting = columnMenuDropDownSetting;
        this.limit = 5;
        this.footerHeight = 50;
        this.headerCheckBox = false;
        this.fundInfo = [];
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        //reset component data and user validation;
        this.commonUtils.validateUser();
        this.rows = [];
        this.subs = [];
        this.isDataAvailable = false;
        this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
        if (this.fundInfo.length > 0) {
            this.renderPositionDetails();
        }
        else {
            //this.navService.fetchFundList();
            this.navService.getFundList().subscribe(data => {
                if (data.length > 0) {
                    /** @type {?} */
                    const fundInfo = [];
                    fundInfo.push(data[0].fundid);
                    fundInfo.push(data[0].name);
                    fundInfo.push(data[0].fundTicker);
                    this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
                    this.renderPositionDetails();
                }
            });
        }
        this.shareInfoBeweenComponentsService.sortDatatableColumn.subscribe(data => {
            console.log([...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)]);
            this.rows = [...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)];
        });
    }
    /**
     * @return {?}
     */
    renderPositionDetails() {
        this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
        if (this.fundInfo.length > 0) {
            this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(data => {
                this.isDataAvailable = true;
                this.rows = data["holdings"];
                this.rows = [...this.rows];
            }));
            this.subs.push(this.navSocketService.getNav().subscribe((data) => {
                if (data['eventType'] === 'fundChange') {
                    /** @type {?} */
                    const fundLevelRow = this.commonUtils.extractWSData(data["eventData"], false);
                    this.updateRow(fundLevelRow);
                }
                else {
                    this.updateRow(data);
                }
            }));
            this.navSocketService.registerFunds([this.fundInfo[0]]);
            this.resourceManger.registInterval(() => { this.rows = [...this.rows]; }, 300);
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.fundInfo.length > 0) {
            this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
            this.subs.forEach(sub => sub.unsubscribe());
        }
        this.resourceManger.cleanResources();
    }
    /**
     * @param {?} data
     * @return {?}
     */
    updateRow(data) {
        if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
            if (this.rows.length && data) {
                /** @type {?} */
                const fundid = data['fundid'];
                /** @type {?} */
                const cusip = data['cusip'];
                /** @type {?} */
                const longShortIndicator = data['longShortIndicator'];
                this.rows.forEach(item => {
                    if (this.fundInfo[0] === fundid && item['cusip'] === cusip && item['longShortIndicator'] === longShortIndicator) {
                        this.normalColumn.forEach(colItem => { if (null != data[colItem.prop]) {
                            item[colItem.prop] = data[colItem.prop];
                        } });
                    }
                });
            }
        }
        if (data && data['eventType'] === 'sodChange') {
            this.navService.getPositionDetails(this.fundInfo[0]).subscribe(data => {
                this.rows = data["holdings"];
                this.rows = [...this.rows];
            });
        }
    }
    // returnBack(): any {
    //   this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-001');
    // }
    /**
     * @return {?}
     */
    togglePauseFlag() {
        this.isDataTablePaused = !this.isDataTablePaused;
    }
}
QnavPositionComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-qnav-position',
                template: `<div class="qnav-position-container" *ngIf="isDataAvailable">
    <!-- <div class="returnBack" (click)="returnBack()">
        <mat-icon class="home" svgIcon="home"></mat-icon>
    </div> -->
    <div class="fundDetails">
        <ul>
            <li>Position Details for</li>
            <li>
                <label>Entity Ticker: </label> {{fundInfo[2]}}
            </li>
             <li>
                <label>Entity Name: </label> {{fundInfo[1]}}
            </li>
        </ul>
    </div>
<lib-common-data-table
    [headerSetting]="headerSetting"
    [headerHeight]="headerHeight"
    [rows]="rows"
    [childRows]="childRows"
    [alertData]="alertData"
    [rowHeight]="rowHeight"
    [customColumn]="customColumn"
    [normalColumn]="normalColumn"
    [limit]="limit"
    [footerHeight]="footerHeight"
    [headerCheckBox]="headerCheckBox"
    [isDataTablePaused]="isDataTablePaused"
    [columnMenuDropDownSetting]="columnMenuDropDownSetting"
    [defaultSortCol]="'cusip'"
    (togglePauseFlagEvent)="togglePauseFlag()"
>
</lib-common-data-table>
</div>`,
                styles: [`.ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:" ";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:"";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:"";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}`, `.ngx-datatable.material{display:unset}.ngx-datatable .datatable-header .datatable-header-cell .datatable-header-cell-template-wrap .columnHeader{color:#000}.returnBack{width:20px;height:20px;position:absolute;top:14px;right:60px;cursor:pointer}.qnav-position-container{width:100%;height:100%}.fundDetails{color:#464646;font-size:16px;position:absolute;top:0;left:-15px;font-family:DINNextLTPro-Medium}ul{list-style:none;display:inline-flex}li{margin-right:5px}`],
            },] },
];
QnavPositionComponent.ctorParameters = () => [
    { type: NavService },
    { type: AppContext },
    { type: NavSocketService },
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService },
    { type: ResourceManagerService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class AddFundModalComponent {
    /**
     * @param {?} commonUtils
     * @param {?} dialogRef
     * @param {?} data
     */
    constructor(commonUtils, dialogRef, data) {
        this.commonUtils = commonUtils;
        this.dialogRef = dialogRef;
        this.data = data;
        this.fundList = _.cloneDeep(data['fundList']);
        this.selectedFundChange = data.dataChange;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    handleSelectFund(fund) {
        /** @type {?} */
        const index = this.fundList.indexOf(fund);
        this.fundList[index]['checked'] = !this.fundList[index]['checked'];
    }
    /**
     * @return {?}
     */
    handleClickSelectBtn() {
        /** @type {?} */
        const removeFundList = this.fundList.filter(item => item.checked === false);
        /** @type {?} */
        const addFundlist = this.fundList.filter(item => item.checked === true);
        removeFundList.forEach(item => {
            this.updateVariableFundList(item);
        });
        addFundlist.forEach(item => {
            this.updateVariableFundList(item);
        });
        this.selectedFundChange.emit(addFundlist);
        this.onNoClick();
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    updateVariableFundList(fund) {
        this.commonUtils.updateFundStatus(fund['fundID'], fund['checked']);
    }
    /**
     * @return {?}
     */
    onNoClick() {
        this.dialogRef.close();
    }
}
AddFundModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-add-fund-modal',
                template: `<div class="modal-header">
	<h1 mat-dialog-title>Add Entity to Chart</h1>
  <span class="alert-close" (click)="onNoClick()">×</span>
</div>
<div mat-dialog-content>
 <div class="form-group">
	<div 
  *ngFor="let fund of fundList"
	class="fund-list-item"
   >
		<div class="checkbox">
			<label>
				 <ng-container
				 *ngIf="fund.checked">
					 <input type="checkbox" (click)="handleSelectFund(fund)" checked> {{fund.fundTicker ? fund.fundTicker : fund.fundID }}
				 </ng-container>
				 <ng-container
				 *ngIf="!fund.checked">
					 <input type="checkbox" (click)="handleSelectFund(fund)"> {{fund.fundTicker ? fund.fundTicker : fund.fundID }}
				 </ng-container>
     		</label>
		</div>
	</div>
</div>
</div>
<div mat-dialog-actions align="end">
  <button mat-button (click)="onNoClick()" cdkFocusInitial>Cancel</button>
  <button mat-button (click)="handleClickSelectBtn()" class="primary-btn">Select</button>
</div>`,
                styles: [`.modal-header{position:relative}.mat-dialog-title{color:#464646;margin:-10px 0 20px}.alert-close{position:absolute;top:-6px;right:-6px;color:rgba(105,105,105,.78);cursor:pointer;font-size:40px}.mat-dialog-content{color:#464646;font-size:16px;border-bottom:2px solid rgba(0,0,0,.15)}.form-group{margin-bottom:1em}.fund-list-item{margin:0 0 15px}.primary-btn{background:#2f749a;color:#fff}`]
            },] },
];
AddFundModalComponent.ctorParameters = () => [
    { type: CommonUtilsService },
    { type: MatDialogRef },
    { type: undefined, decorators: [{ type: Inject, args: [MAT_DIALOG_DATA,] }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
// fund color map, need set color for each fund if add more funds
/** @type {?} */
const dataVisualFundColorMap = [
    {
        fundID: undefined,
        color: '#86BBD1',
    },
    {
        fundID: undefined,
        color: '#FC7C42'
    },
    {
        fundID: undefined,
        color: '#008198'
    },
    {
        fundID: undefined,
        color: '#CDDC39'
    }
];
// for heatmap component color setting
/** @type {?} */
const heatMapColorSetting = [
    {
        value: -3,
        color: '#B91224',
    },
    {
        value: -2,
        color: '#EAB7BD',
    },
    {
        value: -1,
        color: '#F5DCDE',
    },
    {
        value: 1,
        color: '#DFEAE2',
    },
    {
        value: 2,
        color: '#BED5C5',
    },
    {
        value: 3,
        color: '#28743E',
    }
];
/** @type {?} */
const heatMapColorScheme = {
    domain: ['#B91224', '#EAB7BD', '#F5DCDE', '#DFEAE2', '#BED5C5', '#28743E']
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const defaultFundList = [
    {
        "name": "",
        "series": [
            {
                "name": "09:30:00",
                "value": 0.0,
                "nav": "0.0",
                "marketval": "0.0"
            }
        ]
    }
];
/** @type {?} */
const ticksValue = [
    new Date().setHours(9, 30, 0),
    new Date().setHours(10, 30, 0),
    new Date().setHours(11, 30, 0),
    new Date().setHours(12, 30, 0),
    new Date().setHours(13, 30, 0),
    new Date().setHours(14, 30, 0),
    new Date().setHours(15, 30, 0),
    new Date().setHours(16, 30, 0)
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class QnavLineChartComponent extends BaseWidgetComponent {
    /**
     * @param {?} chartElement
     * @param {?} zone
     * @param {?} cd
     * @param {?} navService
     * @param {?} navSocketService
     * @param {?} dialog
     * @param {?} viewContainer
     * @param {?} shareInforBewteenComponents
     * @param {?} commonUtils
     * @param {?} resourceManger
     */
    constructor(chartElement, zone, cd, navService, navSocketService, dialog, viewContainer, shareInforBewteenComponents, commonUtils, resourceManger) {
        super();
        this.navService = navService;
        this.navSocketService = navSocketService;
        this.dialog = dialog;
        this.viewContainer = viewContainer;
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.commonUtils = commonUtils;
        this.resourceManger = resourceManger;
        this.removable = true;
        this.selectable = false;
        this.results = [];
        this.permanentResults = [];
        this.isDataAvailable = false;
        this.height = 240;
        this.margin = [20, 100, 30, 100];
        this.colorDomain = [];
        this.tickValues = ticksValue;
        this.circleData = [];
        this.permanentCircleData = [];
        this.showYAxisLabel = true;
        this.yAxisLabel = 'Nav % Change';
        this.previousTime = new Date();
        this.activeEntries = [];
        this.highLightActiveEntries = [];
        this.fundChange = new EventEmitter();
        this.removeIndexs = [];
        this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width - 100;
        this.xScaleMin = commonUtils.startTime;
        this.xScaleMax = commonUtils.endTime;
        this.currentLineTime = commonUtils.startTime;
        this.resourceManger.registInterval(() => {
            if (new Date() < commonUtils.endTime) {
                this.displayLiveTime = new Date();
            }
            else {
                this.displayLiveTime = commonUtils.endTime;
            }
        }, 1000);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        //need to reset value here when switch back from other dashboard like position or when switch users
        this.commonUtils.validateUser();
        //initialize the  colorDomain with predefined colors.
        this.shareInforBewteenComponents.setColorSchema(dataVisualFundColorMap);
        this.isDataAvailable = false;
        this.subs = [];
        this.results = [];
        this.permanentResults = [];
        this.colorDomain = [];
        this.circleData = [];
        this.permanentCircleData = [];
        this.previousTimeMap = null;
        //reset done
        this.navService.fetchFundList();
        this.subs.push(this.navService.getFundList().subscribe(data => {
            if (data.length > 0) {
                /** @type {?} */
                const fundLevelData = this.commonUtils.extractFundLevelData(data);
                this.permanentResults = [...this.convertToResults(fundLevelData)];
                this.permanentCircleData = [...this.updateCircleData(fundLevelData)];
                this.colorDomain = [...this.setFundColorMap(fundLevelData)];
                this.shareInforBewteenComponents.setColorSchema(this.colorDomain);
                this.isDataAvailable = true;
                this.previousTimeMap = new Map();
                this.permanentResults.forEach(f => {
                    /** @type {?} */
                    let series = f['series'];
                    this.previousTimeMap.set(f['name'], series[series.length - 1]['pricetime']);
                    this.currentLineTime = new Date(this.previousTimeMap.get(f['name']));
                });
                this.results = this.filterResults(this.permanentResults);
                this.circleData = this.filterCircleDate(this.permanentCircleData);
            }
        }));
        this.subs.push(this.navSocketService.getNav().subscribe((data) => {
            if (data && data["eventData"]) {
                /** @type {?} */
                const fundLevelUpdateData = this.commonUtils.extractWSData(data["eventData"], false);
                this.updateChart(fundLevelUpdateData);
            }
        }));
        this.shareInforBewteenComponents.highLightActiveEntries.subscribe(data => {
            /** @type {?} */
            const filteredActiveData = [];
            /** @type {?} */
            const lists = this.shareInforBewteenComponents.getFundList();
            data.forEach(item => {
                if (lists.find(list => (list.fundID === item.name && list.checked))) {
                    filteredActiveData.push(item);
                }
            });
            this.highLightActiveEntries = filteredActiveData;
            this.activeEntries = filteredActiveData;
        });
        this.fundChange.subscribe(data => {
            this.shareInforBewteenComponents.highLightActiveEntries.emit(this.highLightActiveEntries);
            this.results = [];
            this.circleData = [];
            this.shareInforBewteenComponents.getFundList().forEach(fund => {
                this.permanentResults.forEach(result => {
                    if (fund['fundID'] === result['name'] && fund['checked']) {
                        this.results.push(result);
                    }
                });
                this.permanentCircleData.forEach(circle => {
                    if (fund['fundID'] === circle['name'] && fund['checked']) {
                        this.circleData.push(circle);
                    }
                });
            });
        });
    }
    /**
     * @param {?} permnantResult
     * @return {?}
     */
    filterResults(permnantResult) {
        /** @type {?} */
        let filteredResults = [];
        permnantResult.forEach(result => {
            this.shareInforBewteenComponents.getFundList().forEach(item => {
                if (result.name === item.fundID && item.checked) {
                    filteredResults.push(result);
                }
            });
        });
        return filteredResults;
    }
    /**
     * @param {?} permanentCircleData
     * @return {?}
     */
    filterCircleDate(permanentCircleData) {
        /** @type {?} */
        let filteredCircleData = [];
        permanentCircleData.forEach(result => {
            this.shareInforBewteenComponents.getFundList().forEach(item => {
                if (result.name === item.fundID && item.checked) {
                    filteredCircleData.push(result);
                }
            });
        });
        return filteredCircleData;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    setFundColorMap(data) {
        /** @type {?} */
        const temp = [];
        /** @type {?} */
        const lists = this.shareInforBewteenComponents.getFundList();
        data.forEach(item => {
            /** @type {?} */
            let setColor = false;
            lists.forEach(list => {
                if (item.fundid === list.fundID && list.checked)
                    setColor = true;
            });
            if (setColor) {
                /** @type {?} */
                const obj = {
                    fundid: item.fundid,
                    color: this.commonUtils.getColorForFund(item.fundid)
                };
                temp.push(obj);
            }
            else {
                /** @type {?} */
                const obj = {
                    fundid: undefined,
                    color: this.commonUtils.getColorForFund(item.fundid)
                };
                temp.push(obj);
            }
        });
        return temp;
    }
    //need to unsubscribe to avoid potential memory leak.
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.subs.forEach(sub => sub.unsubscribe());
        this.colorDomain = [];
        this.resourceManger.cleanResources();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    resizingChart(event) {
        this.width = event.target.innerWidth - 100;
    }
    /**
     * @param {?} results
     * @return {?}
     */
    getResults(results) {
        if (results.length === 0) {
            return defaultFundList;
        }
        else {
            return results;
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    updateChart(data) {
        if (data) {
            /** @type {?} */
            const fundid = data['fundid'];
            /** @type {?} */
            let time;
            /** @type {?} */
            let currentTime;
            if (data['pricetime']) {
                currentTime = new Date(data['pricetime']);
                if (this.commonUtils.isValidTime(currentTime)) {
                    time = currentTime;
                }
            }
            if (currentTime > this.commonUtils.endTime) {
                this.currentLineTime = this.commonUtils.endTime;
            }
            //for adding alert data if any.
            if (this.commonUtils.isValidTime(new Date(data['pricetime'])) && data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
                /** @type {?} */
                const alertObj = {
                    "name": fundid,
                    "x": new Date(data['pricetime']),
                    "alertType": data['alertType'],
                    "value": data['navChangePercent'],
                    "fundmvChangePercent": data['fundmvChangePercent'],
                    "nav": data['nav'],
                    "marketval": data['fundmv'],
                    "pricetime": data['pricetime']
                };
                this.permanentCircleData.push(alertObj);
                //this.permanentCircleData = [...this.permanentCircleData];
                this.circleData = [...this.filterCircleDate(this.permanentCircleData)];
            }
            this.permanentResults.forEach(item => {
                if (item['name'] === fundid) {
                    //only shows data between 9:30AM to 4:30PM
                    if (time) {
                        if (currentTime.getTime() - new Date(this.previousTimeMap.get(fundid)).getTime() >= 20000) {
                            this.currentLineTime = new Date(data['pricetime']);
                            /** @type {?} */
                            const obj = {
                                'marketval': data['fundmv'],
                                // fund market value
                                'name': this.nextTimeForFund(this.previousTimeMap, fundid, data['pricetime']),
                                'nav': data['nav'],
                                'value': data['navChangePercent'],
                                'pricetime': data['pricetime']
                            };
                            item['series'].push(obj);
                        }
                        else if (currentTime.getTime() - this.previousTime.getTime() >= 2000) {
                            this.previousTime = currentTime;
                            //this.currentLineTime = new Date(this.previousTimeMap.get(fundTicker)); //this will cause component re-render whenever this is ws data coming
                            /** @type {?} */
                            const obj = {
                                'marketval': data['fundmv'],
                                'name': new Date(this.previousTimeMap.get(fundid)),
                                'nav': data['nav'],
                                'value': data['navChangePercent'],
                                'pricetime': data['pricetime']
                            };
                            //this will increase cpu usage as well, need to find better way to update results
                            item['series'].pop();
                            item['series'].push(obj);
                        }
                    }
                }
            });
        }
    }
    // the get fund list service will return the history chart data, using below functions to covert the data to expected result set
    /**
     * @param {?} data
     * @return {?}
     */
    convertToResults(data) {
        /** @type {?} */
        const results = [];
        /** @type {?} */
        const variableFundList = this.shareInforBewteenComponents.getFundList();
        data.forEach(item => {
            // for persistent user selected funds in legend.
            if (variableFundList.findIndex(list => list.fundID === item.fundid) === -1) {
                variableFundList.push({
                    'fundID': item['fundid'],
                    'fundTicker': item['fundTicker'],
                    'checked': true
                });
            }
            /** @type {?} */
            const obj = {
                'name': item['fundid'],
                'fundID': item['fundid'],
                'fundTicker': item['fundTicker'],
                'series': this.createSeries(item)
            };
            results.push(obj);
        });
        this.shareInforBewteenComponents.setVariableFundList(variableFundList);
        return results;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    createSeries(data) {
        /** @type {?} */
        const series = [];
        data['priceChanges'].forEach(item => {
            if (this.commonUtils.isValidTime(new Date(item['pricetime']))) {
                /** @type {?} */
                const obj = {
                    'marketval': item['fundmv'],
                    //fund market value from history data
                    'name': new Date(item['pricetime']),
                    'nav': item['nav'],
                    'value': item['navChangePercent'],
                    'pricetime': item['pricetime']
                };
                series.push(obj);
            }
        });
        if (series.length == 0) {
            /** @type {?} */
            const obj = {
                'marketval': data['fundmv'],
                //fund market value from history data
                'name': this.xScaleMin,
                'nav': data['nav'],
                'value': 0,
                'pricetime': this.commonUtils.startTime
            };
            series.push(obj);
        }
        return series;
    }
    // for collecting historic alert data
    /**
     * @param {?} data
     * @return {?}
     */
    updateCircleData(data) {
        /** @type {?} */
        let CricleData = [];
        data.forEach(item => {
            CricleData = CricleData.concat(this.filterAlertData(item['fundid'], item['priceChanges']));
        });
        return CricleData;
    }
    /**
     * @param {?} fundid
     * @param {?} data
     * @return {?}
     */
    filterAlertData(fundid, data) {
        /** @type {?} */
        const tempAlertCricleData = [];
        data.forEach(item => {
            if (this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                /** @type {?} */
                const alertObj = {
                    "name": fundid,
                    "x": new Date(item['pricetime']),
                    "alertType": item['alertType'],
                    "value": item['navChangePercent'],
                    "nav": item['nav'],
                    "fundmvChangePercent": item['fundmvChangePercent'],
                    "marketval": item['fundmv'],
                    "pricetime": item['pricetime'],
                };
                tempAlertCricleData.push(alertObj);
            }
        });
        return tempAlertCricleData;
    }
    // this method will return the next time and set the new time to the previous time map for the given fund
    /**
     * @param {?} previousTimeMap
     * @param {?} fundid
     * @param {?} time
     * @return {?}
     */
    nextTimeForFund(previousTimeMap, fundid, time) {
        previousTimeMap.set(fundid, time); // set back to the map
        return new Date(time);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    openAddFundModal(event) {
        /** @type {?} */
        const dialogRef = this.dialog.open(AddFundModalComponent, {
            width: '300px',
            data: {
                'fundList': this.shareInforBewteenComponents.getFundList(),
                'dataChange': this.fundChange //create eventemitter ourself as closeDialogSubject is not working
            },
        });
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }
    /**
     * @param {?} v
     * @return {?}
     */
    xAxisTickFormatting(v) {
        /** @type {?} */
        const tempDate = new Date(v);
        return formatDate(tempDate, "h:mm aaaaa'm'", 'en-US');
    }
}
QnavLineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-qnav-line-chart',
                template: `<div  class="qnav-container" *ngIf="isDataAvailable" (window:resize)="resizingChart($event)">
    <div class="live-time-for-title">
        <p *ngIf="commonUtils.isAfterMarketClose else elseBlock">Change in NAV per share for {{commonUtils.liveTime | date:'EEEE'}}, {{commonUtils.liveTime | date:'MM/dd/yyyy'}}, as of Market Close: {{commonUtils.liveTime | date:"h:mm aaaaa'm'"}}</p>
        <ng-template #elseBlock><p>Change in NAV per share for {{commonUtils.liveTime | date:'EEEE'}}, {{commonUtils.liveTime | date:'MM/dd/yyyy'}}, Real Time: {{commonUtils.liveTime | date:"h:mm aaaaa'm'"}}</p></ng-template>
    </div>
    <div class="custom-legend">
    <app-custom-legend
      [results]="results"
      [selectable]="selectable"
      [removable]="removable"
      [colorDomain]='colorDomain'
      [selectedFundChange]="fundChange"
    >
    </app-custom-legend>
    <div class="addChunk">
      <mat-icon class="addFundIcon" svgIcon="circle_plus"  (click)="openAddFundModal($event)"></mat-icon>
      <span class="addContent">Add Entity</span>
    </div>
  </div>
  <lib-fine-line-chart
  [results]='results'
  [height]='height'
  [width]='width'
  [margin]='margin'
  [colorDomain]='colorDomain'
  [circleData]='circleData'
  [currentLineTime]='currentLineTime'
  [displayLiveTime]='displayLiveTime'
  [tickValues]='tickValues'
  [xAxisTickFormatting]='xAxisTickFormatting'
  [xScaleMin]='xScaleMin'
  [xScaleMax]='xScaleMax'
  [showYAxisLabel]='showYAxisLabel'
  [yAxisLabel]='yAxisLabel'
  [activeEntries]='activeEntries'
  [highLightActiveEntries]='highLightActiveEntries'
  >
  </lib-fine-line-chart>
</div>
`,
                styles: [`.ngx-chart.material{display:unset}.qnav-container{width:100%;height:100%}.custom-legend{display:inline-flex;width:98%;align-items:center;margin-top:5px;padding:0 12px;min-height:40px}.addChunk{position:relative;display:inline-block;min-height:30px;min-width:150px}.addChunk .addFundIcon{position:absolute;top:6px;margin-right:5px;width:15px!important;height:15px!important;margin-left:20px;cursor:pointer;min-height:15px!important;min-width:15px!important}.addChunk .addContent{position:absolute;top:6px;left:40px}.live-time-for-title{position:absolute;top:0;left:15px;font-size:16px;font-family:DINNextLTPro-Medium;color:#464646}`]
            },] },
];
QnavLineChartComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: ChangeDetectorRef },
    { type: NavService },
    { type: NavSocketService },
    { type: MatDialog },
    { type: ViewContainerRef },
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService },
    { type: ResourceManagerService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class PercentFormatPipe {
    /**
     * @param {?} value
     * @return {?}
     */
    transform(value) {
        if (value != 0) {
            if (value.toString().indexOf('-') === 0) {
                return value;
            }
            else {
                return '+' + value;
            }
        }
        else {
            return "0.000%";
        }
    }
}
PercentFormatPipe.decorators = [
    { type: Pipe, args: [{
                name: 'percentFormat'
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class NumberRoundUpPipe {
    /**
     * @param {?} value
     * @param {?} maxFractionDigits
     * @return {?}
     */
    transform(value, maxFractionDigits) {
        return Math.round(Math.pow(10, maxFractionDigits) * value) / Math.pow(10, maxFractionDigits);
    }
}
NumberRoundUpPipe.decorators = [
    { type: Pipe, args: [{
                name: 'numberRoundUp'
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CustomAlertModalComponent {
    /**
     * @param {?} commonUtils
     * @param {?} dialogRef
     * @param {?} data
     */
    constructor(commonUtils, dialogRef, data) {
        this.commonUtils = commonUtils;
        this.dialogRef = dialogRef;
        this.data = data;
        this.alertData = [];
        this.alertData = data['alertData'];
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @return {?}
     */
    onNoClick() {
        this.dialogRef.close();
    }
}
CustomAlertModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-custom-alert-modal',
                template: `<div class="modal-header">
  <h1 mat-dialog-title>{{data.title}} {{data.type}} Alerts for {{data.now | date: "EEEE, M/d, h:mm aaaaa'm'"}}</h1>
  <span class="alert-close" (click)="onNoClick()" >×</span>
</div>
<div mat-dialog-content>
  <div class="container custom-alert-sty" *ngFor="let data of alertData">
    <div class="alert-details-item-container">
      <div class="top-line">
        <div class="top-line-item">
        {{data.pricetime | date: "h:mm:ss aaaaa'm'"}}
        </div>
        <div class="top-line-item">
          NAV Diverging from Market Value
        </div>
      </div>
      <div class="button-line">
        <div>
           <div class="button-line-item">
             NAV % Change:
          </div>
          <div class="button-line-item">
            {{data.value | percent: '1.2-2'}}
          </div>
        </div>
        <div>
         <div class="button-line-item">
             MV % Change:
          </div>
          <div class="button-line-item">
            {{data.fundmvChangePercent | percent: '1.2-2'}}
          </div>
        </div>
     </div>
    </div>
    </div>
</div>
<div mat-dialog-actions align="end">
  <!-- <button mat-button (click)="onNoClick()" cdkFocusInitial>Cancel</button> -->
  <button mat-button (click)="onNoClick()" class="primary-btn">OK</button>
</div>`,
                styles: [`.modal-header{position:relative}.mat-dialog-title{color:#464646;margin:-10px 0 20px}.alert-close{position:absolute;top:-6px;right:-6px;color:rgba(105,105,105,.78);cursor:pointer;font-size:40px}.mat-dialog-content{border-bottom:2px solid rgba(0,0,0,.15);height:250px;overflow:auto}.custom-alert-sty{color:#464646;font-size:16px;padding-left:0!important;margin-bottom:20px}.alert-details-item-container{padding:0 0 10px}.top-line{display:inline-flex}.top-line-item{margin-right:15px}.button-line{margin-top:5px;margin-left:90px}.button-line-item{display:inline-flex;width:150px}.primary-btn{background:#2f749a;color:#fff}`]
            },] },
];
CustomAlertModalComponent.ctorParameters = () => [
    { type: CommonUtilsService },
    { type: MatDialogRef },
    { type: undefined, decorators: [{ type: Inject, args: [MAT_DIALOG_DATA,] }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class PositionHeatMapComponent extends BaseWidgetComponent {
    /**
     * @param {?} chartElement
     * @param {?} zone
     * @param {?} cd
     * @param {?} navSocketService
     * @param {?} shareInfoBeweenComponentsService
     * @param {?} commonUtils
     * @param {?} navService
     * @param {?} resourceManger
     */
    constructor(chartElement, zone, cd, navSocketService, shareInfoBeweenComponentsService, commonUtils, navService, resourceManger) {
        super();
        this.navSocketService = navSocketService;
        this.shareInfoBeweenComponentsService = shareInfoBeweenComponentsService;
        this.commonUtils = commonUtils;
        this.navService = navService;
        this.resourceManger = resourceManger;
        this.syncResults = []; // it's results,  change name to syncResults
        this.topFiveResults = [];
        this.height = 260;
        this.margin = [20, 10, 10, 10];
        this.isDataAvailable = false;
        this.heatMapColorSetting = heatMapColorSetting;
        this.dateNow = new Date();
        this.colorScheme = heatMapColorScheme;
        this.fundInfo = [];
        this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.7;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.syncResults = [];
        this.topFiveResults = [];
        this.subs = [];
        this.isDataAvailable = false;
        this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
        if (this.fundInfo.length > 0) {
            this.renderPositionMap();
        }
        else {
            this.navService.fetchFundList();
            this.navService.getFundList().subscribe(data => {
                console.log("data");
                if (data.length > 0) {
                    console.log(data);
                    /** @type {?} */
                    const fundInfo = [];
                    fundInfo.push(data[0].fundid);
                    fundInfo.push(data[0].name);
                    fundInfo.push(data[0].fundTicker);
                    this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
                    this.renderPositionMap();
                }
            });
        }
    }
    /**
     * @return {?}
     */
    renderPositionMap() {
        this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
        if (this.fundInfo.length > 0) {
            this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(data => {
                this.isDataAvailable = true;
                this.syncResults = this.filterHoldingsToHeatMap(data['holdings']);
                this.topFiveResults = this.filterHoldingsToTopFive(data['holdings']);
            }));
            this.subs.push(this.navSocketService.getNav().subscribe(data => {
                this.updateHeatMap(data.eventData);
            }));
            this.navSocketService.registerFunds([this.fundInfo[0]]);
            this.resourceManger.registInterval(() => { this.syncResults = [...this.syncResults]; }, 400); // set interval time for 0.4 seconds temporarily
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    filterHoldingsToHeatMap(data) {
        /** @type {?} */
        const tempResults = [];
        data.forEach(item => {
            /** @type {?} */
            const obj = {
                "name": item.cusip,
                "value": Math.abs(item.navImpact),
                "navImpact": item.navImpact
            };
            tempResults.push(obj);
        });
        return tempResults;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    filterHoldingsToTopFive(data) {
        /** @type {?} */
        const tempTopFive = [];
        data.sort((itema, itemb) => {
            return itemb.navImpact - itema.navImpact;
            // return Math.abs(itemb.navImpact)  - Math.abs(itema.navImpact); TBC...  if we sort it using real value not absolute value, will make confusion between top five records and heat map chart.
        });
        data.forEach(item => {
            if (tempTopFive.length < 5) {
                /** @type {?} */
                let obj = {
                    "name": item.cusip ? item.cusip : item.name,
                    "value": formatNumber(item.navImpact, 'en-US', '1.5-5')
                };
                tempTopFive.push(obj);
            }
        });
        return tempTopFive;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    updateHeatMap(data) {
        if (data && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
            this.syncResults.forEach(item => {
                if (item.name === data.cusip) {
                    item.value = Math.abs(data.navImpact);
                    item.navImpact = data.navImpact;
                }
            });
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    resizingHeatMap(event) {
        this.width = event.target.innerWidth * 0.7;
    }
    // needs more analyze here
    /**
     * @param {?} value
     * @return {?}
     */
    heatMapValueFormatting(value) {
        // const formatValue =  formatNumber(value, 'en-US', '1.5-5');
        // return formatValue;
        return;
    }
    /**
     * @param {?} obj
     * @return {?}
     */
    heatMapLabelFormatting(obj) {
        /** @type {?} */
        const formatValue = formatNumber(obj.value, 'en-US', '1.5-5');
        return `${obj.label}<br/><small>` + `${formatValue}</small>`;
        // return `${obj.label}<br/><small>Instrument Id Ref</small>`;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.fundInfo.length > 0) {
            this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
            this.subs.forEach(sub => sub.unsubscribe());
        }
        this.resourceManger.cleanResources();
    }
}
PositionHeatMapComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-position-heat-map',
                template: `<div class="position-heat-map-container" *ngIf="isDataAvailable" (window:resize)="resizingHeatMap($event)">

  <div class="heat-map-title">
    <p>Postion | NAV Impact T + 1</p>
  </div> <!-- title-->

  <div class="left-side-panel">
    <p class="panel-title">T + 1 View</p>
    <div  class="date-details">
      <p class="day">{{dateNow | date : 'dd'}}</p>
      <div class="date-items">
        <p>{{dateNow | date : 'EEEE'}}</p>
        <p>{{dateNow | date : 'LLLL'}}</p>
        <p>{{dateNow | date : 'yyyy'}}</p>
      </div>
   </div>
   <ul>
     <li
     *ngFor="let item of topFiveResults; let i = index;"
     >
     <p class="left-name">{{item.name}}</p>
     <p class="right-value">{{item.value}}</p>
     </li>
   </ul>
   <div class="btn-wrapper">
     <a class="view-all-btn">View All Positions</a>
   </div>
  </div> <!-- left side panel-->

  <div class="heat-map-container">
    <position-heat-map-chart
    [syncResults]="syncResults"
    [height]='height'
    [width]='width'
    [margin]='margin'
    [tooltipDisabled]="false"
    [scheme]="colorScheme"
    [valueFormatting]="heatMapValueFormatting"
    [labelFormatting]="heatMapLabelFormatting"
    >
    </position-heat-map-chart>

    <div class="bottom">
    <p>Size represents market cap</p>
    <ul>
      <li
      *ngFor="let item of heatMapColorSetting; let i=index;"
      [style.background]="item.color"
      >{{item.value}}%</li>
    </ul>
  </div>
  </div> <!-- heat map -->

</div>
`,
                styles: [`.position-heat-map-container{height:100%;color:#464646!important}.position-heat-map-container .heat-map-title{position:absolute;top:0;left:15px;font-size:16px}.position-heat-map-container .left-side-panel{display:inline-block;border-right:1px solid #eee;text-align:center;padding:0 20px;width:15%}.position-heat-map-container .left-side-panel .panel-title{margin:10px 0 0;font-size:15px;opacity:.6;text-align:left}.position-heat-map-container .left-side-panel .date-details .day{display:inline-block;font-size:60px;padding:0;margin:0 20px 0 0}.position-heat-map-container .left-side-panel .date-details .date-items{display:inline-block}.position-heat-map-container .left-side-panel .date-details .date-items p{margin:0;padding:0 0 2px;font-size:14px;text-align:left}.position-heat-map-container .left-side-panel ul{list-style-type:none;padding:0}.position-heat-map-container .left-side-panel ul li{margin:12px 0;display:block}.position-heat-map-container .left-side-panel ul li p{display:inline-block;margin:0;width:45%}.position-heat-map-container .left-side-panel ul li .left-name{font-size:16px;text-align:left}.position-heat-map-container .left-side-panel ul li .right-value{font-size:12px;opacity:.9;text-align:right}.position-heat-map-container .left-side-panel .btn-wrapper{padding:10px 0 0}.position-heat-map-container .left-side-panel .btn-wrapper .view-all-btn{border:1px solid rgba(0,0,0,.3);cursor:pointer;border-radius:3px;padding:3px 5px}.position-heat-map-container .heat-map-container{width:70%;display:inline-block;margin-left:25px}.position-heat-map-container .heat-map-container .bottom{text-align:right;font-size:14px}.position-heat-map-container .heat-map-container .bottom p{display:inline-flex;font-style:italic}.position-heat-map-container .heat-map-container .bottom ul{display:inline-flex}.position-heat-map-container .heat-map-container .bottom li{display:inline-flex;padding:0 10px}`]
            },] },
];
PositionHeatMapComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: ChangeDetectorRef },
    { type: NavSocketService },
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService },
    { type: NavService },
    { type: ResourceManagerService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class HeatMapComponent extends BaseChartComponent {
    constructor() {
        super(...arguments);
        this.tooltipDisabled = false;
        this.gradient = false;
        this.scheme = {};
        this.animations = true;
        this.select = new EventEmitter();
    }
    /**
     * @return {?}
     */
    update() {
        super.update();
        this.dims = calculateViewDimensions({
            width: this.width,
            height: 260,
            margins: this.margin
        });
        this.height = 260;
        this.domain = this.getDomain();
        this.treemap = treemap()
            .size([this.dims.width, this.dims.height]);
        /** @type {?} */
        const rootNode = {
            name: 'root',
            value: 0,
            isRoot: true
        };
        /** @type {?} */
        const root = stratify()
            .id(d => {
            /** @type {?} */
            let label = d.name;
            if (label.constructor.name === 'Date') {
                label = label.toLocaleDateString();
            }
            else {
                label = label.toLocaleString();
            }
            return label;
        })
            .parentId(d => d.isRoot ? null : 'root')([rootNode, ...this.syncResults])
            .sum(d => d.value);
        this.data = this.treemap(root);
        this.customColors = this.setCustomColors();
        this.setColors();
        this.transform = `translate(${this.dims.xOffset} , ${this.margin[0]})`;
    }
    /**
     * @return {?}
     */
    setCustomColors() {
        /** @type {?} */
        const arr = [];
        this.syncResults.forEach(item => {
            /** @type {?} */
            let color = '';
            if (item.navImpact <= -3) {
                color = '#B91224';
            }
            else if (item.navImpact > -3 && item.navImpact <= -2) {
                color = '#EAB7BD';
            }
            else if (item.navImpact > -2 && item.navImpact <= 0) {
                color = '#F5DCDE';
            }
            else if (item.navImpact >= 0 && item.navImpact < 2) {
                color = '#DFEAE2';
            }
            else if (item.navImpact >= 2 && item.navImpact < 3) {
                color = '#BED5C5';
            }
            else if (item.navImpact >= 3) {
                color = '#28743E';
            }
            else {
                color = '';
            }
            /** @type {?} */
            let obj = {
                name: item.name,
                value: color
            };
            arr.push(obj);
        });
        return arr;
    }
    /**
     * @return {?}
     */
    getDomain() {
        return this.syncResults.map(d => d.name);
    }
    /**
     * @param {?} data
     * @return {?}
     */
    onClick(data) {
        this.select.emit(data);
    }
    /**
     * @return {?}
     */
    setColors() {
        this.colors = new ColorHelper(this.scheme, 'ordinal', this.domain, this.customColors);
    }
}
HeatMapComponent.decorators = [
    { type: Component, args: [{
                selector: 'position-heat-map-chart',
                template: `<ngx-charts-chart
      [view]="[width, height]"
      [showLegend]="false"
      [animations]="animations">
      <svg:g [attr.transform]="transform" class="tree-map chart">
        <svg:g ngx-charts-tree-map-cell-series
          [colors]="colors"
          [data]="data"
          [dims]="dims"
          [tooltipDisabled]="tooltipDisabled"
          [tooltipTemplate]="tooltipTemplate"
          [valueFormatting]="valueFormatting"
          [labelFormatting]="labelFormatting"
          [gradient]="gradient"
          [animations]="animations"
          (select)="onClick($event)"
        />
      </svg:g>
    </ngx-charts-chart>`,
                styles: [`.tree-map .treemap-val{font-size:1.3em;padding-top:5px;display:inline-block}.tree-map .label p{display:table-cell;text-align:center;line-height:1.2em;vertical-align:middle}`],
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] },
];
HeatMapComponent.propDecorators = {
    syncResults: [{ type: Input }],
    tooltipDisabled: [{ type: Input }],
    valueFormatting: [{ type: Input }],
    labelFormatting: [{ type: Input }],
    gradient: [{ type: Input }],
    height: [{ type: Input }],
    width: [{ type: Input }],
    scheme: [{ type: Input }],
    margin: [{ type: Input }],
    animations: [{ type: Input }],
    select: [{ type: Output }],
    tooltipTemplate: [{ type: ContentChild, args: ['tooltipTemplate',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const singleLineTicksValue = [
    new Date().setHours(9, 30, 0),
    new Date().setHours(12, 0, 0),
    new Date().setHours(14, 0, 0),
    new Date().setHours(16, 0, 0)
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class PositionFundSummaryComponent extends BaseWidgetComponent {
    /**
     * @param {?} chartElement
     * @param {?} zone
     * @param {?} cd
     * @param {?} commonUtils
     * @param {?} navService
     * @param {?} shareInforBewteenComponents
     */
    constructor(chartElement, zone, cd, commonUtils, navService, shareInforBewteenComponents) {
        super();
        this.commonUtils = commonUtils;
        this.navService = navService;
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.dateNow = new Date();
        // temp mock data
        this.summaryAssetsValue = [
            {
                title: 'Total Net Assets: USD',
                value: 5000000
            },
            {
                title: 'Market Value: USD',
                value: 4400000
            }
        ];
        this.threeDayTrendData = [
            {
                day: new Date(),
                details: [
                    {
                        title: 'NAV Price',
                        value: 9.91
                    },
                    {
                        title: 'Market Value',
                        value: '4.3M'
                    },
                    {
                        title: 'NAV Change',
                        value: '-2.05%'
                    }
                ],
                color: ''
            },
            {
                day: new Date(),
                details: [
                    {
                        title: 'NAV Price',
                        value: 10.11
                    },
                    {
                        title: 'Market Value',
                        value: '4.25M'
                    },
                    {
                        title: 'NAV Change',
                        value: '-1.19%'
                    }
                ],
                color: '#DFEAE2'
            },
            {
                day: new Date(),
                details: [
                    {
                        title: 'NAV Price',
                        value: 10.23
                    },
                    {
                        title: 'Market Value',
                        value: '4.05M'
                    },
                    {
                        title: 'NAV Change',
                        value: '1.81%'
                    }
                ],
                color: '#BED5C5'
            }
        ];
        this.results = [];
        this.height = 240;
        this.margin = [20, 100, 30, 50];
        this.colorDomain = [];
        this.tickValues = singleLineTicksValue;
        this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.55;
        this.xScaleMin = commonUtils.startTime;
        this.xScaleMax = commonUtils.endTime;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.navService.getFundList().subscribe(data => {
            if (data.length > 0) {
                this.results = [...this.filterFundData(data)];
            }
        });
        this.colorDomain = this.setColorForSelectedFund();
    }
    /**
     * @return {?}
     */
    setColorForSelectedFund() {
        // need enhancemen here: if the line color should be as same as previous live-line-chart? Temporarily set the color #28743E.
        /** @type {?} */
        const color = [];
        /** @type {?} */
        const selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
        /** @type {?} */
        const obj = {
            fundTicker: selectedFundTicker,
            color: "#28743E"
        };
        color.push(obj);
        return color;
    }
    // below function is duplicated with qnav-line-chart needs extract to a common class.
    /**
     * @param {?} data
     * @return {?}
     */
    filterFundData(data) {
        /** @type {?} */
        const results = [];
        /** @type {?} */
        const selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
        data.forEach(item => {
            if (item['fundTicker'] === selectedFundTicker) {
                /** @type {?} */
                const obj = {
                    'name': item['fundTicker'],
                    'fundID': item['fundid'],
                    'series': this.createSeries(item)
                };
                results.push(obj);
            }
        });
        return results;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    createSeries(data) {
        /** @type {?} */
        const series = [];
        data['priceChanges'].forEach(item => {
            if (this.commonUtils.isValidTime(new Date(item['pricetime']))) {
                /** @type {?} */
                const obj = {
                    'marketval': item['fundmv'],
                    'name': new Date(item['pricetime']),
                    'nav': item['nav'],
                    'value': item['navChangePercent'],
                    'pricetime': item['pricetime']
                };
                series.push(obj);
            }
        });
        if (series.length == 0) {
            /** @type {?} */
            const obj = {
                'marketval': data['fundmv'],
                'name': this.xScaleMin,
                'nav': data['nav'],
                'value': 0,
                'pricetime': this.commonUtils.startTime
            };
            series.push(obj);
        }
        return series;
    }
    /**
     * @param {?} v
     * @return {?}
     */
    xAxisTickFormatting(v) {
        /** @type {?} */
        const tempDate = new Date(v);
        return formatDate(tempDate, "h:mm aaaaa'm'", 'en-US');
    }
    /**
     * @param {?} value
     * @return {?}
     */
    getValueSty(value) {
        /** @type {?} */
        let color = '';
        if (value.toString().indexOf('%') !== -1) {
            if (value.toString().indexOf('-')) {
                color = '#28743E';
            }
            else {
                color = '#B91224';
            }
        }
        return color;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.colorDomain = [];
    }
    /**
     * @param {?} event
     * @return {?}
     */
    resizingSingleLineChart(event) {
        this.width = event.target.innerWidth * 0.55;
    }
}
PositionFundSummaryComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-position-fund-summary',
                template: `<div class="position-fund-summary-container" (window:resize)="resizingSingleLineChart($event)">

  <div class="fund-summary-title">
    <p>Fund Summary | {{dateNow | date : 'longDate'}}</p>
  </div> <!-- title-->

  <div class="main-body-wrapper">

    <div class="top-search">
      <input type="text" placeholder="Search Mutual Fund Name"/>
      <mat-icon svgIcon="search" ></mat-icon>
    </div> <!--If need use angular search component ?-->

    <div class="left-side-panel-wrapper">
      <div class="left-side-panel"
      *ngFor="let item of summaryAssetsValue; let i = index;"
      >
        <p>{{item.value | currency : 'USD': '' : '5.0-0'}}</p>
        <label>{{item.title}}</label>
    </div>
    </div>

   <div class="single-line-chart">

     <div class="floating-rect-wrapper">
       <div class="top-left-info">
         <p class="top-left-info-v">500,000</p>
         <label>Shares Outstanding</label>
       </div>
       <div class="top-rightt-info">
         <label>Market Value Change: Today</label>
         <p class="top-rightt-info-v">+100,000</p>
         <p class="top-rightt-info-v">+0.03%</p>
       </div>
       <div class="middle-info">
         4,400,000
       </div>
       <div class="bottom-info">
         4,300,000
       </div>
     </div>

    <lib-single-line-chart
      [results]='results'
      [height]='height'
      [width]='width'
      [margin]='margin'
      [colorDomain]='colorDomain'
      [tickValues]='tickValues'
      [xAxisTickFormatting]='xAxisTickFormatting'
      [xScaleMin]='xScaleMin'
      [xScaleMax]='xScaleMax'
      >
    </lib-single-line-chart>
   </div>

   <div class="right-side-grid-wrapper">
     <h4>Your Three Day Trend</h4>
       <div
       *ngFor="let oneDayData of threeDayTrendData; let i = index;"
       [style.background]="oneDayData.color"
       class="three-day-data-details-item"
       >
         <label class="detail-item-date">{{oneDayData.day | date : 'longDate'}}</label>
         <ul>
           <li
           *ngFor="let item of oneDayData.details;"
           >
             <p
             [style.color]="getValueSty(item.value)"
             >{{item.value}}</p>
             <label>{{item.title}}</label>
           </li>
         </ul>
       </div>
     </div>

  </div><!-- main-->
</div>`,
                styles: [`.position-fund-summary-container{font-family:DINNextLTPro-Medium;color:#464646}.position-fund-summary-container .fund-summary-title{position:absolute;top:0;left:15px;font-size:16px}.position-fund-summary-container .main-body-wrapper .top-search{position:absolute;top:60px;left:20px}.position-fund-summary-container .main-body-wrapper .top-search input{width:160px;padding:8px 20px;display:inline-block}.position-fund-summary-container .main-body-wrapper .top-search mat-icon{position:absolute;top:0;left:200px;background-color:#86bbd1;padding:5px 5px 6px 8px;cursor:pointer}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper{display:inline-block;margin-left:20px;padding-top:40px}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper .left-side-panel p{font-size:40px;margin:10px 0;padding:0}.position-fund-summary-container .main-body-wrapper .left-side-panel-wrapper .left-side-panel label{font-size:14px;margin:0;padding:0}.position-fund-summary-container .main-body-wrapper .single-line-chart{display:inline-block;height:250px;margin:0 20px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper{position:relative}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper div{position:absolute}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper p{margin:0}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper label{display:block;font-size:12px;text-align:right}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-left-info{top:-65px;right:250px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-left-info .top-left-info-v{text-align:right;font-size:25px;margin-bottom:6px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-rightt-info{top:-70px;right:10px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .top-rightt-info .top-rightt-info-v{display:inline-block;background-color:#28743e;color:#faebd7;padding:5px 16px;font-size:18px;margin-top:6px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .middle-info{top:25px;right:10px;background-color:#28743e;color:#faebd7;font-size:16px;padding:2px 15px 2px 5px}.position-fund-summary-container .main-body-wrapper .single-line-chart .floating-rect-wrapper .bottom-info{top:80px;right:10px;background-color:#727272;color:#faebd7;font-size:16px;padding:2px 15px 2px 5px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper{display:inline-block}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item{padding:10px 0}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item .detail-item-date{margin-left:10px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item label{font-size:12px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul{list-style-type:none;margin:0;padding:0}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul li{display:inline-block;margin:10px}.position-fund-summary-container .main-body-wrapper .right-side-grid-wrapper .three-day-data-details-item ul li p{margin:0}`]
            },] },
];
PositionFundSummaryComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: ChangeDetectorRef },
    { type: CommonUtilsService },
    { type: NavService },
    { type: ShareInfoBeweenComponentsService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class SingleLineChartComponent extends BaseChartComponent {
    /**
     * @param {?} chartElement
     * @param {?} zone
     * @param {?} cd
     * @param {?} commonUtils
     * @param {?} datePipe
     */
    constructor(chartElement, zone, cd, commonUtils, datePipe) {
        super(chartElement, zone, cd);
        this.commonUtils = commonUtils;
        this.datePipe = datePipe;
        this.legendTitle = 'Legend';
        this.showGridLines = true;
        this.curve = curveLinear;
        this.roundDomains = false;
        this.tooltipDisabled = true; // if need tooltip then set tooltipObj
        this.showRefLines = false;
        this.showRefLabels = false;
        this.colorDomain = [];
        this.tickValues = [];
        this.activeEntries = [];
        this.activate = new EventEmitter();
        this.deactivate = new EventEmitter();
        this.xAxisHeight = 0;
        this.yAxisWidth = 0;
        this.timelineHeight = 50;
        this.timelinePadding = 10;
        this.tooltipObj = {};
    }
    /**
     * @return {?}
     */
    update() {
        this.dims = calculateViewDimensions({
            width: this.width,
            height: this.height,
            margins: this.margin,
            xAxisHeight: this.xAxisHeight,
            yAxisWidth: this.yAxisWidth,
            showXLabel: this.showXAxisLabel,
            showYLabel: this.showYAxisLabel,
            showLegend: this.legend,
            legendType: this.schemeType,
        });
        if (this.timeline) {
            this.dims.height -= (this.timelineHeight + this.margin[2] + this.timelinePadding);
        }
        this.xDomain = this.getXDomain();
        if (this.filteredDomain) {
            this.xDomain = this.filteredDomain;
        }
        this.yDomain = this.getYDomain();
        this.seriesDomain = this.getSeriesDomain();
        this.xScale = this.getXScale(this.xDomain, this.dims.width);
        this.yScale = this.getYScale(this.yDomain, this.dims.height);
        this.customColors = this.setCustomcolors();
        this.setColors();
        this.legendOptions = this.getLegendOptions();
        this.transform = `translate(${this.dims.xOffset} , ${this.margin[0]})`;
        this.clipPathId = 'clip' + id().toString();
        this.clipPath = `url(#${this.clipPathId})`;
    }
    /**
     * @return {?}
     */
    setCustomcolors() {
        /** @type {?} */
        let arr = [];
        this.results.forEach(item => {
            this.colorDomain.forEach(color => {
                if (item['name'] === color['fundTicker']) {
                    /** @type {?} */
                    let obj = {
                        name: color.fundTicker,
                        value: color.color
                    };
                    arr.push(obj);
                }
            });
        });
        return arr;
    }
    /**
     * @return {?}
     */
    getXDomain() {
        /** @type {?} */
        let values = getUniqueXDomainValues(this.results);
        this.scaleType = this.getScaleType(values);
        /** @type {?} */
        let domain = [];
        if (this.scaleType === 'linear') {
            values = values.map(v => Number(v));
        }
        /** @type {?} */
        let min;
        /** @type {?} */
        let max;
        if (this.scaleType === 'time' || this.scaleType === 'linear') {
            min = this.xScaleMin
                ? this.xScaleMin
                : Math.min(...values);
            max = this.xScaleMax
                ? this.xScaleMax
                : Math.max(...values);
        }
        if (this.scaleType === 'time') {
            domain = [new Date(min), new Date(max)];
            this.xSet = [...values].sort((a, b) => {
                /** @type {?} */
                const aDate = a.getTime();
                /** @type {?} */
                const bDate = b.getTime();
                if (aDate > bDate)
                    return 1;
                if (bDate > aDate)
                    return -1;
                return 0;
            });
        }
        else if (this.scaleType === 'linear') {
            domain = [min, max];
            // Use compare function to sort numbers numerically
            this.xSet = [...values].sort((a, b) => (a - b));
        }
        else {
            domain = values;
            this.xSet = values;
        }
        return domain;
    }
    /**
     * @return {?}
     */
    getYDomain() {
        /** @type {?} */
        const domain = [];
        for (const results of this.results) {
            for (const d of results.series) {
                if (d.value && domain.indexOf(d.value) < 0) {
                    domain.push(d.value);
                }
                if (d.min !== undefined) {
                    this.hasRange = true;
                    if (domain.indexOf(d.min) < 0) {
                        domain.push(d.min);
                    }
                }
                if (d.max !== undefined) {
                    this.hasRange = true;
                    if (domain.indexOf(d.max) < 0) {
                        domain.push(d.max);
                    }
                }
            }
        }
        /** @type {?} */
        const values = [...domain];
        if (!this.autoScale) {
            values.push(0);
        }
        /** @type {?} */
        const min = this.yScaleMin
            ? this.yScaleMin
            : Math.min(...values);
        /** @type {?} */
        const max = this.yScaleMax
            ? this.yScaleMax
            : Math.max(...values);
        if (min && max) {
            return [min, max];
        }
        else {
            return [-0.1, 0.1];
        }
    }
    /**
     * @return {?}
     */
    getSeriesDomain() {
        return this.results.map(d => d.name);
    }
    /**
     * @param {?} domain
     * @param {?} width
     * @return {?}
     */
    getXScale(domain, width) {
        /** @type {?} */
        let scale;
        if (this.scaleType === 'time') {
            scale = scaleTime()
                .range([0, width])
                .domain(domain);
        }
        else if (this.scaleType === 'linear') {
            scale = scaleLinear()
                .range([0, width])
                .domain(domain);
            if (this.roundDomains) {
                scale = scale.nice();
            }
        }
        else if (this.scaleType === 'ordinal') {
            scale = scalePoint()
                .range([0, width])
                .padding(0.1)
                .domain(domain);
        }
        return scale;
    }
    /**
     * @param {?} domain
     * @param {?} height
     * @return {?}
     */
    getYScale(domain, height) {
        /** @type {?} */
        const scale = scaleLinear()
            .range([height, 0])
            .domain(domain);
        return this.roundDomains ? scale.nice() : scale;
    }
    /**
     * @param {?} values
     * @return {?}
     */
    getScaleType(values) {
        /** @type {?} */
        let date = true;
        /** @type {?} */
        let num = true;
        for (const value of values) {
            if (!this.isDate(value)) {
                date = false;
            }
            if (typeof value !== 'number') {
                num = false;
            }
        }
        if (date)
            return 'time';
        if (num)
            return 'linear';
        return 'ordinal';
    }
    /**
     * @param {?} value
     * @return {?}
     */
    isDate(value) {
        if (value instanceof Date) {
            return true;
        }
        return false;
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    updateYAxisWidth({ width }) {
        this.yAxisWidth = width;
        this.update();
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    updateXAxisHeight({ height }) {
        this.xAxisHeight = height;
        this.update();
    }
    /**
     * @param {?} item
     * @return {?}
     */
    updateHoveredVertical(item) {
        this.hoveredVertical = item.value;
        this.deactivateAll();
    }
    /**
     * @return {?}
     */
    hideCircles() {
        this.hoveredVertical = null;
        this.deactivateAll();
    }
    /**
     * @param {?} series
     * @return {?}
     */
    onMouseEnter(series) {
        this.activate.emit(series);
    }
    /**
     * @param {?} series
     * @return {?}
     */
    onMouseLeave(series) {
        this.deactivate.emit(series);
    }
    /**
     * @param {?} data
     * @param {?=} series
     * @return {?}
     */
    onClick(data, series) {
        if (series) {
            data.series = series.name;
        }
        this.select.emit(data);
    }
    /**
     * @param {?} index
     * @param {?} item
     * @return {?}
     */
    trackBy(index, item) {
        return item.name;
    }
    /**
     * @return {?}
     */
    setColors() {
        /** @type {?} */
        let domain;
        if (this.schemeType === 'ordinal') {
            domain = this.seriesDomain;
        }
        else {
            domain = this.yDomain;
        }
        this.colors = new ColorHelper(this.scheme, this.schemeType, domain, this.customColors);
    }
    /**
     * @return {?}
     */
    getLegendOptions() {
        /** @type {?} */
        const opts = {
            scaleType: this.schemeType,
            colors: undefined,
            domain: [],
            title: undefined
        };
        if (opts.scaleType === 'ordinal') {
            opts.domain = this.seriesDomain;
            opts.colors = this.colors;
            opts.title = this.legendTitle;
        }
        else {
            opts.domain = this.yDomain;
            opts.colors = this.colors.scale;
        }
        return opts;
    }
    /**
     * @param {?} item
     * @return {?}
     */
    onActivate(item) {
        this.deactivateAll();
        /** @type {?} */
        const idx = this.activeEntries.findIndex(d => {
            return d.name === item.name && d.value === item.value;
        });
        if (idx > -1) {
            return;
        }
        this.activeEntries = [item];
        this.activate.emit({ value: item, entries: this.activeEntries });
    }
    /**
     * @param {?} item
     * @return {?}
     */
    onDeactivate(item) {
        /** @type {?} */
        const idx = this.activeEntries.findIndex(d => {
            return d.name === item.name && d.value === item.value;
        });
        this.activeEntries.splice(idx, 1);
        this.activeEntries = [...this.activeEntries];
        this.deactivate.emit({ value: item, entries: this.activeEntries });
    }
    /**
     * @return {?}
     */
    deactivateAll() {
        this.activeEntries = [...this.activeEntries];
        for (const entry of this.activeEntries) {
            this.deactivate.emit({ value: entry, entries: [] });
        }
        this.activeEntries = [];
    }
}
SingleLineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-single-line-chart',
                template: `<div class="custom-chart">
  <ngx-charts-chart 
      [view]="[width, height]"
      [showLegend]="false"
      [legendOptions]="legendOptions"
      [activeEntries]="activeEntries"
      [animations]="animations"
      (legendLabelClick)="onClick($event)"
      (legendLabelActivate)="onActivate($event)"
      (legendLabelDeactivate)="onDeactivate($event)">
      <svg:defs>
        <svg:clipPath [attr.id]="clipPathId">
          <svg:rect
            [attr.width]="dims.width + 10"
            [attr.height]="dims.height + 10"
            [attr.transform]="'translate(-5, -5)'"/>
        </svg:clipPath>
      </svg:defs>
      <svg:g [attr.transform]="transform" class="line-chart chart">
        <svg:g ngx-charts-x-axis 
          [xScale]="xScale"
          [dims]="dims"
          [showLabel]="showXAxisLabel"
          [showGridLines]="showGridLines"
          [labelText]="xAxisLabel"
          [ticks]="tickValues"
          [tickFormatting]="xAxisTickFormatting"
          (dimensionsChanged)="updateXAxisHeight($event)">
        </svg:g>
        <svg:g ngx-charts-y-axis
          [yScale]="yScale"
          [dims]="dims"
          [showLabel]="showYAxisLabel"
          [labelText]="yAxisLabel"
          [referenceLines]="referenceLines"
          [showRefLines]="showRefLines"
          [showGridLines]="showGridLines"
          [showRefLabels]="showRefLabels"
          (dimensionsChanged)="updateYAxisWidth($event)">
        </svg:g>

        <svg:g [attr.clip-path]="clipPath">
          <svg:g *ngFor="let series of results; trackBy:trackBy" [@animationState]="'active'">
            <svg:g ngx-charts-line-series
              [xScale]="xScale"
              [yScale]="yScale"
              [colors]="colors"
              [data]="series"
              [activeEntries]="activeEntries"
              [scaleType]="scaleType"
              [curve]="curve"
              [rangeFillOpacity]="rangeFillOpacity"
              [hasRange]="hasRange"
              [animations]="animations"
            />
          </svg:g>
          <svg:g *ngIf="!tooltipDisabled" (mouseleave)="hideCircles()">
            <svg:g ngx-charts-tooltip-area
              [dims]="dims"
              [xSet]="xSet"
              [xScale]="xScale"
              [yScale]="yScale"
              [results]="results"
              [colors]="colors"
              [tooltipDisabled]="!tooltipDisabled"
              (hover)="updateHoveredVertical($event)"
            />

            <svg:g *ngFor="let series of results">
              <svg:g ngx-charts-circle-series
                [xScale]="xScale"
                [yScale]="yScale"
                [colors]="colors"
                [data]="series"
                [scaleType]="scaleType"
                [visibleValue]="hoveredVertical"
                [activeEntries]="activeEntries"
                (select)="onClick($event, series)"
                (activate)="onActivate($event)"
                (deactivate)="onDeactivate($event)"
                [tooltipTemplate]="tooltipTemplate"
              />
            </svg:g>
        
          </svg:g>
        </svg:g>
      </svg:g>
  </ngx-charts-chart>
  <ng-template #tooltipTemplate>
    <div class="single-tooltip">
    </div>
  </ng-template>
</div>`,
                styles: [``],
                encapsulation: ViewEncapsulation.ShadowDom,
                changeDetection: ChangeDetectionStrategy.OnPush,
                animations: [
                    trigger('animationState', [
                        transition(':leave', [
                            style({
                                opacity: 1,
                            }),
                            animate(500, style({
                                opacity: 0
                            }))
                        ])
                    ])
                ]
            },] },
];
SingleLineChartComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: ChangeDetectorRef },
    { type: CommonUtilsService },
    { type: DatePipe }
];
SingleLineChartComponent.propDecorators = {
    legend: [{ type: Input }],
    legendTitle: [{ type: Input }],
    showXAxisLabel: [{ type: Input }],
    showYAxisLabel: [{ type: Input }],
    xAxisLabel: [{ type: Input }],
    yAxisLabel: [{ type: Input }],
    autoScale: [{ type: Input }],
    timeline: [{ type: Input }],
    gradient: [{ type: Input }],
    showGridLines: [{ type: Input }],
    curve: [{ type: Input }],
    schemeType: [{ type: Input }],
    rangeFillOpacity: [{ type: Input }],
    xAxisTickFormatting: [{ type: Input }],
    yAxisTickFormatting: [{ type: Input }],
    xAxisTicks: [{ type: Input }],
    yAxisTicks: [{ type: Input }],
    roundDomains: [{ type: Input }],
    tooltipDisabled: [{ type: Input }],
    showRefLines: [{ type: Input }],
    referenceLines: [{ type: Input }],
    showRefLabels: [{ type: Input }],
    xScaleMin: [{ type: Input }],
    xScaleMax: [{ type: Input }],
    yScaleMin: [{ type: Input }],
    yScaleMax: [{ type: Input }],
    selectable: [{ type: Input }],
    height: [{ type: Input }],
    width: [{ type: Input }],
    margin: [{ type: Input }],
    colorDomain: [{ type: Input }],
    results: [{ type: Input }],
    tickValues: [{ type: Input }],
    activeEntries: [{ type: Input }],
    activate: [{ type: Output }],
    deactivate: [{ type: Output }],
    tooltipTemplate: [{ type: ContentChild, args: ['tooltipTemplate',] }],
    hideCircles: [{ type: HostListener, args: ['mouseleave',] }],
    onMouseEnter: [{ type: HostListener, args: ['mouseenter', ["series"],] }],
    onMouseLeave: [{ type: HostListener, args: ['mouseleave', ["$event"],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class CommonDataTableComponent {
    /**
     * @param {?} cd
     * @param {?} viewContainer
     * @param {?} shareInforBewteenComponents
     * @param {?} commonUtils
     */
    constructor(cd, viewContainer, shareInforBewteenComponents, commonUtils) {
        this.cd = cd;
        this.viewContainer = viewContainer;
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.commonUtils = commonUtils;
        // data
        this.headerSetting = true;
        this.headerHeight = 50;
        this.isDataTablePaused = false;
        this.rows = [];
        this.childRows = [];
        this.alertData = [];
        this.rowHeight = 50;
        this.customColumn = []; //type No. Details
        this.normalColumn = []; // width, draggable, canAutoResize  prop headerClass cellClass headerTemplate cellTemplate columnSetting etc.
        this.limit = 5;
        this.footerHeight = 50;
        this.headerCheckBox = false;
        this.columnMenuDropDownSetting = [];
        this.menuClosed = new EventEmitter();
        this.togglePauseFlagEvent = new EventEmitter();
        this.expandChild = false;
        this.isSelectedMap = [];
        this.expandCollapseIconMap = [];
        this.getSortIconDisplayFlag = {};
        this.isDataAvailable = false;
        this.ascFlag = 'asc';
        shareInforBewteenComponents.clickedOutSide.subscribe(e => {
            // this.selectedCol = '';
        });
    }
    /**
     * @param {?} row
     * @return {?}
     */
    hasChildren(row) {
        return this.childRows.findIndex(item => { return item.fundid === row.fundid; }) === -1 ? false : true;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.expandCollapseIconMap = this.setDefaultExpandCollapseMapping(this.rows);
        this.getSortIconDisplayFlag = this.setDefaultSortIconDisplayFlag(this.normalColumn);
        this.expandChild = this.childRows.length > 0 ? true : false;
        this.isDataAvailable = this.rows.length > 0 ? true : false;
        /** @type {?} */
        let data = this.getSortColumnDetailsInfo();
        this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const layOutComp = document.getElementsByClassName('layout-item')[1];
        if (layOutComp) {
            layOutComp.classList.add('table-layout');
            this.onResize(event);
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    setDefaultExpandCollapseMapping(data) {
        /** @type {?} */
        let mappingArr = [];
        data.forEach(item => {
            /** @type {?} */
            let obj = {
                fundid: item.fundid,
                expand: false
            };
            mappingArr.push(obj);
        });
        return mappingArr;
    }
    /**
     * @param {?} column
     * @return {?}
     */
    setDefaultSortIconDisplayFlag(column) {
        /** @type {?} */
        let tempMap = {};
        column.forEach(item => {
            /** @type {?} */
            let obj = new Object();
            obj[item.prop] = false;
            tempMap = Object.assign(_.cloneDeep(tempMap), obj);
        });
        return tempMap;
    }
    /**
     * @return {?}
     */
    getSortColumnDetailsInfo() {
        /** @type {?} */
        let obj = {
            map: this.expandCollapseIconMap,
            prop: this.defaultSortCol,
            ascFlag: true
        };
        this.normalColumn.forEach(item => {
            if (item.sortColumnAscOrDesc) {
                obj = {
                    map: this.expandCollapseIconMap,
                    prop: item.prop,
                    ascFlag: item.sortColumnAscOrDesc === 'asc' ? true : false
                };
            }
        });
        return obj;
    }
    /**
     * @param {?} column
     * @return {?}
     */
    getHeaderClass(column) {
        switch (column.headerClassFormat) {
            case 'headerLeft':
                return 'columnHeader header-align-left';
            case 'headerCenter':
                return 'columnHeader header-align-center';
            case 'headerRight':
                return 'columnHeader header-align-right';
            default:
                return 'columnHeader';
        }
    }
    /**
     * @param {?} row
     * @param {?} column
     * @param {?} value
     * @return {?}
     */
    getCellClass(row, column, value) {
        switch (column.cellClassFormat) {
            case 'cellLeft':
                return ' align-left';
            case 'cellRight':
                return ' align-right';
            case 'cellNumber':// need more anlyze here
                if (value !== 0) {
                    if (value.toString().indexOf('-') !== -1 && value.toString().indexOf('-') === 0) {
                        return ' is-nagetive';
                    }
                    else {
                        return ' is-positive';
                    }
                }
                else if (column.prop === 'navChangePercent') {
                    if (row['navChange'].toString().indexOf('-') !== -1 && row['navChange'].toString().indexOf('-') === 0) {
                        return ' is-nagetive';
                    }
                    else {
                        return ' is-positive';
                    }
                }
                else if (column.prop === 'fundmvChangePercent') {
                    if (row['fundmvChange'].toString().indexOf('-') !== -1 && row['fundmvChange'].toString().indexOf('-') === 0) {
                        return ' is-nagetive';
                    }
                    else {
                        return ' is-positive';
                    }
                }
                else if (value === 0) {
                    return ' is-zero';
                }
            // tslint:disable-next-line:no-switch-case-fall-through
            default:
                return;
        }
    }
    /**
     * @param {?} col
     * @return {?}
     */
    getColSettingWidth(col) {
        if (col && col.width && !isNaN(Number(col.width))) {
            return col.width;
        }
        else {
            return 150;
        }
    }
    /**
     * @param {?} fund
     * @param {?} classID
     * @return {?}
     */
    showYellowAlert(fund, classID) {
        /** @type {?} */
        let show = false;
        show = this.alertData.find(item => item.name === fund && item.classID === classID && item.alertType === 1);
        return show;
    }
    /**
     * @param {?} fund
     * @param {?} classID
     * @return {?}
     */
    showRedAlert(fund, classID) {
        /** @type {?} */
        let show = false;
        show = this.alertData.find(item => item.name === fund && item.classID === classID && item.alertType === 2);
        return show;
    }
    /**
     * @param {?} row
     * @return {?}
     */
    showNews(row) {
        // according to row info to determine show news icon or not 
        return true;
    }
    /**
     * @param {?} row
     * @return {?}
     */
    getSideColorStyle(row) {
        /** @type {?} */
        let backgroundColor = '';
        this.shareInforBewteenComponents.colorSchema.forEach(item => {
            if (row && row['fundid'] && item['fundid'] === row['fundid']) {
                backgroundColor = item['color'];
            }
        });
        return backgroundColor;
    }
    /**
     * @param {?} row
     * @return {?}
     */
    toggleExpandRow(row) {
        /** @type {?} */
        const parentFundId = row.fundid;
        /** @type {?} */
        let currentExpand;
        this.expandCollapseIconMap.forEach(item => {
            if (parentFundId === item.fundid) {
                item.expand = !item.expand;
                currentExpand = item.expand;
            }
        });
        /** @type {?} */
        const index = this.rows.findIndex(item => { return item.fundid === parentFundId; });
        this.childRows.forEach(item => {
            if (item.fundid === parentFundId) {
                currentExpand ? this.rows.splice(index + 1, 0, item) : this.rows.splice(index + 1, 1);
            }
        });
    }
    /**
     * @param {?} row
     * @return {?}
     */
    getExpandCollapseIcon(row) {
        /** @type {?} */
        const fundid = row.fundid;
        /** @type {?} */
        let expandFlag = false;
        this.expandCollapseIconMap.forEach(item => {
            if (fundid === item.fundid)
                expandFlag = item.expand;
        });
        return row.child === "child" ? "" : expandFlag ? "arrow_down" : "arrow_right";
    }
    /**
     * @param {?} para
     * @return {?}
     */
    getRowHeight(para) {
        // debugger;
        para === 'standard' ? this.rowHeight = 50 : this.rowHeight = 40;
    }
    /**
     * @param {?} e
     * @return {?}
     */
    onClickedOutside(e) {
        this.shareInforBewteenComponents.clickedOutSide.emit(e);
    }
    /**
     * @param {?} event
     * @param {?} prop
     * @return {?}
     */
    selectCurrentCol(event, prop) {
        this.selectedCol = prop;
        event.currentTarget.classList.add("drop-is-visible");
    }
    /**
     * @return {?}
     */
    closeMenu() {
        document.getElementsByClassName("drop-is-visible")[0].classList.remove("drop-is-visible");
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onResize(event) {
        //calcute  datatable-body height according to gridster-item height 
        /** @type {?} */
        var height = Number(((/** @type {?} */ (document.getElementsByClassName('table-layout')[0]))).style.height.slice(0, length - 2));
        /** @type {?} */
        var tableBodyHeight = 260;
        height = (height - 148) > tableBodyHeight ? tableBodyHeight : height - 148;
        if (document.getElementsByClassName('datatable-body')[0]) {
            ((/** @type {?} */ (document.getElementsByClassName('datatable-body')[0]))).style.height = height + 'px';
        }
    }
    /**
     * @param {?} name
     * @return {?}
     */
    getMatMenuItemDisplayname(name) {
        switch (name) {
            case 'Sort Column':
                return this.getSortIconDisplayFlag[this.selectedCol] ? 'Disable Sort' : 'Sort Column';
            case 'Freeze Column':
                return this.getFrozenIconDisplayFalg(this.selectedCol) ? 'Unfreeze Column' : 'Freeze Column';
            default:
                return name;
        }
    }
    /**
     * @param {?} colProp
     * @return {?}
     */
    getFrozenIconDisplayFalg(colProp) {
        /** @type {?} */
        let freezeFlag = false;
        this.normalColumn.forEach(item => {
            if (item.prop === colProp && item.frozenLeft) {
                freezeFlag = true;
            }
        });
        return freezeFlag;
    }
    /**
     * @param {?} type
     * @return {?}
     */
    handleMenuItemClick(type) {
        switch (type) {
            case 'resizeToFit':
                this.resizeToFit();
                return;
            case 'freezeColumn':
                this.freezeColumn();
                return;
            case 'sortColumn':
                this.sortColumn();
                return;
            default:
                return;
        }
    }
    //todo...
    /**
     * @return {?}
     */
    resizeToFit() {
        console.log(this.selectedCol);
        this.selectedCol = "";
    }
    /**
     * @return {?}
     */
    freezeColumn() {
        this.normalColumn.forEach((item, i) => {
            if (item.prop == this.selectedCol) {
                item.frozenLeft = !item.frozenLeft;
            }
        });
    }
    /**
     * @param {?} selectedCol
     * @return {?}
     */
    syncColumnSettingForSortFlag(selectedCol) {
        this.normalColumn.forEach((item, i) => {
            if (item.prop === selectedCol) {
                item.sortColumnAscOrDesc = this.ascFlag;
            }
            else {
                item.sortColumnAscOrDesc = '';
            }
        });
    }
    /**
     * @return {?}
     */
    sortColumn() {
        this.syncColumnSettingForSortFlag(this.selectedCol);
        for (let key in this.getSortIconDisplayFlag) {
            if (key === this.selectedCol) {
                if (!this.getSortIconDisplayFlag[key]) {
                    /** @type {?} */
                    let data = {
                        map: this.expandCollapseIconMap,
                        prop: this.selectedCol,
                        ascFlag: true
                    };
                    this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                }
                else {
                    // the default order is sorted by fundid.
                    /** @type {?} */
                    let data = {
                        map: this.expandCollapseIconMap,
                        prop: this.defaultSortCol,
                        ascFlag: true
                    };
                    this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
                }
                this.getSortIconDisplayFlag[key] = !this.getSortIconDisplayFlag[key];
            }
            else {
                this.getSortIconDisplayFlag[key] = false;
            }
        }
        this.selectedCol = "";
    }
    /**
     * @param {?} e
     * @param {?} prop
     * @return {?}
     */
    changeAscAndDescSort(e, prop) {
        e.stopPropagation();
        if (this.ascFlag === "asc") {
            this.ascFlag = "desc";
            /** @type {?} */
            let data = {
                map: this.expandCollapseIconMap,
                prop: prop,
                ascFlag: false
            };
            this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
        }
        else if (this.ascFlag === "desc") {
            this.ascFlag = "asc";
            /** @type {?} */
            let data = {
                map: this.expandCollapseIconMap,
                prop: prop,
                ascFlag: true
            };
            this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
        }
        this.syncColumnSettingForSortFlag(prop);
        this.selectedCol = "";
    }
    /**
     * @param {?} prop
     * @return {?}
     */
    getSortIconDisplaySty(prop) {
        /** @type {?} */
        let visibility = false;
        this.normalColumn.forEach(item => {
            if (item.prop === prop && item.sortColumnAscOrDesc)
                visibility = true;
        });
        return visibility;
    }
    /**
     * @param {?} prop
     * @return {?}
     */
    getSortIcon(prop) {
        /** @type {?} */
        let icon = '';
        this.normalColumn.forEach(item => {
            if (item.prop === prop)
                icon = item.sortColumnAscOrDesc;
        });
        if (icon !== '') {
            return icon === "asc" ? "circle_arrow_up" : "circle_arrow_down";
        }
        else {
            return this.ascFlag === "asc" ? "circle_arrow_up" : "circle_arrow_down";
        }
    }
    /**
     * @param {?} col
     * @param {?} index
     * @return {?}
     */
    removeOrAddColumn(col, index) {
        console.log(col.prop + "---" + index + "--" + this.selectedCol);
        this.selectedCol = "";
    }
    /**
     * @param {?} row
     * @return {?}
     */
    hyperLinkNavigate(row) {
        this.shareInforBewteenComponents.hyperLinkNavigate.emit(row);
    }
    /**
     * @param {?} row
     * @param {?} type
     * @return {?}
     */
    openAlertModal(row, type) {
        /** @type {?} */
        let obj = {
            rowData: row,
            type: type
        };
        this.shareInforBewteenComponents.openModalData.emit(obj);
    }
    /**
     * @return {?}
     */
    togglePauseFlag() {
        this.isDataTablePaused = !this.isDataTablePaused;
        this.togglePauseFlagEvent.emit();
    }
}
CommonDataTableComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-common-data-table',
                template: `<div *ngIf="isDataAvailable" style="height:50px" class="main-box" (clickOutside)="onClickedOutside($event)">

  <div *ngIf="headerSetting" class="more-icon">
    <button mat-icon-button [matMenuTriggerFor]="menu">
      <mat-icon svgIcon="more"></mat-icon>
    </button>
    <mat-menu #menu="matMenu" [overlapTrigger]='false'>
      <button mat-menu-item [matMenuTriggerFor]="adjustRowHeight">
        <span>Row Height</span>
      </button>
      <button *ngIf='!isDataTablePaused' mat-menu-item (click)="togglePauseFlag()">
        <span>Pause</span>
      </button>  
      <button *ngIf='isDataTablePaused' mat-menu-item (click)="togglePauseFlag()">
        <span>Un-Pause</span>
      </button>    
    </mat-menu>

    <mat-menu #adjustRowHeight="matMenu">
      <button mat-menu-item (click)="getRowHeight('standard')">Standard
        <mat-icon *ngIf='rowHeight==50' svgIcon="check" class="check-icon"></mat-icon>
      </button>
      <button mat-menu-item (click)="getRowHeight('small')">Small
        <mat-icon *ngIf='rowHeight==40' svgIcon="check" class="check-icon"></mat-icon>
      </button>
    </mat-menu>
  </div>
  <!--rowHeight setting-->

  <!--column menu dropdow-->
  <div>
    <mat-menu #columnHeaderMenu="matMenu" [overlapTrigger]='false'>
      <span *ngFor="let item of columnMenuDropDownSetting">
        <button mat-menu-item *ngIf="!item.hasSubMenu">
          <span (click)="handleMenuItemClick(item.type)">{{getMatMenuItemDisplayname(item.name)}}</span>
        </button>
        <button mat-menu-item *ngIf="item.hasSubMenu" [matMenuTriggerFor]="additionalFunctions">
          <span>{{item.name}}</span>
        </button>
      </span>
    </mat-menu>


    <mat-menu #additionalFunctions="matMenu">
      <button *ngFor="let col of normalColumn;let i=index;" mat-menu-item (click)="removeOrAddColumn(col, i)">
        <span class="dropdowMenuListSty">{{col.name}}</span>
        <mat-icon *ngIf='1===1' svgIcon="check" class="check-icon"></mat-icon>
      </button>
    </mat-menu>
  </div>


  <ngx-datatable 
    #mydatatable 
    class="material expandable" 
    [headerHeight]="headerHeight" 
    [limit]="limit"
    [scrollbarH]='true' 
    [columnMode]="'force'" 
    [footerHeight]="footerHeight" 
    [rowHeight]="rowHeight"
    [trackByProp]="'updated'" 
    [rows]="rows">
    <ngx-datatable-column *ngIf="expandChild" [width]="30" [resizeable]="false" [sortable]="false" [draggable]="false"
      [frozenLeft]="true" [canAutoResize]="false">
      <ng-template let-row="row" ngx-datatable-cell-template>
        <span class='sideColorStyle' [style.background]='getSideColorStyle(row)'></span>
        <mat-icon class="expanded-icon" *ngIf="hasChildren(row)" [svgIcon]="getExpandCollapseIcon(row)" (click)="toggleExpandRow(row)">
        </mat-icon>
      </ng-template>
    </ngx-datatable-column>
    <ngx-datatable-column *ngIf="headerCheckBox" [width]="50" [sortable]="false" [canAutoResize]="false"
      [draggable]="false" [frozenLeft]="true" [resizeable]="false">
      <ng-template let-row="row" ngx-datatable-header-template>
        <span *ngIf="!expandChild" class='sideColorStyle' [style.background]='getSideColorStyle(row)'></span>
        <input type="checkbox" [disabled]="getAllRowsDisabled()" [checked]="getAllRowChecked(rows)"
          (change)="onSelectAll(!allRowsSelected, rows)" />
      </ng-template>
      <ng-template ngx-datatable-cell-template let-row="row">
        <input type="checkbox" [disabled]="getSingleRowDisabled(row)" [checked]="getSingleRowChecked(row['fundTicker'])"
          (change)="onCheckboxChange(row['fundTicker'])" />
      </ng-template>
    </ngx-datatable-column>
    <ngx-datatable-column *ngFor="let col of customColumn" 
      [width]="55" 
      [sortable]="false" 
      [canAutoResize]="false"
      [draggable]="false" 
      [resizeable]="false" 
      [frozenLeft]="true">
      <ng-template *ngIf="col.type==='redAlert' " ngx-datatable-header-template>
        <mat-icon class="alertHeader" svgIcon="flag"></mat-icon>
      </ng-template>
      <ng-template *ngIf="col.type==='yellowAlert' " ngx-datatable-header-template>
        <mat-icon class="alertHeader" svgIcon="flag"></mat-icon>
      </ng-template>
      <ng-template *ngIf="col.type==='news' " ngx-datatable-header-template>
        <span>News</span>
      </ng-template>
      <ng-template *ngIf="col.type==='redAlert' " let-row="row" let-column="col" ngx-datatable-cell-template>
        <mat-icon class="alertClass" svgIcon="circle_alert"
          [style.display]="showRedAlert(row['fundid'],row['classID']) ? 'inline-flex' : 'none' "
          (click)="openAlertModal(row,col.type)">
        </mat-icon>
      </ng-template>
      <ng-template *ngIf="col.type==='yellowAlert' " let-row="row" let-column="col" ngx-datatable-cell-template>
        <mat-icon class="alertClass" svgIcon="trianglealert"
          [style.display]="showYellowAlert(row['fundid'],row['classID']) ? 'inline-flex' : 'none' "
          (click)="openAlertModal(row,col.type)">
        </mat-icon>
      </ng-template>
      <ng-template *ngIf="col.type==='news' " let-row="row" ngx-datatable-cell-template>
        <mat-icon class="showNewsClass" [style.display]="showNews(row) ? 'inline-flex' : 'none' " svgIcon="globe">
        </mat-icon>
      </ng-template>
    </ngx-datatable-column>
    <ngx-datatable-column *ngFor="let col of normalColumn" 
      [prop]="col.prop" 
      [draggable]="col.draggable"
      [canAutoResize]="col.canAutoResize" 
      [sortable]="false" 
      [frozenLeft]="col.frozenLeft"
      [width]="getColSettingWidth(col)">
      <ng-template let-column="col" ngx-datatable-header-template>
        <div [class]="getHeaderClass(col)"  
        (click)="selectCurrentCol($event, col.prop)" (menuClosed)="closeMenu()"  [matMenuTriggerFor]="columnHeaderMenu"
          *ngIf="(col.columnSetting && columnMenuDropDownSetting.length > 0) else elseBlock">
          <!-- sort icon start-->
          <span class="sortIconStyContainer">
            <mat-icon [class]="getSortIconDisplaySty(col.prop)" [svgIcon]="getSortIcon(col.prop)"
              (click)="changeAscAndDescSort($event, col.prop)"></mat-icon>
          </span>
           <!-- sort icon end-->

          <!-- header name start-->
          <span class="header-cell-label-sty">
            {{col.name}}
            <mat-icon class="dropdowIconSty" svgIcon="arrow_down"></mat-icon>
          </span>
             <!-- header name end-->
        </div>
        <ng-template #elseBlock>
          <span class="columnHeader">
            {{col.name}}
          </span>
        </ng-template>
      </ng-template>
      <ng-template *ngIf="col.cellTemplate==='hyperLink' " let-row="row" let-value="value" ngx-datatable-cell-template>
        <div [class]="getCellClass(row, col, value)">
          <span *ngIf="row.child === 'parent'" class="hyperLinkCellSty"
            (click)="hyperLinkNavigate(row)">{{row.name}}</span>
          <span *ngIf="row.child === 'child'">{{row.name}}</span>
        </div>
      </ng-template>
      <ng-template *ngIf="col.cellTemplate==='numberFormatShort' " let-row="row" let-value="value" let-i="index"
        ngx-datatable-cell-template>
        <div [class]="getCellClass(row, col, value)">
          {{value | numberRoundUp:2 | number: '1.2-2'}}
        </div>
      </ng-template>
      <ng-template *ngIf="col.cellTemplate==='numberFormatLong' " let-row="row" let-value="value" let-i="index"
        ngx-datatable-cell-template>
        <div [class]="getCellClass(row, col, value)">
          {{value | numberRoundUp:5 | number: '1.5-5'}}
        </div>
      </ng-template>
      <ng-template *ngIf="col.cellTemplate==='percentFormat' " let-row="row" let-value="value" let-i="index"
        ngx-datatable-cell-template>
        <div [class]="getCellClass(row, col, value)">
          {{value | numberRoundUp:5 | percent: '1.3-3' | percentFormat}}
        </div>
      </ng-template>
      <ng-template *ngIf="col.cellTemplate==='default' " let-row="row" let-value="value" let-i="index"
        ngx-datatable-cell-template>
        <div [class]="getCellClass(row, col, value)">
          {{value}}
        </div>
      </ng-template>
    </ngx-datatable-column>
  </ngx-datatable>
</div>`,
                styles: [`.ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:" ";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:"";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:"";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}`, `.main-box .ngx-datatable.material{background:#fff}.main-box .ngx-datatable.material .showNewsClass{display:inline-block;width:20px;height:20px;transition:width .3s}.main-box .ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.main-box .ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#e1ecf2;cursor:pointer}.main-box .ngx-datatable.material .alertClass{text-align:center;display:inline-block;width:22px;height:22px;transition:width .3s;cursor:pointer;margin-left:-10px}.main-box .ngx-datatable.material .datatable-body-cell .expanded-icon{text-align:center;display:inline-block;width:20px;height:20px;cursor:pointer;color:rgba(0,0,0,.54);font-size:12px;transition:width .3s}.main-box .ngx-datatable.material .datatable-header-cell{line-height:50px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap{cursor:pointer;height:100%;line-height:50px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap .alertHeader{display:inline-block;width:20px;height:20px;transition:width .3s;margin-left:-10px}.main-box .ngx-datatable.material .datatable-header-cell .datatable-header-cell-template-wrap .columnHeader{color:#000;position:relative;padding-right:5px}.main-box .ngx-datatable.material .datatable-header-cell .header-align-center,.main-box .ngx-datatable.material .datatable-header-cell .header-align-left,.main-box .ngx-datatable.material .datatable-header-cell .header-align-right{display:flex;align-items:center}.main-box .ngx-datatable.material .datatable-header-cell .header-align-left{justify-content:flex-start}.main-box .ngx-datatable.material .datatable-header-cell .header-align-center{justify-content:center}.main-box .ngx-datatable.material .datatable-header-cell .header-align-right{justify-content:flex-end}.main-box .ngx-datatable.material .dropdowIconSty{visibility:hidden}.main-box .ngx-datatable.material .dropdowIconSty,.main-box .ngx-datatable.material .sortIconStyContainer svg{width:15px!important;height:15px!important;min-width:15px!important;max-width:15px!important}.main-box .ngx-datatable.material .dropdowIconSty svg,.main-box .ngx-datatable.material .sortIconStyContainer svg{vertical-align:middle}.main-box .ngx-datatable.material .columnHeader .header-cell-label-sty{padding-left:3px}.main-box .ngx-datatable.material .columnHeader .dropdowIconSty{visibility:hidden}.main-box .ngx-datatable.material .columnHeader.drop-is-visible .dropdowIconSty,.main-box .ngx-datatable.material .columnHeader:hover .dropdowIconSty{visibility:visible}.main-box .ngx-datatable.material .columnHeader.drop-is-visible{background-color:#e1ecf2}.main-box .ngx-datatable.material .columnHeader .true{visibility:visible}.main-box .ngx-datatable.material .columnHeader .false{visibility:hidden}.main-box .ngx-datatable.material .datatable-body{overflow-y:auto!important}.main-box .ngx-datatable.material .datatable-body .align-right{padding-right:25px;text-align:right}.main-box .ngx-datatable.material .datatable-body .align-left{text-align:left;padding-left:19px}.main-box .ngx-datatable.material .datatable-body .sideColorStyle{position:absolute;width:4px;height:45px;top:3px;left:0}.main-box .ngx-datatable.material .datatable-body .hyperLinkCellSty{cursor:pointer;color:#2f7491;text-decoration:none}.main-box .ngx-datatable.material .datatable-header .datatable-row-left{background-image:none;display:flex}.main-box .more-icon{position:absolute;top:6px;right:58px;cursor:pointer}.main-box .more-icon .mat-icon-button{background-color:#fff;cursor:pointer}.table-layout .adjust-for-show-header{overflow-y:hidden!important}`],
                encapsulation: ViewEncapsulation.None //If you are using PrimeNG or Angular Material in your project that styleUrl will not work like this. You need to import ViewEncapsulation and put encapsulation: ViewEncapsulation.None in the @component definition.
            },] },
];
CommonDataTableComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ViewContainerRef },
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService }
];
CommonDataTableComponent.propDecorators = {
    mydatatable: [{ type: ViewChild, args: ['mydatatable',] }],
    headerSetting: [{ type: Input }],
    headerHeight: [{ type: Input }],
    isDataTablePaused: [{ type: Input }],
    rows: [{ type: Input }],
    childRows: [{ type: Input }],
    alertData: [{ type: Input }],
    rowHeight: [{ type: Input }],
    customColumn: [{ type: Input }],
    normalColumn: [{ type: Input }],
    limit: [{ type: Input }],
    footerHeight: [{ type: Input }],
    headerCheckBox: [{ type: Input }],
    columnMenuDropDownSetting: [{ type: Input }],
    allRowsSelected: [{ type: Input }],
    getAllRowsDisabled: [{ type: Input }],
    getSingleRowDisabled: [{ type: Input }],
    getAllRowChecked: [{ type: Input }],
    getSingleRowChecked: [{ type: Input }],
    onSelectAll: [{ type: Input }],
    onCheckboxChange: [{ type: Input }],
    defaultSortCol: [{ type: Input }],
    menuClosed: [{ type: Output }],
    togglePauseFlagEvent: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @type {?} */
const customColumn$1 = [
    {
        type: "redAlert",
        details: "",
    },
    {
        type: "yellowAlert",
        details: "",
    }
];
/** @type {?} */
const normalColumn$1 = [
    {
        prop: 'name',
        name: 'Entity Name',
        width: 200,
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'hyperLink',
        headerClassFormat: 'headerCenter',
        cellClassFormat: 'cellCenter',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'fundid',
        name: 'Entity Id Ref',
        width: 120,
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'default',
        headerClassFormat: 'headerLeft',
        cellClassFormat: 'cellLeft',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'fundTicker',
        name: 'Entity Ticker',
        width: 120,
        draggable: true,
        canAutoResize: false,
        columnSetting: true,
        cellTemplate: 'default',
        headerClassFormat: 'headerLeft',
        cellClassFormat: 'cellLeft',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'classID',
        name: 'Class ID',
        width: 80,
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'default',
        headerClassFormat: 'headerLeft',
        cellClassFormat: 'cellLeft',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'sodNav',
        name: 'NAV Previous',
        width: 125,
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatLong',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'nav',
        name: 'NAV Current',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatLong',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'navChange',
        name: 'NAV Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatLong',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'navChangePercent',
        name: 'NAV % Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'percentFormat',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'sodTna',
        name: 'TNA Previous',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'tna',
        name: 'TNA Current',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'tnaChange',
        name: 'TNA Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'tnaChangePercent',
        name: 'TNA % Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'percentFormat',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'sodMv',
        name: 'MV Amt Base Previous',
        width: '200',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'fundmv',
        name: 'MV Amt Base',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellRight',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'fundmvChange',
        name: 'MV Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'numberFormatShort',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    },
    {
        prop: 'fundmvChangePercent',
        name: 'MV % Change',
        width: '',
        draggable: true,
        canAutoResize: true,
        columnSetting: true,
        cellTemplate: 'percentFormat',
        headerClassFormat: 'headerRight',
        cellClassFormat: 'cellNumber',
        treeToggleTemplate: 'columnHeaderMenu',
        frozenLeft: false,
        sortColumnAscOrDesc: '',
    }
];
/** @type {?} */
const columnMenuDropDownSetting$1 = [
    // {
    //   name: "Resize to Fit",
    //   type: "resizeToFit",
    //   hasSubMenu: false,
    // },
    {
        name: "Freeze Column",
        type: "freezeColumn",
        hasSubMenu: false,
    },
    {
        name: "Sort Column",
        type: "sortColumn",
        hasSubMenu: false,
    },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class MainDatatableComponent extends BaseWidgetComponent {
    /**
     * @param {?} cd
     * @param {?} navService
     * @param {?} appRegistry
     * @param {?} appContext
     * @param {?} navSocketService
     * @param {?} dialog
     * @param {?} viewContainer
     * @param {?} shareInforBewteenComponents
     * @param {?} commonUtils
     * @param {?} resourceManger
     */
    constructor(cd, navService, appRegistry, appContext, navSocketService, dialog, viewContainer, shareInforBewteenComponents, commonUtils, resourceManger) {
        super();
        this.cd = cd;
        this.navService = navService;
        this.appRegistry = appRegistry;
        this.appContext = appContext;
        this.navSocketService = navSocketService;
        this.dialog = dialog;
        this.viewContainer = viewContainer;
        this.shareInforBewteenComponents = shareInforBewteenComponents;
        this.commonUtils = commonUtils;
        this.resourceManger = resourceManger;
        this.rows = [];
        this.childRows = [];
        this.isDataAvailable = false;
        this.isDataTablePaused = false;
        this.rowHeight = 50;
        this.alertData = [];
        this.allRowsSelected = false;
        this.isSelectedMap = [];
        this.headerSetting = true;
        this.headerHeight = 50;
        // temp data structure
        this.customColumn = customColumn$1;
        this.normalColumn = normalColumn$1;
        this.columnMenuDropDownSetting = columnMenuDropDownSetting$1;
        this.limit = 5;
        this.footerHeight = 50;
        this.headerCheckBox = true;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        //reset component data and user validation;
        this.commonUtils.validateUser();
        this.subs = [];
        this.rows = [];
        this.isDataAvailable = false;
        this.subs.push(this.navService.getFundList().subscribe(data => {
            this.rows = this.commonUtils.extractFundLevelData(data);
            this.childRows = this.commonUtils.extractClassLevelData(data);
            if (data.length > 0) {
                //this.alertData = [...this.updateAlertData(this.rows)];
                this.alertData = [...this.updateAlertDataAtClassLevel(data)];
                this.isDataAvailable = true;
                // seting position page default fund info if fundInfo is null
                if (this.shareInforBewteenComponents.fundInfo.length === 0) {
                    /** @type {?} */
                    const fundInfo = [];
                    fundInfo.push(data[0].fundid);
                    fundInfo.push(data[0].name);
                    fundInfo.push(data[0].fundTicker);
                    this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
                }
            }
            this.rows = [...this.rows];
            this.rows.forEach(row => {
                this.navSocketService.registerFunds([row['fundid']]);
            });
        }));
        this.subs.push(this.navSocketService.getNav().subscribe((data) => {
            if (data['eventType'] === 'fundChange') {
                /** @type {?} */
                const fundLevelRow = this.commonUtils.extractWSData(data["eventData"], false);
                /** @type {?} */
                const childLevelRow = this.commonUtils.extractWSData(data["eventData"], true);
                this.updateRow(fundLevelRow);
                childLevelRow.forEach(row => this.updateRow(row));
            }
            else if (data['eventType'] === 'sodChange') {
                this.doupdate(data["eventData"]);
            }
        }));
        this.resourceManger.registInterval(() => { this.rows = [...this.rows]; }, 300);
        this.shareInforBewteenComponents.hyperLinkNavigate.subscribe(data => {
            console.log("hyperlink navigate");
            console.log(data);
            this.hyperLinkNavigateTo(data);
        });
        this.shareInforBewteenComponents.openModalData.subscribe(data => {
            this.openAlertModal(data.rowData, data.type);
        });
        this.shareInforBewteenComponents.sortDatatableColumn.subscribe(data => {
            this.rows = [...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)];
        });
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.rows.forEach(row => {
            this.navSocketService.unRegisterFunds([row['fundid']]);
        });
        this.subs.forEach(sub => sub.unsubscribe());
        this.resourceManger.cleanResources();
    }
    /**
     * @param {?} data
     * @return {?}
     */
    updateRow(data) {
        if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
            if (data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
                /** @type {?} */
                const alertObj = {
                    "name": data['fundid'],
                    "classID": data['classID'],
                    "alertType": data['alertType'],
                    "nav": data['nav'],
                    "marketval": data['fundmv'],
                    "value": data['navChangePercent'],
                    "fundmvChangePercent": data['fundmvChangePercent'],
                    "pricetime": data['pricetime'],
                };
                this.alertData.push(alertObj);
                this.alertData = [...this.alertData];
            }
            this.doupdate(data);
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    doupdate(data) {
        if (this.rows.length) {
            /** @type {?} */
            const fundId = data['fundid'];
            /** @type {?} */
            const fundTicker = data['fundTicker'];
            /** @type {?} */
            const classID = data['classID'];
            this.rows.forEach(item => {
                if (item['fundid'] === fundId && item['fundTicker'] === fundTicker && item['classID'] === classID) {
                    this.normalColumn.forEach(colItem => { if (null != data[colItem.prop] && (['fundid', 'name', 'fundTicker', 'classID'].indexOf(colItem.prop) === -1)) {
                        item[colItem.prop] = data[colItem.prop];
                    } });
                    /** @type {?} */
                    const counts = this.getAlertCounts(fundId, classID, this.alertData);
                    item['redAlert'] = counts[0];
                    item['yellowAlert'] = counts[1];
                }
            });
        }
    }
    /**
     * @param {?} fundid
     * @param {?} classID
     * @param {?} alerts
     * @return {?}
     */
    getAlertCounts(fundid, classID, alerts) {
        /** @type {?} */
        let counts = [0, 0];
        alerts.forEach(alert => {
            if (alert['name'] === fundid && alert['classID'] === classID) {
                if (alert['alertType'] === 2) {
                    counts[0] += 1;
                }
                if (alert['alertType'] === 1) {
                    counts[1] += 1;
                }
            }
        });
        //console.log("alert counts for fund :"+fundid+" class:"+classID+" counts for type 1:"+counts[0] +" counts for type 1:"+counts[1]);
        return counts;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    updateAlertDataAtClassLevel(data) {
        /** @type {?} */
        let alertAry = [];
        /** @type {?} */
        const fundLevelData = ((/** @type {?} */ (data))).map(d => {
            for (let key in d.classLevelTrialData) {
                alertAry = alertAry.concat(this.filterAlertDataByClass(d.fundid, key, d.classLevelTrialData[key].priceChanges));
            }
        });
        return alertAry;
    }
    // colllects the alert data from getFundList call
    /**
     * @param {?} data
     * @return {?}
     */
    updateAlertData(data) {
        /** @type {?} */
        let alertAry = [];
        data.forEach(item => {
            alertAry = alertAry.concat(this.filterAlertData(item['fundid'], item['priceChanges']));
        });
        return alertAry;
    }
    /**
     * @param {?} fundID
     * @param {?} classID
     * @param {?} data
     * @return {?}
     */
    filterAlertDataByClass(fundID, classID, data) {
        /** @type {?} */
        const tempAlertCricleData = [];
        data.forEach(item => {
            if (this.commonUtils.isValidTime(new Date(item['pricetime']))
                && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                /** @type {?} */
                const alertObj = {
                    "name": fundID,
                    "classID": classID,
                    "alertType": item['alertType'],
                    "nav": item['nav'],
                    "marketval": item['fundmv'],
                    "value": item['navChangePercent'],
                    "fundmvChangePercent": item['fundmvChangePercent'],
                    "pricetime": item['pricetime'],
                };
                tempAlertCricleData.push(alertObj);
            }
        });
        return tempAlertCricleData;
    }
    /**
     * @param {?} fundID
     * @param {?} data
     * @return {?}
     */
    filterAlertData(fundID, data) {
        /** @type {?} */
        const tempAlertCricleData = [];
        data.forEach(item => {
            if (this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
                /** @type {?} */
                const alertObj = {
                    "name": fundID,
                    "alertType": item['alertType'],
                    "nav": item['nav'],
                    "marketval": item['fundmv'],
                    "value": item['navChangePercent'],
                    "fundmvChangePercent": item['fundmvChangePercent'],
                    "pricetime": item['pricetime'],
                };
                tempAlertCricleData.push(alertObj);
            }
        });
        return tempAlertCricleData;
    }
    /**
     * @param {?} row
     * @param {?} type
     * @return {?}
     */
    openAlertModal(row, type) {
        /** @type {?} */
        const dialogRef = this.dialog.open(CustomAlertModalComponent, {
            width: '680px',
            data: {
                "type": type === 'yellowAlert' ? '' : 'Critical',
                "now": new Date() > this.commonUtils.endTime ? this.commonUtils.endTime : new Date(),
                "title": row['name'] + " class-" + row['classID'],
                "fundId": row['fundid'],
                "alertData": this.getAlertDataForFundByClass(row['fundid'], row['classID'], type === 'yellowAlert' ? 1 : 2)
            }
        });
        //    console.log("length fund:"+row+"class: alerttype:");  
        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }
    /**
     * @param {?} fundId
     * @param {?} classID
     * @param {?} alertType
     * @return {?}
     */
    getAlertDataForFundByClass(fundId, classID, alertType) {
        /** @type {?} */
        const alertDataForFund = [];
        this.alertData.forEach(item => {
            if (item['name'] === fundId
                && item['classID'] === classID
                && item['alertType'] === alertType) {
                alertDataForFund.push(item);
            }
        });
        console.log("Fund:" + fundId + ",class:" + classID + ",count:" + alertDataForFund.length);
        return alertDataForFund.reverse();
    }
    /**
     * @param {?} fundId
     * @param {?} alertType
     * @return {?}
     */
    getAlertDataForFund(fundId, alertType) {
        /** @type {?} */
        const alertDataForFund = [];
        this.alertData.forEach(item => {
            if (item['name'] === fundId && item['alertType'] === alertType) {
                alertDataForFund.push(item);
            }
        });
        return alertDataForFund.reverse();
    }
    /**
     * @param {?} row
     * @return {?}
     */
    hyperLinkNavigateTo(row) {
        /** @type {?} */
        const fundInfo = [];
        /** @type {?} */
        const fundID = row['fundid'];
        fundInfo.push(fundID);
        /** @type {?} */
        const fundName = row['name'];
        fundInfo.push(fundName);
        fundInfo.push(row['fundTicker']);
        this.nagativateToPosition(fundInfo);
    }
    /**
     * @param {?} fundInfo
     * @return {?}
     */
    nagativateToPosition(fundInfo) {
        this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
        this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-002');
    }
    /**
     * @return {?}
     */
    getAllRowsDisabled() {
        /** @type {?} */
        const list = this.shareInforBewteenComponents.getFundList();
        /** @type {?} */
        let disableAll = true;
        list.forEach(item => {
            if (item.checked)
                disableAll = false;
        });
        return disableAll;
    }
    /**
     * @param {?} row
     * @return {?}
     */
    getSingleRowDisabled(row) {
        /** @type {?} */
        const list = this.shareInforBewteenComponents.getFundList();
        /** @type {?} */
        let disableSingleRow = true;
        list.forEach(item => {
            if (item.checked && item.fundID === row['fundid'] && row.child === "parent")
                disableSingleRow = false;
        });
        return disableSingleRow;
    }
    /**
     * @param {?} rows
     * @return {?}
     */
    getAllRowChecked(rows) {
        /** @type {?} */
        const list = this.shareInforBewteenComponents.getFundList().filter(item => item.checked);
        /** @type {?} */
        let tempFlag = true;
        /** @type {?} */
        let noFundShowInChart = list.length === 0 ? true : false;
        if (list.length > this.isSelectedMap.length) {
            tempFlag = false;
        }
        else {
            list.forEach(item => {
                this.isSelectedMap.forEach(s => {
                    if (item.fundTicker === s.name && !s.checked) {
                        tempFlag = false;
                    }
                });
                if (this.isSelectedMap.length === 0)
                    tempFlag = false;
            });
        }
        this.allRowsSelected = noFundShowInChart ? !noFundShowInChart : tempFlag;
        return this.allRowsSelected;
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    getSingleRowChecked(fund) {
        /** @type {?} */
        let isChecked = false;
        this.isSelectedMap.forEach(item => {
            if (item.name === fund) {
                isChecked = this.shareInforBewteenComponents.getFundList().find(list => (list.fundTicker === fund && list.checked)) ? item.checked : false;
                item.checked = this.shareInforBewteenComponents.getFundList().find(list => (list.fundTicker === fund && list.checked)) ? item.checked : false;
            }
        });
        return isChecked;
    }
    /**
     * @param {?} checked
     * @param {?} rows
     * @return {?}
     */
    onSelectAll(checked, rows) {
        this.allRowsSelected = checked;
        rows.forEach(item => {
            /** @type {?} */
            let obj = {
                name: item.fundTicker,
                checked: this.shareInforBewteenComponents.getFundList().find(list => (list.fundID === item.fundid && list.checked)) ? checked : false
            };
            if (!this.isSelectedMap.find(s => s.name === item.fundTicker)) {
                this.isSelectedMap.push(obj);
            }
            else {
                /** @type {?} */
                const i = this.isSelectedMap.findIndex(s => s.name === item.fundTicker);
                this.isSelectedMap[i]['checked'] = this.shareInforBewteenComponents.getFundList().find(list => (list.fundID === item.fundid && list.checked)) ? checked : false;
            }
        });
        // this.setHighLightActiveEntries(this.isSelectedMap);
        /** @type {?} */
        const activeEntries = [];
        this.isSelectedMap.forEach(item => {
            if (item.checked) {
                activeEntries.push({ name: item.name });
            }
        });
        this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
    }
    /**
     * @param {?} fund
     * @return {?}
     */
    onCheckboxChange(fund) {
        if (this.isSelectedMap.length > 0 && this.isSelectedMap.find(s => s.name === fund)) {
            /** @type {?} */
            const i = this.isSelectedMap.findIndex(s => s.name === fund);
            this.isSelectedMap[i]['checked'] = !this.isSelectedMap[i]['checked'];
            if (this.isSelectedMap[i]['checked']) {
                this.allRowsSelected = false;
            }
        }
        else {
            /** @type {?} */
            let obj = {
                name: fund,
                checked: true
            };
            this.isSelectedMap.push(obj);
        }
        // this.setHighLightActiveEntries(this.isSelectedMap);
        /** @type {?} */
        const activeEntries = [];
        this.isSelectedMap.forEach(item => {
            if (item.checked) {
                activeEntries.push({ name: item.name });
            }
        });
        this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
    }
    /**
     * @param {?} selectedMap
     * @return {?}
     */
    setHighLightActiveEntries(selectedMap) {
        /** @type {?} */
        const activeEntries = [];
        selectedMap.forEach(item => {
            if (item.checked) {
                activeEntries.push({ name: item.name });
            }
        });
        this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
    }
    /**
     * @param {?} e
     * @return {?}
     */
    onClickedOutside(e) {
        this.shareInforBewteenComponents.clickedOutSide.emit(e);
    }
    /**
     * @return {?}
     */
    togglePauseFlag() {
        this.isDataTablePaused = !this.isDataTablePaused;
    }
}
MainDatatableComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-main-datatable',
                template: `<div class="datatableContainer" *ngIf="isDataAvailable" (clickOutside)="onClickedOutside($event)">

  <div class="live-time-for-title">
    <p *ngIf="commonUtils.isAfterMarketClose else elseBlock">Final Data (
      {{commonUtils.liveTime | date:"MM/dd/yyyy, h:mm aaaaa'm'"}} )</p>
    <ng-template #elseBlock>
      <p>
        Real Time Data ({{commonUtils.liveTime | date:"MM/dd/yyyy, h:mm aaaaa'm'"}})
      </p>
    </ng-template>
  </div>
  
<lib-common-data-table
[headerSetting]="headerSetting"
[isDataTablePaused]="isDataTablePaused"
[headerHeight]="headerHeight"
[rows]="rows"
[childRows]="childRows"
[alertData]="alertData"
[rowHeight]="rowHeight"
[customColumn]="customColumn"
[normalColumn]="normalColumn"
[limit]="limit"
[footerHeight]="footerHeight"
[headerCheckBox]="headerCheckBox"
[getAllRowsDisabled]="getAllRowsDisabled"
[getSingleRowDisabled]="getSingleRowDisabled"
[getAllRowChecked]="getAllRowChecked"
[getSingleRowChecked]="getSingleRowChecked"
[onSelectAll]="onSelectAll"
[onCheckboxChange]="onCheckboxChange"
[allRowsSelected]="allRowsSelected"
[columnMenuDropDownSetting]='columnMenuDropDownSetting'
[defaultSortCol]="'fundid'"
(togglePauseFlagEvent)="togglePauseFlag()"
>
</lib-common-data-table>
</div>`,
                styles: [`.ngx-datatable.material.striped .datatable-row-odd{background:#eee}.ngx-datatable.material.multi-click-selection .datatable-body-row.active,.ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active,.ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active,.ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover,.ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:hover,.ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus,.ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group,.ngx-datatable.material.single-selection .datatable-body-row.active:focus,.ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus,.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell:hover,.ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group{background-color:#eee;transition-property:background;transition-duration:.3s;transition-timing-function:linear}.ngx-datatable.material.cell-selection .datatable-body-cell:focus,.ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group{background-color:#ddd}.ngx-datatable.material.cell-selection .datatable-body-cell.active,.ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group{background-color:#304ffe;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover,.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group{background-color:#193ae4;color:#fff}.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus,.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group{background-color:#2041ef;color:#fff}.ngx-datatable.material .empty-row{height:50px;text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .loading-row{text-align:left;padding:.5rem 1.2rem;vertical-align:top;border-top:0}.ngx-datatable.material .datatable-body .datatable-row-left,.ngx-datatable.material .datatable-header .datatable-row-left{background-color:#fff;background-position:100% 0;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-body .datatable-row-right,.ngx-datatable.material .datatable-header .datatable-row-right{background-position:0 0;background-color:#fff;background-repeat:repeat-y;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==)}.ngx-datatable.material .datatable-header{box-shadow:0 2px 4px 0 rgba(0,0,0,.15);position:sticky;position:-webkit-sticky;top:0;z-index:999;background-color:#fff}.ngx-datatable.material .datatable-header .datatable-header-cell{text-align:center;color:rgba(0,0,0,.54);vertical-align:bottom;font-size:12px;font-weight:500}.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper{position:relative}.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after{transition:transform .4s,opacity .4s,-webkit-transform .4s;opacity:.5;-webkit-transform:scale(1);transform:scale(1)}.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after{content:" ";position:absolute;top:50%;left:50%;margin:-30px 0 0 -30px;height:60px;width:60px;background:#eee;border-radius:100%;opacity:1;-webkit-filter:none;filter:none;-webkit-transform:scale(0);transform:scale(0);z-index:9999;pointer-events:none}.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle{border-right:none}.ngx-datatable.material .datatable-header .resize-handle{border-right:1px solid #eee}.ngx-datatable.material .datatable-body .datatable-row-detail{background:#f5f5f5;padding:10px}.ngx-datatable.material .datatable-body .datatable-group-header{background:#f5f5f5;border-bottom:1px solid #d9d8d9;border-top:1px solid #d9d8d9}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell{text-align:center;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400;line-height:50px}.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell{text-align:left;padding:.9rem 1.2rem;vertical-align:top;border-top:0;color:#353535;transition:width .3s;font-size:14px;font-weight:400}.ngx-datatable.material .datatable-body .progress-linear{display:block;width:100%;height:5px;padding:0;margin:0;position:absolute}.ngx-datatable.material .datatable-body .progress-linear .container{display:block;position:relative;overflow:hidden;width:100%;height:5px;-webkit-transform:translate(0,0) scale(1,1);transform:translate(0,0) scale(1,1);background-color:#aad1f9}.ngx-datatable.material .datatable-body .progress-linear .container .bar{transition:transform .2s linear;-webkit-animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;animation:.8s cubic-bezier(.39,.575,.565,1) infinite query;transition:transform .2s linear,-webkit-transform .2s linear;background-color:#106cc8;position:absolute;left:0;top:0;bottom:0;width:100%;height:5px}.ngx-datatable.material .datatable-footer{border-top:1px solid rgba(0,0,0,.12);font-size:12px;font-weight:400;color:rgba(0,0,0,.54)}.ngx-datatable.material .datatable-footer .page-count{line-height:50px;height:50px;padding:0 1.2rem}.ngx-datatable.material .datatable-footer .datatable-pager{margin:0 10px}.ngx-datatable.material .datatable-footer .datatable-pager li{vertical-align:middle}.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a{color:rgba(0,0,0,.26)!important;background-color:transparent!important}.ngx-datatable.material .datatable-footer .datatable-pager li.active a{background-color:rgba(158,158,158,.2);font-weight:700}.ngx-datatable.material .datatable-footer .datatable-pager a{height:22px;min-width:24px;line-height:22px;padding:0 6px;border-radius:3px;margin:6px 3px;text-align:center;color:rgba(0,0,0,.54);text-decoration:none;vertical-align:bottom}.ngx-datatable.material .datatable-footer .datatable-pager a:hover{color:rgba(0,0,0,.75);background-color:rgba(158,158,158,.2)}.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip{font-size:20px;line-height:20px;padding:0 3px}.ngx-datatable.material .datatable-summary-row .datatable-body-row,.ngx-datatable.material .datatable-summary-row .datatable-body-row:hover{background-color:#ddd}.ngx-datatable.material .datatable-summary-row .datatable-body-row .datatable-body-cell{font-weight:700}.datatable-checkbox{position:relative;margin:0;cursor:pointer;vertical-align:middle;display:inline-block;box-sizing:border-box;padding:0}.datatable-checkbox input[type=checkbox]{position:relative;margin:0 1rem 0 0;cursor:pointer;outline:0}.datatable-checkbox input[type=checkbox]:before{transition:.3s ease-in-out;content:"";position:absolute;left:0;z-index:1;width:1rem;height:1rem;border:2px solid #f2f2f2}.datatable-checkbox input[type=checkbox]:checked:before{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);height:.5rem;border-color:#009688;border-top-style:none;border-right-style:none}.datatable-checkbox input[type=checkbox]:after{content:"";position:absolute;top:0;left:0;width:1rem;height:1rem;background:#fff;cursor:pointer}@-webkit-keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}@keyframes query{0%{opacity:1;-webkit-transform:translateX(35%) scale(.3,1);transform:translateX(35%) scale(.3,1)}100%{opacity:0;-webkit-transform:translateX(-50%) scale(0,1);transform:translateX(-50%) scale(0,1)}}.ngx-datatable.material .datatable-body .datatable-body-row .is-zero{text-align:right;vertical-align:top;border-top:0;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-nagetive{text-align:right;vertical-align:top;border-top:0;color:#b91224;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-body .datatable-body-row .is-positive{text-align:right;vertical-align:top;border-top:0;color:#28743e;transition:width .3s;font-size:14px;font-weight:400;padding-right:25px}.ngx-datatable.material .datatable-header .datatable-column-header-align-left{text-align:left;color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-center{color:#353535}.ngx-datatable.material .datatable-header .datatable-column-header-align-right{text-align:right;color:#353535}button.mat-menu-item{height:30px;line-height:30px;font-size:13px;display:flex;align-items:center}.mat-menu-item:hover:not([disabled]){background:#e1ecf2}.check-icon.mat-icon{width:14px;height:14px;margin-left:20px;color:#000}.ngx-datatable.fixed-header .datatable-header .datatable-header-inner{height:100%}`, `.datatableContainer .live-time-for-title{position:absolute;top:2px;left:15px;font-size:16px;font-family:DINNextLTPro-Medium;color:#464646}`],
                encapsulation: ViewEncapsulation.None
            },] },
];
MainDatatableComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: NavService },
    { type: AppRegistry },
    { type: AppContext },
    { type: NavSocketService },
    { type: MatDialog },
    { type: ViewContainerRef },
    { type: ShareInfoBeweenComponentsService },
    { type: CommonUtilsService },
    { type: ResourceManagerService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class UiQNavModule {
    /**
     * @param {?} appRegistry
     */
    constructor(appRegistry) {
        this.appRegistry = appRegistry;
        this.permissions = ['Application/navdeveloper', 'Application/navanalyst'];
        appRegistry.registerComponent('lineChart', QnavLineChartComponent);
        appRegistry.registerComponent('liveDataTable', MainDatatableComponent);
        appRegistry.registerComponent('livePosition', QnavPositionComponent);
        appRegistry.registerComponent('positionHeatMap', PositionHeatMapComponent);
        appRegistry.registerComponent('positionFundSummary', PositionFundSummaryComponent);
        appRegistry.registerDashboard('QNAV-001', 'QNAV Entity List', [
            { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'lineChart', title: null, showHeader: true },
            { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'liveDataTable', title: null, showHeader: true }
        ], true, true, 'qnf', 'QNAV', this.permissions);
        appRegistry.registerDashboard('QNAV-002', 'QNAV Position', [
            { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'positionHeatMap', title: null, showHeader: true },
            // { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'positionFundSummary', title: null, showHeader: true },
            { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'livePosition', title: null, showHeader: true }
        ], true, true, 'qnp', 'QNAV', this.permissions);
    }
    /**
     * @param {?} environment
     * @return {?}
     */
    static forRoot(environment) {
        return {
            ngModule: UiQNavModule,
            providers: [
                {
                    provide: 'env',
                    useValue: environment
                }
            ]
        };
    }
}
UiQNavModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    BrowserAnimationsModule,
                    MatButtonModule,
                    MatCheckboxModule,
                    UiCommonModule,
                    DynamicModule.withComponents([
                        QnavLineChartComponent,
                        MainDatatableComponent,
                        QnavPositionComponent,
                        PositionHeatMapComponent,
                        PositionFundSummaryComponent
                    ]),
                    NgxDatatableModule,
                    NgxChartsModule,
                    MatChipsModule,
                    MatIconModule,
                    HttpClientModule,
                    MatDialogModule,
                    MatMenuModule,
                    ClickOutsideModule
                ],
                declarations: [
                    QnavLineChartComponent,
                    LineChartComponent,
                    CustomLegendComponent,
                    QnavPositionComponent,
                    PercentFormatPipe,
                    NumberRoundUpPipe,
                    CustomAlertModalComponent,
                    AddFundModalComponent,
                    PositionHeatMapComponent,
                    HeatMapComponent,
                    PositionFundSummaryComponent,
                    SingleLineChartComponent,
                    CommonDataTableComponent,
                    MainDatatableComponent
                ],
                providers: [DatePipe, AppRegistry],
                exports: [
                    QnavLineChartComponent,
                    QnavPositionComponent,
                    PositionHeatMapComponent,
                    PositionFundSummaryComponent,
                    MainDatatableComponent
                ],
                entryComponents: [
                    QnavLineChartComponent,
                    QnavPositionComponent,
                    CustomAlertModalComponent,
                    AddFundModalComponent,
                    PositionHeatMapComponent,
                    PositionFundSummaryComponent,
                    MainDatatableComponent
                ]
            },] },
];
UiQNavModule.ctorParameters = () => [
    { type: AppRegistry }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

export { UiQNavModule, CustomLegendComponent, LineChartComponent, CommonDataTableComponent, AddFundModalComponent as ɵn, CustomAlertModalComponent as ɵm, HeatMapComponent as ɵo, MainDatatableComponent as ɵg, NumberRoundUpPipe as ɵl, PercentFormatPipe as ɵk, PositionFundSummaryComponent as ɵj, PositionHeatMapComponent as ɵi, QnavLineChartComponent as ɵa, QnavPositionComponent as ɵh, CommonUtilsService as ɵe, NavService as ɵb, NavSocketService as ɵc, ResourceManagerService as ɵf, ShareInfoBeweenComponentsService as ɵd, SingleLineChartComponent as ɵp };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib21uaWEtdWktcW5hdi5qcy5tYXAiLCJzb3VyY2VzIjpbIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbGluZS1jaGFydC9saW5lLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2N1c3RvbS1sZWdlbmQvY3VzdG9tLWxlZ2VuZC5jb21wb25lbnQudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9zZXJ2aWNlcy9uYXYtc2VydmljZS5zZXJ2aWNlLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbW9kZWwvcW5hdi50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL25hdi1zb2NrZXQuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZS50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3FuYXYtcG9zaXRpb24vY29sdW1uLWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9xbmF2LXBvc2l0aW9uL3FuYXYtcG9zaXRpb24uY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvYWRkLWZ1bmQtbW9kYWwvYWRkLWZ1bmQtbW9kYWwuY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvY29sb3JzLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvcW5hdi1saW5lLWNoYXJ0LW9sZC9saW5lLWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9xbmF2LWxpbmUtY2hhcnQtb2xkL3FuYXYtbGluZS1jaGFydC5jb21wb25lbnQudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9waXBlL3BlcmNlbnQtZm9ybWF0LnBpcGUudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9waXBlL251bWJlci1yb3VuZHVwLnBpcGUudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9jdXN0b20tYWxlcnQtbW9kYWwvY3VzdG9tLWFsZXJ0LW1vZGFsLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3Bvc2l0aW9uLWhlYXQtbWFwL3Bvc2l0aW9uLWhlYXQtbWFwLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2hlYXQtbWFwL2hlYXQtbWFwLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3Bvc2l0aW9uLWZ1bmQtc3VtbWFyeS9wb3NpdGlvbi1zdW1tYXJ5LWRhdGEudHMiLCJuZzovL0BvbW5pYS91aS1xbmF2L2xpYi9wb3NpdGlvbi1mdW5kLXN1bW1hcnkvcG9zaXRpb24tZnVuZC1zdW1tYXJ5LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL3NpbmdsZS1saW5lLWNoYXJ0L3NpbmdsZS1saW5lLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL2NvbW1vbi1kYXRhLXRhYmxlL2NvbW1vbi1kYXRhLXRhYmxlLmNvbXBvbmVudC50cyIsIm5nOi8vQG9tbmlhL3VpLXFuYXYvbGliL21haW4tZGF0YXRhYmxlL2NvbHVtbi1kYXRhLnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvbWFpbi1kYXRhdGFibGUvbWFpbi1kYXRhdGFibGUuY29tcG9uZW50LnRzIiwibmc6Ly9Ab21uaWEvdWktcW5hdi9saWIvdWktcW5hdi5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgRXZlbnRFbWl0dGVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IGlzRGF0ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9zcmMvaTE4bi9mb3JtYXRfZGF0ZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB7XHJcbiAgcHVibGljIGFjY2Vzc1Rva2VuO1xyXG4gIHB1YmxpYyBmdW5kSW5mbyA6IGFueSA9IFtdO1xyXG4gIHByaXZhdGUgdmFyaWFibGVGdW5kTGlzdDogYW55ID0gW107XHJcbiAgcHVibGljIGNvbG9yU2NoZW1hOiBhbnlbXSA9IFtdO1xyXG4gIHB1YmxpYyBoaWdoTGlnaHRBY3RpdmVFbnRyaWVzOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyAgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuICBwdWJsaWMgY2xpY2tlZE91dFNpZGU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3ICBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gIC8vIGRhdGEtdGFibGUgY29tcG9uZW50cyBkYXRhIGNvbW11bmljYXRpb25cclxuICBwdWJsaWMgaHlwZXJMaW5rTmF2aWdhdGU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgcHVibGljIG9wZW5Nb2RhbERhdGE6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgcHVibGljIHNvcnREYXRhdGFibGVDb2x1bW46IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIHB1YmxpYyBzYXZlUG9zaXRpb25EZXRhaWxzRnVuZEluZm8oZnVuZEluZm8pIHtcclxuICAgIHRoaXMuZnVuZEluZm8gPSBmdW5kSW5mbztcclxuICB9XHJcblxyXG4gIHB1YmxpYyBzZXRWYXJpYWJsZUZ1bmRMaXN0KGRhdGEpIHtcclxuICAgIHRoaXMudmFyaWFibGVGdW5kTGlzdCA9IGRhdGE7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgc2V0Q29sb3JTY2hlbWEoY29sb3JTY2hlbWEgOiBhbnlbXSkge1xyXG4gICAgdGhpcy5jb2xvclNjaGVtYSA9IGNvbG9yU2NoZW1hO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldEZ1bmRMaXN0KCkgOiBhbnlbXXtcclxuICAgIHJldHVybiB0aGlzLnZhcmlhYmxlRnVuZExpc3Q7XHJcbiAgfVxyXG4gIHB1YmxpYyByZXNldCgpIHtcclxuICAgIHRoaXMuZnVuZEluZm8gPSBbXTtcclxuICAgIHRoaXMudmFyaWFibGVGdW5kTGlzdCA9IFtdO1xyXG4gICAgdGhpcy5jb2xvclNjaGVtYSA9IFtdO1xyXG4gICAgdGhpcy5oaWdoTGlnaHRBY3RpdmVFbnRyaWVzID0gbmV3ICBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gICAgdGhpcy5oeXBlckxpbmtOYXZpZ2F0ZSA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gICAgdGhpcy5vcGVuTW9kYWxEYXRhID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcbiAgICB0aGlzLnNvcnREYXRhdGFibGVDb2x1bW4gPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDb21tb25VdGlsc1NlcnZpY2Uge1xyXG4gIHN0YXJ0VGltZTogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgZW5kVGltZTogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgdGltZURpdmlzaW9uOiBEYXRlID0gbmV3IERhdGUoKTtcclxuICBsaXZlVGltZTogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgaXNBZnRlck1hcmtldENsb3NlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBzaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHM6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlXHJcbiAgKSB7XHJcbiAgICB0aGlzLnN0YXJ0VGltZS5zZXRIb3Vycyg5LCAzMCwgMCwgMCk7XHJcbiAgICB0aGlzLmVuZFRpbWUuc2V0SG91cnMoMTYsIDMwLCAwLCAwKTtcclxuICAgIHRoaXMudGltZURpdmlzaW9uLnNldEhvdXJzKDE1LCAzMCwgMCwgMCk7XHJcbiAgICBsZXQgaW5zdGFuY2UgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGlmIChuZXcgRGF0ZSgpIDwgdGhpcy5lbmRUaW1lKSB7XHJcbiAgICAgICAgdGhpcy5saXZlVGltZSA9IG5ldyBEYXRlKClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmxpdmVUaW1lID0gdGhpcy5lbmRUaW1lO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwoaW5zdGFuY2UpO1xyXG4gICAgICB9XHJcbiAgICB9LCAxMDAwKTtcclxuICAgIHRoaXMuaXNBZnRlck1hcmtldENsb3NlID0gdGhpcy5pc0FmdGVyTWFya2V0Q29sc2UodGhpcy5saXZlVGltZSk7XHJcbiAgfVxyXG4gIGlzQWZ0ZXJNYXJrZXRDb2xzZSh0aW1lOiBEYXRlKTogYm9vbGVhbiB7XHJcbiAgICBpZiAoIHRpbWUgPD0gdGhpcy5lbmRUaW1lKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICBpc0JlZm9yZU1hcmtldE9wZW4odGltZTogRGF0ZSk6IGJvb2xlYW4ge1xyXG4gICAgaWYgKCB0aW1lID49IHRoaXMuc3RhcnRUaW1lKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuXHJcbiAgaXNWYWxpZFRpbWUodGltZTogRGF0ZSk6IGJvb2xlYW4ge1xyXG5cclxuICAgIGlmICh0aW1lID49IHRoaXMuc3RhcnRUaW1lICYmIHRpbWUgPD0gdGhpcy5lbmRUaW1lKSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGlzQmV5b25kRGl2aXNpb24odGltZTogRGF0ZSk6IGJvb2xlYW4ge1xyXG4gICAgaWYgKHRpbWUgPj0gdGhpcy50aW1lRGl2aXNpb24pIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0UmFuZG9tQ29sb3IoKSB7XHJcbiAgICBjb25zdCBsZXR0ZXJzID0gJzAxMjM0NTY3ODlBQkNERUYnO1xyXG4gICAgbGV0IGNvbG9yID0gJyMnO1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspIHtcclxuICAgICAgY29sb3IgKz0gbGV0dGVyc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxNildO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGNvbG9yO1xyXG4gIH1cclxuICBcclxuICBwdWJsaWMgZ2V0Q29sb3JGb3JGdW5kKGZ1bmRpZDogU3RyaW5nKSB7XHJcbiAgICB0aGlzLnJlc2V0Q29sb3JGb3JGdW5kKGZ1bmRpZCk7XHJcbiAgICBmb3IgKGxldCBpdGVtIG9mIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmNvbG9yU2NoZW1hKSB7XHJcbiAgICAgIGlmIChpdGVtWydmdW5kaWQnXSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaXRlbVsnZnVuZGlkJ10gPSBmdW5kaWQ7XHJcbiAgICAgICAgcmV0dXJuIGl0ZW1bJ2NvbG9yJ107XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLmdldFJhbmRvbUNvbG9yKCk7XHJcblxyXG4gIH1cclxuICBwdWJsaWMgcmVzZXRDb2xvckZvckZ1bmQoZnVuZGlkOiBTdHJpbmcpIHtcclxuICAgIGZvciAobGV0IGl0ZW0gb2YgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuY29sb3JTY2hlbWEpIHtcclxuICAgICAgaWYgKGl0ZW1bJ2Z1bmRpZCddID09PSBmdW5kaWQpIHtcclxuICAgICAgICBpdGVtWydmdW5kaWQnXSA9IHVuZGVmaW5lZDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIHVwZGF0ZUZ1bmRTdGF0dXMoZnVuZGlkOiBTdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbikge1xyXG4gICAgY29uc3QgaW5kZXggPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpLmZpbmRJbmRleChlbGVtZW50ID0+IGVsZW1lbnQuZnVuZElEID09PSBmdW5kaWQpO1xyXG4gICAgaWYgKGlzQ2hlY2tlZCA9PT0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKVtpbmRleF1bJ2NoZWNrZWQnXSkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpW2luZGV4XVsnY2hlY2tlZCddID0gaXNDaGVja2VkO1xyXG4gICAgLy9yZW1vdmUgdGhlIGNvbG9yIGZvciB0aGUgZnVuZCBhcyB3ZWxsXHJcbiAgICBpZiAoaXNDaGVja2VkID09PSBmYWxzZSkge1xyXG4gICAgICB0aGlzLnJlc2V0Q29sb3JGb3JGdW5kKGZ1bmRpZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmdldENvbG9yRm9yRnVuZChmdW5kaWQpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIHB1YmxpYyBmb3JtYXRUaW1lKHRpbWU6IERhdGUpOiBzdHJpbmcge1xyXG4gICAgbGV0IHQgPSBuZXcgRGF0ZSh0aW1lKTtcclxuICAgIGxldCBzZWNvbmQgPSAnMDAnO1xyXG4gICAgaWYgKHQuZ2V0U2Vjb25kcygpIDw9IDIwKSB7XHJcbiAgICAgIHNlY29uZCA9ICcwMCc7XHJcbiAgICB9IGVsc2UgaWYgKHQuZ2V0U2Vjb25kcygpID4gMjAgJiYgdC5nZXRTZWNvbmRzKCkgPD0gNDApIHtcclxuICAgICAgc2Vjb25kID0gJzIwJztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNlY29uZCA9ICc0MCc7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFwiMFwiICsgdC5nZXRIb3VycygpKS5zbGljZSgtMikgKyAnOicgKyAoXCIwXCIgKyB0LmdldE1pbnV0ZXMoKSkuc2xpY2UoLTIpICsgJzonICsgc2Vjb25kO1xyXG4gIH1cclxuICBwdWJsaWMgZm9ybWF0RGF0ZVRpbWUodGltZSk6IERhdGUge1xyXG4gICAgbGV0IHQgPSBuZXcgRGF0ZSh0aW1lKTtcclxuICAgIGxldCBzZWNvbmQgPSAnMDAnO1xyXG4gICAgaWYgKHQuZ2V0U2Vjb25kcygpIDw9IDIwKSB7XHJcbiAgICAgIHQuc2V0U2Vjb25kcygwKTtcclxuICAgICAgdC5zZXRNaWxsaXNlY29uZHMoMCk7XHJcbiAgICB9IGVsc2UgaWYgKHQuZ2V0U2Vjb25kcygpID4gMjAgJiYgdC5nZXRTZWNvbmRzKCkgPD0gNDApIHtcclxuICAgICAgdC5zZXRTZWNvbmRzKDIwKTtcclxuICAgICAgdC5zZXRNaWxsaXNlY29uZHMoMCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0LnNldFNlY29uZHMoNDApO1xyXG4gICAgICB0LnNldE1pbGxpc2Vjb25kcygwKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0O1xyXG4gIH1cclxuICAvL3Jlc3QgY29tcG9uZW50IHNoYXJlZCBpbmZvcm1hdGlvbiBpZiBsb2dpbiB1c2VyL2F1dGhvcml6ZWQgdG9rZW4gY2hhbmdlZFxyXG4gIHB1YmxpYyB2YWxpZGF0ZVVzZXIoKSB7XHJcbiAgICBpZih0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5hY2Nlc3NUb2tlbikge1xyXG4gICAgICBpZihzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdhY2Nlc3NfdG9rZW4nKSA9PT0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuYWNjZXNzVG9rZW4pIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMucmVzZXQoKTtcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmFjY2Vzc1Rva2VuID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgnYWNjZXNzX3Rva2VuJyk7XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZXh0cmFjdEZ1bmRMZXZlbERhdGEoZGF0YSkge1xyXG4gICAgY29uc3QgZnVuZExldmVsRGF0YSA9IChkYXRhIGFzIGFueVtdKS5tYXAoZCA9PiB7XHJcbiAgICAgICAgICBjb25zdCByb3dUZW1wID0ge1xyXG4gICAgICAgICAgICAgIC8vZnVuZGlkOiBkLmZ1bmRpZCxcclxuICAgICAgICAgICAgICBmdW5kaWQ6IGQuZnVuZGlkLFxyXG4gICAgICAgICAgICAgIG1hc2tlZElkOiBkLm1hc2tlZElkLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGQubmFtZSxcclxuICAgICAgICAgICAgICBjbGFzc0lEOiBcIkFcIixcclxuICAgICAgICAgICAgICBjaGlsZDogXCJwYXJlbnRcIixcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3QgbXVsdGlDbGFzc0RhdGEgPSBkLmNsYXNzTGV2ZWxUcmlhbERhdGE7XHJcbiAgICAgICAgICAgIGNvbnN0IHJvdyA9IE9iamVjdC5hc3NpZ24ocm93VGVtcCwgbXVsdGlDbGFzc0RhdGEuQSk7XHJcbiAgICAgICAgICAgIHJldHVybiByb3c7XHJcbiAgICAgICAgICB9KTtcclxuICAgIHJldHVybiBmdW5kTGV2ZWxEYXRhO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGV4dHJhY3RDbGFzc0xldmVsRGF0YShkYXRhKSB7XHJcbiAgICBjb25zdCBjbGFzc0xldmVsRGF0YSA9IFtdO1xyXG4gICAgKGRhdGEgYXMgYW55W10pLmZvckVhY2goZCA9PiB7XHJcbiAgICAgICAgICAgY29uc3Qgcm93VGVtcCA9IHtcclxuICAgICAgICAgICAgLy9mdW5kaWQ6IGQuZnVuZGlkLFxyXG4gICAgICAgICAgICBmdW5kaWQ6IGQuZnVuZGlkLFxyXG4gICAgICAgICAgICBtYXNrZWRJZDogZC5tYXNrZWRJZCxcclxuICAgICAgICAgICAgbmFtZTogZC5uYW1lLFxyXG4gICAgICAgICAgICBjaGlsZDogXCJjaGlsZFwiLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIGNvbnN0IG11bHRpQ2xhc3NEYXRhID0gZC5jbGFzc0xldmVsVHJpYWxEYXRhO1xyXG4gICAgICAgICAgZm9yKGxldCBrZXkgaW4gbXVsdGlDbGFzc0RhdGEpIHtcclxuICAgICAgICAgICAgaWYgKGtleSAhPT0gXCJBXCIpIHtcclxuICAgICAgICAgICAgICBjb25zdCBjaGlsZFJvdyA9IE9iamVjdC5hc3NpZ24ocm93VGVtcCwgbXVsdGlDbGFzc0RhdGFba2V5XSwge2NsYXNzSUQ6IGtleX0pO1xyXG4gICAgICAgICAgICAgIGNsYXNzTGV2ZWxEYXRhLnB1c2goXy5jbG9uZURlZXAoY2hpbGRSb3cpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIGNsYXNzTGV2ZWxEYXRhLnJldmVyc2UoKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBleHRyYWN0V1NEYXRhKGRhdGEsY2hpbGRPck5vdCkge1xyXG4gICAgbGV0IHJldHVybkRhdGEgPSBbXTtcclxuICAgIGNvbnN0IHRlbXAgPSB7XHJcbiAgICAgIGN1c2lwOiBkYXRhLmN1c2lwLFxyXG4gICAgICBleGNoYW5nZVJhdGU6IGRhdGEuZXhjaGFuZ2VSYXRlLFxyXG4gICAgICAvL2Z1bmRpZDogZGF0YS5mdW5kaWQsXHJcbiAgICAgIGZ1bmRpZDogZGF0YS5mdW5kaWQsXHJcbiAgICAgIGxvbmdTaG9ydEluZGljYXRvcjogZGF0YS5sb25nU2hvcnRJbmRpY2F0b3IsXHJcbiAgICAgIG12OiBkYXRhLm12LFxyXG4gICAgICBtdkNoYW5nZTogZGF0YS5tdkNoYW5nZSxcclxuICAgICAgbmF2SW1wYWN0OiBkYXRhLm5hdkltcGFjdCxcclxuICAgICAgcHJpY2U6IGRhdGEucHJpY2UsXHJcbiAgICAgIHByaWNlQ2hhbmdlUGVyY2VudDogZGF0YS5wcmljZUNoYW5nZVBlcmNlbnQsXHJcbiAgICAgIHNvZE12OiBkYXRhLnNvZE12LFxyXG4gICAgICBzb2RQcmljZTogZGF0YS5zb2RQcmljZSxcclxuICAgICAgdXBkYXRldGltZTogZGF0YS51cGRhdGV0aW1lXHJcbiAgICB9XHJcbiAgICBpZiAoY2hpbGRPck5vdCkge1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBkYXRhKSB7XHJcbiAgICAgICAgaWYgKE51bWJlcihrZXkpKSB7XHJcbiAgICAgICAgICBjb25zdCByb3cgPSBPYmplY3QuYXNzaWduKHRlbXAsIGRhdGFba2V5XSwge2NsYXNzSUQ6IGtleX0pO1xyXG4gICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKF8uY2xvbmVEZWVwKHJvdykpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuRGF0YSA9IGRhdGFbXCJBXCJdO1xyXG4gICAgICByZXR1cm5EYXRhID0gIE9iamVjdC5hc3NpZ24odGVtcCwgcmV0dXJuRGF0YSwge2NsYXNzSUQ6IFwiQVwifSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcmV0dXJuRGF0YTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBzb3J0Q29sdW1uQnlQcm9wKHJvd3MsIGNoaWxkUm93cywgZXhwYW5kQ29sbGFwc2VJY29uTWFwLCBwcm9wLCBhc2NGbGFnKSB7XHJcbiAgICBjb25zdCBwUm93cyA9IFtdO1xyXG4gICAgcm93cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jbGFzc0lEID09PSBcIkFcIikgcFJvd3MucHVzaChpdGVtKTtcclxuICAgICAgaWYgKGNoaWxkUm93cy5sZW5ndGggPT09IDApIHBSb3dzLnB1c2goaXRlbSk7XHJcbiAgICB9KTtcclxuICAgIGFzY0ZsYWcgPyBwUm93cy5zb3J0KHRoaXMuc29ydENvbXBhcmVBc2MocHJvcCkpIDogcFJvd3Muc29ydCh0aGlzLnNvcnRDb21wYXJlRGVzYyhwcm9wKSk7XHJcbiAgICBjaGlsZFJvd3MuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgY29uc3QgZnVuZGlkID0gaXRlbS5mdW5kaWQ7XHJcbiAgICAgIGV4cGFuZENvbGxhcHNlSWNvbk1hcC5mb3JFYWNoKGV4cGFuZEl0ZW0gPT4ge1xyXG4gICAgICAgIGlmIChleHBhbmRJdGVtLmZ1bmRpZCA9PT0gZnVuZGlkICYmIGV4cGFuZEl0ZW0uZXhwYW5kKSB7XHJcbiAgICAgICAgICBjb25zdCBpbmRleCA9IHBSb3dzLmZpbmRJbmRleChwaXRlbSA9PiB7cmV0dXJuIHBpdGVtLmZ1bmRpZCA9PT0gZnVuZGlkfSk7XHJcbiAgICAgICAgICBwUm93cy5zcGxpY2UoaW5kZXggKyAxLCAwLCBpdGVtKVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHBSb3dzO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzb3J0Q29tcGFyZUFzYyhwcm9wKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKG9iajEsIG9iajIpIHtcclxuICAgICAgbGV0IHYxID0gb2JqMVtwcm9wXTtcclxuICAgICAgbGV0IHYyICA9IG9iajJbcHJvcF07XHJcbiAgICAgIGlmICghaXNOYU4oTnVtYmVyKHYxKSkgJiYgIWlzTmFOKE51bWJlcih2MikpKSB7XHJcbiAgICAgICAgdjEgPSBOdW1iZXIodjEpO1xyXG4gICAgICAgIHYyID0gTnVtYmVyKHYyKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHYxID09PSB1bmRlZmluZWQgfHwgdjEgPCB2Mikge1xyXG4gICAgICAgIHJldHVybiAtMVxyXG4gICAgICB9IGVsc2UgaWYgKHYyID09PSB1bmRlZmluZWQgfHwgIHYxID4gdjIpIHtcclxuICAgICAgICByZXR1cm4gMTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gMFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHNvcnRDb21wYXJlRGVzYyhwcm9wKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKG9iajEsIG9iajIpIHtcclxuICAgICAgbGV0IHYxID0gb2JqMVtwcm9wXTtcclxuICAgICAgbGV0IHYyICA9IG9iajJbcHJvcF07XHJcbiAgICAgIGlmICghaXNOYU4oTnVtYmVyKHYxKSkgJiYgIWlzTmFOKE51bWJlcih2MikpKSB7XHJcbiAgICAgICAgdjEgPSBOdW1iZXIodjEpO1xyXG4gICAgICAgIHYyID0gTnVtYmVyKHYyKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAodjEgPT09IHVuZGVmaW5lZCB8fCB2MSA8IHYyICkge1xyXG4gICAgICAgIHJldHVybiAxXHJcbiAgICAgIH0gZWxzZSBpZiAodjIgPT09IHVuZGVmaW5lZCB8fCB2MSA+IHYyKSB7XHJcbiAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiAwXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgdHJpZ2dlcixcclxuICBzdHlsZSxcclxuICBhbmltYXRlLFxyXG4gIHRyYW5zaXRpb25cclxufSBmcm9tICdAYW5ndWxhci9hbmltYXRpb25zJztcclxuaW1wb3J0IHsgRGF0ZVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBzY2FsZUxpbmVhciwgc2NhbGVUaW1lLCBzY2FsZVBvaW50IH0gZnJvbSAnZDMtc2NhbGUnO1xyXG5pbXBvcnQgeyBjdXJ2ZUxpbmVhciB9IGZyb20gJ2QzLXNoYXBlJztcclxuXHJcbmltcG9ydCB7IGlkIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMvcmVsZWFzZS91dGlscyc7XHJcbmltcG9ydCB7IGdldFVuaXF1ZVhEb21haW5WYWx1ZXMgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cy9yZWxlYXNlL2NvbW1vbi9kb21haW4uaGVscGVyJztcclxuXHJcbmltcG9ydCB7IGNhbGN1bGF0ZVZpZXdEaW1lbnNpb25zLCBWaWV3RGltZW5zaW9ucywgQmFzZUNoYXJ0Q29tcG9uZW50LCBDb2xvckhlbHBlciB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItZmluZS1saW5lLWNoYXJ0JyxcclxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJjdXN0b20tY2hhcnRcIj5cclxuICA8bmd4LWNoYXJ0cy1jaGFydCBcclxuICAgICAgW3ZpZXddPVwiW3dpZHRoLCBoZWlnaHRdXCJcclxuICAgICAgW3Nob3dMZWdlbmRdPVwiZmFsc2VcIlxyXG4gICAgICBbbGVnZW5kT3B0aW9uc109XCJsZWdlbmRPcHRpb25zXCJcclxuICAgICAgW2FjdGl2ZUVudHJpZXNdPVwiYWN0aXZlRW50cmllc1wiXHJcbiAgICAgIFthbmltYXRpb25zXT1cImFuaW1hdGlvbnNcIlxyXG4gICAgICAobGVnZW5kTGFiZWxDbGljayk9XCJvbkNsaWNrKCRldmVudClcIlxyXG4gICAgICAobGVnZW5kTGFiZWxBY3RpdmF0ZSk9XCJvbkFjdGl2YXRlKCRldmVudClcIlxyXG4gICAgICAobGVnZW5kTGFiZWxEZWFjdGl2YXRlKT1cIm9uRGVhY3RpdmF0ZSgkZXZlbnQpXCI+XHJcbiAgICAgIDxzdmc6ZGVmcz5cclxuICAgICAgICA8c3ZnOmNsaXBQYXRoIFthdHRyLmlkXT1cImNsaXBQYXRoSWRcIj5cclxuICAgICAgICAgIDxzdmc6cmVjdFxyXG4gICAgICAgICAgICBbYXR0ci53aWR0aF09XCJkaW1zLndpZHRoICsgMTBcIlxyXG4gICAgICAgICAgICBbYXR0ci5oZWlnaHRdPVwiZGltcy5oZWlnaHQgKyAxMFwiXHJcbiAgICAgICAgICAgIFthdHRyLnRyYW5zZm9ybV09XCIndHJhbnNsYXRlKC01LCAtNSknXCIvPlxyXG4gICAgICAgIDwvc3ZnOmNsaXBQYXRoPlxyXG4gICAgICA8L3N2ZzpkZWZzPlxyXG4gICAgICA8c3ZnOmcgW2F0dHIudHJhbnNmb3JtXT1cInRyYW5zZm9ybVwiIGNsYXNzPVwibGluZS1jaGFydCBjaGFydFwiPlxyXG4gICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLXgtYXhpcyBcclxuICAgICAgICAgIFt4U2NhbGVdPVwieFNjYWxlXCJcclxuICAgICAgICAgIFtkaW1zXT1cImRpbXNcIlxyXG4gICAgICAgICAgW3Nob3dMYWJlbF09XCJzaG93WEF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbc2hvd0dyaWRMaW5lc109XCJzaG93R3JpZExpbmVzXCJcclxuICAgICAgICAgIFtsYWJlbFRleHRdPVwieEF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbdGlja3NdPVwidGlja1ZhbHVlc1wiXHJcbiAgICAgICAgICBbdGlja0Zvcm1hdHRpbmddPVwieEF4aXNUaWNrRm9ybWF0dGluZ1wiXHJcbiAgICAgICAgICAoZGltZW5zaW9uc0NoYW5nZWQpPVwidXBkYXRlWEF4aXNIZWlnaHQoJGV2ZW50KVwiPlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMteS1heGlzXHJcbiAgICAgICAgICBbeVNjYWxlXT1cInlTY2FsZVwiXHJcbiAgICAgICAgICBbZGltc109XCJkaW1zXCJcclxuICAgICAgICAgIFtzaG93TGFiZWxdPVwic2hvd1lBeGlzTGFiZWxcIlxyXG4gICAgICAgICAgW2xhYmVsVGV4dF09XCJ5QXhpc0xhYmVsXCJcclxuICAgICAgICAgIFtyZWZlcmVuY2VMaW5lc109XCJyZWZlcmVuY2VMaW5lc1wiXHJcbiAgICAgICAgICBbc2hvd1JlZkxpbmVzXT1cInNob3dSZWZMaW5lc1wiXHJcbiAgICAgICAgICBbc2hvd0dyaWRMaW5lc109XCJzaG93R3JpZExpbmVzXCJcclxuICAgICAgICAgIFtzaG93UmVmTGFiZWxzXT1cInNob3dSZWZMYWJlbHNcIlxyXG4gICAgICAgICAgKGRpbWVuc2lvbnNDaGFuZ2VkKT1cInVwZGF0ZVlBeGlzV2lkdGgoJGV2ZW50KVwiPlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgPHN2ZzpsaW5lXHJcbiAgICAgICAgW2F0dHIueDFdPVwibGFzdERhdGFYXCJcclxuICAgICAgICBbYXR0ci55MV09XCIwXCJcclxuICAgICAgICBbYXR0ci54Ml09XCJsYXN0RGF0YVhcIlxyXG4gICAgICAgIFthdHRyLnkyXT1cImhlaWdodFwiXHJcbiAgICAgICAgW2F0dHIuY2xhc3NdPVwiJ2VuZC1saW5lJ1wiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxzdmc6Zm9yZWlnbk9iamVjdFxyXG4gICAgICAgIFthdHRyLnhdPVwibGFzdERhdGFYIC0gNDBcIlxyXG4gICAgICAgIFthdHRyLnldPVwiaGVpZ2h0IC0gMTVcIlxyXG4gICAgICAgIFthdHRyLndpZHRoXT1cIjgwICsgJ3B4J1wiXHJcbiAgICAgICAgW2F0dHIuaGVpZ2h0XT1cIjMwICsgJ3B4J1wiXHJcbiAgICAgICAgW3N0eWxlLnBvaW50ZXItZXZlbnRzXT1cIidub25lJ1wiPlxyXG4gICAgICAgIDx4aHRtbDpkaXZcclxuICAgICAgICAgIGNsYXNzPSdsYXN0LXRpbWUnXHJcbiAgICAgICAgICBbc3R5bGUud2lkdGhdPVwiODAgKyAncHgnXCJcclxuICAgICAgICAgIFtzdHlsZS5oZWlnaHRdPVwiMjAgKyAncHgnXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgIDx4aHRtbDpzcGFuPiB7e2Rpc3BsYXlMaXZlVGltZSB8IGRhdGU6IFwiaDptbTpzcyBhYWFhYSdtJ1wifX1cclxuICAgICAgICAgIDwveGh0bWw6c3Bhbj5cclxuICAgICAgICA8L3hodG1sOmRpdj5cclxuICAgICAgPC9zdmc6Zm9yZWlnbk9iamVjdD5cclxuICAgICAgICA8c3ZnOmcgW2F0dHIuY2xpcC1wYXRoXT1cImNsaXBQYXRoXCI+XHJcbiAgICAgICAgICA8c3ZnOmcgKm5nRm9yPVwibGV0IHNlcmllcyBvZiByZXN1bHRzOyB0cmFja0J5OnRyYWNrQnlcIiBbQGFuaW1hdGlvblN0YXRlXT1cIidhY3RpdmUnXCI+XHJcbiAgICAgICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLWxpbmUtc2VyaWVzXHJcbiAgICAgICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgICAgICBbY29sb3JzXT1cImNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgW2RhdGFdPVwic2VyaWVzXCJcclxuICAgICAgICAgICAgICBbYWN0aXZlRW50cmllc109XCJhY3RpdmVFbnRyaWVzXCJcclxuICAgICAgICAgICAgICBbc2NhbGVUeXBlXT1cInNjYWxlVHlwZVwiXHJcbiAgICAgICAgICAgICAgW2N1cnZlXT1cImN1cnZlXCJcclxuICAgICAgICAgICAgICBbcmFuZ2VGaWxsT3BhY2l0eV09XCJyYW5nZUZpbGxPcGFjaXR5XCJcclxuICAgICAgICAgICAgICBbaGFzUmFuZ2VdPVwiaGFzUmFuZ2VcIlxyXG4gICAgICAgICAgICAgIFthbmltYXRpb25zXT1cImFuaW1hdGlvbnNcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICAgIDxzdmc6ZyAqbmdJZj1cIiF0b29sdGlwRGlzYWJsZWRcIiAobW91c2VsZWF2ZSk9XCJoaWRlQ2lyY2xlcygpXCI+XHJcbiAgICAgICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLXRvb2x0aXAtYXJlYVxyXG4gICAgICAgICAgICAgIFtkaW1zXT1cImRpbXNcIlxyXG4gICAgICAgICAgICAgIFt4U2V0XT1cInhTZXRcIlxyXG4gICAgICAgICAgICAgIFt4U2NhbGVdPVwieFNjYWxlXCJcclxuICAgICAgICAgICAgICBbeVNjYWxlXT1cInlTY2FsZVwiXHJcbiAgICAgICAgICAgICAgW3Jlc3VsdHNdPVwicmVzdWx0c1wiXHJcbiAgICAgICAgICAgICAgW2NvbG9yc109XCJjb2xvcnNcIlxyXG4gICAgICAgICAgICAgIFt0b29sdGlwRGlzYWJsZWRdPVwiIXRvb2x0aXBEaXNhYmxlZFwiXHJcbiAgICAgICAgICAgICAgKGhvdmVyKT1cInVwZGF0ZUhvdmVyZWRWZXJ0aWNhbCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgICA8c3ZnOmcgKm5nRm9yPVwibGV0IHNlcmllcyBvZiByZXN1bHRzXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtY2lyY2xlLXNlcmllc1xyXG4gICAgICAgICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgICAgICAgW3lTY2FsZV09XCJ5U2NhbGVcIlxyXG4gICAgICAgICAgICAgICAgW2NvbG9yc109XCJjb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgW2RhdGFdPVwic2VyaWVzXCJcclxuICAgICAgICAgICAgICAgIFtzY2FsZVR5cGVdPVwic2NhbGVUeXBlXCJcclxuICAgICAgICAgICAgICAgIFt2aXNpYmxlVmFsdWVdPVwiaG92ZXJlZFZlcnRpY2FsXCJcclxuICAgICAgICAgICAgICAgIFthY3RpdmVFbnRyaWVzXT1cImFjdGl2ZUVudHJpZXNcIlxyXG4gICAgICAgICAgICAgICAgKHNlbGVjdCk9XCJvbkNsaWNrKCRldmVudCwgc2VyaWVzKVwiXHJcbiAgICAgICAgICAgICAgICAoYWN0aXZhdGUpPVwib25BY3RpdmF0ZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChkZWFjdGl2YXRlKT1cIm9uRGVhY3RpdmF0ZSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIFt0b29sdGlwVGVtcGxhdGVdPVwidG9vbHRpcFRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPHN2ZzpnICpuZ0Zvcj1cImxldCBjaXJjbGUgb2YgY2lyY2xlU2VyaWVzXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnOmcgbmd4LWNoYXJ0cy1jaXJjbGVcclxuICAgICAgICAgICAgICAgICAgW2N4XT1cImNpcmNsZS54XCJcclxuICAgICAgICAgICAgICAgICAgW2N5XT1cImNpcmNsZS52YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgIFtyXT1cImNpcmNsZVJhZGl1c1wiXHJcbiAgICAgICAgICAgICAgICAgIFtkYXRhXT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICAgIFtmaWxsXT1cImNpcmNsZS5maWxsXCJcclxuICAgICAgICAgICAgICAgICAgKHNlbGVjdCk9XCJvbkNsaWNrQWxlcnRDaXJjbGUoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgIDxzdmc6ZyAqbmdGb3I9XCJsZXQgY2lyY2xlIG9mIGNpcmNsZVNlcmllc1wiPlxyXG4gICAgICAgICAgICA8c3ZnOmZvcmVpZ25PYmplY3RcclxuICAgICAgICAgICAgICAgICAgKm5nSWY9XCJnZXRTaG93QWxlcnREZXRhaWxzKGNpcmNsZSlcIlxyXG4gICAgICAgICAgICAgICAgICBbYXR0ci54XT1cImdldFJlY3RMb2FjdGlvblgoY2lyY2xlKVwiXHJcbiAgICAgICAgICAgICAgICAgIFthdHRyLnldPVwiZ2V0UmVjdExvYWN0aW9uWShjaXJjbGUpXCJcclxuICAgICAgICAgICAgICAgICAgW2F0dHIud2lkdGhdPVwiMjEwICsgJ3B4J1wiXHJcbiAgICAgICAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCIxNDAgKyAncHgnXCJcclxuICAgICAgICAgICAgICAgICAgW3N0eWxlLnBvaW50ZXItZXZlbnRzXT1cIidub25lJ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx4aHRtbDpkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPSdhbGVydC1kZXRhaWxzLXN0eSdcclxuICAgICAgICAgICAgICAgICAgICAgIFtzdHlsZS5ib3JkZXItY29sb3JdPVwiY2lyY2xlLmZpbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHhodG1sOnNwYW4+IHt7Y2lyY2xlLm5hbWV9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDpzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHhodG1sOnNwYW4+IHt7Y2lyY2xlLnRpbWV9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDpzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgIDx4aHRtbDpsYWJlbD4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTkFWIGRpdmVyZ2luZyBmcm9tIG1hcmtldCB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDpsYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx4aHRtbDp0YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHhodG1sOnRyPk5BViBDaGFuZ2U6PHhodG1sOnRkPnt7Y2lyY2xlLm5hdkNoYW5nZSB8IHBlcmNlbnQ6ICcxLjItMid9fTwveGh0bWw6dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwveGh0bWw6dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx4aHRtbDp0cj5NViBDaGFuZ2U6PHhodG1sOnRkPnt7Y2lyY2xlLm12Q2hhbmdlIHwgcGVyY2VudDogJzEuMi0yJ319PC94aHRtbDp0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC94aHRtbDp0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwveGh0bWw6dGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC94aHRtbDpkaXY+XHJcbiAgICAgICAgICAgICAgICA8L3N2Zzpmb3JlaWduT2JqZWN0PlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgIDwvc3ZnOmc+XHJcbiAgPC9uZ3gtY2hhcnRzLWNoYXJ0PlxyXG4gIDxuZy10ZW1wbGF0ZSAjdG9vbHRpcFRlbXBsYXRlPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibGluZS10b29sdGlwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidG9wXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmdW5kLW5hbWVcIj57e3Rvb2x0aXBPYmoubmFtZX19IDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3Bhbj4gLSA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0aW1lXCI+e3t0b29sdGlwT2JqLnZhbHVlIHwgZGF0ZTogXCJoOm1tOnNzIGFhYWFhJ20nXCJ9fTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHRhYmxlPlxyXG4gICAgICAgICAgICA8dHIgYWxpZ249J3JpZ2h0Jz5OQVY8dGQ+e3t0b29sdGlwT2JqLm5hdiB8IG51bWJlcjogJzEuMi0yJ319PC90ZD48L3RyPlxyXG4gICAgICAgICAgICA8dHIgYWxpZ249J3JpZ2h0Jz5NViBBbXQgQmFzZTx0ZD57e3Rvb2x0aXBPYmoubWFya2V0dmFsIHwgbnVtYmVyOiAnMS4yLTInfX08L3RkPjwvdHI+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICA8L2Rpdj5cclxuICA8L25nLXRlbXBsYXRlPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2AuY3VzdG9tLWNoYXJ0e3Bvc2l0aW9uOnJlbGF0aXZlfS5jdXN0b20tY2hhcnQgLmN1c3RvbS10b29sdGlwe2JhY2tncm91bmQtY29sb3I6I2RkZDtib3JkZXI6MnB4IHNvbGlkIGdyZXk7cG9zaXRpb246YWJzb2x1dGU7ei1pbmRleDo5OX0uY3VzdG9tLWNoYXJ0IC5jdXN0b20tdG9vbHRpcCB0YWJsZXtib3JkZXItc3BhY2luZzowO2JvcmRlci1jb2xsYXBzZTpjb2xsYXBzZTt3aWR0aDoxMDAlfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHN7ZmxvYXQ6bGVmdDtvdmVyZmxvdzp2aXNpYmxlfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmN1c3RvbS1heGlzLWxpbmV7c3Ryb2tlOiNlZWU7c3Ryb2tlLXdpZHRoOjJ9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuZW5kLWxpbmV7c3Ryb2tlOiM2Yzc1N2Q7c3Ryb2tlLXdpZHRoOjF9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAubGFzdC10aW1le2JhY2tncm91bmQtY29sb3I6I2VlZTtib3gtc2hhZG93OjAgMCAycHggMCByZ2JhKDAsMCwwLC4xNSk7ZGlzcGxheTpmbGV4O2p1c3RpZnktY29udGVudDpjZW50ZXI7YWxpZ24taXRlbXM6Y2VudGVyO2ZvbnQtd2VpZ2h0OjcwMDtmb250LXNpemU6MTRweDtib3JkZXItcmFkaXVzOjVweH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hbGVydC1kZXRhaWxzLXN0eXtjb2xvcjojNmM3NTdkO2JvcmRlcjoycHggc29saWQ7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDI1NSwyNTUsMjU1LC45KTt3aWR0aDoyMDBweDtoZWlnaHQ6OTVweDtwYWRkaW5nLWxlZnQ6NXB4fS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFsZXJ0LWRldGFpbHMtc3R5IHNwYW57dGV4dC1hbGlnbjpjZW50ZXI7ZGlzcGxheTppbmxpbmUtZmxleDt3aWR0aDo4MHB4O2ZvbnQtc2l6ZToxNHB4O2ZvbnQtd2VpZ2h0OjcwMH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hbGVydC1kZXRhaWxzLXN0eSBsYWJlbHtkaXNwbGF5OmlubGluZS1ibG9jaztmb250LXNpemU6MTJweDtwYWRkaW5nOjVweCAwIDVweCAycHh9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYWxlcnQtZGV0YWlscy1zdHkgdGFibGV7Zm9udC1zaXplOjEycHh9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYXJjLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmJhciwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jaXJjbGV7Y3Vyc29yOnBvaW50ZXJ9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYXJjLmFjdGl2ZSwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hcmM6aG92ZXIsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYmFyLmFjdGl2ZSwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5iYXI6aG92ZXIsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY2FyZC5hY3RpdmUsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY2FyZDpob3ZlciwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jZWxsLmFjdGl2ZSwuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5jZWxsOmhvdmVye29wYWNpdHk6Ljg7dHJhbnNpdGlvbjpvcGFjaXR5IC4xcyBlYXNlLWluLW91dH0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5hcmM6Zm9jdXMsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYmFyOmZvY3VzLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmNhcmQ6Zm9jdXMsLmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuY2VsbDpmb2N1cywuY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIGc6Zm9jdXN7b3V0bGluZTowfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmFyZWEtc2VyaWVzLmluYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmxpbmUtc2VyaWVzLXJhbmdlLmluYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmxpbmUtc2VyaWVzLmluYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLnBvbGFyLXNlcmllcy1hcmVhLmluYWN0aXZlLC5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLnBvbGFyLXNlcmllcy1wYXRoLmluYWN0aXZle3RyYW5zaXRpb246b3BhY2l0eSAuMXMgZWFzZS1pbi1vdXQ7b3BhY2l0eTouMn0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5saW5lLWhpZ2hsaWdodHtkaXNwbGF5Om5vbmV9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAubGluZS1oaWdobGlnaHQuYWN0aXZle2Rpc3BsYXk6YmxvY2t9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuYXJlYXtvcGFjaXR5Oi42fS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmNpcmNsZTpob3ZlcntjdXJzb3I6cG9pbnRlcn0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5sYWJlbHtmb250LXNpemU6MThweDtmb250LXdlaWdodDo0MDB9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAudG9vbHRpcC1hbmNob3J7ZmlsbDojMDAwfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmdyaWRsaW5lLXBhdGh7c3Ryb2tlOiNkZGQ7c3Ryb2tlLXdpZHRoOjE7ZmlsbDpub25lfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLnJlZmxpbmUtcGF0aHtzdHJva2U6I2E4YjJjNztzdHJva2Utd2lkdGg6MTtzdHJva2UtZGFzaGFycmF5OjU7c3Ryb2tlLWRhc2hvZmZzZXQ6NX0uY3VzdG9tLWNoYXJ0IC5uZ3gtY2hhcnRzIC5yZWZsaW5lLWxhYmVse2ZvbnQtc2l6ZTo5cHh9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAucmVmZXJlbmNlLWFyZWF7ZmlsbC1vcGFjaXR5Oi4wNTtmaWxsOiMwMDB9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuZ3JpZGxpbmUtcGF0aC1kb3R0ZWR7c3Ryb2tlOiNkZGQ7c3Ryb2tlLXdpZHRoOjE7ZmlsbDpub25lO3N0cm9rZS1kYXNoYXJyYXk6MSwyMDtzdHJva2UtZGFzaG9mZnNldDozfS5jdXN0b20tY2hhcnQgLm5neC1jaGFydHMgLmdyaWQtcGFuZWwgcmVjdHtmaWxsOm5vbmV9LmN1c3RvbS1jaGFydCAubmd4LWNoYXJ0cyAuZ3JpZC1wYW5lbC5vZGQgcmVjdHtmaWxsOnJnYmEoMTcwLDM1LDM1LC4wNSl9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudHtwb3NpdGlvbjpmaXhlZDtib3JkZXItcmFkaXVzOjNweDt6LWluZGV4OjUwMDA7ZGlzcGxheTpibG9jaztmb250LXdlaWdodDo0MDA7b3BhY2l0eTowO3BvaW50ZXItZXZlbnRzOm5vbmUhaW1wb3J0YW50O2ZvbnQtc2l6ZToxNHB4fS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLmxpbmUtdG9vbHRpcCAudG9we2JvcmRlci1ib3R0b206MXB4IHNvbGlkIGdyZXk7cGFkZGluZy1ib3R0b206NXB4O21hcmdpbi1ib3R0b206MDtvdmVyZmxvdzphdXRvfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLmxpbmUtdG9vbHRpcCAudG9wIC5mdW5kLW5hbWV7ZmxvYXQ6bGVmdDtmb250LXdlaWdodDo3MDB9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIC50b3AgLnRpbWV7ZmxvYXQ6cmlnaHQ7Zm9udC13ZWlnaHQ6NzAwfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLmxpbmUtdG9vbHRpcCAuZGVzY3JpcHRpb257Y2xlYXI6Ym90aDtmb250LXNpemU6MTRweDttYXJnaW4tdG9wOjEwcHh9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudCAubGluZS10b29sdGlwIHRke3BhZGRpbmc6MnB4IDIwcHg7dGV4dC1hbGlnbjpyaWdodH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50IC5saW5lLXRvb2x0aXAgLmJ0aC1ncm91cHtmbG9hdDpyaWdodDttYXJnaW4tcmlnaHQ6LTEwcHg7bWFyZ2luLXRvcDoxNXB4fS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQgLmxpbmUtdG9vbHRpcCAuYnRoLWdyb3VwIGJ1dHRvbntiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7cGFkZGluZzo4cHg7Ym9yZGVyOjJweCBzb2xpZCAjZGRkO3dpZHRoOjg1cHg7Zm9udC1zaXplOjEycHh9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC50eXBlLXRvb2x0aXB7Y29sb3I6IzAwMDtiYWNrZ3JvdW5kOiNlZWU7Zm9udC1zaXplOjE0cHg7cGFkZGluZzoxNXB4IDE4cHg7dGV4dC1hbGlnbjpsZWZ0O3BvaW50ZXItZXZlbnRzOmF1dG87d2lkdGg6MjIwcHg7aGVpZ2h0OjExNXB4O2JvcmRlcjoycHggc29saWQgI2RkZH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnR5cGUtdG9vbHRpcC5hbGVydDF7Ym9yZGVyOjJweCBzb2xpZCAjZmZiYzA2O2hlaWdodDoxNTBweDt3aWR0aDoyNDlweH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnR5cGUtdG9vbHRpcC5hbGVydDJ7Ym9yZGVyOjJweCBzb2xpZCAjYjkxMjI0O2hlaWdodDoxNTBweDt3aWR0aDoyNDlweH0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnR5cGUtdG9vbHRpcCAudG9vbHRpcC1jYXJldC5wb3NpdGlvbi1sZWZ0e2JvcmRlci10b3A6N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci1ib3R0b206N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci1sZWZ0OjdweCBzb2xpZCAjZWVlfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwIC50b29sdGlwLWNhcmV0LnBvc2l0aW9uLXRvcHtib3JkZXItbGVmdDo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLXJpZ2h0OjdweCBzb2xpZCB0cmFuc3BhcmVudDtib3JkZXItdG9wOjdweCBzb2xpZCAjZWVlfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQudHlwZS10b29sdGlwIC50b29sdGlwLWNhcmV0LnBvc2l0aW9uLXJpZ2h0e2JvcmRlci10b3A6N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci1ib3R0b206N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci1yaWdodDo3cHggc29saWQgI2VlZX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnR5cGUtdG9vbHRpcCAudG9vbHRpcC1jYXJldC5wb3NpdGlvbi1ib3R0b217Ym9yZGVyLWxlZnQ6N3B4IHNvbGlkIHRyYW5zcGFyZW50O2JvcmRlci1yaWdodDo3cHggc29saWQgdHJhbnNwYXJlbnQ7Ym9yZGVyLWJvdHRvbTo3cHggc29saWQgI2VlZX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50IC50b29sdGlwLWNhcmV0e3Bvc2l0aW9uOmFic29sdXRlO3otaW5kZXg6NTAwMTt3aWR0aDowO2hlaWdodDowfS50eXBlLXRvb2x0aXAubmd4LWNoYXJ0cy10b29sdGlwLWNvbnRlbnQucG9zaXRpb24tcmlnaHR7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlM2QoMTBweCwwLDApO3RyYW5zZm9ybTp0cmFuc2xhdGUzZCgxMHB4LDAsMCl9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC5wb3NpdGlvbi1sZWZ0ey13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCl9LnR5cGUtdG9vbHRpcC5uZ3gtY2hhcnRzLXRvb2x0aXAtY29udGVudC5wb3NpdGlvbi10b3B7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlM2QoMCwtMTBweCwwKTt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoMCwtMTBweCwwKX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LnBvc2l0aW9uLWJvdHRvbXstd2Via2l0LXRyYW5zZm9ybTp0cmFuc2xhdGUzZCgwLDEwcHgsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDAsMTBweCwwKX0udHlwZS10b29sdGlwLm5neC1jaGFydHMtdG9vbHRpcC1jb250ZW50LmFuaW1hdGV7b3BhY2l0eToxO3RyYW5zaXRpb246b3BhY2l0eSAuM3MsdHJhbnNmb3JtIC4zcywtd2Via2l0LXRyYW5zZm9ybSAuM3M7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlM2QoMCwwLDApO3RyYW5zZm9ybTp0cmFuc2xhdGUzZCgwLDAsMCk7cG9pbnRlci1ldmVudHM6YXV0b30uYXJlYS10b29sdGlwLWNvbnRhaW5lcntwYWRkaW5nOjVweCAwO3BvaW50ZXItZXZlbnRzOm5vbmV9LnRvb2x0aXAtaXRlbXt0ZXh0LWFsaWduOmxlZnQ7bGluZS1oZWlnaHQ6MS4yZW07cGFkZGluZzo1cHggMH0udG9vbHRpcC1pdGVtIC50b29sdGlwLWl0ZW0tY29sb3J7ZGlzcGxheTppbmxpbmUtYmxvY2s7aGVpZ2h0OjEycHg7d2lkdGg6MTJweDttYXJnaW4tcmlnaHQ6NXB4O2NvbG9yOiM1YjY0NmI7Ym9yZGVyLXJhZGl1czozcHh9YF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uU2hhZG93RG9tLFxyXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxyXG4gIGFuaW1hdGlvbnM6IFtcclxuICAgIHRyaWdnZXIoJ2FuaW1hdGlvblN0YXRlJywgW1xyXG4gICAgICB0cmFuc2l0aW9uKCc6bGVhdmUnLCBbXHJcbiAgICAgICAgc3R5bGUoe1xyXG4gICAgICAgICAgb3BhY2l0eTogMSxcclxuICAgICAgICB9KSxcclxuICAgICAgICBhbmltYXRlKDUwMCwgc3R5bGUoe1xyXG4gICAgICAgICAgb3BhY2l0eTogMFxyXG4gICAgICAgIH0pKVxyXG4gICAgICBdKVxyXG4gICAgXSlcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBMaW5lQ2hhcnRDb21wb25lbnQgZXh0ZW5kcyBCYXNlQ2hhcnRDb21wb25lbnQge1xyXG4gIEBJbnB1dCgpIGxlZ2VuZDtcclxuICBASW5wdXQoKSBsZWdlbmRUaXRsZTogc3RyaW5nID0gJ0xlZ2VuZCc7XHJcbiAgQElucHV0KCkgc2hvd1hBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgc2hvd1lBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgeEF4aXNMYWJlbDtcclxuICBASW5wdXQoKSB5QXhpc0xhYmVsO1xyXG4gIEBJbnB1dCgpIGF1dG9TY2FsZTtcclxuICBASW5wdXQoKSB0aW1lbGluZTtcclxuICBASW5wdXQoKSBncmFkaWVudDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBzaG93R3JpZExpbmVzOiBib29sZWFuID0gdHJ1ZTtcclxuICBASW5wdXQoKSBjdXJ2ZTogYW55ID0gY3VydmVMaW5lYXI7XHJcbiAgQElucHV0KCkgc2NoZW1lVHlwZTogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIHJhbmdlRmlsbE9wYWNpdHk6IG51bWJlcjtcclxuICBASW5wdXQoKSB4QXhpc1RpY2tGb3JtYXR0aW5nOiBhbnk7XHJcbiAgQElucHV0KCkgeUF4aXNUaWNrRm9ybWF0dGluZzogYW55O1xyXG4gIEBJbnB1dCgpIHhBeGlzVGlja3M6IGFueVtdO1xyXG4gIEBJbnB1dCgpIHlBeGlzVGlja3M6IGFueVtdO1xyXG4gIEBJbnB1dCgpIHJvdW5kRG9tYWluczogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHRvb2x0aXBEaXNhYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHNob3dSZWZMaW5lczogYm9vbGVhbiA9IGZhbHNlOyAvLyBpZiBkb24ndCBzaG93IGdyaWQgbGluZSBpbiB4LWF4aXMgbGV2ZWwgd2UgY2FuIHVzZSByZWZMaW5lIHRvIGN1c3RvbWl6ZSB4LWF4aXMgbGV2ZWwgbGluZXMuLlxyXG4gIEBJbnB1dCgpIHJlZmVyZW5jZUxpbmVzOiBhbnkgPSBbXTsgLy9beyB2YWx1ZTogMC4xLCBuYW1lOiAnTWF4aW11bScgfSwgeyB2YWx1ZTogMC4wLCBuYW1lOiAnQXZlcmFnZScgfSwgeyB2YWx1ZTogLTAuMSwgbmFtZTogJ01pbmltdW0nIH1dO1xyXG4gIEBJbnB1dCgpIHNob3dSZWZMYWJlbHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSB4U2NhbGVNaW46IGFueTtcclxuICBASW5wdXQoKSB4U2NhbGVNYXg6IGFueTtcclxuICBASW5wdXQoKSB5U2NhbGVNaW46IG51bWJlcjtcclxuICBASW5wdXQoKSB5U2NhbGVNYXg6IG51bWJlcjtcclxuICBASW5wdXQoKSBzZWxlY3RhYmxlO1xyXG4gIEBJbnB1dCgpIGhlaWdodDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHdpZHRoOiBudW1iZXI7XHJcbiAgQElucHV0KCkgbWFyZ2luOiBudW1iZXI7XHJcbiAgQElucHV0KCkgY29sb3JEb21haW46IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgcmVzdWx0czogYW55W107XHJcbiAgQElucHV0KCkgY2lyY2xlRGF0YTogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSBjdXJyZW50TGluZVRpbWU6IHN0cmluZztcclxuICBASW5wdXQoKSB0aWNrVmFsdWVzOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIGRpc3BsYXlMaXZlVGltZTogYW55O1xyXG4gIEBJbnB1dCgpIGFjdGl2ZUVudHJpZXM6IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgaGlnaExpZ2h0QWN0aXZlRW50cmllczogYW55W10gPSBbXTtcclxuXHJcbiAgQE91dHB1dCgpIGFjdGl2YXRlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICBAT3V0cHV0KCkgZGVhY3RpdmF0ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gIEBDb250ZW50Q2hpbGQoJ3Rvb2x0aXBUZW1wbGF0ZScpIHRvb2x0aXBUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcclxuICBAQ29udGVudENoaWxkKCdzZXJpZXNUb29sdGlwVGVtcGxhdGUnKSBzZXJpZXNUb29sdGlwVGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XHJcbiAgZGltczogVmlld0RpbWVuc2lvbnM7XHJcbiAgeFNldDogYW55O1xyXG4gIHhEb21haW46IGFueTtcclxuICB5RG9tYWluOiBhbnk7XHJcbiAgc2VyaWVzRG9tYWluOiBhbnk7XHJcbiAgeVNjYWxlOiBhbnk7XHJcbiAgeFNjYWxlOiBhbnk7XHJcbiAgY29sb3JzOiBDb2xvckhlbHBlcjtcclxuICBzY2FsZVR5cGU6IHN0cmluZztcclxuICB0cmFuc2Zvcm06IHN0cmluZztcclxuICBjbGlwUGF0aDogc3RyaW5nO1xyXG4gIGNsaXBQYXRoSWQ6IHN0cmluZztcclxuICBzZXJpZXM6IGFueTtcclxuICBhcmVhUGF0aDogYW55O1xyXG4gIGhvdmVyZWRWZXJ0aWNhbDogYW55OyAvLyB0aGUgdmFsdWUgb2YgdGhlIHggYXhpcyB0aGF0IGlzIGhvdmVyZWQgb3ZlclxyXG4gIHhBeGlzSGVpZ2h0OiBudW1iZXIgPSAwO1xyXG4gIHlBeGlzV2lkdGg6IG51bWJlciA9IDA7XHJcbiAgZmlsdGVyZWREb21haW46IGFueTtcclxuICBsZWdlbmRPcHRpb25zOiBhbnk7XHJcbiAgaGFzUmFuZ2U6IGJvb2xlYW47IC8vIHdoZXRoZXIgdGhlIGxpbmUgaGFzIGEgbWluLW1heCByYW5nZSBhcm91bmQgaXRcclxuICB0aW1lbGluZVdpZHRoOiBhbnk7XHJcbiAgdGltZWxpbmVIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIHRpbWVsaW5lWFNjYWxlOiBhbnk7XHJcbiAgdGltZWxpbmVZU2NhbGU6IGFueTtcclxuICB0aW1lbGluZVhEb21haW46IGFueTtcclxuICB0aW1lbGluZVRyYW5zZm9ybTogYW55O1xyXG4gIHRpbWVsaW5lUGFkZGluZzogbnVtYmVyID0gMTA7XHJcbiAgY2lyY2xlU2VyaWVzOiBhbnk7XHJcbiAgY3VzdG9tQ29sb3JzOiBhbnlbXTtcclxuICBjaXJjbGVSYWRpdXM6IG51bWJlciA9IDU7XHJcbiAgdG9vbHRpcE9iajogYW55ID0ge307XHJcbiAgY3VzdG9tVG9vbHRpcENsYXNzOiBzdHJpbmc7XHJcbiAgbGFzdERhdGFYOiBudW1iZXI7XHJcbiAgc2hvd0FsZXJ0RGV0YWlsc01hcDogYW55W10gPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3IoY2hhcnRFbGVtZW50OiBFbGVtZW50UmVmLCBcclxuICAgICAgICAgICAgICAgICAgICAgIHpvbmU6IE5nWm9uZSwgXHJcbiAgICAgICAgICAgICAgICAgICAgICBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIGRhdGVQaXBlOiBEYXRlUGlwZSkge1xyXG4gICAgc3VwZXIoY2hhcnRFbGVtZW50LCB6b25lLCBjZCk7XHJcbiAgfVxyXG5cclxuICB1cGRhdGUoKTogdm9pZCB7XHJcblxyXG4gICAgdGhpcy5kaW1zID0gY2FsY3VsYXRlVmlld0RpbWVuc2lvbnMoe1xyXG4gICAgICB3aWR0aDogdGhpcy53aWR0aCxcclxuICAgICAgaGVpZ2h0OiB0aGlzLmhlaWdodCxcclxuICAgICAgbWFyZ2luczogdGhpcy5tYXJnaW4sXHJcbiAgICAgIHhBeGlzSGVpZ2h0OiB0aGlzLnhBeGlzSGVpZ2h0LFxyXG4gICAgICB5QXhpc1dpZHRoOiB0aGlzLnlBeGlzV2lkdGgsXHJcbiAgICAgIHNob3dYTGFiZWw6IHRoaXMuc2hvd1hBeGlzTGFiZWwsXHJcbiAgICAgIHNob3dZTGFiZWw6IHRoaXMuc2hvd1lBeGlzTGFiZWwsXHJcbiAgICAgIHNob3dMZWdlbmQ6IHRoaXMubGVnZW5kLFxyXG4gICAgICBsZWdlbmRUeXBlOiB0aGlzLnNjaGVtZVR5cGUsXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAodGhpcy50aW1lbGluZSkge1xyXG4gICAgICB0aGlzLmRpbXMuaGVpZ2h0IC09ICh0aGlzLnRpbWVsaW5lSGVpZ2h0ICsgdGhpcy5tYXJnaW5bMl0gKyB0aGlzLnRpbWVsaW5lUGFkZGluZyk7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy54RG9tYWluID0gdGhpcy5nZXRYRG9tYWluKCk7XHJcbiAgICBpZiAodGhpcy5maWx0ZXJlZERvbWFpbikge1xyXG4gICAgICB0aGlzLnhEb21haW4gPSB0aGlzLmZpbHRlcmVkRG9tYWluO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMueURvbWFpbiA9IHRoaXMuZ2V0WURvbWFpbigpO1xyXG4gICAgdGhpcy5zZXJpZXNEb21haW4gPSB0aGlzLmdldFNlcmllc0RvbWFpbigpO1xyXG5cclxuICAgIHRoaXMueFNjYWxlID0gdGhpcy5nZXRYU2NhbGUodGhpcy54RG9tYWluLCB0aGlzLmRpbXMud2lkdGgpO1xyXG5cclxuICAgIHRoaXMueVNjYWxlID0gdGhpcy5nZXRZU2NhbGUodGhpcy55RG9tYWluLCB0aGlzLmRpbXMuaGVpZ2h0KTtcclxuXHJcbiAgICB0aGlzLmN1c3RvbUNvbG9ycyA9IHRoaXMuc2V0Q3VzdG9tY29sb3JzKCk7XHJcbiAgICB0aGlzLnNldENvbG9ycygpO1xyXG4gICAgdGhpcy5sZWdlbmRPcHRpb25zID0gdGhpcy5nZXRMZWdlbmRPcHRpb25zKCk7XHJcblxyXG4gICAgdGhpcy50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlKCR7dGhpcy5kaW1zLnhPZmZzZXR9ICwgJHt0aGlzLm1hcmdpblswXX0pYDtcclxuXHJcbiAgICB0aGlzLmNsaXBQYXRoSWQgPSAnY2xpcCcgKyBpZCgpLnRvU3RyaW5nKCk7XHJcbiAgICB0aGlzLmNsaXBQYXRoID0gYHVybCgjJHt0aGlzLmNsaXBQYXRoSWR9KWA7XHJcblxyXG4gICAgLy9tYXAgY2lyY2xlXHJcbiAgICB0aGlzLmNpcmNsZVNlcmllcyA9IHRoaXMubWFwQ2lyY2xlKHRoaXMuY2lyY2xlRGF0YSk7XHJcbiAgICB0aGlzLmxhc3REYXRhWD10aGlzLnhTY2FsZSh0aGlzLmN1cnJlbnRMaW5lVGltZSk7XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIG1hcENpcmNsZShjaXJjbGVEYXRhKTogYW55W10ge1xyXG4gICAgbGV0IHhzY2FsZSA9IHRoaXMueFNjYWxlO1xyXG4gICAgbGV0IHlzY2FsZSA9IHRoaXMueVNjYWxlO1xyXG4gICAgbGV0IGFyciA9IFtdO1xyXG5cclxuICAgIGNpcmNsZURhdGEuZm9yRWFjaCgoaXRlbSwgaW5kZXgpICA9PiB7XHJcbiAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgeDogeHNjYWxlKGl0ZW0ueCksXHJcbiAgICAgICAgdGltZTogdGhpcy5kYXRlUGlwZS50cmFuc2Zvcm0oaXRlbS5wcmljZXRpbWUsXCJoaDptbTpzcyBhYWFhYSdtJ1wiKSxcclxuICAgICAgICB2YWx1ZTogeXNjYWxlKGl0ZW0udmFsdWUpLFxyXG4gICAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgICAgICBmaWxsOiBpdGVtLmFsZXJ0VHlwZSA9PSAxID8gWycjZmZiYzA2J10gOiBbJyNiOTEyMjQnXSxcclxuICAgICAgICBhbGVydFR5cGU6IGl0ZW0uYWxlcnRUeXBlLFxyXG4gICAgICAgIG5hdkNoYW5nZTogaXRlbS52YWx1ZSxcclxuICAgICAgICBtdkNoYW5nZTogaXRlbS5mdW5kbXZDaGFuZ2VQZXJjZW50LFxyXG4gICAgICAgIHByaWNldGltZTogaXRlbS5wcmljZXRpbWUsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhcnIucHVzaChvYmopO1xyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGFycjtcclxuICB9XHJcblxyXG4gIHNldEN1c3RvbWNvbG9ycygpOiBhbnlbXSB7XHJcbiAgICBsZXQgYXJyID0gW107XHJcbiAgICB0aGlzLnJlc3VsdHMuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgdGhpcy5jb2xvckRvbWFpbi5mb3JFYWNoKGNvbG9yID0+IHtcclxuICAgICAgICBpZiAoaXRlbVsnbmFtZSddID09PSBjb2xvclsnZnVuZGlkJ10pIHtcclxuICAgICAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgICAgIG5hbWU6IGNvbG9yLmZ1bmRpZCxcclxuICAgICAgICAgICAgdmFsdWU6IGNvbG9yLmNvbG9yXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBhcnIucHVzaChvYmopXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gYXJyO1xyXG4gIH1cclxuXHJcbiAgZ2V0WERvbWFpbigpOiBhbnlbXSB7XHJcbiAgICBsZXQgdmFsdWVzID0gZ2V0VW5pcXVlWERvbWFpblZhbHVlcyh0aGlzLnJlc3VsdHMpO1xyXG4gICAgdGhpcy5zY2FsZVR5cGUgPSB0aGlzLmdldFNjYWxlVHlwZSh2YWx1ZXMpO1xyXG4gICAgbGV0IGRvbWFpbiA9IFtdO1xyXG5cclxuICAgIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgdmFsdWVzID0gdmFsdWVzLm1hcCh2ID0+IE51bWJlcih2KSk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1pbjtcclxuICAgIGxldCBtYXg7XHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICd0aW1lJyB8fCB0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgbWluID0gdGhpcy54U2NhbGVNaW5cclxuICAgICAgICA/IHRoaXMueFNjYWxlTWluXHJcbiAgICAgICAgOiBNYXRoLm1pbiguLi52YWx1ZXMpO1xyXG5cclxuICAgICAgbWF4ID0gdGhpcy54U2NhbGVNYXhcclxuICAgICAgICA/IHRoaXMueFNjYWxlTWF4XHJcbiAgICAgICAgOiBNYXRoLm1heCguLi52YWx1ZXMpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ3RpbWUnKSB7XHJcbiAgICAgIGRvbWFpbiA9IFtuZXcgRGF0ZShtaW4pLCBuZXcgRGF0ZShtYXgpXTtcclxuICAgICAgdGhpcy54U2V0ID0gWy4uLnZhbHVlc10uc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFEYXRlID0gYS5nZXRUaW1lKCk7XHJcbiAgICAgICAgY29uc3QgYkRhdGUgPSBiLmdldFRpbWUoKTtcclxuICAgICAgICBpZiAoYURhdGUgPiBiRGF0ZSkgcmV0dXJuIDE7XHJcbiAgICAgICAgaWYgKGJEYXRlID4gYURhdGUpIHJldHVybiAtMTtcclxuICAgICAgICByZXR1cm4gMDtcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAnbGluZWFyJykge1xyXG4gICAgICBkb21haW4gPSBbbWluLCBtYXhdO1xyXG4gICAgICAvLyBVc2UgY29tcGFyZSBmdW5jdGlvbiB0byBzb3J0IG51bWJlcnMgbnVtZXJpY2FsbHlcclxuICAgICAgdGhpcy54U2V0ID0gWy4uLnZhbHVlc10uc29ydCgoYSwgYikgPT4gKGEgLSBiKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb21haW4gPSB2YWx1ZXM7XHJcbiAgICAgIHRoaXMueFNldCA9IHZhbHVlcztcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZG9tYWluO1xyXG4gIH1cclxuXHJcbiAgZ2V0WURvbWFpbigpOiBhbnlbXSB7XHJcbiAgICBjb25zdCBkb21haW4gPSBbXTtcclxuICAgIGZvciAoY29uc3QgcmVzdWx0cyBvZiB0aGlzLnJlc3VsdHMpIHtcclxuICAgICAgZm9yIChjb25zdCBkIG9mIHJlc3VsdHMuc2VyaWVzKSB7XHJcbiAgICAgICAgaWYgKGQudmFsdWUgJiYgZG9tYWluLmluZGV4T2YoZC52YWx1ZSkgPCAwKSB7XHJcbiAgICAgICAgICBkb21haW4ucHVzaChkLnZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGQubWluICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgIHRoaXMuaGFzUmFuZ2UgPSB0cnVlO1xyXG4gICAgICAgICAgaWYgKGRvbWFpbi5pbmRleE9mKGQubWluKSA8IDApIHtcclxuICAgICAgICAgICAgZG9tYWluLnB1c2goZC5taW4pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZC5tYXggIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgdGhpcy5oYXNSYW5nZSA9IHRydWU7XHJcbiAgICAgICAgICBpZiAoZG9tYWluLmluZGV4T2YoZC5tYXgpIDwgMCkge1xyXG4gICAgICAgICAgICBkb21haW4ucHVzaChkLm1heCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdmFsdWVzID0gWy4uLmRvbWFpbl07XHJcbiAgICBpZiAoIXRoaXMuYXV0b1NjYWxlKSB7XHJcbiAgICAgIHZhbHVlcy5wdXNoKDApO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG1pbiA9IHRoaXMueVNjYWxlTWluXHJcbiAgICAgID8gdGhpcy55U2NhbGVNaW5cclxuICAgICAgOiBNYXRoLm1pbiguLi52YWx1ZXMpO1xyXG5cclxuICAgIGNvbnN0IG1heCA9IHRoaXMueVNjYWxlTWF4XHJcbiAgICAgID8gdGhpcy55U2NhbGVNYXhcclxuICAgICAgOiBNYXRoLm1heCguLi52YWx1ZXMpO1xyXG5cclxuICAgICAgaWYgKG1pbiAhPT0gdW5kZWZpbmVkICYmIG1heCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgcmV0dXJuIFttaW4sIG1heF07XHJcbiAgICAgIH1lbHNlIHtcclxuICAgICAgICByZXR1cm4gWy0wLjEsIDAuMV07XHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIGdldFNlcmllc0RvbWFpbigpOiBhbnlbXSB7XHJcbiAgICByZXR1cm4gdGhpcy5yZXN1bHRzLm1hcChkID0+IGQubmFtZSk7XHJcbiAgfVxyXG5cclxuICBnZXRYU2NhbGUoZG9tYWluLCB3aWR0aCk6IGFueSB7XHJcbiAgICBsZXQgc2NhbGU7XHJcblxyXG4gICAgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAndGltZScpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZVRpbWUoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5kb21haW4oZG9tYWluKTtcclxuICAgIH0gZWxzZSBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdsaW5lYXInKSB7XHJcbiAgICAgIHNjYWxlID0gc2NhbGVMaW5lYXIoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5kb21haW4oZG9tYWluKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLnJvdW5kRG9tYWlucykge1xyXG4gICAgICAgIHNjYWxlID0gc2NhbGUubmljZSgpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZVBvaW50KClcclxuICAgICAgICAucmFuZ2UoWzAsIHdpZHRoXSlcclxuICAgICAgICAucGFkZGluZygwLjEpXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBzY2FsZTtcclxuICB9XHJcblxyXG4gIGdldFlTY2FsZShkb21haW4sIGhlaWdodCk6IGFueSB7XHJcbiAgICBjb25zdCBzY2FsZSA9IHNjYWxlTGluZWFyKClcclxuICAgICAgLnJhbmdlKFtoZWlnaHQsIDBdKVxyXG4gICAgICAuZG9tYWluKGRvbWFpbik7XHJcblxyXG4gICAgcmV0dXJuIHRoaXMucm91bmREb21haW5zID8gc2NhbGUubmljZSgpIDogc2NhbGU7XHJcbiAgfVxyXG5cclxuICBnZXRTY2FsZVR5cGUodmFsdWVzKTogc3RyaW5nIHtcclxuICAgIGxldCBkYXRlID0gdHJ1ZTtcclxuICAgIGxldCBudW0gPSB0cnVlO1xyXG5cclxuICAgIGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSB7XHJcbiAgICAgIGlmICghdGhpcy5pc0RhdGUodmFsdWUpKSB7XHJcbiAgICAgICAgZGF0ZSA9IGZhbHNlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJykge1xyXG4gICAgICAgIG51bSA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGUpIHJldHVybiAndGltZSc7XHJcbiAgICBpZiAobnVtKSByZXR1cm4gJ2xpbmVhcic7XHJcbiAgICByZXR1cm4gJ29yZGluYWwnO1xyXG4gIH1cclxuXHJcbiAgaXNEYXRlKHZhbHVlKTogYm9vbGVhbiB7XHJcbiAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVlBeGlzV2lkdGgoeyB3aWR0aCB9KTogdm9pZCB7XHJcbiAgICB0aGlzLnlBeGlzV2lkdGggPSB3aWR0aDtcclxuICAgIHRoaXMudXBkYXRlKCk7XHJcbiAgfVxyXG5cclxuICB1cGRhdGVYQXhpc0hlaWdodCh7IGhlaWdodCB9KTogdm9pZCB7XHJcbiAgICB0aGlzLnhBeGlzSGVpZ2h0ID0gaGVpZ2h0O1xyXG4gICAgdGhpcy51cGRhdGUoKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZUhvdmVyZWRWZXJ0aWNhbChpdGVtKTogdm9pZCB7XHJcbiAgICB0aGlzLnRvb2x0aXBPYmogPSBPYmplY3QuYXNzaWduKHRoaXMudG9vbHRpcE9iaiwgaXRlbSlcclxuXHJcbiAgICB0aGlzLmhvdmVyZWRWZXJ0aWNhbCA9IGl0ZW0udmFsdWU7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuICB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ21vdXNlbGVhdmUnKVxyXG4gIGhpZGVDaXJjbGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5ob3ZlcmVkVmVydGljYWwgPSBudWxsO1xyXG4gICAgdGhpcy5kZWFjdGl2YXRlQWxsKCk7XHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSB0aGlzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXM7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCdtb3VzZWVudGVyJywgW1wic2VyaWVzXCJdKVxyXG4gIG9uTW91c2VFbnRlcihzZXJpZXMpOiB2b2lkIHtcclxuICAgIHRoaXMuYWN0aXZhdGUuZW1pdChzZXJpZXMpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignbW91c2VsZWF2ZScsIFtcIiRldmVudFwiXSlcclxuICBvbk1vdXNlTGVhdmUoc2VyaWVzKTogdm9pZCB7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGUuZW1pdChzZXJpZXMpO1xyXG4gIH1cclxuXHJcbiAgb25DbGljayhkYXRhLCBzZXJpZXM/KTogdm9pZCB7XHJcbiAgICBpZiAoc2VyaWVzKSB7XHJcbiAgICAgIGRhdGEuc2VyaWVzID0gc2VyaWVzLm5hbWU7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZWxlY3QuZW1pdChkYXRhKTtcclxuICB9XHJcblxyXG4gIHRyYWNrQnkoaW5kZXgsIGl0ZW0pOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIGl0ZW0ubmFtZTtcclxuICB9XHJcblxyXG4gIHNldENvbG9ycygpOiB2b2lkIHtcclxuICAgIGxldCBkb21haW47XHJcbiAgICBpZiAodGhpcy5zY2hlbWVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgZG9tYWluID0gdGhpcy5zZXJpZXNEb21haW47XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb21haW4gPSB0aGlzLnlEb21haW47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5jb2xvcnMgPSBuZXcgQ29sb3JIZWxwZXIodGhpcy5zY2hlbWUsIHRoaXMuc2NoZW1lVHlwZSwgZG9tYWluLCB0aGlzLmN1c3RvbUNvbG9ycyk7XHJcbiAgfVxyXG5cclxuICBnZXRMZWdlbmRPcHRpb25zKCkge1xyXG4gICAgY29uc3Qgb3B0cyA9IHtcclxuICAgICAgc2NhbGVUeXBlOiB0aGlzLnNjaGVtZVR5cGUsXHJcbiAgICAgIGNvbG9yczogdW5kZWZpbmVkLFxyXG4gICAgICBkb21haW46IFtdLFxyXG4gICAgICB0aXRsZTogdW5kZWZpbmVkXHJcbiAgICB9O1xyXG4gICAgaWYgKG9wdHMuc2NhbGVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgb3B0cy5kb21haW4gPSB0aGlzLnNlcmllc0RvbWFpbjtcclxuICAgICAgb3B0cy5jb2xvcnMgPSB0aGlzLmNvbG9ycztcclxuICAgICAgb3B0cy50aXRsZSA9IHRoaXMubGVnZW5kVGl0bGU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBvcHRzLmRvbWFpbiA9IHRoaXMueURvbWFpbjtcclxuICAgICAgb3B0cy5jb2xvcnMgPSB0aGlzLmNvbG9ycy5zY2FsZTtcclxuICAgIH1cclxuICAgIHJldHVybiBvcHRzO1xyXG4gIH1cclxuXHJcbiAgb25BY3RpdmF0ZShpdGVtKSB7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuXHJcbiAgICBjb25zdCBpZHggPSB0aGlzLmFjdGl2ZUVudHJpZXMuZmluZEluZGV4KGQgPT4ge1xyXG4gICAgICByZXR1cm4gZC5uYW1lID09PSBpdGVtLm5hbWUgJiYgZC52YWx1ZSA9PT0gaXRlbS52YWx1ZTtcclxuICAgIH0pO1xyXG4gICAgaWYgKGlkeCA+IC0xKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSBbaXRlbV07XHJcbiAgICB0aGlzLmFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogaXRlbSwgZW50cmllczogdGhpcy5hY3RpdmVFbnRyaWVzIH0pO1xyXG5cclxuICAgIHRoaXMudG9vbHRpcE9iaiA9IE9iamVjdC5hc3NpZ24odGhpcy50b29sdGlwT2JqLCBpdGVtKVxyXG4gICAgdGhpcy5maW5kT3RoZXJQcm9wZXJ0eSgpO1xyXG4gICAgdGhpcy5zZXRDdXN0b21DbGFzcygpO1xyXG4gIH1cclxuXHJcbiAgb25EZWFjdGl2YXRlKGl0ZW0pIHtcclxuICAgIGNvbnN0IGlkeCA9IHRoaXMuYWN0aXZlRW50cmllcy5maW5kSW5kZXgoZCA9PiB7XHJcbiAgICAgIHJldHVybiBkLm5hbWUgPT09IGl0ZW0ubmFtZSAmJiBkLnZhbHVlID09PSBpdGVtLnZhbHVlO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzLnNwbGljZShpZHgsIDEpO1xyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gWy4uLnRoaXMuYWN0aXZlRW50cmllc107XHJcblxyXG4gICAgdGhpcy5kZWFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogaXRlbSwgZW50cmllczogdGhpcy5hY3RpdmVFbnRyaWVzIH0pO1xyXG4gIH1cclxuXHJcbiAgZGVhY3RpdmF0ZUFsbCgpIHtcclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFsuLi50aGlzLmFjdGl2ZUVudHJpZXNdO1xyXG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzLmFjdGl2ZUVudHJpZXMpIHtcclxuICAgICAgdGhpcy5kZWFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogZW50cnksIGVudHJpZXM6IFtdIH0pO1xyXG4gICAgfVxyXG4gICAgdGhpcy5hY3RpdmVFbnRyaWVzID0gW107XHJcbiAgfVxyXG5cclxuICBzZXRDdXN0b21DbGFzcygpIHtcclxuICAgIGxldCBhbGVydFR5cGUgPSB0aGlzLnRvb2x0aXBPYmpbXCJhbGVydFR5cGVcIl07XHJcbiAgICBpZiAoYWxlcnRUeXBlKSB7XHJcbiAgICAgIGlmIChhbGVydFR5cGUgPT0gMSkge1xyXG4gICAgICAgIHRoaXMuY3VzdG9tVG9vbHRpcENsYXNzID0gJ2FsZXJ0MSdcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmN1c3RvbVRvb2x0aXBDbGFzcyA9ICdhbGVydDInXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuICBmaW5kT3RoZXJQcm9wZXJ0eSgpIHtcclxuICAgIGxldCBhcnIgPSB0aGlzLnJlc3VsdHM7XHJcbiAgICBsZXQgZnVuZE5hbWUgPSB0aGlzLnRvb2x0aXBPYmpbXCJuYW1lXCJdO1xyXG4gICAgbGV0IHRpbWVOYW1lID0gdGhpcy50b29sdGlwT2JqW1widmFsdWVcIl07XHJcbiAgICBsZXQgZmluZFNlcmllcyA9IHt9O1xyXG4gICAgbGV0IG9iajtcclxuXHJcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICBpZiAoYXJyW2ldW1wibmFtZVwiXSA9PT0gZnVuZE5hbWUpIHtcclxuICAgICAgICBmaW5kU2VyaWVzID0gT2JqZWN0LmFzc2lnbihmaW5kU2VyaWVzLCBhcnJbaV0pO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHNlcmllcyA9IGZpbmRTZXJpZXNbXCJzZXJpZXNcIl07XHJcblxyXG4gICAgZm9yICh2YXIgaiA9IDA7IGogPCBzZXJpZXMubGVuZ3RoOyBqKyspIHtcclxuICAgICAgaWYgKHNlcmllc1tqXVtcIm5hbWVcIl0gPT09IHRpbWVOYW1lKSB7XHJcbiAgICAgICAgb2JqID0ge1xyXG4gICAgICAgICAgXCJuYXZcIjogc2VyaWVzW2pdW1wibmF2XCJdLFxyXG4gICAgICAgICAgXCJtYXJrZXR2YWxcIjogc2VyaWVzW2pdW1wibWFya2V0dmFsXCJdXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMudG9vbHRpcE9iaiA9IE9iamVjdC5hc3NpZ24odGhpcy50b29sdGlwT2JqLCBvYmopXHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIGJlbG93IGlzIGZvciBjdXN0b20gYWxlcnQgZGV0YWlscyByZWN0IGxvZ2ljXHJcbiAgIG9uQ2xpY2tBbGVydENpcmNsZShkYXRhKTogdm9pZCB7XHJcbiAgICBpZiAoZGF0YSkge1xyXG4gICAgICBsZXQgYWxyZWFkeUluU2hvd01hcCA9IGZhbHNlO1xyXG4gICAgICB0aGlzLnNob3dBbGVydERldGFpbHNNYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICBpZiAoZGF0YS54ID09PSBpdGVtLnggJiYgZGF0YS5uYW1lID09PSBpdGVtLm5hbWUpIHtcclxuICAgICAgICAgIGFscmVhZHlJblNob3dNYXAgPSB0cnVlO1xyXG4gICAgICAgICAgaXRlbS5zaG93ID0gIWl0ZW0uc2hvdztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgaXRlbS5zaG93ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKCFhbHJlYWR5SW5TaG93TWFwKXtcclxuICAgICAgICBsZXQgb2JqID0ge1xyXG4gICAgICAgICAgeDogZGF0YS54LFxyXG4gICAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxyXG4gICAgICAgICAgc2hvdzogZGF0YVsnc2hvdyddID8gIWRhdGFbJ3Nob3cnXSA6IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zaG93QWxlcnREZXRhaWxzTWFwLnB1c2gob2JqKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0U2hvd0FsZXJ0RGV0YWlscyhkYXRhKSB7XHJcbiAgICBsZXQgc2hvd09yTm90ID0gZmFsc2U7XHJcbiAgICB0aGlzLnNob3dBbGVydERldGFpbHNNYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGRhdGEueCA9PT0gaXRlbS54ICYmIGRhdGEubmFtZSA9PT0gaXRlbS5uYW1lKSB7XHJcbiAgICAgICAgc2hvd09yTm90ID0gaXRlbS5zaG93O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBzaG93T3JOb3Q7XHJcbiAgfVxyXG5cclxuICBnZXRSZWN0TG9hY3Rpb25YKGNpcmNsZSk6IG51bWJlciB7XHJcbiAgICBsZXQgeExvY2F0aW9uID0gMDtcclxuICAgICAgaWYgKHRoaXMuY29tbW9uVXRpbHMuaXNCZXlvbmREaXZpc2lvbihuZXcgRGF0ZShjaXJjbGUucHJpY2V0aW1lKSkpIHtcclxuICAgICAgeExvY2F0aW9uID0gY2lyY2xlLnggLTIyMFxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgeExvY2F0aW9uID0gY2lyY2xlLnggKzEwXHJcbiAgICB9XHJcbiAgICByZXR1cm4geExvY2F0aW9uO1xyXG4gIH1cclxuXHJcbiAgZ2V0UmVjdExvYWN0aW9uWShjaXJjbGUpOiBudW1iZXIge1xyXG4gICAgbGV0IHlMb2NhdGlvbiA9IDA7XHJcbiAgICBpZihjaXJjbGUubmF2Q2hhbmdlID49MCkge1xyXG4gICAgICB5TG9jYXRpb24gPSBjaXJjbGUudmFsdWUgKyAxMFxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgeUxvY2F0aW9uID0gY2lyY2xlLnZhbHVlIC0xMTBcclxuICAgIH1cclxuICAgIHJldHVybiB5TG9jYXRpb25cclxuICB9XHJcbn0iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zaGFyZS1pbmZvLWJld2Vlbi1jb21wb25lbnRzLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtY3VzdG9tLWxlZ2VuZCcsXHJcbiAgdGVtcGxhdGU6IGA8bWF0LWNoaXAtbGlzdCBjbGFzcz1cIm1hdC1jaGlwLWxpc3RcIj5cclxuICA8bmctY29udGFpbmVyXHJcbiAgKm5nRm9yPVwibGV0IGZ1bmQgb2YgcmVzdWx0cztsZXQgaT1pbmRleDt0cmFja0J5OmluZGV4XCIgXHJcbiAgPlxyXG4gICAgIDxtYXQtYmFzaWMtY2hpcFxyXG4gICAgICAqbmdJZj1cImdldFNob3dMZWdlbmRBbmRDb25zaXN0ZW50KGZ1bmQpXCJcclxuICAgICAgW3NlbGVjdGFibGVdPVwic2VsZWN0YWJsZVwiIFxyXG4gICAgICBbcmVtb3ZhYmxlXT1cInJlbW92YWJsZVwiIFxyXG4gICAgICBbc3R5bGUuYm9yZGVyQ29sb3JdPVwiZ2V0RnVuZFJlbGF0ZWRDb2xvcihmdW5kKVwiXHJcbiAgICAgIGRpc2FibGVSaXBwbGU+XHJcbiAgICAgICAge3tmdW5kLmZ1bmRUaWNrZXIgPyBmdW5kLmZ1bmRUaWNrZXIgOiBmdW5kLmZ1bmRJRCB9fVxyXG4gICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJyZW1vdmVJY29uXCIgc3ZnSWNvbj1cImNsb3NlXCIgbWF0Q2hpcFJlbW92ZSAoY2xpY2spPVwicmVtb3ZlKGZ1bmQpXCI+PC9tYXQtaWNvbj4gXHJcbiAgPC9tYXQtYmFzaWMtY2hpcD5cclxuICA8L25nLWNvbnRhaW5lcj5cclxuPC9tYXQtY2hpcC1saXN0PmAsXHJcbiAgc3R5bGVzOiBbYC5tYXQtYmFzaWMtY2hpcHttYXJnaW46MTBweCAxMHB4IDE1cHg7Ym9yZGVyLXRvcDoxcHggc29saWQ7Ym9yZGVyLWJvdHRvbToxcHggc29saWQ7Ym9yZGVyLXJpZ2h0OjFweCBzb2xpZDtib3JkZXItbGVmdDo1cHggc29saWQ7ZGlzcGxheTppbmxpbmUtZmxleDtwYWRkaW5nOjNweCAwIDAgMTBweDtmb250LXNpemU6MTRweH0ubWF0LWJhc2ljLWNoaXAgLnJlbW92ZUljb257d2lkdGg6MTBweCFpbXBvcnRhbnQ7aGVpZ2h0OjEwcHghaW1wb3J0YW50O21hcmdpbjowIDhweDtjdXJzb3I6cG9pbnRlcjttaW4taGVpZ2h0OjEwcHghaW1wb3J0YW50O21pbi13aWR0aDoxMHB4IWltcG9ydGFudH1gXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ3VzdG9tTGVnZW5kQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBASW5wdXQoKSByZXN1bHRzO1xyXG4gIEBJbnB1dCgpIHNlbGVjdGFibGU7XHJcbiAgQElucHV0KCkgcmVtb3ZhYmxlO1xyXG4gIEBJbnB1dCgpIGNvbG9yRG9tYWluO1xyXG4gIEBJbnB1dCgpIGluZGV4O1xyXG4gIEBJbnB1dCgpIHNlbGVjdGVkRnVuZENoYW5nZVxyXG5cclxuICBjb25zdHJ1Y3RvciggICAgcHJpdmF0ZSBzaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMgOiBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSwgIFxyXG4gICAgIHByaXZhdGUgY29tbW9uVXRpbHMgOiBDb21tb25VdGlsc1NlcnZpY2UpIHsgXHJcbiAgICAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIFxyXG4gIH1cclxuXHJcbiAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgfVxyXG5cclxuICBnZXRTaG93TGVnZW5kQW5kQ29uc2lzdGVudChmdW5kKSB7XHJcbiAgICBcclxuICAgIGlmIChmdW5kLm5hbWUgPT09IFwiXCIpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBsaXN0ID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKTtcclxuICAgICAgbGV0IHNob3cgPSBmYWxzZTtcclxuICAgICAgbGlzdC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLmZ1bmRJRCA9PT0gZnVuZC5uYW1lICYmIGl0ZW0uY2hlY2tlZCkge1xyXG4gICAgICAgICAgc2hvdyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICByZXR1cm4gc2hvd1xyXG4gICAgfVxyXG4gIH1cclxuICBnZXRGdW5kUmVsYXRlZENvbG9yKGZ1bmQpIHtcclxuICAgIGxldCBjb2xvclN0ciA9ICcnO1xyXG4gICAgdGhpcy5jb2xvckRvbWFpbi5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbVsnZnVuZGlkJ10gPT09IGZ1bmRbJ25hbWUnXSkge1xyXG4gICAgICAgIGNvbG9yU3RyID0gaXRlbVsnY29sb3InXTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBjb2xvclN0cjtcclxuICB9XHJcbiAgXHJcblxyXG4gIHJlbW92ZShmdW5kKTogdm9pZCB7XHJcbiAgICB0aGlzLmNvbW1vblV0aWxzLnVwZGF0ZUZ1bmRTdGF0dXMoZnVuZFsnZnVuZElEJ10sIGZhbHNlKTtcclxuICAgIGxldCBmdW5kSW5kZXggPSAtMTtcclxuICAgIHRoaXMucmVzdWx0cy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICBpZiAoaXRlbVsnbmFtZSddID09PSBmdW5kWyduYW1lJ10pIHtcclxuICAgICAgICBmdW5kSW5kZXggPSBpbmRleDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKGZ1bmRJbmRleCA+PSAwKSB7XHJcbiAgICAgIHRoaXMucmVzdWx0cy5zcGxpY2UoZnVuZEluZGV4LCAxKTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNlbGVjdGVkRnVuZENoYW5nZS5lbWl0KGZ1bmQpO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgT25Jbml0LCBJbmplY3R9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuLy9pbXBvcnQgeyBkZXYsIHByb2QgfSBmcm9tICcuLi9saWItZW52JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIE5hdlNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGRhdGEgOiBCZWhhdmlvclN1YmplY3Q8YW55W10+ID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSBhcyBhbnlbXSk7XHJcblxyXG4gIC8vYmFzZVVybCA9IHRoaXMuZW52LnByb2R1Y3Rpb24/IHByb2Quc2VydmljZV9iYXNlX3VybDogZGV2LnNlcnZpY2VfYmFzZV91cmw7XHJcbiAgLy9jb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQsIEBJbmplY3QoJ2VudicpIHByaXZhdGUgZW52KSB7IH1cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGh0dHA6IEh0dHBDbGllbnQpIHsgfVxyXG5cclxuXHJcbiAgZ2V0VG9kYXlOYXYoZnVuZHMpOiBPYnNlcnZhYmxlPGFueVtdPiB7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxhbnlbXT4oJy9hcGkvdG9kYXknKTsvLyBkZW1vIGFwaSwgY2FuIGJlIHJlbW92ZWQgYWZ0ZXIgbWVyZ2UgcW5hdi1saW5lLWNoYXJ0XHJcbiAgfVxyXG4gIC8vIGNhbGwgdGhpcyBvbmUgZnJvbSBjaGFydCBjb21wb25lbnQgb25seSB0byBhdm9pZCBtdWx0aXBsZSBjYWxsIHJlcXVlc3QgYnkgZGlmZmVyZW50IGNvbXBvbmVudFxyXG4gIGZldGNoRnVuZExpc3QoKSB7XHJcbiAgICAvL3JldHVybiB0aGlzLmh0dHAuZ2V0PGFueVtdPignL2FwaS9mdW5kTGlzdCcpLnN1YnNjcmliZShkID0+IHRoaXMuZGF0YS5uZXh0KGQgYXMgYW55W10pKTtcclxuICAgIHRoaXMuZGF0YSA9IG5ldyBCZWhhdmlvclN1YmplY3QoW10gYXMgYW55W10pOy8vcmVzZXQgZGF0YSBhcyB0aGUgZ2V0RnVuZExpc3Qgc3ViY3JpcHRpb24gbWF5IHN0aWxsIGdldCB0aGUgb2xkIGRhdGEgaWYgbmV3IGNhbGwgaGFzbid0IHJldHVybmVkIHlldC5cclxuICAgIHRoaXMuaHR0cC5nZXQ8YW55W10+KCcvcW5hdi13ZWItbXVsdGljbGFzcy9kYXRhL2Z1bmRsaXN0P3RpbWVab25lT2Zmc2V0PScgKyBuZXcgRGF0ZSgpLmdldFRpbWV6b25lT2Zmc2V0KCkgKiAoLTEpKVxyXG4gICAgICAuc3Vic2NyaWJlKGQgPT4ge1xyXG4gICAgICAgIHRoaXMuZGF0YS5uZXh0KGQgYXMgYW55W10pXHJcbiAgICAgIH0sXHJcbiAgICAgICAgZXJyb3IgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpXHJcbiAgICAgICAgfSk7XHJcbiAgfVxyXG4gIC8vIGNhbGwgdGhpcyBvbmUgZm9yIGFsbCBjb21wb25lbnRzIHRvIGdldCBmdW5kbGlzdCBpZiBpdCdzIGFscmVhZHkgZmV0Y2hlZC5cclxuICBnZXRGdW5kTGlzdCgpOiBPYnNlcnZhYmxlPGFueVtdPiB7XHJcbiAgICAgIHJldHVybiB0aGlzLmRhdGEuYXNPYnNlcnZhYmxlKCk7XHJcbiAgfVxyXG4gIGdldFBvc2l0aW9uRGV0YWlscyhmdW5kOiBzdHJpbmcpIDogT2JzZXJ2YWJsZTxhbnlbXT4ge1xyXG4gICAgLy9yZXR1cm4gdGhpcy5odHRwLmdldCgnYXBpL3Bvc2l0aW9uRGV0YWlscycpXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxhbnlbXT4oJy9xbmF2LXdlYi1tdWx0aWNsYXNzL2RhdGEvZnVuZERldGFpbD9mdW5kSWQ9JytmdW5kKTs7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJleHBvcnQgZW51bSBBY3Rpb24ge1xyXG4gICAgUkVHSVNURVIgPSBcInJlZ2lzdGVyXCIsXHJcbiAgICBTRU5EVE8gPSBcInNlbmRUb1wiLFxyXG4gICAgU1RPUFdBVENIRlVORCA9IFwic3RvcFdhdGNoRnVuZFwiLFxyXG4gICAgV0FUQ0hGVU5EID0gXCJ3YXRjaEZ1bmRcIlxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVlc3Qge1xyXG4gICAgYWN0aW9uPzogQWN0aW9uO1xyXG4gICAgc2Vzc2lvbklkPzogYW55O1xyXG4gICAgZnVuZElkPzphbnk7XHJcbiAgICB0aW1lWm9uZU9mZnNldD86YW55O1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XHJcbiAgICBuYW1lOiBhbnk7XHJcbiAgICB2YWx1ZTogYW55O1xyXG59XHJcbmV4cG9ydCBpbnRlcmZhY2UgTmF2IHtcclxuXHJcbiAgICBjdXNpcD86IGFueTtcclxuICAgIGV4Y2hhbmdlUmF0ZT86IG51bWJlcjtcclxuICAgIGZ1bmRpZDogYW55O1xyXG4gICAgcGFyU2hhcmU6IG51bWJlcjtcclxuICAgIGZ1bmRtdjogbnVtYmVyO1xyXG4gICAgZnVuZG12Q2hhbmdlPzogbnVtYmVyO1xyXG4gICAgZnVuZG12Q2hhbmdlUGVyY2VudD86IG51bWJlcjtcclxuICAgIG12PzogbnVtYmVyO1xyXG4gICAgbXZDaGFuZ2U/OiBudW1iZXI7XHJcbiAgICBuYXY/OiBudW1iZXI7XHJcbiAgICBuYXZDaGFuZ2U/OiBudW1iZXI7XHJcbiAgICBuYXZDaGFuZ2VQZXJjZW50PzogbnVtYmVyO1xyXG4gICAgcHJldmlvdXNQcmljZT86IG51bWJlcjsgLy9uZXdcclxuICAgIHByaWNlPzogbnVtYmVyO1xyXG4gICAgc29kbXY/OiBudW1iZXI7XHJcbiAgICB1cGRhdGV0aW1lPzogbnVtYmVyOyAvL25ld1xyXG4gICAgcHJpY2V0aW1lPzpudW1iZXI7XHJcbiBcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBOYXZFdmVudCB7XHJcbiAgICBldmVudFR5cGU/OyAvL2Z1bmRDaGFuZ2Ugb3Igc29kQ2hhbmdlXHJcbiAgICBldmVudERhdGE/OiBOYXY7XHJcbn0iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBJbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgQmVoYXZpb3JTdWJqZWN0IH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IHdlYlNvY2tldCwgV2ViU29ja2V0U3ViamVjdH0gZnJvbSAncnhqcy93ZWJTb2NrZXQnIC8vIGZvciBSeEpTIDYsIGZvciB2NSB1c2UgT2JzZXJ2YWJsZS53ZWJTb2NrZXRcclxuaW1wb3J0IHsgTmF2LFJlcXVlc3QsIEFjdGlvbiwgTmF2RXZlbnQgfSBmcm9tICcuLi9tb2RlbC9xbmF2JztcclxuLy9pbXBvcnQgeyBkZXYsIHByb2QgfSBmcm9tICcuLi9saWItZW52JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIE5hdlNvY2tldFNlcnZpY2Uge1xyXG4gICBcclxuICAgIHByaXZhdGUgc3ViamVjdDsgLy86IFdlYlNvY2tldFN1YmplY3Q8TmF2RXZlbnQ+O1xyXG5cclxuICAgIHByaXZhdGUgbmF2IDogQmVoYXZpb3JTdWJqZWN0PE5hdkV2ZW50PiA9IG5ldyBCZWhhdmlvclN1YmplY3Qoe30gYXMgTmF2RXZlbnQpO1xyXG4gICAgXHJcbiAgICBcclxuICAgIC8vIGNvbnN0cnVjdG9yKEBJbmplY3QoJ2VudicpIHByaXZhdGUgZW52KSB7XHJcbiAgICAvLyAgICAgdGhpcy5pbml0U29ja2V0KCk7XHJcbiAgICAvLyAgICAgdGhpcy5yZWdpc3RlclNlcnZpY2UoKTtcclxuICAgIC8vIH1cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgICAgICB0aGlzLmluaXRTb2NrZXQoKTtcclxuICAgICAgICAgICAgdGhpcy5yZWdpc3RlclNlcnZpY2UoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaW5pdFNvY2tldCgpICB7XHJcbiAgICAgICAgdGhpcy5zdWJqZWN0ID0gd2ViU29ja2V0KCd3c3M6Ly8nK3dpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZStcIjpcIit3aW5kb3cubG9jYXRpb24ucG9ydCsnL3FuYXYtd2ViLW11bHRpY2xhc3MvY29ubicpOyAvLyAgcHJveHkgd29uJ3QgYmUgYWJsZSB0byBmdW5jdGlvbiBpZiB0aGUgcG9ydCBub3QgbWF0Y2ggd2l0aCBzdGFydCBwb3J0XHJcbiAgICAgICAgLy9yZXR1cm4gdGhpcy5zdWJqZWN0O1xyXG4gICAgICAgIHRoaXMuc3ViamVjdC5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgIChtc2cpID0+IHt0aGlzLm5hdi5uZXh0KG1zZyBhcyBOYXZFdmVudCk7fSxcclxuICAgICAgICAgICAgKGVycikgPT4gY29uc29sZS5sb2coXCJFUlJPUiEhISFcIitlcnIpLFxyXG4gICAgICAgICAgICAoKSA9PiBjb25zb2xlLmxvZyhcIk5BViBTb2NrZXQgQ09NUExFVEVELi4uLi5cIilcclxuICAgICAgICApO1xyXG4gICAgICAgLy8gY29uc29sZS5sb2cobmV3IERhdGUoMTUyNDgyMzgwOTIwMDQzMSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXROYXYoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMubmF2LmFzT2JzZXJ2YWJsZSgpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHNlbmQocmVxdWVzdDogUmVxdWVzdCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc3ViamVjdC5uZXh0KHJlcXVlc3QpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZWdpc3RlckZ1bmRzKGZ1bmRzOiBhbnlbXSkge1xyXG5cclxuICAgICAgICBmdW5kcy5mb3JFYWNoKGZ1bmQgPT4ge1xyXG4gICAgICAgICAgdGhpcy5zZW5kKHtcImFjdGlvblwiOkFjdGlvbi5XQVRDSEZVTkQsXCJmdW5kSWRcIjpmdW5kfSkgICAgICBcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIHB1YmxpYyB1blJlZ2lzdGVyRnVuZHMoZnVuZHM6IGFueVtdKSB7XHJcbiAgICAgICAgZnVuZHMuZm9yRWFjaChmdW5kID0+IHtcclxuICAgICAgICAgIHRoaXMuc2VuZCh7XCJhY3Rpb25cIjpBY3Rpb24uU1RPUFdBVENIRlVORCxcImZ1bmRJZFwiOmZ1bmR9KSAgICAgIFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHJlZ2lzdGVyU2VydmljZSgpIHtcclxuICAgICAgICB0aGlzLnNlbmQoe2FjdGlvbjpBY3Rpb24uUkVHSVNURVIsc2Vzc2lvbklkOm5ldyBEYXRlKCkudmFsdWVPZigpICsgJycsdGltZVpvbmVPZmZzZXQ6bmV3IERhdGUoKS5nZXRUaW1lem9uZU9mZnNldCgpKigtMSl9KTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuXHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgIC8vd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLChldmVudCk9Pnt0aGlzLmRlYWN0aXZlKGV2ZW50KX0pO1xyXG4gICAgICAvL3dpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdmb2N1cycsKGV2ZW50KT0+e3RoaXMuYWN0aXZlKGV2ZW50KX0pO1xyXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsKGV2ZW50KT0+e1xyXG4gICAgICAgIGlmKGRvY3VtZW50LmhpZGRlbikge1xyXG4gICAgICAgICAgdGhpcy5kZWFjdGl2ZShldmVudCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMuYWN0aXZlKGV2ZW50KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgIH1cclxuXHJcbiAgcHJpdmF0ZSBpbnRlcnZhbEluc3RhbmNlczogYW55W10gPSBbXTtcclxuICBwcml2YXRlIGludGVydmFsRnVuY3M6IGFueVtdID0gW107XHJcbiAgcHJpdmF0ZSBkZWFjdGl2ZShldmVudDogYW55KSB7XHJcbiAgICAvL2NvbnNvbGUubG9nKGV2ZW50KTtcclxuICAgICB0aGlzLmRvRGVhY3RpdmUoKTsgIFxyXG4gIH1cclxuICBwcml2YXRlIGRvRGVhY3RpdmUoKSB7XHJcbiAgICAgIHRoaXMuaW50ZXJ2YWxJbnN0YW5jZXMuZm9yRWFjaCAoIGl0ZW0gPT4ge1xyXG4gICAgICAgIGxldCB0aW1lID0gbmV3IERhdGUoKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhgY2xlYXIgdGhlIHNldGludGVydmFsIGZvciBjb21wb25lbnQ6ICR7aXRlbX0sICR7dGltZX1gKTtcclxuICAgICAgICBjbGVhckludGVydmFsKGl0ZW0pO1xyXG4gICAgfSlcclxuICB9XHJcbiAgcHJpdmF0ZSBhY3RpdmUoZXZlbnQ6IGFueSkge1xyXG4gICAgLy9jb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICB0aGlzLmludGVydmFsRnVuY3MuZm9yRWFjaCggaXRlbSA9PiB7XHJcbiAgICAgIGxldCB0aW1lID0gbmV3IERhdGUoKTtcclxuICAgICAgLy9jb25zb2xlLmxvZyhgYWN0aXZlIHRoZSBzZXRpbnRlcnZhbCBmb3IgY29tcG9uZW50OiAke2l0ZW1bJ2Z1bmMnXX0sIGludGVydmFsOiR7aXRlbVsnaW50ZXJ2YWwnXX0sICR7dGltZX1gKTtcclxuICAgICAgdGhpcy5pbnRlcnZhbEluc3RhbmNlcy5wdXNoKHNldEludGVydmFsKGl0ZW1bJ2Z1bmMnXSwgaXRlbVsnaW50ZXJ2YWwnXSkpO1xyXG4gICAgfSlcclxuICB9XHJcbiAgcmVnaXN0SW50ZXJ2YWwoaW50ZXJ2YWxGdW5jLCBpbnRlcnZhbDogbnVtYmVyKSB7XHJcbiAgICBsZXQgaW5zdGFuY2UgPSBzZXRJbnRlcnZhbChpbnRlcnZhbEZ1bmMsIGludGVydmFsKTtcclxuICAgIHRoaXMuaW50ZXJ2YWxJbnN0YW5jZXMucHVzaChpbnN0YW5jZSk7XHJcbiAgICB0aGlzLmludGVydmFsRnVuY3MucHVzaCh7J2Z1bmMnOmludGVydmFsRnVuYywgJ2ludGVydmFsJzppbnRlcnZhbH0pO1xyXG4gIH1cclxuICAvL25lZWQgY2FsbCBpbiBjb21wb25lbnQgbmdPbkRlc3Ryb3koKSB0byBjbGVhciByZXNvdXJjZXMgZm9yIGN1cnJlbnQgY29tcG9uZW50XHJcbiAgY2xlYW5SZXNvdXJjZXMoKSB7XHJcbiAgICB0aGlzLmRvRGVhY3RpdmUoKTtcclxuICAgIHRoaXMuaW50ZXJ2YWxJbnN0YW5jZXMgPSBbXTtcclxuICAgIHRoaXMuaW50ZXJ2YWxGdW5jcyA9IFtdO1xyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgY29uc3QgY3VzdG9tQ29sdW1uID0gW107XHJcblxyXG4gIGV4cG9ydCBjb25zdCBub3JtYWxDb2x1bW4gPSAgW1xyXG4gICAge1xyXG4gICAgICBwcm9wOiAnY3VzaXAnLFxyXG4gICAgICBuYW1lOiAnSW5zdHJ1bWVudCBJZCBSZWYnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2RlZmF1bHQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlckxlZnQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTGVmdCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbG9uZ1Nob3J0SW5kaWNhdG9yJyxcclxuICAgICAgbmFtZTogJ0xvbmcvU2hvcnQnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2RlZmF1bHQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlckxlZnQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTGVmdCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAncGFyU2hhcmUnLFxyXG4gICAgICBuYW1lOiAnVW5pdHMnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnc29kUHJpY2UnLFxyXG4gICAgICBuYW1lOiAnUHJpY2UgUHJldmlvdXMnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdwcmljZScsXHJcbiAgICAgIG5hbWU6ICdQcmljZSBDdXJyZW50JyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbXYnLFxyXG4gICAgICBuYW1lOiAnTWFya2V0IFZhbHVlJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAncHJpY2VDaGFuZ2VQZXJjZW50JyxcclxuICAgICAgbmFtZTogJ1ByaWNlICUgQ2hhbmdlJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ3BlcmNlbnRGb3JtYXQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbE51bWJlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbmF2SW1wYWN0JyxcclxuICAgICAgbmFtZTogJ05BViBJbXBhY3QnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0TG9uZycsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH1cclxuICBdO1xyXG5cclxuICBleHBvcnQgY29uc3QgY29sdW1uTWVudURyb3BEb3duU2V0dGluZyA9IFtcclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogXCJSZXNpemUgdG8gRml0XCIsXHJcbiAgICAvLyAgIHR5cGU6IFwicmVzaXplVG9GaXRcIixcclxuICAgIC8vICAgaGFzU3ViTWVudTogZmFsc2UsXHJcbiAgICAvLyB9LFxyXG4gICAge1xyXG4gICAgICBuYW1lOiBcIkZyZWV6ZSBDb2x1bW5cIixcclxuICAgICAgdHlwZTogXCJmcmVlemVDb2x1bW5cIixcclxuICAgICAgaGFzU3ViTWVudTogZmFsc2UsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBuYW1lOiBcIlNvcnQgQ29sdW1uXCIsXHJcbiAgICAgIHR5cGU6IFwic29ydENvbHVtblwiLFxyXG4gICAgICBoYXNTdWJNZW51OiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IFwiVmlldyBNb3JlIENvbHVtbnNcIixcclxuICAgIC8vICAgdHlwZTogXCJ2aWV3TW9yZUNvbHVtbnNcIixcclxuICAgIC8vICAgaGFzU3ViTWVudTogdHJ1ZSxcclxuICAgIC8vIH0sXHJcbiAgXTsiLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgVmlld0NoaWxkLCBWaWV3RW5jYXBzdWxhdGlvbiwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQmFzZVdpZGdldENvbXBvbmVudCwgQXBwQ29udGV4dCwgQXBwUmVnaXN0cnkgfSBmcm9tICdAb21uaWEvdWktY29tbW9uJztcclxuaW1wb3J0IHsgTmF2U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zZXJ2aWNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZTb2NrZXRTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNvY2tldC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZFdmVudCB9IGZyb20gJy4uL21vZGVsL3FuYXYnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvcmVzb3VyY2UtbWFuYWdlci5zZXJ2aWNlJztcclxuaW1wb3J0IHtjdXN0b21Db2x1bW4sIG5vcm1hbENvbHVtbiwgY29sdW1uTWVudURyb3BEb3duU2V0dGluZ30gZnJvbSAnLi9jb2x1bW4tZGF0YSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1xbmF2LXBvc2l0aW9uJyxcclxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJxbmF2LXBvc2l0aW9uLWNvbnRhaW5lclwiICpuZ0lmPVwiaXNEYXRhQXZhaWxhYmxlXCI+XHJcbiAgICA8IS0tIDxkaXYgY2xhc3M9XCJyZXR1cm5CYWNrXCIgKGNsaWNrKT1cInJldHVybkJhY2soKVwiPlxyXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImhvbWVcIiBzdmdJY29uPVwiaG9tZVwiPjwvbWF0LWljb24+XHJcbiAgICA8L2Rpdj4gLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZnVuZERldGFpbHNcIj5cclxuICAgICAgICA8dWw+XHJcbiAgICAgICAgICAgIDxsaT5Qb3NpdGlvbiBEZXRhaWxzIGZvcjwvbGk+XHJcbiAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5FbnRpdHkgVGlja2VyOiA8L2xhYmVsPiB7e2Z1bmRJbmZvWzJdfX1cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5FbnRpdHkgTmFtZTogPC9sYWJlbD4ge3tmdW5kSW5mb1sxXX19XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgPC91bD5cclxuICAgIDwvZGl2PlxyXG48bGliLWNvbW1vbi1kYXRhLXRhYmxlXHJcbiAgICBbaGVhZGVyU2V0dGluZ109XCJoZWFkZXJTZXR0aW5nXCJcclxuICAgIFtoZWFkZXJIZWlnaHRdPVwiaGVhZGVySGVpZ2h0XCJcclxuICAgIFtyb3dzXT1cInJvd3NcIlxyXG4gICAgW2NoaWxkUm93c109XCJjaGlsZFJvd3NcIlxyXG4gICAgW2FsZXJ0RGF0YV09XCJhbGVydERhdGFcIlxyXG4gICAgW3Jvd0hlaWdodF09XCJyb3dIZWlnaHRcIlxyXG4gICAgW2N1c3RvbUNvbHVtbl09XCJjdXN0b21Db2x1bW5cIlxyXG4gICAgW25vcm1hbENvbHVtbl09XCJub3JtYWxDb2x1bW5cIlxyXG4gICAgW2xpbWl0XT1cImxpbWl0XCJcclxuICAgIFtmb290ZXJIZWlnaHRdPVwiZm9vdGVySGVpZ2h0XCJcclxuICAgIFtoZWFkZXJDaGVja0JveF09XCJoZWFkZXJDaGVja0JveFwiXHJcbiAgICBbaXNEYXRhVGFibGVQYXVzZWRdPVwiaXNEYXRhVGFibGVQYXVzZWRcIlxyXG4gICAgW2NvbHVtbk1lbnVEcm9wRG93blNldHRpbmddPVwiY29sdW1uTWVudURyb3BEb3duU2V0dGluZ1wiXHJcbiAgICBbZGVmYXVsdFNvcnRDb2xdPVwiJ2N1c2lwJ1wiXHJcbiAgICAodG9nZ2xlUGF1c2VGbGFnRXZlbnQpPVwidG9nZ2xlUGF1c2VGbGFnKClcIlxyXG4+XHJcbjwvbGliLWNvbW1vbi1kYXRhLXRhYmxlPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2Aubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zdHJpcGVkIC5kYXRhdGFibGUtcm93LW9kZHtiYWNrZ3JvdW5kOiNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2VlZTt0cmFuc2l0aW9uLXByb3BlcnR5OmJhY2tncm91bmQ7dHJhbnNpdGlvbi1kdXJhdGlvbjouM3M7dHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246bGluZWFyfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZGRkfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMzA0ZmZlO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMxOTNhZTQ7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzIwNDFlZjtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5lbXB0eS1yb3d7aGVpZ2h0OjUwcHg7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmxvYWRpbmctcm93e3RleHQtYWxpZ246bGVmdDtwYWRkaW5nOi41cmVtIDEuMnJlbTt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LWxlZnR7YmFja2dyb3VuZC1jb2xvcjojZmZmO2JhY2tncm91bmQtcG9zaXRpb246MTAwJSAwO2JhY2tncm91bmQtcmVwZWF0OnJlcGVhdC15O2JhY2tncm91bmQtaW1hZ2U6dXJsKGRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQVFBQUFBQkNBWUFBQUQ1UEEvTkFBQUFGa2xFUVZRSUhXUFNrTmVTQm1KaFRRVnRiaUROQ2dBU2FnSUl1Slg4T2dBQUFBQkpSVTVFcmtKZ2dnPT0pfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodHtiYWNrZ3JvdW5kLXBvc2l0aW9uOjAgMDtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJMTJQUWtOZGkxVlRRNWdiU3drQXNEUUFSTEFJR3RPU0ZVQUFBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXJ7Ym94LXNoYWRvdzowIDJweCA0cHggMCByZ2JhKDAsMCwwLC4xNSk7cG9zaXRpb246c3RpY2t5O3Bvc2l0aW9uOi13ZWJraXQtc3RpY2t5O3RvcDowO3otaW5kZXg6OTk5O2JhY2tncm91bmQtY29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxse3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt2ZXJ0aWNhbC1hbGlnbjpib3R0b207Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NTAwfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVye3Bvc2l0aW9uOnJlbGF0aXZlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwubG9uZ3ByZXNzIC5kcmFnZ2FibGU6OmFmdGVye3RyYW5zaXRpb246dHJhbnNmb3JtIC40cyxvcGFjaXR5IC40cywtd2Via2l0LXRyYW5zZm9ybSAuNHM7b3BhY2l0eTouNTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgxKTt0cmFuc2Zvcm06c2NhbGUoMSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZHJhZ2dhYmxlOjphZnRlcntjb250ZW50OlwiIFwiO3Bvc2l0aW9uOmFic29sdXRlO3RvcDo1MCU7bGVmdDo1MCU7bWFyZ2luOi0zMHB4IDAgMCAtMzBweDtoZWlnaHQ6NjBweDt3aWR0aDo2MHB4O2JhY2tncm91bmQ6I2VlZTtib3JkZXItcmFkaXVzOjEwMCU7b3BhY2l0eToxOy13ZWJraXQtZmlsdGVyOm5vbmU7ZmlsdGVyOm5vbmU7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoMCk7dHJhbnNmb3JtOnNjYWxlKDApO3otaW5kZXg6OTk5OTtwb2ludGVyLWV2ZW50czpub25lfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwuZHJhZ2dpbmcgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0Om5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjZWVlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1kZXRhaWx7YmFja2dyb3VuZDojZjVmNWY1O3BhZGRpbmc6MTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ncm91cC1oZWFkZXJ7YmFja2dyb3VuZDojZjVmNWY1O2JvcmRlci1ib3R0b206MXB4IHNvbGlkICNkOWQ4ZDk7Ym9yZGVyLXRvcDoxcHggc29saWQgI2Q5ZDhkOX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktY2VsbHt0ZXh0LWFsaWduOmNlbnRlcjt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMzNTM1MzU7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO2xpbmUtaGVpZ2h0OjUwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWdyb3VwLWNlbGx7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjlyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXJ7ZGlzcGxheTpibG9jazt3aWR0aDoxMDAlO2hlaWdodDo1cHg7cGFkZGluZzowO21hcmdpbjowO3Bvc2l0aW9uOmFic29sdXRlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXJ7ZGlzcGxheTpibG9jaztwb3NpdGlvbjpyZWxhdGl2ZTtvdmVyZmxvdzpoaWRkZW47d2lkdGg6MTAwJTtoZWlnaHQ6NXB4Oy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7YmFja2dyb3VuZC1jb2xvcjojYWFkMWY5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXIgLmJhcnt0cmFuc2l0aW9uOnRyYW5zZm9ybSAuMnMgbGluZWFyOy13ZWJraXQtYW5pbWF0aW9uOi44cyBjdWJpYy1iZXppZXIoLjM5LC41NzUsLjU2NSwxKSBpbmZpbml0ZSBxdWVyeTthbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXIsLXdlYmtpdC10cmFuc2Zvcm0gLjJzIGxpbmVhcjtiYWNrZ3JvdW5kLWNvbG9yOiMxMDZjYzg7cG9zaXRpb246YWJzb2x1dGU7bGVmdDowO3RvcDowO2JvdHRvbTowO3dpZHRoOjEwMCU7aGVpZ2h0OjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3Rlcntib3JkZXItdG9wOjFweCBzb2xpZCByZ2JhKDAsMCwwLC4xMik7Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NDAwO2NvbG9yOnJnYmEoMCwwLDAsLjU0KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAucGFnZS1jb3VudHtsaW5lLWhlaWdodDo1MHB4O2hlaWdodDo1MHB4O3BhZGRpbmc6MCAxLjJyZW19Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlcnttYXJnaW46MCAxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGl7dmVydGljYWwtYWxpZ246bWlkZGxlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuZGlzYWJsZWQgYXtjb2xvcjpyZ2JhKDAsMCwwLC4yNikhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQhaW1wb3J0YW50fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuYWN0aXZlIGF7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKTtmb250LXdlaWdodDo3MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhe2hlaWdodDoyMnB4O21pbi13aWR0aDoyNHB4O2xpbmUtaGVpZ2h0OjIycHg7cGFkZGluZzowIDZweDtib3JkZXItcmFkaXVzOjNweDttYXJnaW46NnB4IDNweDt0ZXh0LWFsaWduOmNlbnRlcjtjb2xvcjpyZ2JhKDAsMCwwLC41NCk7dGV4dC1kZWNvcmF0aW9uOm5vbmU7dmVydGljYWwtYWxpZ246Ym90dG9tfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgYTpob3Zlcntjb2xvcjpyZ2JhKDAsMCwwLC43NSk7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLXByZXYsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcmlnaHQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tc2tpcHtmb250LXNpemU6MjBweDtsaW5lLWhlaWdodDoyMHB4O3BhZGRpbmc6MCAzcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtc3VtbWFyeS1yb3cgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3ZlcntiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse2ZvbnQtd2VpZ2h0OjcwMH0uZGF0YXRhYmxlLWNoZWNrYm94e3Bvc2l0aW9uOnJlbGF0aXZlO21hcmdpbjowO2N1cnNvcjpwb2ludGVyO3ZlcnRpY2FsLWFsaWduOm1pZGRsZTtkaXNwbGF5OmlubGluZS1ibG9jaztib3gtc2l6aW5nOmJvcmRlci1ib3g7cGFkZGluZzowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF17cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjAgMXJlbSAwIDA7Y3Vyc29yOnBvaW50ZXI7b3V0bGluZTowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06YmVmb3Jle3RyYW5zaXRpb246LjNzIGVhc2UtaW4tb3V0O2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7ei1pbmRleDoxO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07Ym9yZGVyOjJweCBzb2xpZCAjZjJmMmYyfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZDpiZWZvcmV7LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7dHJhbnNmb3JtOnJvdGF0ZSgtNDVkZWcpO2hlaWdodDouNXJlbTtib3JkZXItY29sb3I6IzAwOTY4ODtib3JkZXItdG9wLXN0eWxlOm5vbmU7Ym9yZGVyLXJpZ2h0LXN0eWxlOm5vbmV9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTphZnRlcntjb250ZW50OlwiXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDowO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07YmFja2dyb3VuZDojZmZmO2N1cnNvcjpwb2ludGVyfUAtd2Via2l0LWtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fUBrZXlmcmFtZXMgcXVlcnl7MCV7b3BhY2l0eToxOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpfTEwMCV7b3BhY2l0eTowOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpfX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtemVyb3t0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtbmFnZXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiNiOTEyMjQ7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtcG9zaXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMyODc0M2U7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tbGVmdHt0ZXh0LWFsaWduOmxlZnQ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItY2VudGVye2NvbG9yOiMzNTM1MzV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1jb2x1bW4taGVhZGVyLWFsaWduLXJpZ2h0e3RleHQtYWxpZ246cmlnaHQ7Y29sb3I6IzM1MzUzNX1idXR0b24ubWF0LW1lbnUtaXRlbXtoZWlnaHQ6MzBweDtsaW5lLWhlaWdodDozMHB4O2ZvbnQtc2l6ZToxM3B4O2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXJ9Lm1hdC1tZW51LWl0ZW06aG92ZXI6bm90KFtkaXNhYmxlZF0pe2JhY2tncm91bmQ6I2UxZWNmMn0uY2hlY2staWNvbi5tYXQtaWNvbnt3aWR0aDoxNHB4O2hlaWdodDoxNHB4O21hcmdpbi1sZWZ0OjIwcHg7Y29sb3I6IzAwMH0ubmd4LWRhdGF0YWJsZS5maXhlZC1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItaW5uZXJ7aGVpZ2h0OjEwMCV9YCwgYC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFse2Rpc3BsYXk6dW5zZXR9Lm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsLXRlbXBsYXRlLXdyYXAgLmNvbHVtbkhlYWRlcntjb2xvcjojMDAwfS5yZXR1cm5CYWNre3dpZHRoOjIwcHg7aGVpZ2h0OjIwcHg7cG9zaXRpb246YWJzb2x1dGU7dG9wOjE0cHg7cmlnaHQ6NjBweDtjdXJzb3I6cG9pbnRlcn0ucW5hdi1wb3NpdGlvbi1jb250YWluZXJ7d2lkdGg6MTAwJTtoZWlnaHQ6MTAwJX0uZnVuZERldGFpbHN7Y29sb3I6IzQ2NDY0Njtmb250LXNpemU6MTZweDtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6MDtsZWZ0Oi0xNXB4O2ZvbnQtZmFtaWx5OkRJTk5leHRMVFByby1NZWRpdW19dWx7bGlzdC1zdHlsZTpub25lO2Rpc3BsYXk6aW5saW5lLWZsZXh9bGl7bWFyZ2luLXJpZ2h0OjVweH1gXSxcclxuICAvL2VuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLlNoYWRvd0RvbVxyXG59KVxyXG5leHBvcnQgY2xhc3MgUW5hdlBvc2l0aW9uQ29tcG9uZW50IGV4dGVuZHMgQmFzZVdpZGdldENvbXBvbmVudCB7XHJcblxyXG4gIHByaXZhdGUgc3ViczogU3Vic2NyaXB0aW9uW107XHJcbiAgcm93czogYW55W10gPSBbXTtcclxuICBjaGlsZFJvd3M6IGFueVtdID0gW107XHJcbiAgaXNEYXRhQXZhaWxhYmxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgcm93SGVpZ2h0Om51bWJlcj01MDtcclxuICBhbGVydERhdGE6IGFueVtdID0gW107XHJcbiAgYWxsUm93c1NlbGVjdGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgaXNTZWxlY3RlZE1hcDogYW55W10gPSBbXTtcclxuICBoZWFkZXJTZXR0aW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICBoZWFkZXJIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIC8vIHRlbXAgZGF0YSBzdHJ1Y3R1cmVcclxuICBpc0RhdGFUYWJsZVBhdXNlZDpib29sZWFuID0gZmFsc2U7XHJcbiAgY3VzdG9tQ29sdW1uOiBhbnlbXSA9IGN1c3RvbUNvbHVtbjtcclxuICBub3JtYWxDb2x1bW46IGFueVtdID0gbm9ybWFsQ29sdW1uO1xyXG4gIGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmc6IGFueVtdID0gY29sdW1uTWVudURyb3BEb3duU2V0dGluZztcclxuICBsaW1pdDogbnVtYmVyID0gNTtcclxuICBmb290ZXJIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIGhlYWRlckNoZWNrQm94OiBib29sZWFuID0gZmFsc2U7XHJcbiAgZnVuZEluZm86IGFueSA9IFtdO1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbmF2U2VydmljZTogTmF2U2VydmljZSwgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gcHJpdmF0ZSBhcHBSZWdpc3RyeTogQXBwUmVnaXN0cnksIFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBhcHBDb250ZXh0OiBBcHBDb250ZXh0LCBcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgbmF2U29ja2V0U2VydmljZTogTmF2U29ja2V0U2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgc2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2U6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSByZXNvdXJjZU1hbmdlcjogUmVzb3VyY2VNYW5hZ2VyU2VydmljZSkgeyBcclxuICAgIHN1cGVyKCk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIC8vcmVzZXQgY29tcG9uZW50IGRhdGEgYW5kIHVzZXIgdmFsaWRhdGlvbjtcclxuICAgIHRoaXMuY29tbW9uVXRpbHMudmFsaWRhdGVVc2VyKCk7XHJcbiAgICB0aGlzLnJvd3MgPSBbXTtcclxuICAgIHRoaXMuc3VicyA9IFtdO1xyXG4gICAgdGhpcy5pc0RhdGFBdmFpbGFibGUgPSBmYWxzZTtcclxuXHJcbiAgICB0aGlzLmZ1bmRJbmZvID0gdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5mdW5kSW5mbztcclxuICAgIGlmICh0aGlzLmZ1bmRJbmZvLmxlbmd0aCA+IDApIHtcclxuICAgICB0aGlzLnJlbmRlclBvc2l0aW9uRGV0YWlscygpO1xyXG4gICAgfVxyXG4gICAgZWxzZXtcclxuICAgICAgLy90aGlzLm5hdlNlcnZpY2UuZmV0Y2hGdW5kTGlzdCgpO1xyXG4gICAgICB0aGlzLm5hdlNlcnZpY2UuZ2V0RnVuZExpc3QoKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgaWYoZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIGNvbnN0IGZ1bmRJbmZvID0gW107XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5mdW5kaWQpO1xyXG4gICAgICAgICAgICBmdW5kSW5mby5wdXNoKGRhdGFbMF0ubmFtZSk7XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5mdW5kVGlja2VyKVxyXG4gICAgICAgICAgICB0aGlzLnNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLnNhdmVQb3NpdGlvbkRldGFpbHNGdW5kSW5mbyhmdW5kSW5mbyk7XHJcbiAgICAgICAgICAgIHRoaXMucmVuZGVyUG9zaXRpb25EZXRhaWxzKCk7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5zb3J0RGF0YXRhYmxlQ29sdW1uLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgY29uc29sZS5sb2coWy4uLnRoaXMuY29tbW9uVXRpbHMuc29ydENvbHVtbkJ5UHJvcCh0aGlzLnJvd3MsIHRoaXMuY2hpbGRSb3dzLCBkYXRhLm1hcCwgZGF0YS5wcm9wLCBkYXRhLmFzY0ZsYWcpXSk7XHJcbiAgICAgIHRoaXMucm93cyA9IFsuLi50aGlzLmNvbW1vblV0aWxzLnNvcnRDb2x1bW5CeVByb3AodGhpcy5yb3dzLCB0aGlzLmNoaWxkUm93cywgZGF0YS5tYXAsIGRhdGEucHJvcCwgZGF0YS5hc2NGbGFnKV07XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG5cclxuXHJcbiAgcmVuZGVyUG9zaXRpb25EZXRhaWxzKCl7XHJcbiAgICB0aGlzLmZ1bmRJbmZvID0gdGhpcy5zaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZS5mdW5kSW5mbztcclxuICAgIGlmICh0aGlzLmZ1bmRJbmZvLmxlbmd0aCA+IDApIHtcclxuICAgICAgdGhpcy5zdWJzLnB1c2godGhpcy5uYXZTZXJ2aWNlLmdldFBvc2l0aW9uRGV0YWlscyh0aGlzLmZ1bmRJbmZvWzBdKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IHRydWU7XHJcbiAgICAgICAgICB0aGlzLnJvd3MgPSBkYXRhW1wiaG9sZGluZ3NcIl07XHJcbiAgICAgICAgICB0aGlzLnJvd3MgPSBbLi4udGhpcy5yb3dzXTtcclxuICAgICAgICB9XHJcbiAgICAgICkpO1xyXG5cclxuICAgICAgdGhpcy5zdWJzLnB1c2godGhpcy5uYXZTb2NrZXRTZXJ2aWNlLmdldE5hdigpLnN1YnNjcmliZShcclxuICAgICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgaWYgKGRhdGFbJ2V2ZW50VHlwZSddID09PSAnZnVuZENoYW5nZScpIHtcclxuICAgICAgICAgICAgY29uc3QgZnVuZExldmVsUm93ID0gdGhpcy5jb21tb25VdGlscy5leHRyYWN0V1NEYXRhKGRhdGFbXCJldmVudERhdGFcIl0sIGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy51cGRhdGVSb3coZnVuZExldmVsUm93KVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy51cGRhdGVSb3coZGF0YSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHRoaXMubmF2U29ja2V0U2VydmljZS5yZWdpc3RlckZ1bmRzKFt0aGlzLmZ1bmRJbmZvWzBdXSk7XHJcblxyXG4gICAgdGhpcy5yZXNvdXJjZU1hbmdlci5yZWdpc3RJbnRlcnZhbCgoKSA9PiB7IHRoaXMucm93cyA9IFsuLi50aGlzLnJvd3NdOyB9LDMwMCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHJcbiAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICBpZiAodGhpcy5mdW5kSW5mby5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHRoaXMubmF2U29ja2V0U2VydmljZS51blJlZ2lzdGVyRnVuZHMoW3RoaXMuZnVuZEluZm9bMF1dKTtcclxuICAgICAgdGhpcy5zdWJzLmZvckVhY2ggKHN1YiA9PiBzdWIudW5zdWJzY3JpYmUoKSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnJlc291cmNlTWFuZ2VyLmNsZWFuUmVzb3VyY2VzKCk7XHJcbiAgfVxyXG5cclxuICB1cGRhdGVSb3coZGF0YSkge1xyXG4gICAgaWYgKGRhdGEgJiYgIXRoaXMuaXNEYXRhVGFibGVQYXVzZWQgJiYgdGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShkYXRhWydwcmljZXRpbWUnXSkpKSB7XHJcbiAgICAgIGlmICh0aGlzLnJvd3MubGVuZ3RoICYmIGRhdGEpIHtcclxuICAgICAgICBjb25zdCBmdW5kaWQgPSBkYXRhWydmdW5kaWQnXTtcclxuICAgICAgICBjb25zdCBjdXNpcCA9IGRhdGFbJ2N1c2lwJ107XHJcbiAgICAgICAgY29uc3QgbG9uZ1Nob3J0SW5kaWNhdG9yID0gZGF0YVsnbG9uZ1Nob3J0SW5kaWNhdG9yJ107XHJcbiAgICAgICAgdGhpcy5yb3dzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5mdW5kSW5mb1swXSA9PT0gZnVuZGlkICYmIGl0ZW1bJ2N1c2lwJ10gPT09IGN1c2lwICYmIGl0ZW1bJ2xvbmdTaG9ydEluZGljYXRvciddID09PSBsb25nU2hvcnRJbmRpY2F0b3IpIHtcclxuICAgICAgICAgICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaChjb2xJdGVtID0+IHsgaWYgKG51bGwgIT0gZGF0YVtjb2xJdGVtLnByb3BdKSB7aXRlbVtjb2xJdGVtLnByb3BdID0gZGF0YVtjb2xJdGVtLnByb3BdIH19KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYoZGF0YSAmJiBkYXRhWydldmVudFR5cGUnXSA9PT0gJ3NvZENoYW5nZScpIHtcclxuICAgICAgdGhpcy5uYXZTZXJ2aWNlLmdldFBvc2l0aW9uRGV0YWlscyh0aGlzLmZ1bmRJbmZvWzBdKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgdGhpcy5yb3dzID0gZGF0YVtcImhvbGRpbmdzXCJdO1xyXG4gICAgICAgICAgIHRoaXMucm93cyA9IFsuLi50aGlzLnJvd3NdO1xyXG4gICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIHJldHVybkJhY2soKTogYW55IHtcclxuICAvLyAgIHRoaXMuYXBwQ29udGV4dC5jdXJyZW50RGFzaGJvYXJkID0gdGhpcy5hcHBSZWdpc3RyeS5nZXREYXNoYm9hcmQoJ1FOQVYtMDAxJyk7XHJcbiAgLy8gfVxyXG4gIHRvZ2dsZVBhdXNlRmxhZygpIHtcclxuICAgIHRoaXMuaXNEYXRhVGFibGVQYXVzZWQgPSAhdGhpcy5pc0RhdGFUYWJsZVBhdXNlZDtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEluamVjdCwgRXZlbnRFbWl0dGVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7TWF0RGlhbG9nUmVmLCBNQVRfRElBTE9HX0RBVEF9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItYWRkLWZ1bmQtbW9kYWwnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxyXG5cdDxoMSBtYXQtZGlhbG9nLXRpdGxlPkFkZCBFbnRpdHkgdG8gQ2hhcnQ8L2gxPlxyXG4gIDxzcGFuIGNsYXNzPVwiYWxlcnQtY2xvc2VcIiAoY2xpY2spPVwib25Ob0NsaWNrKClcIj7Dg8KXPC9zcGFuPlxyXG48L2Rpdj5cclxuPGRpdiBtYXQtZGlhbG9nLWNvbnRlbnQ+XHJcbiA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG5cdDxkaXYgXHJcbiAgKm5nRm9yPVwibGV0IGZ1bmQgb2YgZnVuZExpc3RcIlxyXG5cdGNsYXNzPVwiZnVuZC1saXN0LWl0ZW1cIlxyXG4gICA+XHJcblx0XHQ8ZGl2IGNsYXNzPVwiY2hlY2tib3hcIj5cclxuXHRcdFx0PGxhYmVsPlxyXG5cdFx0XHRcdCA8bmctY29udGFpbmVyXHJcblx0XHRcdFx0ICpuZ0lmPVwiZnVuZC5jaGVja2VkXCI+XHJcblx0XHRcdFx0XHQgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIChjbGljayk9XCJoYW5kbGVTZWxlY3RGdW5kKGZ1bmQpXCIgY2hlY2tlZD4ge3tmdW5kLmZ1bmRUaWNrZXIgPyBmdW5kLmZ1bmRUaWNrZXIgOiBmdW5kLmZ1bmRJRCB9fVxyXG5cdFx0XHRcdCA8L25nLWNvbnRhaW5lcj5cclxuXHRcdFx0XHQgPG5nLWNvbnRhaW5lclxyXG5cdFx0XHRcdCAqbmdJZj1cIiFmdW5kLmNoZWNrZWRcIj5cclxuXHRcdFx0XHRcdCA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgKGNsaWNrKT1cImhhbmRsZVNlbGVjdEZ1bmQoZnVuZClcIj4ge3tmdW5kLmZ1bmRUaWNrZXIgPyBmdW5kLmZ1bmRUaWNrZXIgOiBmdW5kLmZ1bmRJRCB9fVxyXG5cdFx0XHRcdCA8L25nLWNvbnRhaW5lcj5cclxuICAgICBcdFx0PC9sYWJlbD5cclxuXHRcdDwvZGl2PlxyXG5cdDwvZGl2PlxyXG48L2Rpdj5cclxuPC9kaXY+XHJcbjxkaXYgbWF0LWRpYWxvZy1hY3Rpb25zIGFsaWduPVwiZW5kXCI+XHJcbiAgPGJ1dHRvbiBtYXQtYnV0dG9uIChjbGljayk9XCJvbk5vQ2xpY2soKVwiIGNka0ZvY3VzSW5pdGlhbD5DYW5jZWw8L2J1dHRvbj5cclxuICA8YnV0dG9uIG1hdC1idXR0b24gKGNsaWNrKT1cImhhbmRsZUNsaWNrU2VsZWN0QnRuKClcIiBjbGFzcz1cInByaW1hcnktYnRuXCI+U2VsZWN0PC9idXR0b24+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYC5tb2RhbC1oZWFkZXJ7cG9zaXRpb246cmVsYXRpdmV9Lm1hdC1kaWFsb2ctdGl0bGV7Y29sb3I6IzQ2NDY0NjttYXJnaW46LTEwcHggMCAyMHB4fS5hbGVydC1jbG9zZXtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6LTZweDtyaWdodDotNnB4O2NvbG9yOnJnYmEoMTA1LDEwNSwxMDUsLjc4KTtjdXJzb3I6cG9pbnRlcjtmb250LXNpemU6NDBweH0ubWF0LWRpYWxvZy1jb250ZW50e2NvbG9yOiM0NjQ2NDY7Zm9udC1zaXplOjE2cHg7Ym9yZGVyLWJvdHRvbToycHggc29saWQgcmdiYSgwLDAsMCwuMTUpfS5mb3JtLWdyb3Vwe21hcmdpbi1ib3R0b206MWVtfS5mdW5kLWxpc3QtaXRlbXttYXJnaW46MCAwIDE1cHh9LnByaW1hcnktYnRue2JhY2tncm91bmQ6IzJmNzQ5YTtjb2xvcjojZmZmfWBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBZGRGdW5kTW9kYWxDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBmdW5kTGlzdDogYW55W107XHJcbiAgc2VsZWN0ZWRGdW5kQ2hhbmdlOiAgRXZlbnRFbWl0dGVyPGFueT47XHJcbiAgXHJcbiAgIGNvbnN0cnVjdG9yKFxyXG4gICAgIHByaXZhdGUgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgIHB1YmxpYyBkaWFsb2dSZWY6IE1hdERpYWxvZ1JlZjxBZGRGdW5kTW9kYWxDb21wb25lbnQ+LFxyXG4gICAgQEluamVjdChNQVRfRElBTE9HX0RBVEEpIHB1YmxpYyBkYXRhOiBhbnkpIHtcclxuICAgICAgdGhpcy5mdW5kTGlzdCA9IF8uY2xvbmVEZWVwKGRhdGFbJ2Z1bmRMaXN0J10pO1xyXG4gICAgICB0aGlzLnNlbGVjdGVkRnVuZENoYW5nZSA9IGRhdGEuZGF0YUNoYW5nZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG4gIGhhbmRsZVNlbGVjdEZ1bmQoZnVuZCkge1xyXG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmZ1bmRMaXN0LmluZGV4T2YoZnVuZCk7XHJcbiAgICB0aGlzLmZ1bmRMaXN0W2luZGV4XVsnY2hlY2tlZCddID0gIXRoaXMuZnVuZExpc3RbaW5kZXhdWydjaGVja2VkJ107XHJcbiAgfVxyXG5cclxuICBoYW5kbGVDbGlja1NlbGVjdEJ0bigpIHtcclxuICAgIGNvbnN0IHJlbW92ZUZ1bmRMaXN0ID0gdGhpcy5mdW5kTGlzdC5maWx0ZXIoaXRlbSA9PiBpdGVtLmNoZWNrZWQgPT09IGZhbHNlKTtcclxuICAgIGNvbnN0IGFkZEZ1bmRsaXN0ID0gdGhpcy5mdW5kTGlzdC5maWx0ZXIoaXRlbSA9PiBpdGVtLmNoZWNrZWQgPT09IHRydWUpO1xyXG4gICAgcmVtb3ZlRnVuZExpc3QuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgIHRoaXMudXBkYXRlVmFyaWFibGVGdW5kTGlzdChpdGVtKTtcclxuICAgICB9KTtcclxuXHJcbiAgICAgYWRkRnVuZGxpc3QuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgIHRoaXMudXBkYXRlVmFyaWFibGVGdW5kTGlzdChpdGVtKTtcclxuICAgICB9KTtcclxuXHJcbiAgICAgdGhpcy5zZWxlY3RlZEZ1bmRDaGFuZ2UuZW1pdChhZGRGdW5kbGlzdCk7XHJcbiAgICAgdGhpcy5vbk5vQ2xpY2soKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVZhcmlhYmxlRnVuZExpc3QoZnVuZCkge1xyXG4gICAgbGV0IGluZGV4ID0gLTE7XHJcbiAgICB0aGlzLmNvbW1vblV0aWxzLnVwZGF0ZUZ1bmRTdGF0dXMoZnVuZFsnZnVuZElEJ10sZnVuZFsnY2hlY2tlZCddKTtcclxuICB9XHJcblxyXG4gIG9uTm9DbGljaygpOiB2b2lkIHtcclxuICAgIHRoaXMuZGlhbG9nUmVmLmNsb3NlKCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCIvLyBmdW5kIGNvbG9yIG1hcCwgbmVlZCBzZXQgY29sb3IgZm9yIGVhY2ggZnVuZCBpZiBhZGQgbW9yZSBmdW5kc1xyXG5leHBvcnQgY29uc3QgZGF0YVZpc3VhbEZ1bmRDb2xvck1hcCA9IFtcclxuICAgIHtcclxuICAgICAgICBmdW5kSUQ6IHVuZGVmaW5lZCxcclxuICAgICAgICBjb2xvcjonIzg2QkJEMScsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGZ1bmRJRDogdW5kZWZpbmVkLFxyXG4gICAgICAgIGNvbG9yOicjRkM3QzQyJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBmdW5kSUQ6IHVuZGVmaW5lZCxcclxuICAgICAgICBjb2xvcjonIzAwODE5OCdcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgZnVuZElEOiB1bmRlZmluZWQsXHJcbiAgICAgICAgY29sb3I6JyNDRERDMzknXHJcbiAgICB9XHJcbl1cclxuXHJcbmV4cG9ydCBjb25zdCBkYXRhVmlzdWFsQ29sb3IgPSBbXHJcbiAgICAnIzg2QkJEMScsJyNGQzdDNDInLCAnIzAwODE5OCcsJyNDRERDMzknXHJcbl1cclxuXHJcbi8vIGZvciBoZWF0bWFwIGNvbXBvbmVudCBjb2xvciBzZXR0aW5nXHJcbmV4cG9ydCBjb25zdCBoZWF0TWFwQ29sb3JTZXR0aW5nID0gW1xyXG4gICAge1xyXG4gICAgICAgIHZhbHVlOiAtMyxcclxuICAgICAgICBjb2xvcjogJyNCOTEyMjQnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICB2YWx1ZTogLTIsXHJcbiAgICAgICAgY29sb3I6ICcjRUFCN0JEJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgdmFsdWU6IC0xLFxyXG4gICAgICAgIGNvbG9yOiAnI0Y1RENERScsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIHZhbHVlOiAxLFxyXG4gICAgICAgIGNvbG9yOiAnI0RGRUFFMicsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIHZhbHVlOiAyLFxyXG4gICAgICAgIGNvbG9yOiAnI0JFRDVDNScsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIHZhbHVlOiAzLFxyXG4gICAgICAgIGNvbG9yOiAnIzI4NzQzRScsXHJcbiAgICB9XHJcbl1cclxuXHJcbmV4cG9ydCBjb25zdCBoZWF0TWFwQ29sb3JTY2hlbWUgPSB7XHJcbiAgICBkb21haW46IFsnI0I5MTIyNCcsICcjRUFCN0JEJywgJyNGNURDREUnLCAnI0RGRUFFMicsJyNCRUQ1QzUnLCcjMjg3NDNFJ11cclxuICB9OyIsImV4cG9ydCBjb25zdCBkZWZhdWx0RnVuZExpc3QgPSBbXHJcblxyXG4gIHtcclxuICAgIFwibmFtZVwiOiBcIlwiLFxyXG4gICAgXCJzZXJpZXNcIjogW1xyXG4gICAgICB7XHJcbiAgICAgICAgXCJuYW1lXCI6IFwiMDk6MzA6MDBcIixcclxuICAgICAgICBcInZhbHVlXCI6IDAuMCxcclxuICAgICAgICBcIm5hdlwiOiBcIjAuMFwiLFxyXG4gICAgICAgIFwibWFya2V0dmFsXCI6IFwiMC4wXCJcclxuICAgICAgfVxyXG4gICAgXVxyXG4gIH1cclxuXTtcclxuXHJcbmV4cG9ydCBjb25zdCB0aWNrc1ZhbHVlID0gW1xyXG4gICAgbmV3IERhdGUoKS5zZXRIb3Vycyg5LCAzMCwgMCksIFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxMCwgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxMSwgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxMiwgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxMywgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxNCwgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxNSwgMzAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxNiwgMzAsIDApXHJcbiAgICBdO1xyXG4gICAgXHJcbiIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmLFxyXG4gIFZpZXdDb250YWluZXJSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IEJhc2VXaWRnZXRDb21wb25lbnQgfSBmcm9tICdAb21uaWEvdWktY29tbW9uJztcclxuaW1wb3J0IHtNYXREaWFsb2d9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsJztcclxuaW1wb3J0IHsgQWRkRnVuZE1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi4vYWRkLWZ1bmQtbW9kYWwvYWRkLWZ1bmQtbW9kYWwuY29tcG9uZW50JztcclxuaW1wb3J0IHsgTmF2U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zZXJ2aWNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZTb2NrZXRTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNvY2tldC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ29tbW9uVXRpbHNTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY29tbW9uLXV0aWxzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBkYXRhVmlzdWFsRnVuZENvbG9yTWFwIH0gZnJvbSAnLi4vY29sb3JzJztcclxuaW1wb3J0IHsgTmF2IH0gZnJvbSAnLi4vbW9kZWwvcW5hdic7XHJcbmltcG9ydCB7IHRpY2tzVmFsdWUsIGRlZmF1bHRGdW5kTGlzdCB9IGZyb20gJy4vbGluZS1kYXRhJztcclxuaW1wb3J0IHsgU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zaGFyZS1pbmZvLWJld2Vlbi1jb21wb25lbnRzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgVEhJU19FWFBSIH0gZnJvbSAnQGFuZ3VsYXIvY29tcGlsZXIvc3JjL291dHB1dC9vdXRwdXRfYXN0JztcclxuaW1wb3J0IHsgUmVzb3VyY2VNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1xbmF2LWxpbmUtY2hhcnQnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiAgY2xhc3M9XCJxbmF2LWNvbnRhaW5lclwiICpuZ0lmPVwiaXNEYXRhQXZhaWxhYmxlXCIgKHdpbmRvdzpyZXNpemUpPVwicmVzaXppbmdDaGFydCgkZXZlbnQpXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwibGl2ZS10aW1lLWZvci10aXRsZVwiPlxyXG4gICAgICAgIDxwICpuZ0lmPVwiY29tbW9uVXRpbHMuaXNBZnRlck1hcmtldENsb3NlIGVsc2UgZWxzZUJsb2NrXCI+Q2hhbmdlIGluIE5BViBwZXIgc2hhcmUgZm9yIHt7Y29tbW9uVXRpbHMubGl2ZVRpbWUgfCBkYXRlOidFRUVFJ319LCB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTonTU0vZGQveXl5eSd9fSwgYXMgb2YgTWFya2V0IENsb3NlOiB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTpcImg6bW0gYWFhYWEnbSdcIn19PC9wPlxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZWxzZUJsb2NrPjxwPkNoYW5nZSBpbiBOQVYgcGVyIHNoYXJlIGZvciB7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTonRUVFRSd9fSwge3tjb21tb25VdGlscy5saXZlVGltZSB8IGRhdGU6J01NL2RkL3l5eXknfX0sIFJlYWwgVGltZToge3tjb21tb25VdGlscy5saXZlVGltZSB8IGRhdGU6XCJoOm1tIGFhYWFhJ20nXCJ9fTwvcD48L25nLXRlbXBsYXRlPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY3VzdG9tLWxlZ2VuZFwiPlxyXG4gICAgPGFwcC1jdXN0b20tbGVnZW5kXHJcbiAgICAgIFtyZXN1bHRzXT1cInJlc3VsdHNcIlxyXG4gICAgICBbc2VsZWN0YWJsZV09XCJzZWxlY3RhYmxlXCJcclxuICAgICAgW3JlbW92YWJsZV09XCJyZW1vdmFibGVcIlxyXG4gICAgICBbY29sb3JEb21haW5dPSdjb2xvckRvbWFpbidcclxuICAgICAgW3NlbGVjdGVkRnVuZENoYW5nZV09XCJmdW5kQ2hhbmdlXCJcclxuICAgID5cclxuICAgIDwvYXBwLWN1c3RvbS1sZWdlbmQ+XHJcbiAgICA8ZGl2IGNsYXNzPVwiYWRkQ2h1bmtcIj5cclxuICAgICAgPG1hdC1pY29uIGNsYXNzPVwiYWRkRnVuZEljb25cIiBzdmdJY29uPVwiY2lyY2xlX3BsdXNcIiAgKGNsaWNrKT1cIm9wZW5BZGRGdW5kTW9kYWwoJGV2ZW50KVwiPjwvbWF0LWljb24+XHJcbiAgICAgIDxzcGFuIGNsYXNzPVwiYWRkQ29udGVudFwiPkFkZCBFbnRpdHk8L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8bGliLWZpbmUtbGluZS1jaGFydFxyXG4gIFtyZXN1bHRzXT0ncmVzdWx0cydcclxuICBbaGVpZ2h0XT0naGVpZ2h0J1xyXG4gIFt3aWR0aF09J3dpZHRoJ1xyXG4gIFttYXJnaW5dPSdtYXJnaW4nXHJcbiAgW2NvbG9yRG9tYWluXT0nY29sb3JEb21haW4nXHJcbiAgW2NpcmNsZURhdGFdPSdjaXJjbGVEYXRhJ1xyXG4gIFtjdXJyZW50TGluZVRpbWVdPSdjdXJyZW50TGluZVRpbWUnXHJcbiAgW2Rpc3BsYXlMaXZlVGltZV09J2Rpc3BsYXlMaXZlVGltZSdcclxuICBbdGlja1ZhbHVlc109J3RpY2tWYWx1ZXMnXHJcbiAgW3hBeGlzVGlja0Zvcm1hdHRpbmddPSd4QXhpc1RpY2tGb3JtYXR0aW5nJ1xyXG4gIFt4U2NhbGVNaW5dPSd4U2NhbGVNaW4nXHJcbiAgW3hTY2FsZU1heF09J3hTY2FsZU1heCdcclxuICBbc2hvd1lBeGlzTGFiZWxdPSdzaG93WUF4aXNMYWJlbCdcclxuICBbeUF4aXNMYWJlbF09J3lBeGlzTGFiZWwnXHJcbiAgW2FjdGl2ZUVudHJpZXNdPSdhY3RpdmVFbnRyaWVzJ1xyXG4gIFtoaWdoTGlnaHRBY3RpdmVFbnRyaWVzXT0naGlnaExpZ2h0QWN0aXZlRW50cmllcydcclxuICA+XHJcbiAgPC9saWItZmluZS1saW5lLWNoYXJ0PlxyXG48L2Rpdj5cclxuYCxcclxuICBzdHlsZXM6IFtgLm5neC1jaGFydC5tYXRlcmlhbHtkaXNwbGF5OnVuc2V0fS5xbmF2LWNvbnRhaW5lcnt3aWR0aDoxMDAlO2hlaWdodDoxMDAlfS5jdXN0b20tbGVnZW5ke2Rpc3BsYXk6aW5saW5lLWZsZXg7d2lkdGg6OTglO2FsaWduLWl0ZW1zOmNlbnRlcjttYXJnaW4tdG9wOjVweDtwYWRkaW5nOjAgMTJweDttaW4taGVpZ2h0OjQwcHh9LmFkZENodW5re3Bvc2l0aW9uOnJlbGF0aXZlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO21pbi1oZWlnaHQ6MzBweDttaW4td2lkdGg6MTUwcHh9LmFkZENodW5rIC5hZGRGdW5kSWNvbntwb3NpdGlvbjphYnNvbHV0ZTt0b3A6NnB4O21hcmdpbi1yaWdodDo1cHg7d2lkdGg6MTVweCFpbXBvcnRhbnQ7aGVpZ2h0OjE1cHghaW1wb3J0YW50O21hcmdpbi1sZWZ0OjIwcHg7Y3Vyc29yOnBvaW50ZXI7bWluLWhlaWdodDoxNXB4IWltcG9ydGFudDttaW4td2lkdGg6MTVweCFpbXBvcnRhbnR9LmFkZENodW5rIC5hZGRDb250ZW50e3Bvc2l0aW9uOmFic29sdXRlO3RvcDo2cHg7bGVmdDo0MHB4fS5saXZlLXRpbWUtZm9yLXRpdGxle3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6MTVweDtmb250LXNpemU6MTZweDtmb250LWZhbWlseTpESU5OZXh0TFRQcm8tTWVkaXVtO2NvbG9yOiM0NjQ2NDZ9YF1cclxufSlcclxuZXhwb3J0IGNsYXNzIFFuYXZMaW5lQ2hhcnRDb21wb25lbnQgZXh0ZW5kcyBCYXNlV2lkZ2V0Q29tcG9uZW50IHtcclxuICByZW1vdmFibGU6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIHNlbGVjdGFibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgcmVzdWx0czogYW55W10gPSBbXTtcclxuICBwZXJtYW5lbnRSZXN1bHRzOiBhbnlbXSA9IFtdO1xyXG4gIGlzRGF0YUF2YWlsYWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGhlaWdodDogbnVtYmVyID0gMjQwO1xyXG4gIG1hcmdpbjogYW55W10gPSBbMjAsIDEwMCwgMzAsIDEwMF07XHJcbiAgY29sb3JEb21haW46IGFueVtdID0gW107XHJcbiAgd2lkdGg6IG51bWJlcjtcclxuICB0aWNrVmFsdWVzOiBhbnlbXSA9IHRpY2tzVmFsdWU7XHJcbiAgY3VycmVudExpbmVUaW1lOiBEYXRlO1xyXG4gIGRpc3BsYXlMaXZlVGltZTogYW55O1xyXG4gIGNpcmNsZURhdGE6IGFueVtdID0gW107XHJcbiAgcGVybWFuZW50Q2lyY2xlRGF0YTogYW55W10gPSBbXTtcclxuICBwcmV2aW91c1RpbWVNYXA6IE1hcDxTdHJpbmcsIERhdGU+O1xyXG4gIHhTY2FsZU1pbjogYW55O1xyXG4gIHhTY2FsZU1heDogYW55O1xyXG4gIHNob3dZQXhpc0xhYmVsID0gdHJ1ZTtcclxuICB5QXhpc0xhYmVsID0gJ05hdiAlIENoYW5nZSdcclxuICBwcmV2aW91c1RpbWUgPSBuZXcgRGF0ZSgpO1xyXG4gIGFjdGl2ZUVudHJpZXM6IGFueVtdID0gW107XHJcbiAgaGlnaExpZ2h0QWN0aXZlRW50cmllczogYW55W10gPSBbXTtcclxuXHJcbiAgZnVuZENoYW5nZTogIEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3ICBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG4gIHJlbW92ZUluZGV4czogYW55W10gPSBbXTtcclxuICBwcml2YXRlIHN1YnM6IFN1YnNjcmlwdGlvbltdO1xyXG4gIGNvbnN0cnVjdG9yKGNoYXJ0RWxlbWVudDogRWxlbWVudFJlZiwgem9uZTogTmdab25lLCBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICBwcml2YXRlIG5hdlNlcnZpY2U6IE5hdlNlcnZpY2UsIHByaXZhdGUgbmF2U29ja2V0U2VydmljZTogTmF2U29ja2V0U2VydmljZSxcclxuICAgIHByaXZhdGUgZGlhbG9nOiBNYXREaWFsb2csXHJcbiAgICBwcml2YXRlIHZpZXdDb250YWluZXI6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cyA6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLFxyXG4gICAgcHVibGljIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICBwcml2YXRlIHJlc291cmNlTWFuZ2VyOiBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlKSB7XHJcbiAgICBzdXBlcigpO1xyXG4gICAgdGhpcy53aWR0aCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ21haW4nKVswXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCAtIDEwMDtcclxuICAgIHRoaXMueFNjYWxlTWluID0gY29tbW9uVXRpbHMuc3RhcnRUaW1lO1xyXG4gICAgdGhpcy54U2NhbGVNYXggPSBjb21tb25VdGlscy5lbmRUaW1lO1xyXG4gICAgdGhpcy5jdXJyZW50TGluZVRpbWUgPSBjb21tb25VdGlscy5zdGFydFRpbWU7XHJcblxyXG4gICAgdGhpcy5yZXNvdXJjZU1hbmdlci5yZWdpc3RJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGlmIChuZXcgRGF0ZSgpIDwgY29tbW9uVXRpbHMuZW5kVGltZSkge1xyXG4gICAgICAgIHRoaXMuZGlzcGxheUxpdmVUaW1lID0gbmV3IERhdGUoKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuZGlzcGxheUxpdmVUaW1lID0gY29tbW9uVXRpbHMuZW5kVGltZTtcclxuICAgICAgfVxyXG4gICAgfSwxMDAwKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgLy9uZWVkIHRvIHJlc2V0IHZhbHVlIGhlcmUgd2hlbiBzd2l0Y2ggYmFjayBmcm9tIG90aGVyIGRhc2hib2FyZCBsaWtlIHBvc2l0aW9uIG9yIHdoZW4gc3dpdGNoIHVzZXJzXHJcbiAgICB0aGlzLmNvbW1vblV0aWxzLnZhbGlkYXRlVXNlcigpO1xyXG4gICAgLy9pbml0aWFsaXplIHRoZSAgY29sb3JEb21haW4gd2l0aCBwcmVkZWZpbmVkIGNvbG9ycy5cclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNldENvbG9yU2NoZW1hKGRhdGFWaXN1YWxGdW5kQ29sb3JNYXApO1xyXG4gICAgdGhpcy5pc0RhdGFBdmFpbGFibGUgPSBmYWxzZTtcclxuICAgIHRoaXMuc3VicyA9IFtdO1xyXG4gICAgdGhpcy5yZXN1bHRzID0gW107XHJcbiAgICB0aGlzLnBlcm1hbmVudFJlc3VsdHMgPSBbXTtcclxuICAgIHRoaXMuY29sb3JEb21haW4gPSBbXTtcclxuICAgIHRoaXMuY2lyY2xlRGF0YSA9IFtdO1xyXG4gICAgdGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhID0gW107XHJcbiAgICB0aGlzLnByZXZpb3VzVGltZU1hcCA9IG51bGw7XHJcbiAgICAvL3Jlc2V0IGRvbmVcclxuICAgIHRoaXMubmF2U2VydmljZS5mZXRjaEZ1bmRMaXN0KCk7XHJcbiAgICB0aGlzLnN1YnMucHVzaCh0aGlzLm5hdlNlcnZpY2UuZ2V0RnVuZExpc3QoKS5zdWJzY3JpYmUoXHJcbiAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZ1bmRMZXZlbERhdGEgPSB0aGlzLmNvbW1vblV0aWxzLmV4dHJhY3RGdW5kTGV2ZWxEYXRhKGRhdGEpO1xyXG4gICAgICAgICAgdGhpcy5wZXJtYW5lbnRSZXN1bHRzID0gWy4uLnRoaXMuY29udmVydFRvUmVzdWx0cyhmdW5kTGV2ZWxEYXRhKV07XHJcbiAgICAgICAgICB0aGlzLnBlcm1hbmVudENpcmNsZURhdGEgPSBbLi4udGhpcy51cGRhdGVDaXJjbGVEYXRhKGZ1bmRMZXZlbERhdGEpXTtcclxuICAgICAgICAgIHRoaXMuY29sb3JEb21haW4gPSBbLi4udGhpcy5zZXRGdW5kQ29sb3JNYXAoZnVuZExldmVsRGF0YSldO1xyXG4gICAgICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc2V0Q29sb3JTY2hlbWEodGhpcy5jb2xvckRvbWFpbik7XHJcbiAgICAgICAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IHRydWU7XHJcbiAgICAgICAgICB0aGlzLnByZXZpb3VzVGltZU1hcCA9IG5ldyBNYXAoKTtcclxuICAgICAgICAgIHRoaXMucGVybWFuZW50UmVzdWx0cy5mb3JFYWNoKGYgPT4ge1xyXG4gICAgICAgICAgICBsZXQgc2VyaWVzID0gZlsnc2VyaWVzJ107XHJcbiAgICAgICAgICAgIHRoaXMucHJldmlvdXNUaW1lTWFwLnNldChmWyduYW1lJ10sIHNlcmllc1tzZXJpZXMubGVuZ3RoIC0gMV1bJ3ByaWNldGltZSddKTtcclxuICAgICAgICAgICAgdGhpcy5jdXJyZW50TGluZVRpbWUgPSBuZXcgRGF0ZSh0aGlzLnByZXZpb3VzVGltZU1hcC5nZXQoZlsnbmFtZSddKSk7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHRoaXMucmVzdWx0cyA9IHRoaXMuZmlsdGVyUmVzdWx0cyh0aGlzLnBlcm1hbmVudFJlc3VsdHMpO1xyXG4gICAgICAgICAgdGhpcy5jaXJjbGVEYXRhID0gdGhpcy5maWx0ZXJDaXJjbGVEYXRlKHRoaXMucGVybWFuZW50Q2lyY2xlRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApKTtcclxuXHJcbiAgICB0aGlzLnN1YnMucHVzaCh0aGlzLm5hdlNvY2tldFNlcnZpY2UuZ2V0TmF2KCkuc3Vic2NyaWJlKFxyXG4gICAgICAoZGF0YSkgPT4ge1xyXG4gICAgICAgIGlmIChkYXRhICYmIGRhdGFbXCJldmVudERhdGFcIl0pIHtcclxuICAgICAgICAgIGNvbnN0IGZ1bmRMZXZlbFVwZGF0ZURhdGEgPSB0aGlzLmNvbW1vblV0aWxzLmV4dHJhY3RXU0RhdGEoZGF0YVtcImV2ZW50RGF0YVwiXSwgZmFsc2UpO1xyXG4gICAgICAgICAgdGhpcy51cGRhdGVDaGFydChmdW5kTGV2ZWxVcGRhdGVEYXRhKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICkpO1xyXG5cclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMuc3Vic2NyaWJlKGRhdGEgPT4ge1xyXG4gICAgICBjb25zdCBmaWx0ZXJlZEFjdGl2ZURhdGEgPSBbXTtcclxuICAgICAgY29uc3QgbGlzdHMgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgICBkYXRhLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKGxpc3RzLmZpbmQobGlzdCA9PiAobGlzdC5mdW5kSUQgPT09IGl0ZW0ubmFtZSAmJiBsaXN0LmNoZWNrZWQpKSkge1xyXG4gICAgICAgICAgZmlsdGVyZWRBY3RpdmVEYXRhLnB1c2goaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICB0aGlzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMgPSBmaWx0ZXJlZEFjdGl2ZURhdGE7XHJcbiAgICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IGZpbHRlcmVkQWN0aXZlRGF0YTtcclxuICAgIH0pXHJcblxyXG4gICAgICB0aGlzLmZ1bmRDaGFuZ2Uuc3Vic2NyaWJlKGRhdGEgPT4ge1xyXG4gICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMuZW1pdCh0aGlzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMpO1xyXG4gICAgICAgIHRoaXMucmVzdWx0cyA9IFtdO1xyXG4gICAgICAgIHRoaXMuY2lyY2xlRGF0YSA9IFtdO1xyXG4gICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZm9yRWFjaCAoZnVuZCA9PiB7XHJcbiAgICAgICAgICB0aGlzLnBlcm1hbmVudFJlc3VsdHMuZm9yRWFjaCAocmVzdWx0ID0+IHtcclxuICAgICAgICAgICAgaWYoZnVuZFsnZnVuZElEJ10gPT09IHJlc3VsdFsnbmFtZSddICYmIGZ1bmRbJ2NoZWNrZWQnXSkge1xyXG4gICAgICAgICAgICAgIHRoaXMucmVzdWx0cy5wdXNoKHJlc3VsdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgdGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhLmZvckVhY2goY2lyY2xlID0+IHtcclxuICAgICAgICAgICAgaWYgKGZ1bmRbJ2Z1bmRJRCddID09PSBjaXJjbGVbJ25hbWUnXSAmJiBmdW5kWydjaGVja2VkJ10pIHtcclxuICAgICAgICAgICAgICB0aGlzLmNpcmNsZURhdGEucHVzaChjaXJjbGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9XHJcblxyXG4gIGZpbHRlclJlc3VsdHMocGVybW5hbnRSZXN1bHQpOiBhbnlbXSB7XHJcbiAgICBsZXQgZmlsdGVyZWRSZXN1bHRzID0gW107XHJcbiAgICAgcGVybW5hbnRSZXN1bHQuZm9yRWFjaChyZXN1bHQgPT4ge1xyXG4gICAgICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgICBpZiAoIHJlc3VsdC5uYW1lID09PSBpdGVtLmZ1bmRJRCAmJiBpdGVtLmNoZWNrZWQpIHtcclxuICAgICAgICAgICBmaWx0ZXJlZFJlc3VsdHMucHVzaChyZXN1bHQpO1xyXG4gICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGZpbHRlcmVkUmVzdWx0cztcclxuICB9XHJcblxyXG4gIGZpbHRlckNpcmNsZURhdGUocGVybWFuZW50Q2lyY2xlRGF0YSk6IGFueVtdIHtcclxuICAgIGxldCBmaWx0ZXJlZENpcmNsZURhdGEgPSBbXTtcclxuICAgICBwZXJtYW5lbnRDaXJjbGVEYXRhLmZvckVhY2gocmVzdWx0ID0+IHtcclxuICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICAgaWYgKCByZXN1bHQubmFtZSA9PT0gaXRlbS5mdW5kSUQgJiYgaXRlbS5jaGVja2VkKSB7XHJcbiAgICAgICAgICAgZmlsdGVyZWRDaXJjbGVEYXRhLnB1c2gocmVzdWx0KTtcclxuICAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICAgIHJldHVybiBmaWx0ZXJlZENpcmNsZURhdGE7XHJcbiAgfVxyXG5cclxuICBzZXRGdW5kQ29sb3JNYXAoZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcCA9IFtdO1xyXG4gICAgY29uc3QgbGlzdHMgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBsZXQgc2V0Q29sb3IgPSBmYWxzZTtcclxuICAgICAgbGlzdHMuZm9yRWFjaChsaXN0ID0+IHtcclxuICAgICAgIGlmIChpdGVtLmZ1bmRpZCA9PT0gbGlzdC5mdW5kSUQgJiYgbGlzdC5jaGVja2VkKSBzZXRDb2xvciA9IHRydWU7XHJcbiAgICAgIH0pXHJcbiAgICAgICBpZiAoc2V0Q29sb3IpIHtcclxuICAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgZnVuZGlkOiBpdGVtLmZ1bmRpZCxcclxuICAgICAgICAgIGNvbG9yOiB0aGlzLmNvbW1vblV0aWxzLmdldENvbG9yRm9yRnVuZChpdGVtLmZ1bmRpZClcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcC5wdXNoKG9iailcclxuICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICAgIGZ1bmRpZDogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgY29sb3I6IHRoaXMuY29tbW9uVXRpbHMuZ2V0Q29sb3JGb3JGdW5kKGl0ZW0uZnVuZGlkKVxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wLnB1c2gob2JqKVxyXG4gICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wO1xyXG4gIH1cclxuXHJcbiAgXHJcbiAgLy9uZWVkIHRvIHVuc3Vic2NyaWJlIHRvIGF2b2lkIHBvdGVudGlhbCBtZW1vcnkgbGVhay5cclxuICBuZ09uRGVzdHJveSgpIHtcclxuICAgIHRoaXMuc3Vicy5mb3JFYWNoKHN1YiA9PiBzdWIudW5zdWJzY3JpYmUoKSk7XHJcbiAgICB0aGlzLmNvbG9yRG9tYWluID0gW107XHJcbiAgICB0aGlzLnJlc291cmNlTWFuZ2VyLmNsZWFuUmVzb3VyY2VzKCk7XHJcbiAgfVxyXG5cclxuICByZXNpemluZ0NoYXJ0KGV2ZW50KSB7XHJcbiAgICB0aGlzLndpZHRoID0gZXZlbnQudGFyZ2V0LmlubmVyV2lkdGggLSAxMDA7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdldFJlc3VsdHMocmVzdWx0czogYW55W10pIDogYW55W117XHJcbiAgICBpZihyZXN1bHRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIHJldHVybiBkZWZhdWx0RnVuZExpc3Q7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gcmVzdWx0cztcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVwZGF0ZUNoYXJ0KGRhdGEpIHtcclxuICAgIGlmIChkYXRhKSB7XHJcbiAgICAgIGNvbnN0IGZ1bmRpZCA9IGRhdGFbJ2Z1bmRpZCddO1xyXG4gICAgICBsZXQgdGltZVxyXG4gICAgICBsZXQgY3VycmVudFRpbWU6IERhdGU7XHJcbiAgICAgIGlmIChkYXRhWydwcmljZXRpbWUnXSkge1xyXG4gICAgICAgIGN1cnJlbnRUaW1lID0gbmV3IERhdGUoZGF0YVsncHJpY2V0aW1lJ10pO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKGN1cnJlbnRUaW1lKSkge1xyXG4gICAgICAgICAgdGltZSA9IGN1cnJlbnRUaW1lO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAoY3VycmVudFRpbWUgPiB0aGlzLmNvbW1vblV0aWxzLmVuZFRpbWUpIHtcclxuICAgICAgICB0aGlzLmN1cnJlbnRMaW5lVGltZSA9IHRoaXMuY29tbW9uVXRpbHMuZW5kVGltZTtcclxuICAgICAgfVxyXG4gICAgICAvL2ZvciBhZGRpbmcgYWxlcnQgZGF0YSBpZiBhbnkuXHJcbiAgICAgIGlmICh0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKSkgJiYgZGF0YVsnYWxlcnRUeXBlJ10gJiYgKGRhdGFbJ2FsZXJ0VHlwZSddID09IDEgfHwgZGF0YVsnYWxlcnRUeXBlJ10gPT09IDIpKSB7XHJcbiAgICAgICAgY29uc3QgYWxlcnRPYmogPSB7XHJcbiAgICAgICAgICBcIm5hbWVcIjogZnVuZGlkLFxyXG4gICAgICAgICAgXCJ4XCI6IG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKSxcclxuICAgICAgICAgIFwiYWxlcnRUeXBlXCI6IGRhdGFbJ2FsZXJ0VHlwZSddLFxyXG4gICAgICAgICAgXCJ2YWx1ZVwiOiBkYXRhWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcImZ1bmRtdkNoYW5nZVBlcmNlbnRcIjogZGF0YVsnZnVuZG12Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJuYXZcIjogZGF0YVsnbmF2J10sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBkYXRhWydmdW5kbXYnXSxcclxuICAgICAgICAgIFwicHJpY2V0aW1lXCI6IGRhdGFbJ3ByaWNldGltZSddXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucGVybWFuZW50Q2lyY2xlRGF0YS5wdXNoKGFsZXJ0T2JqKTtcclxuICAgICAgICAvL3RoaXMucGVybWFuZW50Q2lyY2xlRGF0YSA9IFsuLi50aGlzLnBlcm1hbmVudENpcmNsZURhdGFdO1xyXG4gICAgICAgIHRoaXMuY2lyY2xlRGF0YSA9IFsuLi50aGlzLmZpbHRlckNpcmNsZURhdGUodGhpcy5wZXJtYW5lbnRDaXJjbGVEYXRhKV07XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5wZXJtYW5lbnRSZXN1bHRzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW1bJ25hbWUnXSA9PT0gZnVuZGlkKSB7XHJcbiAgICAgICAgICAvL29ubHkgc2hvd3MgZGF0YSBiZXR3ZWVuIDk6MzBBTSB0byA0OjMwUE1cclxuICAgICAgICAgIGlmICh0aW1lKSB7XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50VGltZS5nZXRUaW1lKCkgLSBuZXcgRGF0ZSh0aGlzLnByZXZpb3VzVGltZU1hcC5nZXQoZnVuZGlkKSkuZ2V0VGltZSgpID49IDIwMDAwKSB7XHJcbiAgICAgICAgICAgICAgdGhpcy5jdXJyZW50TGluZVRpbWUgPSBuZXcgRGF0ZShkYXRhWydwcmljZXRpbWUnXSk7XHJcbiAgICAgICAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgICAgICAgJ21hcmtldHZhbCc6IGRhdGFbJ2Z1bmRtdiddLCAvLyBmdW5kIG1hcmtldCB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgJ25hbWUnOiB0aGlzLm5leHRUaW1lRm9yRnVuZCh0aGlzLnByZXZpb3VzVGltZU1hcCwgZnVuZGlkLCBkYXRhWydwcmljZXRpbWUnXSksXHJcbiAgICAgICAgICAgICAgICAnbmF2JzogZGF0YVsnbmF2J10sXHJcbiAgICAgICAgICAgICAgICAndmFsdWUnOiBkYXRhWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICAgICAgICAncHJpY2V0aW1lJzogZGF0YVsncHJpY2V0aW1lJ11cclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIGl0ZW1bJ3NlcmllcyddLnB1c2gob2JqKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmKGN1cnJlbnRUaW1lLmdldFRpbWUoKSAtIHRoaXMucHJldmlvdXNUaW1lLmdldFRpbWUoKSA+PTIwMDApe1xyXG4gICAgICAgICAgICAgIHRoaXMucHJldmlvdXNUaW1lID0gY3VycmVudFRpbWU7XHJcbiAgICAgICAgICAgICAgLy90aGlzLmN1cnJlbnRMaW5lVGltZSA9IG5ldyBEYXRlKHRoaXMucHJldmlvdXNUaW1lTWFwLmdldChmdW5kVGlja2VyKSk7IC8vdGhpcyB3aWxsIGNhdXNlIGNvbXBvbmVudCByZS1yZW5kZXIgd2hlbmV2ZXIgdGhpcyBpcyB3cyBkYXRhIGNvbWluZ1xyXG4gICAgICAgICAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICAgICAgICAgICdtYXJrZXR2YWwnOiBkYXRhWydmdW5kbXYnXSxcclxuICAgICAgICAgICAgICAgICduYW1lJzogbmV3IERhdGUodGhpcy5wcmV2aW91c1RpbWVNYXAuZ2V0KGZ1bmRpZCkpLFxyXG4gICAgICAgICAgICAgICAgJ25hdic6IGRhdGFbJ25hdiddLFxyXG4gICAgICAgICAgICAgICAgJ3ZhbHVlJzogZGF0YVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgICAgICAgJ3ByaWNldGltZSc6IGRhdGFbJ3ByaWNldGltZSddXHJcbiAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAvL3RoaXMgd2lsbCBpbmNyZWFzZSBjcHUgdXNhZ2UgYXMgd2VsbCwgbmVlZCB0byBmaW5kIGJldHRlciB3YXkgdG8gdXBkYXRlIHJlc3VsdHNcclxuICAgICAgICAgICAgICBpdGVtWydzZXJpZXMnXS5wb3AoKTtcclxuICAgICAgICAgICAgICBpdGVtWydzZXJpZXMnXS5wdXNoKG9iaik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgfVxyXG5cclxuICB9XHJcbiAgLy8gdGhlIGdldCBmdW5kIGxpc3Qgc2VydmljZSB3aWxsIHJldHVybiB0aGUgaGlzdG9yeSBjaGFydCBkYXRhLCB1c2luZyBiZWxvdyBmdW5jdGlvbnMgdG8gY292ZXJ0IHRoZSBkYXRhIHRvIGV4cGVjdGVkIHJlc3VsdCBzZXRcclxuICBjb252ZXJ0VG9SZXN1bHRzKGRhdGE6IGFueVtdKTogYW55W10ge1xyXG4gICAgY29uc3QgcmVzdWx0czogYW55W10gPSBbXTtcclxuICAgIGNvbnN0IHZhcmlhYmxlRnVuZExpc3Q6IGFueVtdID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKTtcclxuICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgLy8gZm9yIHBlcnNpc3RlbnQgdXNlciBzZWxlY3RlZCBmdW5kcyBpbiBsZWdlbmQuXHJcbiAgICAgIGlmICh2YXJpYWJsZUZ1bmRMaXN0LmZpbmRJbmRleChsaXN0ID0+IGxpc3QuZnVuZElEID09PSBpdGVtLmZ1bmRpZCkgPT09IC0xKSB7ICAgICAgICBcclxuICAgICAgICAgIHZhcmlhYmxlRnVuZExpc3QucHVzaCh7XHJcbiAgICAgICAgICAnZnVuZElEJzogaXRlbVsnZnVuZGlkJ10sXHJcbiAgICAgICAgICAnZnVuZFRpY2tlcic6aXRlbVsnZnVuZFRpY2tlciddLFxyXG4gICAgICAgICAgJ2NoZWNrZWQnOiB0cnVlXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgJ25hbWUnOiBpdGVtWydmdW5kaWQnXSxcclxuICAgICAgICAnZnVuZElEJzogaXRlbVsnZnVuZGlkJ10sXHJcbiAgICAgICAgJ2Z1bmRUaWNrZXInOml0ZW1bJ2Z1bmRUaWNrZXInXSxcclxuICAgICAgICAnc2VyaWVzJzogdGhpcy5jcmVhdGVTZXJpZXMoaXRlbSlcclxuICAgICAgfVxyXG4gICAgICByZXN1bHRzLnB1c2gob2JqKTtcclxuICAgIH0pXHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zZXRWYXJpYWJsZUZ1bmRMaXN0KHZhcmlhYmxlRnVuZExpc3QpO1xyXG4gICAgcmV0dXJuIHJlc3VsdHM7XHJcbiAgfVxyXG4gIGNyZWF0ZVNlcmllcyhkYXRhOiBhbnkpOiBhbnlbXSB7XHJcbiAgICBjb25zdCBzZXJpZXM6IGFueVtdID0gW107XHJcbiAgICBkYXRhWydwcmljZUNoYW5nZXMnXS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSkpKSB7XHJcbiAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgJ21hcmtldHZhbCc6IGl0ZW1bJ2Z1bmRtdiddLCAvL2Z1bmQgbWFya2V0IHZhbHVlIGZyb20gaGlzdG9yeSBkYXRhXHJcbiAgICAgICAgICAnbmFtZSc6IG5ldyBEYXRlKGl0ZW1bJ3ByaWNldGltZSddKSxcclxuICAgICAgICAgICduYXYnOiBpdGVtWyduYXYnXSxcclxuICAgICAgICAgICd2YWx1ZSc6IGl0ZW1bJ25hdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgICdwcmljZXRpbWUnOiBpdGVtWydwcmljZXRpbWUnXVxyXG4gICAgICAgIH1cclxuICAgICAgICBzZXJpZXMucHVzaChvYmopO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICApXHJcbiAgICBpZiAoc2VyaWVzLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IHtcclxuICAgICAgICAnbWFya2V0dmFsJzogZGF0YVsnZnVuZG12J10sIC8vZnVuZCBtYXJrZXQgdmFsdWUgZnJvbSBoaXN0b3J5IGRhdGFcclxuICAgICAgICAnbmFtZSc6IHRoaXMueFNjYWxlTWluLFxyXG4gICAgICAgICduYXYnOiBkYXRhWyduYXYnXSxcclxuICAgICAgICAndmFsdWUnOiAwLFxyXG4gICAgICAgICdwcmljZXRpbWUnOiB0aGlzLmNvbW1vblV0aWxzLnN0YXJ0VGltZVxyXG4gICAgICB9XHJcbiAgICAgIHNlcmllcy5wdXNoKG9iaik7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc2VyaWVzO1xyXG4gIH1cclxuXHJcbiAgLy8gZm9yIGNvbGxlY3RpbmcgaGlzdG9yaWMgYWxlcnQgZGF0YVxyXG4gIHVwZGF0ZUNpcmNsZURhdGEoZGF0YSkge1xyXG4gICAgbGV0IENyaWNsZURhdGEgPSBbXTtcclxuICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgQ3JpY2xlRGF0YSA9IENyaWNsZURhdGEuY29uY2F0KHRoaXMuZmlsdGVyQWxlcnREYXRhKGl0ZW1bJ2Z1bmRpZCddLCBpdGVtWydwcmljZUNoYW5nZXMnXSkpO1xyXG4gICAgfSlcclxuICAgIHJldHVybiBDcmljbGVEYXRhO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyQWxlcnREYXRhKGZ1bmRpZCwgZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcEFsZXJ0Q3JpY2xlRGF0YSA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSkpICYmIGl0ZW1bJ2FsZXJ0VHlwZSddICYmIChpdGVtWydhbGVydFR5cGUnXSA9PSAxIHx8IGl0ZW1bJ2FsZXJ0VHlwZSddID09PSAyKSkge1xyXG4gICAgICAgIGNvbnN0IGFsZXJ0T2JqID0ge1xyXG4gICAgICAgICAgXCJuYW1lXCI6IGZ1bmRpZCxcclxuICAgICAgICAgIFwieFwiOiBuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSksXHJcbiAgICAgICAgICBcImFsZXJ0VHlwZVwiOiBpdGVtWydhbGVydFR5cGUnXSxcclxuICAgICAgICAgIFwidmFsdWVcIjogaXRlbVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJuYXZcIjogaXRlbVsnbmF2J10sXHJcbiAgICAgICAgICBcImZ1bmRtdkNoYW5nZVBlcmNlbnRcIjogaXRlbVsnZnVuZG12Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJtYXJrZXR2YWxcIjogaXRlbVsnZnVuZG12J10sXHJcbiAgICAgICAgICBcInByaWNldGltZVwiOiBpdGVtWydwcmljZXRpbWUnXSxcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcEFsZXJ0Q3JpY2xlRGF0YS5wdXNoKGFsZXJ0T2JqKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wQWxlcnRDcmljbGVEYXRhO1xyXG4gIH1cclxuXHJcblxyXG4gIC8vIHRoaXMgbWV0aG9kIHdpbGwgcmV0dXJuIHRoZSBuZXh0IHRpbWUgYW5kIHNldCB0aGUgbmV3IHRpbWUgdG8gdGhlIHByZXZpb3VzIHRpbWUgbWFwIGZvciB0aGUgZ2l2ZW4gZnVuZFxyXG4gIG5leHRUaW1lRm9yRnVuZChwcmV2aW91c1RpbWVNYXA6IE1hcDxTdHJpbmcsIERhdGU+LCBmdW5kaWQ6IFN0cmluZywgdGltZSkge1xyXG4gICAgcHJldmlvdXNUaW1lTWFwLnNldChmdW5kaWQsIHRpbWUpOyAvLyBzZXQgYmFjayB0byB0aGUgbWFwXHJcbiAgICByZXR1cm4gbmV3IERhdGUodGltZSk7XHJcbiAgfVxyXG5cclxuICBvcGVuQWRkRnVuZE1vZGFsKGV2ZW50KTogdm9pZCB7XHJcbiAgICBjb25zdCBkaWFsb2dSZWYgPSB0aGlzLmRpYWxvZy5vcGVuKEFkZEZ1bmRNb2RhbENvbXBvbmVudCwge1xyXG4gICAgICB3aWR0aDogJzMwMHB4JyxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgICAgJ2Z1bmRMaXN0JzogdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKSxcclxuICAgICAgICAgICdkYXRhQ2hhbmdlJzogdGhpcy5mdW5kQ2hhbmdlIC8vY3JlYXRlIGV2ZW50ZW1pdHRlciBvdXJzZWxmIGFzIGNsb3NlRGlhbG9nU3ViamVjdCBpcyBub3Qgd29ya2luZ1xyXG4gICAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIGRpYWxvZ1JlZi5hZnRlckNsb3NlZCgpLnN1YnNjcmliZShyZXN1bHQgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygnVGhlIGRpYWxvZyB3YXMgY2xvc2VkJyk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHhBeGlzVGlja0Zvcm1hdHRpbmcodikge1xyXG4gICBjb25zdCB0ZW1wRGF0ZSA9IG5ldyBEYXRlKHYpO1xyXG4gICByZXR1cm4gZm9ybWF0RGF0ZSh0ZW1wRGF0ZSxcImg6bW0gYWFhYWEnbSdcIiwnZW4tVVMnKTtcclxuIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQFBpcGUoe1xyXG4gIG5hbWU6ICdwZXJjZW50Rm9ybWF0J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgUGVyY2VudEZvcm1hdFBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcclxuXHJcbiAgdHJhbnNmb3JtKHZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgaWYgKHZhbHVlICE9IDApIHtcclxuICAgICAgaWYgKHZhbHVlLnRvU3RyaW5nKCkuaW5kZXhPZignLScpID09PSAwKSB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiAnKycgKyB2YWx1ZTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIFwiMC4wMDAlXCI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AUGlwZSh7XHJcbiAgbmFtZTogJ251bWJlclJvdW5kVXAnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBOdW1iZXJSb3VuZFVwUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xyXG5cclxuICB0cmFuc2Zvcm0odmFsdWU6IGFueSwgbWF4RnJhY3Rpb25EaWdpdHM6IG51bWJlcik6IGFueSB7XHJcbiAgICByZXR1cm4gTWF0aC5yb3VuZCgxMCoqbWF4RnJhY3Rpb25EaWdpdHMqdmFsdWUpLzEwKiptYXhGcmFjdGlvbkRpZ2l0cztcclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbmplY3QsIEV2ZW50RW1pdHRlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge01hdERpYWxvZ1JlZiwgTUFUX0RJQUxPR19EQVRBfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbCc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLWN1c3RvbS1hbGVydC1tb2RhbCcsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwibW9kYWwtaGVhZGVyXCI+XHJcbiAgPGgxIG1hdC1kaWFsb2ctdGl0bGU+e3tkYXRhLnRpdGxlfX0ge3tkYXRhLnR5cGV9fSBBbGVydHMgZm9yIHt7ZGF0YS5ub3cgfCBkYXRlOiBcIkVFRUUsIE0vZCwgaDptbSBhYWFhYSdtJ1wifX08L2gxPlxyXG4gIDxzcGFuIGNsYXNzPVwiYWxlcnQtY2xvc2VcIiAoY2xpY2spPVwib25Ob0NsaWNrKClcIiA+w4PClzwvc3Bhbj5cclxuPC9kaXY+XHJcbjxkaXYgbWF0LWRpYWxvZy1jb250ZW50PlxyXG4gIDxkaXYgY2xhc3M9XCJjb250YWluZXIgY3VzdG9tLWFsZXJ0LXN0eVwiICpuZ0Zvcj1cImxldCBkYXRhIG9mIGFsZXJ0RGF0YVwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImFsZXJ0LWRldGFpbHMtaXRlbS1jb250YWluZXJcIj5cclxuICAgICAgPGRpdiBjbGFzcz1cInRvcC1saW5lXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInRvcC1saW5lLWl0ZW1cIj5cclxuICAgICAgICB7e2RhdGEucHJpY2V0aW1lIHwgZGF0ZTogXCJoOm1tOnNzIGFhYWFhJ20nXCJ9fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0b3AtbGluZS1pdGVtXCI+XHJcbiAgICAgICAgICBOQVYgRGl2ZXJnaW5nIGZyb20gTWFya2V0IFZhbHVlXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYnV0dG9uLWxpbmVcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgIDxkaXYgY2xhc3M9XCJidXR0b24tbGluZS1pdGVtXCI+XHJcbiAgICAgICAgICAgICBOQVYgJSBDaGFuZ2U6XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJidXR0b24tbGluZS1pdGVtXCI+XHJcbiAgICAgICAgICAgIHt7ZGF0YS52YWx1ZSB8IHBlcmNlbnQ6ICcxLjItMid9fVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgPGRpdiBjbGFzcz1cImJ1dHRvbi1saW5lLWl0ZW1cIj5cclxuICAgICAgICAgICAgIE1WICUgQ2hhbmdlOlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiYnV0dG9uLWxpbmUtaXRlbVwiPlxyXG4gICAgICAgICAgICB7e2RhdGEuZnVuZG12Q2hhbmdlUGVyY2VudCB8IHBlcmNlbnQ6ICcxLjItMid9fVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxuPGRpdiBtYXQtZGlhbG9nLWFjdGlvbnMgYWxpZ249XCJlbmRcIj5cclxuICA8IS0tIDxidXR0b24gbWF0LWJ1dHRvbiAoY2xpY2spPVwib25Ob0NsaWNrKClcIiBjZGtGb2N1c0luaXRpYWw+Q2FuY2VsPC9idXR0b24+IC0tPlxyXG4gIDxidXR0b24gbWF0LWJ1dHRvbiAoY2xpY2spPVwib25Ob0NsaWNrKClcIiBjbGFzcz1cInByaW1hcnktYnRuXCI+T0s8L2J1dHRvbj5cclxuPC9kaXY+YCxcclxuICBzdHlsZXM6IFtgLm1vZGFsLWhlYWRlcntwb3NpdGlvbjpyZWxhdGl2ZX0ubWF0LWRpYWxvZy10aXRsZXtjb2xvcjojNDY0NjQ2O21hcmdpbjotMTBweCAwIDIwcHh9LmFsZXJ0LWNsb3Nle3Bvc2l0aW9uOmFic29sdXRlO3RvcDotNnB4O3JpZ2h0Oi02cHg7Y29sb3I6cmdiYSgxMDUsMTA1LDEwNSwuNzgpO2N1cnNvcjpwb2ludGVyO2ZvbnQtc2l6ZTo0MHB4fS5tYXQtZGlhbG9nLWNvbnRlbnR7Ym9yZGVyLWJvdHRvbToycHggc29saWQgcmdiYSgwLDAsMCwuMTUpO2hlaWdodDoyNTBweDtvdmVyZmxvdzphdXRvfS5jdXN0b20tYWxlcnQtc3R5e2NvbG9yOiM0NjQ2NDY7Zm9udC1zaXplOjE2cHg7cGFkZGluZy1sZWZ0OjAhaW1wb3J0YW50O21hcmdpbi1ib3R0b206MjBweH0uYWxlcnQtZGV0YWlscy1pdGVtLWNvbnRhaW5lcntwYWRkaW5nOjAgMCAxMHB4fS50b3AtbGluZXtkaXNwbGF5OmlubGluZS1mbGV4fS50b3AtbGluZS1pdGVte21hcmdpbi1yaWdodDoxNXB4fS5idXR0b24tbGluZXttYXJnaW4tdG9wOjVweDttYXJnaW4tbGVmdDo5MHB4fS5idXR0b24tbGluZS1pdGVte2Rpc3BsYXk6aW5saW5lLWZsZXg7d2lkdGg6MTUwcHh9LnByaW1hcnktYnRue2JhY2tncm91bmQ6IzJmNzQ5YTtjb2xvcjojZmZmfWBdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgYWxlcnREYXRhIDogYW55W10gPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICAgcHJpdmF0ZSBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgcHVibGljIGRpYWxvZ1JlZjogTWF0RGlhbG9nUmVmPEN1c3RvbUFsZXJ0TW9kYWxDb21wb25lbnQ+LFxyXG4gICAgQEluamVjdChNQVRfRElBTE9HX0RBVEEpIHB1YmxpYyBkYXRhOiBhbnkpICB7XHJcbiAgICB0aGlzLmFsZXJ0RGF0YSA9IGRhdGFbJ2FsZXJ0RGF0YSddOyAgICBcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gIH1cclxuXHJcbiAgb25Ob0NsaWNrKCk6IHZvaWQge1xyXG4gICAgdGhpcy5kaWFsb2dSZWYuY2xvc2UoKTtcclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmLFxyXG4gIFZpZXdDb250YWluZXJSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgZm9ybWF0TnVtYmVyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgQmFzZVdpZGdldENvbXBvbmVudCB9IGZyb20gJ0BvbW5pYS91aS1jb21tb24nO1xyXG5pbXBvcnQgeyBoZWF0TWFwQ29sb3JTZXR0aW5nLCBoZWF0TWFwQ29sb3JTY2hlbWUgfSBmcm9tICcuLi9jb2xvcnMnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdlNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9uYXYtc2VydmljZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2U29ja2V0U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zb2NrZXQuc2VydmljZSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJlc291cmNlTWFuYWdlclNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9yZXNvdXJjZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItcG9zaXRpb24taGVhdC1tYXAnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cInBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lclwiICpuZ0lmPVwiaXNEYXRhQXZhaWxhYmxlXCIgKHdpbmRvdzpyZXNpemUpPVwicmVzaXppbmdIZWF0TWFwKCRldmVudClcIj5cclxuXHJcbiAgPGRpdiBjbGFzcz1cImhlYXQtbWFwLXRpdGxlXCI+XHJcbiAgICA8cD5Qb3N0aW9uIHwgTkFWIEltcGFjdCBUICsgMTwvcD5cclxuICA8L2Rpdj4gPCEtLSB0aXRsZS0tPlxyXG5cclxuICA8ZGl2IGNsYXNzPVwibGVmdC1zaWRlLXBhbmVsXCI+XHJcbiAgICA8cCBjbGFzcz1cInBhbmVsLXRpdGxlXCI+VCArIDEgVmlldzwvcD5cclxuICAgIDxkaXYgIGNsYXNzPVwiZGF0ZS1kZXRhaWxzXCI+XHJcbiAgICAgIDxwIGNsYXNzPVwiZGF5XCI+e3tkYXRlTm93IHwgZGF0ZSA6ICdkZCd9fTwvcD5cclxuICAgICAgPGRpdiBjbGFzcz1cImRhdGUtaXRlbXNcIj5cclxuICAgICAgICA8cD57e2RhdGVOb3cgfCBkYXRlIDogJ0VFRUUnfX08L3A+XHJcbiAgICAgICAgPHA+e3tkYXRlTm93IHwgZGF0ZSA6ICdMTExMJ319PC9wPlxyXG4gICAgICAgIDxwPnt7ZGF0ZU5vdyB8IGRhdGUgOiAneXl5eSd9fTwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgIDwvZGl2PlxyXG4gICA8dWw+XHJcbiAgICAgPGxpXHJcbiAgICAgKm5nRm9yPVwibGV0IGl0ZW0gb2YgdG9wRml2ZVJlc3VsdHM7IGxldCBpID0gaW5kZXg7XCJcclxuICAgICA+XHJcbiAgICAgPHAgY2xhc3M9XCJsZWZ0LW5hbWVcIj57e2l0ZW0ubmFtZX19PC9wPlxyXG4gICAgIDxwIGNsYXNzPVwicmlnaHQtdmFsdWVcIj57e2l0ZW0udmFsdWV9fTwvcD5cclxuICAgICA8L2xpPlxyXG4gICA8L3VsPlxyXG4gICA8ZGl2IGNsYXNzPVwiYnRuLXdyYXBwZXJcIj5cclxuICAgICA8YSBjbGFzcz1cInZpZXctYWxsLWJ0blwiPlZpZXcgQWxsIFBvc2l0aW9uczwvYT5cclxuICAgPC9kaXY+XHJcbiAgPC9kaXY+IDwhLS0gbGVmdCBzaWRlIHBhbmVsLS0+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJoZWF0LW1hcC1jb250YWluZXJcIj5cclxuICAgIDxwb3NpdGlvbi1oZWF0LW1hcC1jaGFydFxyXG4gICAgW3N5bmNSZXN1bHRzXT1cInN5bmNSZXN1bHRzXCJcclxuICAgIFtoZWlnaHRdPSdoZWlnaHQnXHJcbiAgICBbd2lkdGhdPSd3aWR0aCdcclxuICAgIFttYXJnaW5dPSdtYXJnaW4nXHJcbiAgICBbdG9vbHRpcERpc2FibGVkXT1cImZhbHNlXCJcclxuICAgIFtzY2hlbWVdPVwiY29sb3JTY2hlbWVcIlxyXG4gICAgW3ZhbHVlRm9ybWF0dGluZ109XCJoZWF0TWFwVmFsdWVGb3JtYXR0aW5nXCJcclxuICAgIFtsYWJlbEZvcm1hdHRpbmddPVwiaGVhdE1hcExhYmVsRm9ybWF0dGluZ1wiXHJcbiAgICA+XHJcbiAgICA8L3Bvc2l0aW9uLWhlYXQtbWFwLWNoYXJ0PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJib3R0b21cIj5cclxuICAgIDxwPlNpemUgcmVwcmVzZW50cyBtYXJrZXQgY2FwPC9wPlxyXG4gICAgPHVsPlxyXG4gICAgICA8bGlcclxuICAgICAgKm5nRm9yPVwibGV0IGl0ZW0gb2YgaGVhdE1hcENvbG9yU2V0dGluZzsgbGV0IGk9aW5kZXg7XCJcclxuICAgICAgW3N0eWxlLmJhY2tncm91bmRdPVwiaXRlbS5jb2xvclwiXHJcbiAgICAgID57e2l0ZW0udmFsdWV9fSU8L2xpPlxyXG4gICAgPC91bD5cclxuICA8L2Rpdj5cclxuICA8L2Rpdj4gPCEtLSBoZWF0IG1hcCAtLT5cclxuXHJcbjwvZGl2PlxyXG5gLFxyXG4gIHN0eWxlczogW2AucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVye2hlaWdodDoxMDAlO2NvbG9yOiM0NjQ2NDYhaW1wb3J0YW50fS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmhlYXQtbWFwLXRpdGxle3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6MTVweDtmb250LXNpemU6MTZweH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWx7ZGlzcGxheTppbmxpbmUtYmxvY2s7Ym9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjZWVlO3RleHQtYWxpZ246Y2VudGVyO3BhZGRpbmc6MCAyMHB4O3dpZHRoOjE1JX0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgLnBhbmVsLXRpdGxle21hcmdpbjoxMHB4IDAgMDtmb250LXNpemU6MTVweDtvcGFjaXR5Oi42O3RleHQtYWxpZ246bGVmdH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgLmRhdGUtZGV0YWlscyAuZGF5e2Rpc3BsYXk6aW5saW5lLWJsb2NrO2ZvbnQtc2l6ZTo2MHB4O3BhZGRpbmc6MDttYXJnaW46MCAyMHB4IDAgMH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgLmRhdGUtZGV0YWlscyAuZGF0ZS1pdGVtc3tkaXNwbGF5OmlubGluZS1ibG9ja30ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgLmRhdGUtZGV0YWlscyAuZGF0ZS1pdGVtcyBwe21hcmdpbjowO3BhZGRpbmc6MCAwIDJweDtmb250LXNpemU6MTRweDt0ZXh0LWFsaWduOmxlZnR9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAubGVmdC1zaWRlLXBhbmVsIHVse2xpc3Qtc3R5bGUtdHlwZTpub25lO3BhZGRpbmc6MH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgdWwgbGl7bWFyZ2luOjEycHggMDtkaXNwbGF5OmJsb2NrfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCB1bCBsaSBwe2Rpc3BsYXk6aW5saW5lLWJsb2NrO21hcmdpbjowO3dpZHRoOjQ1JX0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5sZWZ0LXNpZGUtcGFuZWwgdWwgbGkgLmxlZnQtbmFtZXtmb250LXNpemU6MTZweDt0ZXh0LWFsaWduOmxlZnR9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAubGVmdC1zaWRlLXBhbmVsIHVsIGxpIC5yaWdodC12YWx1ZXtmb250LXNpemU6MTJweDtvcGFjaXR5Oi45O3RleHQtYWxpZ246cmlnaHR9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAubGVmdC1zaWRlLXBhbmVsIC5idG4td3JhcHBlcntwYWRkaW5nOjEwcHggMCAwfS5wb3NpdGlvbi1oZWF0LW1hcC1jb250YWluZXIgLmxlZnQtc2lkZS1wYW5lbCAuYnRuLXdyYXBwZXIgLnZpZXctYWxsLWJ0bntib3JkZXI6MXB4IHNvbGlkIHJnYmEoMCwwLDAsLjMpO2N1cnNvcjpwb2ludGVyO2JvcmRlci1yYWRpdXM6M3B4O3BhZGRpbmc6M3B4IDVweH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5oZWF0LW1hcC1jb250YWluZXJ7d2lkdGg6NzAlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO21hcmdpbi1sZWZ0OjI1cHh9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAuaGVhdC1tYXAtY29udGFpbmVyIC5ib3R0b217dGV4dC1hbGlnbjpyaWdodDtmb250LXNpemU6MTRweH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5oZWF0LW1hcC1jb250YWluZXIgLmJvdHRvbSBwe2Rpc3BsYXk6aW5saW5lLWZsZXg7Zm9udC1zdHlsZTppdGFsaWN9LnBvc2l0aW9uLWhlYXQtbWFwLWNvbnRhaW5lciAuaGVhdC1tYXAtY29udGFpbmVyIC5ib3R0b20gdWx7ZGlzcGxheTppbmxpbmUtZmxleH0ucG9zaXRpb24taGVhdC1tYXAtY29udGFpbmVyIC5oZWF0LW1hcC1jb250YWluZXIgLmJvdHRvbSBsaXtkaXNwbGF5OmlubGluZS1mbGV4O3BhZGRpbmc6MCAxMHB4fWBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBQb3NpdGlvbkhlYXRNYXBDb21wb25lbnQgZXh0ZW5kcyBCYXNlV2lkZ2V0Q29tcG9uZW50IHtcclxuXHJcbnByaXZhdGUgc3ViczogU3Vic2NyaXB0aW9uW107XHJcbnN5bmNSZXN1bHRzOiBhbnlbXSA9IFtdOyAvLyBpdCdzIHJlc3VsdHMsICBjaGFuZ2UgbmFtZSB0byBzeW5jUmVzdWx0c1xyXG50b3BGaXZlUmVzdWx0cyA9IFtdO1xyXG5oZWlnaHQ6IG51bWJlciA9IDI2MDtcclxud2lkdGg6IG51bWJlcjtcclxubWFyZ2luID0gWzIwLCAxMCwgMTAsIDEwXTtcclxuaXNEYXRhQXZhaWxhYmxlOiBib29sZWFuID0gZmFsc2U7XHJcbmhlYXRNYXBDb2xvclNldHRpbmc6IGFueVtdID0gaGVhdE1hcENvbG9yU2V0dGluZztcclxuZGF0ZU5vdyA9IG5ldyBEYXRlKCk7XHJcbmNvbG9yU2NoZW1lID0gaGVhdE1hcENvbG9yU2NoZW1lO1xyXG5mdW5kSW5mbzogYW55ID0gW107XHJcblxyXG4gIGNvbnN0cnVjdG9yKGNoYXJ0RWxlbWVudDogRWxlbWVudFJlZiwgXHJcbiAgICAgICAgICAgICAgICAgICAgICB6b25lOiBOZ1pvbmUsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBuYXZTb2NrZXRTZXJ2aWNlOiBOYXZTb2NrZXRTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZSBzaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZTogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIG5hdlNlcnZpY2U6IE5hdlNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcml2YXRlIHJlc291cmNlTWFuZ2VyOiBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlKSB7IFxyXG4gICAgc3VwZXIoKTtcclxuICAgIHRoaXMud2lkdGggPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdtYWluJylbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggKiAwLjc7XHJcbiAgIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLnN5bmNSZXN1bHRzID0gW107XHJcbiAgICB0aGlzLnRvcEZpdmVSZXN1bHRzID0gW107XHJcbiAgICB0aGlzLnN1YnMgPSBbXTtcclxuICAgIHRoaXMuaXNEYXRhQXZhaWxhYmxlID0gZmFsc2U7XHJcblxyXG4gICAgdGhpcy5mdW5kSW5mbyA9IHRoaXMuc2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UuZnVuZEluZm87XHJcbiAgICBpZih0aGlzLmZ1bmRJbmZvLmxlbmd0aCA+IDApIHtcclxuICAgICAgdGhpcy5yZW5kZXJQb3NpdGlvbk1hcCgpO1xyXG4gICAgfWVsc2V7XHJcbiAgICAgIHRoaXMubmF2U2VydmljZS5mZXRjaEZ1bmRMaXN0KCk7XHJcbiAgICAgIHRoaXMubmF2U2VydmljZS5nZXRGdW5kTGlzdCgpLnN1YnNjcmliZShcclxuICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YVwiKTtcclxuICAgICAgICAgICBpZihkYXRhLmxlbmd0aD4wKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG4gICAgICAgICAgICAgY29uc3QgZnVuZEluZm8gPSBbXTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRpZCk7XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5uYW1lKTtcclxuICAgICAgICAgICAgZnVuZEluZm8ucHVzaChkYXRhWzBdLmZ1bmRUaWNrZXIpXHJcbiAgICAgICAgICAgIHRoaXMuc2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2Uuc2F2ZVBvc2l0aW9uRGV0YWlsc0Z1bmRJbmZvKGZ1bmRJbmZvKTtcclxuICAgICAgICAgICAgdGhpcy5yZW5kZXJQb3NpdGlvbk1hcCgpO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICByZW5kZXJQb3NpdGlvbk1hcCgpe1xyXG4gICAgdGhpcy5mdW5kSW5mbyA9IHRoaXMuc2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UuZnVuZEluZm87XHJcbiAgICBpZih0aGlzLmZ1bmRJbmZvLmxlbmd0aCA+IDApIHtcclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U2VydmljZS5nZXRQb3NpdGlvbkRldGFpbHModGhpcy5mdW5kSW5mb1swXSkuc3Vic2NyaWJlKFxyXG4gICAgICBkYXRhID0+IHtcclxuICAgICAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5zeW5jUmVzdWx0cyA9IHRoaXMuZmlsdGVySG9sZGluZ3NUb0hlYXRNYXAoZGF0YVsnaG9sZGluZ3MnXSk7XHJcbiAgICAgICAgdGhpcy50b3BGaXZlUmVzdWx0cyA9IHRoaXMuZmlsdGVySG9sZGluZ3NUb1RvcEZpdmUoZGF0YVsnaG9sZGluZ3MnXSk7XHJcbiAgICAgIH1cclxuICAgICkpXHJcbiAgICB0aGlzLnN1YnMucHVzaCh0aGlzLm5hdlNvY2tldFNlcnZpY2UuZ2V0TmF2KCkuc3Vic2NyaWJlKFxyXG4gICAgICBkYXRhID0+IHtcclxuICAgICAgICB0aGlzLnVwZGF0ZUhlYXRNYXAoZGF0YS5ldmVudERhdGEpO1xyXG4gICAgICB9KSk7XHJcbiAgICBcclxuICAgICB0aGlzLm5hdlNvY2tldFNlcnZpY2UucmVnaXN0ZXJGdW5kcyhbdGhpcy5mdW5kSW5mb1swXV0pO1xyXG5cclxuICAgICB0aGlzLnJlc291cmNlTWFuZ2VyLnJlZ2lzdEludGVydmFsKCgpID0+IHsgdGhpcy5zeW5jUmVzdWx0cyA9IFsuLi50aGlzLnN5bmNSZXN1bHRzXX0sNDAwKTsgLy8gc2V0IGludGVydmFsIHRpbWUgZm9yIDAuNCBzZWNvbmRzIHRlbXBvcmFyaWx5XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZmlsdGVySG9sZGluZ3NUb0hlYXRNYXAoZGF0YSl7XHJcbiAgICBjb25zdCB0ZW1wUmVzdWx0cyA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgXCJuYW1lXCI6IGl0ZW0uY3VzaXAsXHJcbiAgICAgICAgXCJ2YWx1ZVwiOiBNYXRoLmFicyhpdGVtLm5hdkltcGFjdCksXHJcbiAgICAgICAgXCJuYXZJbXBhY3RcIjogaXRlbS5uYXZJbXBhY3RcclxuICAgICAgfTtcclxuICAgICAgdGVtcFJlc3VsdHMucHVzaChvYmopO1xyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wUmVzdWx0cztcclxuICB9XHJcblxyXG4gIGZpbHRlckhvbGRpbmdzVG9Ub3BGaXZlKGRhdGEpIHtcclxuICAgIGNvbnN0IHRlbXBUb3BGaXZlID0gW107XHJcbiAgICBkYXRhLnNvcnQoKGl0ZW1hLCBpdGVtYikgPT4ge1xyXG4gICAgICByZXR1cm4gaXRlbWIubmF2SW1wYWN0ICAtIGl0ZW1hLm5hdkltcGFjdDtcclxuICAgICAgLy8gcmV0dXJuIE1hdGguYWJzKGl0ZW1iLm5hdkltcGFjdCkgIC0gTWF0aC5hYnMoaXRlbWEubmF2SW1wYWN0KTsgVEJDLi4uICBpZiB3ZSBzb3J0IGl0IHVzaW5nIHJlYWwgdmFsdWUgbm90IGFic29sdXRlIHZhbHVlLCB3aWxsIG1ha2UgY29uZnVzaW9uIGJldHdlZW4gdG9wIGZpdmUgcmVjb3JkcyBhbmQgaGVhdCBtYXAgY2hhcnQuXHJcbiAgICB9KTtcclxuICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKHRlbXBUb3BGaXZlLmxlbmd0aCA8IDUpIHtcclxuICAgICAgICBsZXQgb2JqID0ge1xyXG4gICAgICAgICAgXCJuYW1lXCI6IGl0ZW0uY3VzaXAgPyBpdGVtLmN1c2lwIDogaXRlbS5uYW1lLFxyXG4gICAgICAgICAgXCJ2YWx1ZVwiOiBmb3JtYXROdW1iZXIoaXRlbS5uYXZJbXBhY3QsICdlbi1VUycsICcxLjUtNScpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRlbXBUb3BGaXZlLnB1c2gob2JqKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wVG9wRml2ZTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZUhlYXRNYXAoZGF0YSl7XHJcbiAgICBpZiAoZGF0YSAmJiB0aGlzLmNvbW1vblV0aWxzLmlzVmFsaWRUaW1lKG5ldyBEYXRlKGRhdGFbJ3ByaWNldGltZSddKSkpIHtcclxuICAgICAgdGhpcy5zeW5jUmVzdWx0cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLm5hbWUgPT09IGRhdGEuY3VzaXApIHtcclxuICAgICAgICAgIGl0ZW0udmFsdWUgPSBNYXRoLmFicyhkYXRhLm5hdkltcGFjdCk7XHJcbiAgICAgICAgICBpdGVtLm5hdkltcGFjdCA9IGRhdGEubmF2SW1wYWN0XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJlc2l6aW5nSGVhdE1hcChldmVudCkge1xyXG4gICAgdGhpcy53aWR0aCA9IGV2ZW50LnRhcmdldC5pbm5lcldpZHRoICogMC43O1xyXG4gIH1cclxuXHJcbiAgLy8gbmVlZHMgbW9yZSBhbmFseXplIGhlcmVcclxuICBoZWF0TWFwVmFsdWVGb3JtYXR0aW5nKHZhbHVlKSB7XHJcbiAgICAvLyBjb25zdCBmb3JtYXRWYWx1ZSA9ICBmb3JtYXROdW1iZXIodmFsdWUsICdlbi1VUycsICcxLjUtNScpO1xyXG4gICAgLy8gcmV0dXJuIGZvcm1hdFZhbHVlO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgaGVhdE1hcExhYmVsRm9ybWF0dGluZyhvYmope1xyXG4gICAgY29uc3QgZm9ybWF0VmFsdWUgPSAgZm9ybWF0TnVtYmVyKG9iai52YWx1ZSwgJ2VuLVVTJywgJzEuNS01Jyk7XHJcbiAgICByZXR1cm4gYCR7b2JqLmxhYmVsfTxici8+PHNtYWxsPmAgKyBgJHtmb3JtYXRWYWx1ZX08L3NtYWxsPmA7XHJcbiAgICAvLyByZXR1cm4gYCR7b2JqLmxhYmVsfTxici8+PHNtYWxsPkluc3RydW1lbnQgSWQgUmVmPC9zbWFsbD5gO1xyXG4gIH1cclxuXHJcbiAgIG5nT25EZXN0cm95KCkge1xyXG4gICAgaWYgKHRoaXMuZnVuZEluZm8ubGVuZ3RoID4gMCkge1xyXG4gICAgICB0aGlzLm5hdlNvY2tldFNlcnZpY2UudW5SZWdpc3RlckZ1bmRzKFt0aGlzLmZ1bmRJbmZvWzBdXSk7XHJcbiAgICAgIHRoaXMuc3Vicy5mb3JFYWNoIChzdWIgPT4gc3ViLnVuc3Vic2NyaWJlKCkpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5yZXNvdXJjZU1hbmdlci5jbGVhblJlc291cmNlcygpO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICBDb250ZW50Q2hpbGQsXHJcbiAgVGVtcGxhdGVSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IHRyZWVtYXAsIHN0cmF0aWZ5IH0gZnJvbSAnZDMtaGllcmFyY2h5JztcclxuaW1wb3J0IHsgY2FsY3VsYXRlVmlld0RpbWVuc2lvbnMsIFZpZXdEaW1lbnNpb25zLCBCYXNlQ2hhcnRDb21wb25lbnQsIENvbG9ySGVscGVyIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdwb3NpdGlvbi1oZWF0LW1hcC1jaGFydCcsXHJcbiAgdGVtcGxhdGU6IGA8bmd4LWNoYXJ0cy1jaGFydFxyXG4gICAgICBbdmlld109XCJbd2lkdGgsIGhlaWdodF1cIlxyXG4gICAgICBbc2hvd0xlZ2VuZF09XCJmYWxzZVwiXHJcbiAgICAgIFthbmltYXRpb25zXT1cImFuaW1hdGlvbnNcIj5cclxuICAgICAgPHN2ZzpnIFthdHRyLnRyYW5zZm9ybV09XCJ0cmFuc2Zvcm1cIiBjbGFzcz1cInRyZWUtbWFwIGNoYXJ0XCI+XHJcbiAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtdHJlZS1tYXAtY2VsbC1zZXJpZXNcclxuICAgICAgICAgIFtjb2xvcnNdPVwiY29sb3JzXCJcclxuICAgICAgICAgIFtkYXRhXT1cImRhdGFcIlxyXG4gICAgICAgICAgW2RpbXNdPVwiZGltc1wiXHJcbiAgICAgICAgICBbdG9vbHRpcERpc2FibGVkXT1cInRvb2x0aXBEaXNhYmxlZFwiXHJcbiAgICAgICAgICBbdG9vbHRpcFRlbXBsYXRlXT1cInRvb2x0aXBUZW1wbGF0ZVwiXHJcbiAgICAgICAgICBbdmFsdWVGb3JtYXR0aW5nXT1cInZhbHVlRm9ybWF0dGluZ1wiXHJcbiAgICAgICAgICBbbGFiZWxGb3JtYXR0aW5nXT1cImxhYmVsRm9ybWF0dGluZ1wiXHJcbiAgICAgICAgICBbZ3JhZGllbnRdPVwiZ3JhZGllbnRcIlxyXG4gICAgICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiXHJcbiAgICAgICAgICAoc2VsZWN0KT1cIm9uQ2xpY2soJGV2ZW50KVwiXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9zdmc6Zz5cclxuICAgIDwvbmd4LWNoYXJ0cy1jaGFydD5gLFxyXG4gIHN0eWxlczogW2AudHJlZS1tYXAgLnRyZWVtYXAtdmFse2ZvbnQtc2l6ZToxLjNlbTtwYWRkaW5nLXRvcDo1cHg7ZGlzcGxheTppbmxpbmUtYmxvY2t9LnRyZWUtbWFwIC5sYWJlbCBwe2Rpc3BsYXk6dGFibGUtY2VsbDt0ZXh0LWFsaWduOmNlbnRlcjtsaW5lLWhlaWdodDoxLjJlbTt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9YF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaFxyXG59KVxyXG5leHBvcnQgY2xhc3MgSGVhdE1hcENvbXBvbmVudCBleHRlbmRzIEJhc2VDaGFydENvbXBvbmVudCB7XHJcblxyXG4gIEBJbnB1dCgpIHN5bmNSZXN1bHRzO1xyXG4gIEBJbnB1dCgpIHRvb2x0aXBEaXNhYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBJbnB1dCgpIHZhbHVlRm9ybWF0dGluZzogYW55O1xyXG4gIEBJbnB1dCgpIGxhYmVsRm9ybWF0dGluZzogYW55O1xyXG4gIEBJbnB1dCgpIGdyYWRpZW50OiBib29sZWFuID0gZmFsc2U7XHJcbiAgQElucHV0KCkgaGVpZ2h0OiBudW1iZXI7XHJcbiAgQElucHV0KCkgd2lkdGg6IG51bWJlcjtcclxuICBASW5wdXQoKSBzY2hlbWU6IGFueSA9IHt9O1xyXG4gIEBJbnB1dCgpIG1hcmdpbjogYW55W107XHJcbiAgQElucHV0KCkgYW5pbWF0aW9uczogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gIEBPdXRwdXQoKSBzZWxlY3QgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gIEBDb250ZW50Q2hpbGQoJ3Rvb2x0aXBUZW1wbGF0ZScpIHRvb2x0aXBUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcclxuXHJcbiAgZGltczogYW55O1xyXG4gIGRvbWFpbjogYW55O1xyXG4gIHRyYW5zZm9ybTogYW55O1xyXG4gIGNvbG9yczogQ29sb3JIZWxwZXI7XHJcbiAgdHJlZW1hcDogYW55O1xyXG4gIGRhdGE6IGFueTtcclxuICBjdXN0b21Db2xvcnM6IGFueTtcclxuICBcclxuXHJcbiAgdXBkYXRlKCk6IHZvaWQge1xyXG4gICAgc3VwZXIudXBkYXRlKCk7XHJcblxyXG4gICAgdGhpcy5kaW1zID0gY2FsY3VsYXRlVmlld0RpbWVuc2lvbnMoe1xyXG4gICAgICB3aWR0aDogdGhpcy53aWR0aCxcclxuICAgICAgaGVpZ2h0OiAyNjAsXHJcbiAgICAgIG1hcmdpbnM6IHRoaXMubWFyZ2luXHJcbiAgICB9KTtcclxuICAgIHRoaXMuaGVpZ2h0ID0gMjYwO1xyXG5cclxuICAgIHRoaXMuZG9tYWluID0gdGhpcy5nZXREb21haW4oKTtcclxuXHJcbiAgICB0aGlzLnRyZWVtYXAgPSB0cmVlbWFwPGFueT4oKVxyXG4gICAgICAuc2l6ZShbdGhpcy5kaW1zLndpZHRoLCB0aGlzLmRpbXMuaGVpZ2h0XSk7XHJcblxyXG4gICAgY29uc3Qgcm9vdE5vZGUgPSB7XHJcbiAgICAgIG5hbWU6ICdyb290JyxcclxuICAgICAgdmFsdWU6IDAsXHJcbiAgICAgIGlzUm9vdDogdHJ1ZVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByb290ID0gc3RyYXRpZnk8YW55PigpXHJcbiAgICAgIC5pZChkID0+IHtcclxuICAgICAgICBsZXQgbGFiZWwgPSBkLm5hbWU7XHJcblxyXG4gICAgICAgIGlmIChsYWJlbC5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgIGxhYmVsID0gbGFiZWwudG9Mb2NhbGVEYXRlU3RyaW5nKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGxhYmVsID0gbGFiZWwudG9Mb2NhbGVTdHJpbmcoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGxhYmVsO1xyXG4gICAgICB9KVxyXG4gICAgICAucGFyZW50SWQoZCA9PiBkLmlzUm9vdCA/IG51bGwgOiAncm9vdCcpXHJcbiAgICAgIChbcm9vdE5vZGUsIC4uLnRoaXMuc3luY1Jlc3VsdHNdKVxyXG4gICAgICAuc3VtKGQgPT4gZC52YWx1ZSk7XHJcblxyXG4gICAgdGhpcy5kYXRhID0gdGhpcy50cmVlbWFwKHJvb3QpO1xyXG5cclxuICAgIHRoaXMuY3VzdG9tQ29sb3JzID0gdGhpcy5zZXRDdXN0b21Db2xvcnMoKTtcclxuXHJcbiAgICB0aGlzLnNldENvbG9ycygpO1xyXG5cclxuICAgIHRoaXMudHJhbnNmb3JtID0gYHRyYW5zbGF0ZSgkeyB0aGlzLmRpbXMueE9mZnNldCB9ICwgJHsgdGhpcy5tYXJnaW5bMF0gfSlgO1xyXG4gIH1cclxuXHJcbiAgc2V0Q3VzdG9tQ29sb3JzKCk6IGFueVtdIHtcclxuICAgIGNvbnN0IGFyciA9IFtdO1xyXG4gICAgdGhpcy5zeW5jUmVzdWx0cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBsZXQgY29sb3I6IHN0cmluZyA9ICcnO1xyXG4gICAgICBpZiAoaXRlbS5uYXZJbXBhY3QgPD0gLTMpIHsgLy8gLTNcclxuICAgICAgICBjb2xvciA9ICcjQjkxMjI0JztcclxuICAgICAgfSBlbHNlIGlmIChpdGVtLm5hdkltcGFjdCA+IC0zICYmIGl0ZW0ubmF2SW1wYWN0IDw9IC0yKSB7IC8vIC0yXHJcbiAgICAgICAgY29sb3IgPSAnI0VBQjdCRCc7XHJcbiAgICAgIH0gZWxzZSBpZiAoaXRlbS5uYXZJbXBhY3QgPiAtMiAmJiBpdGVtLm5hdkltcGFjdCA8PSAwKSB7IC8vIC0xXHJcbiAgICAgICAgY29sb3IgPSAnI0Y1RENERSc7XHJcbiAgICAgIH0gZWxzZSBpZiAoaXRlbS5uYXZJbXBhY3QgPj0gMCAmJiBpdGVtLm5hdkltcGFjdCA8IDIpIHsvLyAxXHJcbiAgICAgICAgY29sb3IgPSAnI0RGRUFFMic7XHJcbiAgICAgIH0gZWxzZSBpZiAoaXRlbS5uYXZJbXBhY3QgPj0gMiAmJiBpdGVtLm5hdkltcGFjdCA8IDMpIHsvLyAyXHJcbiAgICAgICAgY29sb3IgPSAnI0JFRDVDNSc7XHJcbiAgICAgIH0gZWxzZSBpZiAoaXRlbS5uYXZJbXBhY3QgPj0gMykgeyAvLzNcclxuICAgICAgICBjb2xvciA9ICcjMjg3NDNFJztcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb2xvciA9ICcnO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgICAgIHZhbHVlOiBjb2xvclxyXG4gICAgICB9XHJcbiAgICAgIGFyci5wdXNoKG9iaik7XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIGFycjtcclxuICB9XHJcblxyXG4gIGdldERvbWFpbigpOiBhbnlbXSB7XHJcbiAgICByZXR1cm4gdGhpcy5zeW5jUmVzdWx0cy5tYXAoZCA9PiBkLm5hbWUpO1xyXG4gIH1cclxuXHJcbiAgb25DbGljayhkYXRhKTogdm9pZCB7XHJcbiAgICB0aGlzLnNlbGVjdC5lbWl0KGRhdGEpO1xyXG4gIH1cclxuXHJcbiAgc2V0Q29sb3JzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5jb2xvcnMgPSBuZXcgQ29sb3JIZWxwZXIodGhpcy5zY2hlbWUsICdvcmRpbmFsJywgdGhpcy5kb21haW4sIHRoaXMuY3VzdG9tQ29sb3JzKTtcclxuICB9XHJcblxyXG59XHJcbiIsImV4cG9ydCBjb25zdCBzaW5nbGVMaW5lVGlja3NWYWx1ZSA9IFtcclxuICAgIG5ldyBEYXRlKCkuc2V0SG91cnMoOSwgMzAsIDApLCBcclxuICAgIG5ldyBEYXRlKCkuc2V0SG91cnMoMTIsIDAsIDApLFxyXG4gICAgbmV3IERhdGUoKS5zZXRIb3VycygxNCwgMCwgMCksXHJcbiAgICBuZXcgRGF0ZSgpLnNldEhvdXJzKDE2LCAwLCAwKVxyXG4gICAgXTtcclxuICAgICIsImltcG9ydCB7XHJcbiAgRWxlbWVudFJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBDb21wb25lbnQsXHJcbiAgSW5wdXQsXHJcbiAgT3V0cHV0LFxyXG4gIEV2ZW50RW1pdHRlcixcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBIb3N0TGlzdGVuZXIsXHJcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgQ29udGVudENoaWxkLFxyXG4gIFRlbXBsYXRlUmVmLFxyXG4gIFZpZXdDb250YWluZXJSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQmFzZVdpZGdldENvbXBvbmVudCB9IGZyb20gJ0BvbW5pYS91aS1jb21tb24nO1xyXG5pbXBvcnQgeyBmb3JtYXREYXRlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgc2luZ2xlTGluZVRpY2tzVmFsdWUgfSBmcm9tICcuL3Bvc2l0aW9uLXN1bW1hcnktZGF0YSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2U2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL25hdi1zZXJ2aWNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTaGFyZUluZm9CZXdlZW5Db21wb25lbnRzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3NoYXJlLWluZm8tYmV3ZWVuLWNvbXBvbmVudHMuc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1wb3NpdGlvbi1mdW5kLXN1bW1hcnknLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiBjbGFzcz1cInBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXJcIiAod2luZG93OnJlc2l6ZSk9XCJyZXNpemluZ1NpbmdsZUxpbmVDaGFydCgkZXZlbnQpXCI+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJmdW5kLXN1bW1hcnktdGl0bGVcIj5cclxuICAgIDxwPkZ1bmQgU3VtbWFyeSB8IHt7ZGF0ZU5vdyB8IGRhdGUgOiAnbG9uZ0RhdGUnfX08L3A+XHJcbiAgPC9kaXY+IDwhLS0gdGl0bGUtLT5cclxuXHJcbiAgPGRpdiBjbGFzcz1cIm1haW4tYm9keS13cmFwcGVyXCI+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cInRvcC1zZWFyY2hcIj5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJTZWFyY2ggTXV0dWFsIEZ1bmQgTmFtZVwiLz5cclxuICAgICAgPG1hdC1pY29uIHN2Z0ljb249XCJzZWFyY2hcIiA+PC9tYXQtaWNvbj5cclxuICAgIDwvZGl2PiA8IS0tSWYgbmVlZCB1c2UgYW5ndWxhciBzZWFyY2ggY29tcG9uZW50ID8tLT5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibGVmdC1zaWRlLXBhbmVsLXdyYXBwZXJcIj5cclxuICAgICAgPGRpdiBjbGFzcz1cImxlZnQtc2lkZS1wYW5lbFwiXHJcbiAgICAgICpuZ0Zvcj1cImxldCBpdGVtIG9mIHN1bW1hcnlBc3NldHNWYWx1ZTsgbGV0IGkgPSBpbmRleDtcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHA+e3tpdGVtLnZhbHVlIHwgY3VycmVuY3kgOiAnVVNEJzogJycgOiAnNS4wLTAnfX08L3A+XHJcbiAgICAgICAgPGxhYmVsPnt7aXRlbS50aXRsZX19PC9sYWJlbD5cclxuICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICA8ZGl2IGNsYXNzPVwic2luZ2xlLWxpbmUtY2hhcnRcIj5cclxuXHJcbiAgICAgPGRpdiBjbGFzcz1cImZsb2F0aW5nLXJlY3Qtd3JhcHBlclwiPlxyXG4gICAgICAgPGRpdiBjbGFzcz1cInRvcC1sZWZ0LWluZm9cIj5cclxuICAgICAgICAgPHAgY2xhc3M9XCJ0b3AtbGVmdC1pbmZvLXZcIj41MDAsMDAwPC9wPlxyXG4gICAgICAgICA8bGFiZWw+U2hhcmVzIE91dHN0YW5kaW5nPC9sYWJlbD5cclxuICAgICAgIDwvZGl2PlxyXG4gICAgICAgPGRpdiBjbGFzcz1cInRvcC1yaWdodHQtaW5mb1wiPlxyXG4gICAgICAgICA8bGFiZWw+TWFya2V0IFZhbHVlIENoYW5nZTogVG9kYXk8L2xhYmVsPlxyXG4gICAgICAgICA8cCBjbGFzcz1cInRvcC1yaWdodHQtaW5mby12XCI+KzEwMCwwMDA8L3A+XHJcbiAgICAgICAgIDxwIGNsYXNzPVwidG9wLXJpZ2h0dC1pbmZvLXZcIj4rMC4wMyU8L3A+XHJcbiAgICAgICA8L2Rpdj5cclxuICAgICAgIDxkaXYgY2xhc3M9XCJtaWRkbGUtaW5mb1wiPlxyXG4gICAgICAgICA0LDQwMCwwMDBcclxuICAgICAgIDwvZGl2PlxyXG4gICAgICAgPGRpdiBjbGFzcz1cImJvdHRvbS1pbmZvXCI+XHJcbiAgICAgICAgIDQsMzAwLDAwMFxyXG4gICAgICAgPC9kaXY+XHJcbiAgICAgPC9kaXY+XHJcblxyXG4gICAgPGxpYi1zaW5nbGUtbGluZS1jaGFydFxyXG4gICAgICBbcmVzdWx0c109J3Jlc3VsdHMnXHJcbiAgICAgIFtoZWlnaHRdPSdoZWlnaHQnXHJcbiAgICAgIFt3aWR0aF09J3dpZHRoJ1xyXG4gICAgICBbbWFyZ2luXT0nbWFyZ2luJ1xyXG4gICAgICBbY29sb3JEb21haW5dPSdjb2xvckRvbWFpbidcclxuICAgICAgW3RpY2tWYWx1ZXNdPSd0aWNrVmFsdWVzJ1xyXG4gICAgICBbeEF4aXNUaWNrRm9ybWF0dGluZ109J3hBeGlzVGlja0Zvcm1hdHRpbmcnXHJcbiAgICAgIFt4U2NhbGVNaW5dPSd4U2NhbGVNaW4nXHJcbiAgICAgIFt4U2NhbGVNYXhdPSd4U2NhbGVNYXgnXHJcbiAgICAgID5cclxuICAgIDwvbGliLXNpbmdsZS1saW5lLWNoYXJ0PlxyXG4gICA8L2Rpdj5cclxuXHJcbiAgIDxkaXYgY2xhc3M9XCJyaWdodC1zaWRlLWdyaWQtd3JhcHBlclwiPlxyXG4gICAgIDxoND5Zb3VyIFRocmVlIERheSBUcmVuZDwvaDQ+XHJcbiAgICAgICA8ZGl2XHJcbiAgICAgICAqbmdGb3I9XCJsZXQgb25lRGF5RGF0YSBvZiB0aHJlZURheVRyZW5kRGF0YTsgbGV0IGkgPSBpbmRleDtcIlxyXG4gICAgICAgW3N0eWxlLmJhY2tncm91bmRdPVwib25lRGF5RGF0YS5jb2xvclwiXHJcbiAgICAgICBjbGFzcz1cInRocmVlLWRheS1kYXRhLWRldGFpbHMtaXRlbVwiXHJcbiAgICAgICA+XHJcbiAgICAgICAgIDxsYWJlbCBjbGFzcz1cImRldGFpbC1pdGVtLWRhdGVcIj57e29uZURheURhdGEuZGF5IHwgZGF0ZSA6ICdsb25nRGF0ZSd9fTwvbGFiZWw+XHJcbiAgICAgICAgIDx1bD5cclxuICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAqbmdGb3I9XCJsZXQgaXRlbSBvZiBvbmVEYXlEYXRhLmRldGFpbHM7XCJcclxuICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgW3N0eWxlLmNvbG9yXT1cImdldFZhbHVlU3R5KGl0ZW0udmFsdWUpXCJcclxuICAgICAgICAgICAgID57e2l0ZW0udmFsdWV9fTwvcD5cclxuICAgICAgICAgICAgIDxsYWJlbD57e2l0ZW0udGl0bGV9fTwvbGFiZWw+XHJcbiAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgPC91bD5cclxuICAgICAgIDwvZGl2PlxyXG4gICAgIDwvZGl2PlxyXG5cclxuICA8L2Rpdj48IS0tIG1haW4tLT5cclxuPC9kaXY+YCxcclxuICBzdHlsZXM6IFtgLnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXJ7Zm9udC1mYW1pbHk6RElOTmV4dExUUHJvLU1lZGl1bTtjb2xvcjojNDY0NjQ2fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5mdW5kLXN1bW1hcnktdGl0bGV7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDoxNXB4O2ZvbnQtc2l6ZToxNnB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAudG9wLXNlYXJjaHtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6NjBweDtsZWZ0OjIwcHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC50b3Atc2VhcmNoIGlucHV0e3dpZHRoOjE2MHB4O3BhZGRpbmc6OHB4IDIwcHg7ZGlzcGxheTppbmxpbmUtYmxvY2t9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC50b3Atc2VhcmNoIG1hdC1pY29ue3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6MjAwcHg7YmFja2dyb3VuZC1jb2xvcjojODZiYmQxO3BhZGRpbmc6NXB4IDVweCA2cHggOHB4O2N1cnNvcjpwb2ludGVyfS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAubGVmdC1zaWRlLXBhbmVsLXdyYXBwZXJ7ZGlzcGxheTppbmxpbmUtYmxvY2s7bWFyZ2luLWxlZnQ6MjBweDtwYWRkaW5nLXRvcDo0MHB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAubGVmdC1zaWRlLXBhbmVsLXdyYXBwZXIgLmxlZnQtc2lkZS1wYW5lbCBwe2ZvbnQtc2l6ZTo0MHB4O21hcmdpbjoxMHB4IDA7cGFkZGluZzowfS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAubGVmdC1zaWRlLXBhbmVsLXdyYXBwZXIgLmxlZnQtc2lkZS1wYW5lbCBsYWJlbHtmb250LXNpemU6MTRweDttYXJnaW46MDtwYWRkaW5nOjB9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5zaW5nbGUtbGluZS1jaGFydHtkaXNwbGF5OmlubGluZS1ibG9jaztoZWlnaHQ6MjUwcHg7bWFyZ2luOjAgMjBweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXJ7cG9zaXRpb246cmVsYXRpdmV9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5zaW5nbGUtbGluZS1jaGFydCAuZmxvYXRpbmctcmVjdC13cmFwcGVyIGRpdntwb3NpdGlvbjphYnNvbHV0ZX0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgcHttYXJnaW46MH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgbGFiZWx7ZGlzcGxheTpibG9jaztmb250LXNpemU6MTJweDt0ZXh0LWFsaWduOnJpZ2h0fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciAudG9wLWxlZnQtaW5mb3t0b3A6LTY1cHg7cmlnaHQ6MjUwcHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5zaW5nbGUtbGluZS1jaGFydCAuZmxvYXRpbmctcmVjdC13cmFwcGVyIC50b3AtbGVmdC1pbmZvIC50b3AtbGVmdC1pbmZvLXZ7dGV4dC1hbGlnbjpyaWdodDtmb250LXNpemU6MjVweDttYXJnaW4tYm90dG9tOjZweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgLnRvcC1yaWdodHQtaW5mb3t0b3A6LTcwcHg7cmlnaHQ6MTBweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgLnRvcC1yaWdodHQtaW5mbyAudG9wLXJpZ2h0dC1pbmZvLXZ7ZGlzcGxheTppbmxpbmUtYmxvY2s7YmFja2dyb3VuZC1jb2xvcjojMjg3NDNlO2NvbG9yOiNmYWViZDc7cGFkZGluZzo1cHggMTZweDtmb250LXNpemU6MThweDttYXJnaW4tdG9wOjZweH0ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnNpbmdsZS1saW5lLWNoYXJ0IC5mbG9hdGluZy1yZWN0LXdyYXBwZXIgLm1pZGRsZS1pbmZve3RvcDoyNXB4O3JpZ2h0OjEwcHg7YmFja2dyb3VuZC1jb2xvcjojMjg3NDNlO2NvbG9yOiNmYWViZDc7Zm9udC1zaXplOjE2cHg7cGFkZGluZzoycHggMTVweCAycHggNXB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAuc2luZ2xlLWxpbmUtY2hhcnQgLmZsb2F0aW5nLXJlY3Qtd3JhcHBlciAuYm90dG9tLWluZm97dG9wOjgwcHg7cmlnaHQ6MTBweDtiYWNrZ3JvdW5kLWNvbG9yOiM3MjcyNzI7Y29sb3I6I2ZhZWJkNztmb250LXNpemU6MTZweDtwYWRkaW5nOjJweCAxNXB4IDJweCA1cHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlcntkaXNwbGF5OmlubGluZS1ibG9ja30ucG9zaXRpb24tZnVuZC1zdW1tYXJ5LWNvbnRhaW5lciAubWFpbi1ib2R5LXdyYXBwZXIgLnJpZ2h0LXNpZGUtZ3JpZC13cmFwcGVyIC50aHJlZS1kYXktZGF0YS1kZXRhaWxzLWl0ZW17cGFkZGluZzoxMHB4IDB9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlciAudGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtIC5kZXRhaWwtaXRlbS1kYXRle21hcmdpbi1sZWZ0OjEwcHh9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlciAudGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtIGxhYmVse2ZvbnQtc2l6ZToxMnB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAucmlnaHQtc2lkZS1ncmlkLXdyYXBwZXIgLnRocmVlLWRheS1kYXRhLWRldGFpbHMtaXRlbSB1bHtsaXN0LXN0eWxlLXR5cGU6bm9uZTttYXJnaW46MDtwYWRkaW5nOjB9LnBvc2l0aW9uLWZ1bmQtc3VtbWFyeS1jb250YWluZXIgLm1haW4tYm9keS13cmFwcGVyIC5yaWdodC1zaWRlLWdyaWQtd3JhcHBlciAudGhyZWUtZGF5LWRhdGEtZGV0YWlscy1pdGVtIHVsIGxpe2Rpc3BsYXk6aW5saW5lLWJsb2NrO21hcmdpbjoxMHB4fS5wb3NpdGlvbi1mdW5kLXN1bW1hcnktY29udGFpbmVyIC5tYWluLWJvZHktd3JhcHBlciAucmlnaHQtc2lkZS1ncmlkLXdyYXBwZXIgLnRocmVlLWRheS1kYXRhLWRldGFpbHMtaXRlbSB1bCBsaSBwe21hcmdpbjowfWBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBQb3NpdGlvbkZ1bmRTdW1tYXJ5Q29tcG9uZW50IGV4dGVuZHMgQmFzZVdpZGdldENvbXBvbmVudCB7XHJcblxyXG4gIGRhdGVOb3cgPSBuZXcgRGF0ZSgpO1xyXG4gIC8vIHRlbXAgbW9jayBkYXRhXHJcbiAgc3VtbWFyeUFzc2V0c1ZhbHVlID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogJ1RvdGFsIE5ldCBBc3NldHM6IFVTRCcsXHJcbiAgICAgIHZhbHVlOiA1MDAwMDAwXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogJ01hcmtldCBWYWx1ZTogVVNEJyxcclxuICAgICAgdmFsdWU6IDQ0MDAwMDBcclxuICAgIH1cclxuICBdO1xyXG4gIHRocmVlRGF5VHJlbmREYXRhOiBhbnlbXSA9IFtcclxuICAgIHtcclxuICAgICAgZGF5OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBkZXRhaWxzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgUHJpY2UnLFxyXG4gICAgICAgICAgdmFsdWU6IDkuOTFcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHRpdGxlOiAnTWFya2V0IFZhbHVlJyxcclxuICAgICAgICAgIHZhbHVlOiAnNC4zTSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHRpdGxlOiAnTkFWIENoYW5nZScsXHJcbiAgICAgICAgICB2YWx1ZTogJy0yLjA1JSdcclxuICAgICAgICB9XHJcbiAgICAgIF0sXHJcbiAgICAgIGNvbG9yOiAnJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgZGF5OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBkZXRhaWxzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgUHJpY2UnLFxyXG4gICAgICAgICAgdmFsdWU6IDEwLjExXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ01hcmtldCBWYWx1ZScsXHJcbiAgICAgICAgICB2YWx1ZTogJzQuMjVNJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgQ2hhbmdlJyxcclxuICAgICAgICAgIHZhbHVlOiAnLTEuMTklJ1xyXG4gICAgICAgIH1cclxuICAgICAgXSxcclxuICAgICAgY29sb3I6ICcjREZFQUUyJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgZGF5OiBuZXcgRGF0ZSgpLFxyXG4gICAgICBkZXRhaWxzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgUHJpY2UnLFxyXG4gICAgICAgICAgdmFsdWU6IDEwLjIzXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0aXRsZTogJ01hcmtldCBWYWx1ZScsXHJcbiAgICAgICAgICB2YWx1ZTogJzQuMDVNJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgdGl0bGU6ICdOQVYgQ2hhbmdlJyxcclxuICAgICAgICAgIHZhbHVlOiAnMS44MSUnXHJcbiAgICAgICAgfVxyXG4gICAgICBdLFxyXG4gICAgICBjb2xvcjogJyNCRUQ1QzUnXHJcbiAgICB9XHJcbiAgXTtcclxuICByZXN1bHRzOiBhbnlbXSA9IFtdO1xyXG4gIGhlaWdodDogbnVtYmVyID0gMjQwO1xyXG4gIHdpZHRoOiBudW1iZXI7XHJcbiAgbWFyZ2luOiBhbnlbXSA9IFsyMCwgMTAwLCAzMCwgNTBdO1xyXG4gIGNvbG9yRG9tYWluOiBhbnlbXSA9IFtdO1xyXG4gIHRpY2tWYWx1ZXM6IGFueVtdID0gc2luZ2xlTGluZVRpY2tzVmFsdWU7XHJcbiAgeFNjYWxlTWluOiBhbnk7XHJcbiAgeFNjYWxlTWF4OiBhbnk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgY2hhcnRFbGVtZW50OiBFbGVtZW50UmVmLCB6b25lOiBOZ1pvbmUsIFxyXG4gICAgY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgIHB1YmxpYyBjb21tb25VdGlsczogQ29tbW9uVXRpbHNTZXJ2aWNlLFxyXG4gICAgIHByaXZhdGUgbmF2U2VydmljZTogTmF2U2VydmljZSxcclxuICAgICBwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cyA6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLCkgeyBcclxuICAgIHN1cGVyKCk7XHJcbiAgICB0aGlzLndpZHRoID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnbWFpbicpWzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICogMC41NTtcclxuICAgIHRoaXMueFNjYWxlTWluID0gY29tbW9uVXRpbHMuc3RhcnRUaW1lO1xyXG4gICAgdGhpcy54U2NhbGVNYXggPSBjb21tb25VdGlscy5lbmRUaW1lO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLm5hdlNlcnZpY2UuZ2V0RnVuZExpc3QoKS5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICB0aGlzLnJlc3VsdHMgPSBbLi4udGhpcy5maWx0ZXJGdW5kRGF0YShkYXRhKV1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5jb2xvckRvbWFpbiA9IHRoaXMuc2V0Q29sb3JGb3JTZWxlY3RlZEZ1bmQoKTtcclxuICB9XHJcblxyXG4gIHNldENvbG9yRm9yU2VsZWN0ZWRGdW5kKCkge1xyXG4gICAgLy8gbmVlZCBlbmhhbmNlbWVuIGhlcmU6IGlmIHRoZSBsaW5lIGNvbG9yIHNob3VsZCBiZSBhcyBzYW1lIGFzIHByZXZpb3VzIGxpdmUtbGluZS1jaGFydD8gVGVtcG9yYXJpbHkgc2V0IHRoZSBjb2xvciAjMjg3NDNFLlxyXG4gICAgY29uc3QgY29sb3IgPSBbXTtcclxuICAgIGNvbnN0IHNlbGVjdGVkRnVuZFRpY2tlciA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmZ1bmRJbmZvWzJdO1xyXG4gICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICBmdW5kVGlja2VyOiBzZWxlY3RlZEZ1bmRUaWNrZXIsXHJcbiAgICAgIGNvbG9yOiBcIiMyODc0M0VcIlxyXG4gICAgfVxyXG4gICAgY29sb3IucHVzaChvYmopO1xyXG4gICAgcmV0dXJuIGNvbG9yO1xyXG4gIH1cclxuXHJcbi8vIGJlbG93IGZ1bmN0aW9uIGlzIGR1cGxpY2F0ZWQgd2l0aCBxbmF2LWxpbmUtY2hhcnQgbmVlZHMgZXh0cmFjdCB0byBhIGNvbW1vbiBjbGFzcy5cclxuICBmaWx0ZXJGdW5kRGF0YShkYXRhOiBhbnlbXSk6IGFueVtdIHtcclxuICAgIGNvbnN0IHJlc3VsdHM6IGFueVtdID0gW107XHJcbiAgICBjb25zdCBzZWxlY3RlZEZ1bmRUaWNrZXIgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5mdW5kSW5mb1syXTtcclxuICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW1bJ2Z1bmRUaWNrZXInXSA9PT0gc2VsZWN0ZWRGdW5kVGlja2VyKSB7XHJcbiAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgJ25hbWUnOiBpdGVtWydmdW5kVGlja2VyJ10sXHJcbiAgICAgICAgICAnZnVuZElEJzogaXRlbVsnZnVuZGlkJ10sXHJcbiAgICAgICAgICAnc2VyaWVzJzogdGhpcy5jcmVhdGVTZXJpZXMoaXRlbSlcclxuICAgICAgICB9XHJcbiAgICAgICAgcmVzdWx0cy5wdXNoKG9iaik7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gcmVzdWx0cztcclxuICB9XHJcblxyXG4gIGNyZWF0ZVNlcmllcyhkYXRhOiBhbnkpOiBhbnlbXSB7XHJcbiAgICBjb25zdCBzZXJpZXM6IGFueVtdID0gW107XHJcbiAgICBkYXRhWydwcmljZUNoYW5nZXMnXS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSkpKSB7XHJcbiAgICAgICAgY29uc3Qgb2JqID0ge1xyXG4gICAgICAgICAgJ21hcmtldHZhbCc6IGl0ZW1bJ2Z1bmRtdiddLFxyXG4gICAgICAgICAgJ25hbWUnOiBuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSksXHJcbiAgICAgICAgICAnbmF2JzogaXRlbVsnbmF2J10sXHJcbiAgICAgICAgICAndmFsdWUnOiBpdGVtWyduYXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICAncHJpY2V0aW1lJzogaXRlbVsncHJpY2V0aW1lJ11cclxuICAgICAgICB9XHJcbiAgICAgICAgc2VyaWVzLnB1c2gob2JqKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgKVxyXG4gICAgaWYgKHNlcmllcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICBjb25zdCBvYmogPSB7XHJcbiAgICAgICAgJ21hcmtldHZhbCc6IGRhdGFbJ2Z1bmRtdiddLCBcclxuICAgICAgICAnbmFtZSc6IHRoaXMueFNjYWxlTWluLFxyXG4gICAgICAgICduYXYnOiBkYXRhWyduYXYnXSxcclxuICAgICAgICAndmFsdWUnOiAwLFxyXG4gICAgICAgICdwcmljZXRpbWUnOiB0aGlzLmNvbW1vblV0aWxzLnN0YXJ0VGltZVxyXG4gICAgICB9XHJcbiAgICAgIHNlcmllcy5wdXNoKG9iaik7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc2VyaWVzO1xyXG4gIH1cclxuXHJcbiAgIHhBeGlzVGlja0Zvcm1hdHRpbmcodikge1xyXG4gICBjb25zdCB0ZW1wRGF0ZSA9IG5ldyBEYXRlKHYpO1xyXG4gICByZXR1cm4gZm9ybWF0RGF0ZSh0ZW1wRGF0ZSxcImg6bW0gYWFhYWEnbSdcIiwnZW4tVVMnKTtcclxuIH1cclxuXHJcbiBnZXRWYWx1ZVN0eSh2YWx1ZSk6IHN0cmluZyB7XHJcbiAgIGxldCBjb2xvciA9ICcnO1xyXG4gICBpZiAodmFsdWUudG9TdHJpbmcoKS5pbmRleE9mKCclJykgIT09IC0xKSB7XHJcbiAgICAgaWYgKHZhbHVlLnRvU3RyaW5nKCkuaW5kZXhPZignLScpKSB7XHJcbiAgICAgICBjb2xvciA9ICcjMjg3NDNFJ1xyXG4gICAgIH0gZWxzZSB7XHJcbiAgICAgICBjb2xvcj0nI0I5MTIyNCdcclxuICAgICB9XHJcbiAgIH1cclxuICAgcmV0dXJuIGNvbG9yO1xyXG4gfVxyXG5cclxuIG5nT25EZXN0cm95KCkge1xyXG4gICAgdGhpcy5jb2xvckRvbWFpbiA9IFtdO1xyXG4gIH1cclxuXHJcbiAgcmVzaXppbmdTaW5nbGVMaW5lQ2hhcnQoZXZlbnQpIHtcclxuICAgIHRoaXMud2lkdGggPSBldmVudC50YXJnZXQuaW5uZXJXaWR0aCAqIDAuNTU7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIEVsZW1lbnRSZWYsIE5nWm9uZSwgQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgQ29tcG9uZW50LFxyXG4gIElucHV0LFxyXG4gIE91dHB1dCxcclxuICBFdmVudEVtaXR0ZXIsXHJcbiAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgSG9zdExpc3RlbmVyLFxyXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxyXG4gIENvbnRlbnRDaGlsZCxcclxuICBUZW1wbGF0ZVJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gIHRyaWdnZXIsXHJcbiAgc3R5bGUsXHJcbiAgYW5pbWF0ZSxcclxuICB0cmFuc2l0aW9uXHJcbn0gZnJvbSAnQGFuZ3VsYXIvYW5pbWF0aW9ucyc7XHJcbmltcG9ydCB7IERhdGVQaXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgc2NhbGVMaW5lYXIsIHNjYWxlVGltZSwgc2NhbGVQb2ludCB9IGZyb20gJ2QzLXNjYWxlJztcclxuaW1wb3J0IHsgY3VydmVMaW5lYXIgfSBmcm9tICdkMy1zaGFwZSc7XHJcblxyXG5pbXBvcnQgeyBpZCB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtY2hhcnRzL3JlbGVhc2UvdXRpbHMnO1xyXG5pbXBvcnQgeyBnZXRVbmlxdWVYRG9tYWluVmFsdWVzIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMvcmVsZWFzZS9jb21tb24vZG9tYWluLmhlbHBlcic7XHJcblxyXG5pbXBvcnQgeyBjYWxjdWxhdGVWaWV3RGltZW5zaW9ucywgVmlld0RpbWVuc2lvbnMsIEJhc2VDaGFydENvbXBvbmVudCwgQ29sb3JIZWxwZXIgfSBmcm9tICdAc3dpbWxhbmUvbmd4LWNoYXJ0cyc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnbGliLXNpbmdsZS1saW5lLWNoYXJ0JyxcclxuICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9XCJjdXN0b20tY2hhcnRcIj5cclxuICA8bmd4LWNoYXJ0cy1jaGFydCBcclxuICAgICAgW3ZpZXddPVwiW3dpZHRoLCBoZWlnaHRdXCJcclxuICAgICAgW3Nob3dMZWdlbmRdPVwiZmFsc2VcIlxyXG4gICAgICBbbGVnZW5kT3B0aW9uc109XCJsZWdlbmRPcHRpb25zXCJcclxuICAgICAgW2FjdGl2ZUVudHJpZXNdPVwiYWN0aXZlRW50cmllc1wiXHJcbiAgICAgIFthbmltYXRpb25zXT1cImFuaW1hdGlvbnNcIlxyXG4gICAgICAobGVnZW5kTGFiZWxDbGljayk9XCJvbkNsaWNrKCRldmVudClcIlxyXG4gICAgICAobGVnZW5kTGFiZWxBY3RpdmF0ZSk9XCJvbkFjdGl2YXRlKCRldmVudClcIlxyXG4gICAgICAobGVnZW5kTGFiZWxEZWFjdGl2YXRlKT1cIm9uRGVhY3RpdmF0ZSgkZXZlbnQpXCI+XHJcbiAgICAgIDxzdmc6ZGVmcz5cclxuICAgICAgICA8c3ZnOmNsaXBQYXRoIFthdHRyLmlkXT1cImNsaXBQYXRoSWRcIj5cclxuICAgICAgICAgIDxzdmc6cmVjdFxyXG4gICAgICAgICAgICBbYXR0ci53aWR0aF09XCJkaW1zLndpZHRoICsgMTBcIlxyXG4gICAgICAgICAgICBbYXR0ci5oZWlnaHRdPVwiZGltcy5oZWlnaHQgKyAxMFwiXHJcbiAgICAgICAgICAgIFthdHRyLnRyYW5zZm9ybV09XCIndHJhbnNsYXRlKC01LCAtNSknXCIvPlxyXG4gICAgICAgIDwvc3ZnOmNsaXBQYXRoPlxyXG4gICAgICA8L3N2ZzpkZWZzPlxyXG4gICAgICA8c3ZnOmcgW2F0dHIudHJhbnNmb3JtXT1cInRyYW5zZm9ybVwiIGNsYXNzPVwibGluZS1jaGFydCBjaGFydFwiPlxyXG4gICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLXgtYXhpcyBcclxuICAgICAgICAgIFt4U2NhbGVdPVwieFNjYWxlXCJcclxuICAgICAgICAgIFtkaW1zXT1cImRpbXNcIlxyXG4gICAgICAgICAgW3Nob3dMYWJlbF09XCJzaG93WEF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbc2hvd0dyaWRMaW5lc109XCJzaG93R3JpZExpbmVzXCJcclxuICAgICAgICAgIFtsYWJlbFRleHRdPVwieEF4aXNMYWJlbFwiXHJcbiAgICAgICAgICBbdGlja3NdPVwidGlja1ZhbHVlc1wiXHJcbiAgICAgICAgICBbdGlja0Zvcm1hdHRpbmddPVwieEF4aXNUaWNrRm9ybWF0dGluZ1wiXHJcbiAgICAgICAgICAoZGltZW5zaW9uc0NoYW5nZWQpPVwidXBkYXRlWEF4aXNIZWlnaHQoJGV2ZW50KVwiPlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMteS1heGlzXHJcbiAgICAgICAgICBbeVNjYWxlXT1cInlTY2FsZVwiXHJcbiAgICAgICAgICBbZGltc109XCJkaW1zXCJcclxuICAgICAgICAgIFtzaG93TGFiZWxdPVwic2hvd1lBeGlzTGFiZWxcIlxyXG4gICAgICAgICAgW2xhYmVsVGV4dF09XCJ5QXhpc0xhYmVsXCJcclxuICAgICAgICAgIFtyZWZlcmVuY2VMaW5lc109XCJyZWZlcmVuY2VMaW5lc1wiXHJcbiAgICAgICAgICBbc2hvd1JlZkxpbmVzXT1cInNob3dSZWZMaW5lc1wiXHJcbiAgICAgICAgICBbc2hvd0dyaWRMaW5lc109XCJzaG93R3JpZExpbmVzXCJcclxuICAgICAgICAgIFtzaG93UmVmTGFiZWxzXT1cInNob3dSZWZMYWJlbHNcIlxyXG4gICAgICAgICAgKGRpbWVuc2lvbnNDaGFuZ2VkKT1cInVwZGF0ZVlBeGlzV2lkdGgoJGV2ZW50KVwiPlxyXG4gICAgICAgIDwvc3ZnOmc+XHJcblxyXG4gICAgICAgIDxzdmc6ZyBbYXR0ci5jbGlwLXBhdGhdPVwiY2xpcFBhdGhcIj5cclxuICAgICAgICAgIDxzdmc6ZyAqbmdGb3I9XCJsZXQgc2VyaWVzIG9mIHJlc3VsdHM7IHRyYWNrQnk6dHJhY2tCeVwiIFtAYW5pbWF0aW9uU3RhdGVdPVwiJ2FjdGl2ZSdcIj5cclxuICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtbGluZS1zZXJpZXNcclxuICAgICAgICAgICAgICBbeFNjYWxlXT1cInhTY2FsZVwiXHJcbiAgICAgICAgICAgICAgW3lTY2FsZV09XCJ5U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFtjb2xvcnNdPVwiY29sb3JzXCJcclxuICAgICAgICAgICAgICBbZGF0YV09XCJzZXJpZXNcIlxyXG4gICAgICAgICAgICAgIFthY3RpdmVFbnRyaWVzXT1cImFjdGl2ZUVudHJpZXNcIlxyXG4gICAgICAgICAgICAgIFtzY2FsZVR5cGVdPVwic2NhbGVUeXBlXCJcclxuICAgICAgICAgICAgICBbY3VydmVdPVwiY3VydmVcIlxyXG4gICAgICAgICAgICAgIFtyYW5nZUZpbGxPcGFjaXR5XT1cInJhbmdlRmlsbE9wYWNpdHlcIlxyXG4gICAgICAgICAgICAgIFtoYXNSYW5nZV09XCJoYXNSYW5nZVwiXHJcbiAgICAgICAgICAgICAgW2FuaW1hdGlvbnNdPVwiYW5pbWF0aW9uc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L3N2ZzpnPlxyXG4gICAgICAgICAgPHN2ZzpnICpuZ0lmPVwiIXRvb2x0aXBEaXNhYmxlZFwiIChtb3VzZWxlYXZlKT1cImhpZGVDaXJjbGVzKClcIj5cclxuICAgICAgICAgICAgPHN2ZzpnIG5neC1jaGFydHMtdG9vbHRpcC1hcmVhXHJcbiAgICAgICAgICAgICAgW2RpbXNdPVwiZGltc1wiXHJcbiAgICAgICAgICAgICAgW3hTZXRdPVwieFNldFwiXHJcbiAgICAgICAgICAgICAgW3hTY2FsZV09XCJ4U2NhbGVcIlxyXG4gICAgICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgICAgICBbcmVzdWx0c109XCJyZXN1bHRzXCJcclxuICAgICAgICAgICAgICBbY29sb3JzXT1cImNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgW3Rvb2x0aXBEaXNhYmxlZF09XCIhdG9vbHRpcERpc2FibGVkXCJcclxuICAgICAgICAgICAgICAoaG92ZXIpPVwidXBkYXRlSG92ZXJlZFZlcnRpY2FsKCRldmVudClcIlxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPHN2ZzpnICpuZ0Zvcj1cImxldCBzZXJpZXMgb2YgcmVzdWx0c1wiPlxyXG4gICAgICAgICAgICAgIDxzdmc6ZyBuZ3gtY2hhcnRzLWNpcmNsZS1zZXJpZXNcclxuICAgICAgICAgICAgICAgIFt4U2NhbGVdPVwieFNjYWxlXCJcclxuICAgICAgICAgICAgICAgIFt5U2NhbGVdPVwieVNjYWxlXCJcclxuICAgICAgICAgICAgICAgIFtjb2xvcnNdPVwiY29sb3JzXCJcclxuICAgICAgICAgICAgICAgIFtkYXRhXT1cInNlcmllc1wiXHJcbiAgICAgICAgICAgICAgICBbc2NhbGVUeXBlXT1cInNjYWxlVHlwZVwiXHJcbiAgICAgICAgICAgICAgICBbdmlzaWJsZVZhbHVlXT1cImhvdmVyZWRWZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgICAgICBbYWN0aXZlRW50cmllc109XCJhY3RpdmVFbnRyaWVzXCJcclxuICAgICAgICAgICAgICAgIChzZWxlY3QpPVwib25DbGljaygkZXZlbnQsIHNlcmllcylcIlxyXG4gICAgICAgICAgICAgICAgKGFjdGl2YXRlKT1cIm9uQWN0aXZhdGUoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICAoZGVhY3RpdmF0ZSk9XCJvbkRlYWN0aXZhdGUoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICBbdG9vbHRpcFRlbXBsYXRlXT1cInRvb2x0aXBUZW1wbGF0ZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgICBcclxuICAgICAgICAgIDwvc3ZnOmc+XHJcbiAgICAgICAgPC9zdmc6Zz5cclxuICAgICAgPC9zdmc6Zz5cclxuICA8L25neC1jaGFydHMtY2hhcnQ+XHJcbiAgPG5nLXRlbXBsYXRlICN0b29sdGlwVGVtcGxhdGU+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2luZ2xlLXRvb2x0aXBcIj5cclxuICAgIDwvZGl2PlxyXG4gIDwvbmctdGVtcGxhdGU+XHJcbjwvZGl2PmAsXHJcbiAgc3R5bGVzOiBbYGBdLFxyXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLlNoYWRvd0RvbSxcclxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcclxuICBhbmltYXRpb25zOiBbXHJcbiAgICB0cmlnZ2VyKCdhbmltYXRpb25TdGF0ZScsIFtcclxuICAgICAgdHJhbnNpdGlvbignOmxlYXZlJywgW1xyXG4gICAgICAgIHN0eWxlKHtcclxuICAgICAgICAgIG9wYWNpdHk6IDEsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgYW5pbWF0ZSg1MDAsIHN0eWxlKHtcclxuICAgICAgICAgIG9wYWNpdHk6IDBcclxuICAgICAgICB9KSlcclxuICAgICAgXSlcclxuICAgIF0pXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgU2luZ2xlTGluZUNoYXJ0Q29tcG9uZW50IGV4dGVuZHMgQmFzZUNoYXJ0Q29tcG9uZW50IHtcclxuICBASW5wdXQoKSBsZWdlbmQ7XHJcbiAgQElucHV0KCkgbGVnZW5kVGl0bGU6IHN0cmluZyA9ICdMZWdlbmQnO1xyXG4gIEBJbnB1dCgpIHNob3dYQXhpc0xhYmVsO1xyXG4gIEBJbnB1dCgpIHNob3dZQXhpc0xhYmVsO1xyXG4gIEBJbnB1dCgpIHhBeGlzTGFiZWw7XHJcbiAgQElucHV0KCkgeUF4aXNMYWJlbDtcclxuICBASW5wdXQoKSBhdXRvU2NhbGU7XHJcbiAgQElucHV0KCkgdGltZWxpbmU7XHJcbiAgQElucHV0KCkgZ3JhZGllbnQ6IGJvb2xlYW47XHJcbiAgQElucHV0KCkgc2hvd0dyaWRMaW5lczogYm9vbGVhbiA9IHRydWU7XHJcbiAgQElucHV0KCkgY3VydmU6IGFueSA9IGN1cnZlTGluZWFyO1xyXG4gIEBJbnB1dCgpIHNjaGVtZVR5cGU6IHN0cmluZztcclxuICBASW5wdXQoKSByYW5nZUZpbGxPcGFjaXR5OiBudW1iZXI7XHJcbiAgQElucHV0KCkgeEF4aXNUaWNrRm9ybWF0dGluZzogYW55O1xyXG4gIEBJbnB1dCgpIHlBeGlzVGlja0Zvcm1hdHRpbmc6IGFueTtcclxuICBASW5wdXQoKSB4QXhpc1RpY2tzOiBhbnlbXTtcclxuICBASW5wdXQoKSB5QXhpc1RpY2tzOiBhbnlbXTtcclxuICBASW5wdXQoKSByb3VuZERvbWFpbnM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSB0b29sdGlwRGlzYWJsZWQ6IGJvb2xlYW4gPSB0cnVlOyAvLyBpZiBuZWVkIHRvb2x0aXAgdGhlbiBzZXQgdG9vbHRpcE9ialxyXG4gIEBJbnB1dCgpIHNob3dSZWZMaW5lczogYm9vbGVhbiA9IGZhbHNlOyBcclxuICBASW5wdXQoKSByZWZlcmVuY2VMaW5lczogYW55O1xyXG4gIEBJbnB1dCgpIHNob3dSZWZMYWJlbHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSB4U2NhbGVNaW46IGFueTtcclxuICBASW5wdXQoKSB4U2NhbGVNYXg6IGFueTtcclxuICBASW5wdXQoKSB5U2NhbGVNaW46IG51bWJlcjtcclxuICBASW5wdXQoKSB5U2NhbGVNYXg6IG51bWJlcjtcclxuICBASW5wdXQoKSBzZWxlY3RhYmxlO1xyXG4gIEBJbnB1dCgpIGhlaWdodDogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIHdpZHRoOiBudW1iZXI7XHJcbiAgQElucHV0KCkgbWFyZ2luOiBudW1iZXI7XHJcbiAgQElucHV0KCkgY29sb3JEb21haW46IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgcmVzdWx0czogYW55W107XHJcbiAgQElucHV0KCkgdGlja1ZhbHVlczogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSBhY3RpdmVFbnRyaWVzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBAT3V0cHV0KCkgYWN0aXZhdGU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gIEBPdXRwdXQoKSBkZWFjdGl2YXRlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgQENvbnRlbnRDaGlsZCgndG9vbHRpcFRlbXBsYXRlJykgdG9vbHRpcFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xyXG5cclxuICBkaW1zOiBWaWV3RGltZW5zaW9ucztcclxuICB4U2V0OiBhbnk7XHJcbiAgeERvbWFpbjogYW55O1xyXG4gIHlEb21haW46IGFueTtcclxuICBzZXJpZXNEb21haW46IGFueTtcclxuICB5U2NhbGU6IGFueTtcclxuICB4U2NhbGU6IGFueTtcclxuICBjb2xvcnM6IENvbG9ySGVscGVyO1xyXG4gIHNjYWxlVHlwZTogc3RyaW5nO1xyXG4gIHRyYW5zZm9ybTogc3RyaW5nO1xyXG4gIGNsaXBQYXRoOiBzdHJpbmc7XHJcbiAgY2xpcFBhdGhJZDogc3RyaW5nO1xyXG4gIHNlcmllczogYW55O1xyXG4gIGFyZWFQYXRoOiBhbnk7XHJcbiAgaG92ZXJlZFZlcnRpY2FsOiBhbnk7IC8vIHRoZSB2YWx1ZSBvZiB0aGUgeCBheGlzIHRoYXQgaXMgaG92ZXJlZCBvdmVyXHJcbiAgeEF4aXNIZWlnaHQ6IG51bWJlciA9IDA7XHJcbiAgeUF4aXNXaWR0aDogbnVtYmVyID0gMDtcclxuICBmaWx0ZXJlZERvbWFpbjogYW55O1xyXG4gIGxlZ2VuZE9wdGlvbnM6IGFueTtcclxuICBoYXNSYW5nZTogYm9vbGVhbjsgLy8gd2hldGhlciB0aGUgbGluZSBoYXMgYSBtaW4tbWF4IHJhbmdlIGFyb3VuZCBpdFxyXG4gIHRpbWVsaW5lV2lkdGg6IGFueTtcclxuICB0aW1lbGluZUhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgdGltZWxpbmVYU2NhbGU6IGFueTtcclxuICB0aW1lbGluZVlTY2FsZTogYW55O1xyXG4gIHRpbWVsaW5lWERvbWFpbjogYW55O1xyXG4gIHRpbWVsaW5lVHJhbnNmb3JtOiBhbnk7XHJcbiAgdGltZWxpbmVQYWRkaW5nOiBudW1iZXIgPSAxMDtcclxuICBjdXN0b21Db2xvcnM6IGFueVtdO1xyXG4gIHRvb2x0aXBPYmo6IGFueSA9IHt9O1xyXG5cclxuICBjb25zdHJ1Y3RvcihjaGFydEVsZW1lbnQ6IEVsZW1lbnRSZWYsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgem9uZTogTmdab25lLCBcclxuICAgICAgICAgICAgICAgICAgICAgIGNkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGUgZGF0ZVBpcGU6IERhdGVQaXBlKSB7XHJcbiAgICBzdXBlcihjaGFydEVsZW1lbnQsIHpvbmUsIGNkKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZSgpOiB2b2lkIHtcclxuXHJcbiAgICB0aGlzLmRpbXMgPSBjYWxjdWxhdGVWaWV3RGltZW5zaW9ucyh7XHJcbiAgICAgIHdpZHRoOiB0aGlzLndpZHRoLFxyXG4gICAgICBoZWlnaHQ6IHRoaXMuaGVpZ2h0LFxyXG4gICAgICBtYXJnaW5zOiB0aGlzLm1hcmdpbixcclxuICAgICAgeEF4aXNIZWlnaHQ6IHRoaXMueEF4aXNIZWlnaHQsXHJcbiAgICAgIHlBeGlzV2lkdGg6IHRoaXMueUF4aXNXaWR0aCxcclxuICAgICAgc2hvd1hMYWJlbDogdGhpcy5zaG93WEF4aXNMYWJlbCxcclxuICAgICAgc2hvd1lMYWJlbDogdGhpcy5zaG93WUF4aXNMYWJlbCxcclxuICAgICAgc2hvd0xlZ2VuZDogdGhpcy5sZWdlbmQsXHJcbiAgICAgIGxlZ2VuZFR5cGU6IHRoaXMuc2NoZW1lVHlwZSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICh0aGlzLnRpbWVsaW5lKSB7XHJcbiAgICAgIHRoaXMuZGltcy5oZWlnaHQgLT0gKHRoaXMudGltZWxpbmVIZWlnaHQgKyB0aGlzLm1hcmdpblsyXSArIHRoaXMudGltZWxpbmVQYWRkaW5nKTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnhEb21haW4gPSB0aGlzLmdldFhEb21haW4oKTtcclxuICAgIGlmICh0aGlzLmZpbHRlcmVkRG9tYWluKSB7XHJcbiAgICAgIHRoaXMueERvbWFpbiA9IHRoaXMuZmlsdGVyZWREb21haW47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy55RG9tYWluID0gdGhpcy5nZXRZRG9tYWluKCk7XHJcbiAgICB0aGlzLnNlcmllc0RvbWFpbiA9IHRoaXMuZ2V0U2VyaWVzRG9tYWluKCk7XHJcblxyXG4gICAgdGhpcy54U2NhbGUgPSB0aGlzLmdldFhTY2FsZSh0aGlzLnhEb21haW4sIHRoaXMuZGltcy53aWR0aCk7XHJcblxyXG4gICAgdGhpcy55U2NhbGUgPSB0aGlzLmdldFlTY2FsZSh0aGlzLnlEb21haW4sIHRoaXMuZGltcy5oZWlnaHQpO1xyXG5cclxuICAgIHRoaXMuY3VzdG9tQ29sb3JzID0gdGhpcy5zZXRDdXN0b21jb2xvcnMoKTtcclxuICAgIHRoaXMuc2V0Q29sb3JzKCk7XHJcbiAgICB0aGlzLmxlZ2VuZE9wdGlvbnMgPSB0aGlzLmdldExlZ2VuZE9wdGlvbnMoKTtcclxuXHJcbiAgICB0aGlzLnRyYW5zZm9ybSA9IGB0cmFuc2xhdGUoJHt0aGlzLmRpbXMueE9mZnNldH0gLCAke3RoaXMubWFyZ2luWzBdfSlgO1xyXG5cclxuICAgIHRoaXMuY2xpcFBhdGhJZCA9ICdjbGlwJyArIGlkKCkudG9TdHJpbmcoKTtcclxuICAgIHRoaXMuY2xpcFBhdGggPSBgdXJsKCMke3RoaXMuY2xpcFBhdGhJZH0pYDtcclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgc2V0Q3VzdG9tY29sb3JzKCk6IGFueVtdIHtcclxuICAgIGxldCBhcnIgPSBbXTtcclxuICAgIHRoaXMucmVzdWx0cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICB0aGlzLmNvbG9yRG9tYWluLmZvckVhY2goY29sb3IgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtWyduYW1lJ10gPT09IGNvbG9yWydmdW5kVGlja2VyJ10pIHtcclxuICAgICAgICAgIGxldCBvYmogPSB7XHJcbiAgICAgICAgICAgIG5hbWU6IGNvbG9yLmZ1bmRUaWNrZXIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBjb2xvci5jb2xvclxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgYXJyLnB1c2gob2JqKVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGFycjtcclxuICB9XHJcblxyXG4gIGdldFhEb21haW4oKTogYW55W10ge1xyXG4gICAgbGV0IHZhbHVlcyA9IGdldFVuaXF1ZVhEb21haW5WYWx1ZXModGhpcy5yZXN1bHRzKTtcclxuICAgIHRoaXMuc2NhbGVUeXBlID0gdGhpcy5nZXRTY2FsZVR5cGUodmFsdWVzKTtcclxuICAgIGxldCBkb21haW4gPSBbXTtcclxuXHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdsaW5lYXInKSB7XHJcbiAgICAgIHZhbHVlcyA9IHZhbHVlcy5tYXAodiA9PiBOdW1iZXIodikpO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBtaW47XHJcbiAgICBsZXQgbWF4O1xyXG4gICAgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAndGltZScgfHwgdGhpcy5zY2FsZVR5cGUgPT09ICdsaW5lYXInKSB7XHJcbiAgICAgIG1pbiA9IHRoaXMueFNjYWxlTWluXHJcbiAgICAgICAgPyB0aGlzLnhTY2FsZU1pblxyXG4gICAgICAgIDogTWF0aC5taW4oLi4udmFsdWVzKTtcclxuXHJcbiAgICAgIG1heCA9IHRoaXMueFNjYWxlTWF4XHJcbiAgICAgICAgPyB0aGlzLnhTY2FsZU1heFxyXG4gICAgICAgIDogTWF0aC5tYXgoLi4udmFsdWVzKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICd0aW1lJykge1xyXG4gICAgICBkb21haW4gPSBbbmV3IERhdGUobWluKSwgbmV3IERhdGUobWF4KV07XHJcbiAgICAgIHRoaXMueFNldCA9IFsuLi52YWx1ZXNdLnNvcnQoKGEsIGIpID0+IHtcclxuICAgICAgICBjb25zdCBhRGF0ZSA9IGEuZ2V0VGltZSgpO1xyXG4gICAgICAgIGNvbnN0IGJEYXRlID0gYi5nZXRUaW1lKCk7XHJcbiAgICAgICAgaWYgKGFEYXRlID4gYkRhdGUpIHJldHVybiAxO1xyXG4gICAgICAgIGlmIChiRGF0ZSA+IGFEYXRlKSByZXR1cm4gLTE7XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLnNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcclxuICAgICAgZG9tYWluID0gW21pbiwgbWF4XTtcclxuICAgICAgLy8gVXNlIGNvbXBhcmUgZnVuY3Rpb24gdG8gc29ydCBudW1iZXJzIG51bWVyaWNhbGx5XHJcbiAgICAgIHRoaXMueFNldCA9IFsuLi52YWx1ZXNdLnNvcnQoKGEsIGIpID0+IChhIC0gYikpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZG9tYWluID0gdmFsdWVzO1xyXG4gICAgICB0aGlzLnhTZXQgPSB2YWx1ZXM7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGRvbWFpbjtcclxuICB9XHJcblxyXG4gIGdldFlEb21haW4oKTogYW55W10ge1xyXG4gICAgY29uc3QgZG9tYWluID0gW107XHJcbiAgICBmb3IgKGNvbnN0IHJlc3VsdHMgb2YgdGhpcy5yZXN1bHRzKSB7XHJcbiAgICAgIGZvciAoY29uc3QgZCBvZiByZXN1bHRzLnNlcmllcykge1xyXG4gICAgICAgIGlmIChkLnZhbHVlICYmIGRvbWFpbi5pbmRleE9mKGQudmFsdWUpIDwgMCkge1xyXG4gICAgICAgICAgZG9tYWluLnB1c2goZC52YWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChkLm1pbiAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICB0aGlzLmhhc1JhbmdlID0gdHJ1ZTtcclxuICAgICAgICAgIGlmIChkb21haW4uaW5kZXhPZihkLm1pbikgPCAwKSB7XHJcbiAgICAgICAgICAgIGRvbWFpbi5wdXNoKGQubWluKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGQubWF4ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgIHRoaXMuaGFzUmFuZ2UgPSB0cnVlO1xyXG4gICAgICAgICAgaWYgKGRvbWFpbi5pbmRleE9mKGQubWF4KSA8IDApIHtcclxuICAgICAgICAgICAgZG9tYWluLnB1c2goZC5tYXgpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHZhbHVlcyA9IFsuLi5kb21haW5dO1xyXG4gICAgaWYgKCF0aGlzLmF1dG9TY2FsZSkge1xyXG4gICAgICB2YWx1ZXMucHVzaCgwKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBtaW4gPSB0aGlzLnlTY2FsZU1pblxyXG4gICAgICA/IHRoaXMueVNjYWxlTWluXHJcbiAgICAgIDogTWF0aC5taW4oLi4udmFsdWVzKTtcclxuXHJcbiAgICBjb25zdCBtYXggPSB0aGlzLnlTY2FsZU1heFxyXG4gICAgICA/IHRoaXMueVNjYWxlTWF4XHJcbiAgICAgIDogTWF0aC5tYXgoLi4udmFsdWVzKTtcclxuXHJcbiAgICAgIGlmIChtaW4gJiYgbWF4KSB7XHJcbiAgICAgICAgcmV0dXJuIFttaW4sIG1heF07XHJcbiAgICAgIH1lbHNlIHtcclxuICAgICAgICByZXR1cm4gWy0wLjEsIDAuMV07XHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIGdldFNlcmllc0RvbWFpbigpOiBhbnlbXSB7XHJcbiAgICByZXR1cm4gdGhpcy5yZXN1bHRzLm1hcChkID0+IGQubmFtZSk7XHJcbiAgfVxyXG5cclxuICBnZXRYU2NhbGUoZG9tYWluLCB3aWR0aCk6IGFueSB7XHJcbiAgICBsZXQgc2NhbGU7XHJcblxyXG4gICAgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAndGltZScpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZVRpbWUoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5kb21haW4oZG9tYWluKTtcclxuICAgIH0gZWxzZSBpZiAodGhpcy5zY2FsZVR5cGUgPT09ICdsaW5lYXInKSB7XHJcbiAgICAgIHNjYWxlID0gc2NhbGVMaW5lYXIoKVxyXG4gICAgICAgIC5yYW5nZShbMCwgd2lkdGhdKVxyXG4gICAgICAgIC5kb21haW4oZG9tYWluKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLnJvdW5kRG9tYWlucykge1xyXG4gICAgICAgIHNjYWxlID0gc2NhbGUubmljZSgpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2NhbGVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgc2NhbGUgPSBzY2FsZVBvaW50KClcclxuICAgICAgICAucmFuZ2UoWzAsIHdpZHRoXSlcclxuICAgICAgICAucGFkZGluZygwLjEpXHJcbiAgICAgICAgLmRvbWFpbihkb21haW4pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBzY2FsZTtcclxuICB9XHJcblxyXG4gIGdldFlTY2FsZShkb21haW4sIGhlaWdodCk6IGFueSB7XHJcbiAgICBjb25zdCBzY2FsZSA9IHNjYWxlTGluZWFyKClcclxuICAgICAgLnJhbmdlKFtoZWlnaHQsIDBdKVxyXG4gICAgICAuZG9tYWluKGRvbWFpbik7XHJcblxyXG4gICAgcmV0dXJuIHRoaXMucm91bmREb21haW5zID8gc2NhbGUubmljZSgpIDogc2NhbGU7XHJcbiAgfVxyXG5cclxuICBnZXRTY2FsZVR5cGUodmFsdWVzKTogc3RyaW5nIHtcclxuICAgIGxldCBkYXRlID0gdHJ1ZTtcclxuICAgIGxldCBudW0gPSB0cnVlO1xyXG5cclxuICAgIGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSB7XHJcbiAgICAgIGlmICghdGhpcy5pc0RhdGUodmFsdWUpKSB7XHJcbiAgICAgICAgZGF0ZSA9IGZhbHNlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAnbnVtYmVyJykge1xyXG4gICAgICAgIG51bSA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGUpIHJldHVybiAndGltZSc7XHJcbiAgICBpZiAobnVtKSByZXR1cm4gJ2xpbmVhcic7XHJcbiAgICByZXR1cm4gJ29yZGluYWwnO1xyXG4gIH1cclxuXHJcbiAgaXNEYXRlKHZhbHVlKTogYm9vbGVhbiB7XHJcbiAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZVlBeGlzV2lkdGgoeyB3aWR0aCB9KTogdm9pZCB7XHJcbiAgICB0aGlzLnlBeGlzV2lkdGggPSB3aWR0aDtcclxuICAgIHRoaXMudXBkYXRlKCk7XHJcbiAgfVxyXG5cclxuICB1cGRhdGVYQXhpc0hlaWdodCh7IGhlaWdodCB9KTogdm9pZCB7XHJcbiAgICB0aGlzLnhBeGlzSGVpZ2h0ID0gaGVpZ2h0O1xyXG4gICAgdGhpcy51cGRhdGUoKTtcclxuICB9XHJcblxyXG4gIHVwZGF0ZUhvdmVyZWRWZXJ0aWNhbChpdGVtKTogdm9pZCB7XHJcbiAgICB0aGlzLmhvdmVyZWRWZXJ0aWNhbCA9IGl0ZW0udmFsdWU7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuICB9XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ21vdXNlbGVhdmUnKVxyXG4gIGhpZGVDaXJjbGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5ob3ZlcmVkVmVydGljYWwgPSBudWxsO1xyXG4gICAgdGhpcy5kZWFjdGl2YXRlQWxsKCk7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCdtb3VzZWVudGVyJywgW1wic2VyaWVzXCJdKVxyXG4gIG9uTW91c2VFbnRlcihzZXJpZXMpOiB2b2lkIHtcclxuICAgIHRoaXMuYWN0aXZhdGUuZW1pdChzZXJpZXMpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignbW91c2VsZWF2ZScsIFtcIiRldmVudFwiXSlcclxuICBvbk1vdXNlTGVhdmUoc2VyaWVzKTogdm9pZCB7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGUuZW1pdChzZXJpZXMpO1xyXG4gIH1cclxuXHJcbiAgb25DbGljayhkYXRhLCBzZXJpZXM/KTogdm9pZCB7XHJcbiAgICBpZiAoc2VyaWVzKSB7XHJcbiAgICAgIGRhdGEuc2VyaWVzID0gc2VyaWVzLm5hbWU7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZWxlY3QuZW1pdChkYXRhKTtcclxuICB9XHJcblxyXG4gIHRyYWNrQnkoaW5kZXgsIGl0ZW0pOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIGl0ZW0ubmFtZTtcclxuICB9XHJcblxyXG4gIHNldENvbG9ycygpOiB2b2lkIHtcclxuICAgIGxldCBkb21haW47XHJcbiAgICBpZiAodGhpcy5zY2hlbWVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgZG9tYWluID0gdGhpcy5zZXJpZXNEb21haW47XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb21haW4gPSB0aGlzLnlEb21haW47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5jb2xvcnMgPSBuZXcgQ29sb3JIZWxwZXIodGhpcy5zY2hlbWUsIHRoaXMuc2NoZW1lVHlwZSwgZG9tYWluLCB0aGlzLmN1c3RvbUNvbG9ycyk7XHJcbiAgfVxyXG5cclxuICBnZXRMZWdlbmRPcHRpb25zKCkge1xyXG4gICAgY29uc3Qgb3B0cyA9IHtcclxuICAgICAgc2NhbGVUeXBlOiB0aGlzLnNjaGVtZVR5cGUsXHJcbiAgICAgIGNvbG9yczogdW5kZWZpbmVkLFxyXG4gICAgICBkb21haW46IFtdLFxyXG4gICAgICB0aXRsZTogdW5kZWZpbmVkXHJcbiAgICB9O1xyXG4gICAgaWYgKG9wdHMuc2NhbGVUeXBlID09PSAnb3JkaW5hbCcpIHtcclxuICAgICAgb3B0cy5kb21haW4gPSB0aGlzLnNlcmllc0RvbWFpbjtcclxuICAgICAgb3B0cy5jb2xvcnMgPSB0aGlzLmNvbG9ycztcclxuICAgICAgb3B0cy50aXRsZSA9IHRoaXMubGVnZW5kVGl0bGU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBvcHRzLmRvbWFpbiA9IHRoaXMueURvbWFpbjtcclxuICAgICAgb3B0cy5jb2xvcnMgPSB0aGlzLmNvbG9ycy5zY2FsZTtcclxuICAgIH1cclxuICAgIHJldHVybiBvcHRzO1xyXG4gIH1cclxuXHJcbiAgb25BY3RpdmF0ZShpdGVtKSB7XHJcbiAgICB0aGlzLmRlYWN0aXZhdGVBbGwoKTtcclxuXHJcbiAgICBjb25zdCBpZHggPSB0aGlzLmFjdGl2ZUVudHJpZXMuZmluZEluZGV4KGQgPT4ge1xyXG4gICAgICByZXR1cm4gZC5uYW1lID09PSBpdGVtLm5hbWUgJiYgZC52YWx1ZSA9PT0gaXRlbS52YWx1ZTtcclxuICAgIH0pO1xyXG4gICAgaWYgKGlkeCA+IC0xKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSBbaXRlbV07XHJcbiAgICB0aGlzLmFjdGl2YXRlLmVtaXQoeyB2YWx1ZTogaXRlbSwgZW50cmllczogdGhpcy5hY3RpdmVFbnRyaWVzIH0pO1xyXG5cclxuICB9XHJcblxyXG4gIG9uRGVhY3RpdmF0ZShpdGVtKSB7XHJcbiAgICBjb25zdCBpZHggPSB0aGlzLmFjdGl2ZUVudHJpZXMuZmluZEluZGV4KGQgPT4ge1xyXG4gICAgICByZXR1cm4gZC5uYW1lID09PSBpdGVtLm5hbWUgJiYgZC52YWx1ZSA9PT0gaXRlbS52YWx1ZTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuYWN0aXZlRW50cmllcy5zcGxpY2UoaWR4LCAxKTtcclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFsuLi50aGlzLmFjdGl2ZUVudHJpZXNdO1xyXG5cclxuICAgIHRoaXMuZGVhY3RpdmF0ZS5lbWl0KHsgdmFsdWU6IGl0ZW0sIGVudHJpZXM6IHRoaXMuYWN0aXZlRW50cmllcyB9KTtcclxuICB9XHJcblxyXG4gIGRlYWN0aXZhdGVBbGwoKSB7XHJcbiAgICB0aGlzLmFjdGl2ZUVudHJpZXMgPSBbLi4udGhpcy5hY3RpdmVFbnRyaWVzXTtcclxuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcy5hY3RpdmVFbnRyaWVzKSB7XHJcbiAgICAgIHRoaXMuZGVhY3RpdmF0ZS5lbWl0KHsgdmFsdWU6IGVudHJ5LCBlbnRyaWVzOiBbXSB9KTtcclxuICAgIH1cclxuICAgIHRoaXMuYWN0aXZlRW50cmllcyA9IFtdO1xyXG4gIH1cclxufVxyXG5cclxuXHJcblxyXG4iLCJpbXBvcnQge1xyXG4gIEVsZW1lbnRSZWYsIE5nWm9uZSwgQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgQ29tcG9uZW50LFxyXG4gIElucHV0LFxyXG4gIE91dHB1dCxcclxuICBFdmVudEVtaXR0ZXIsXHJcbiAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgSG9zdExpc3RlbmVyLFxyXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxyXG4gIENvbnRlbnRDaGlsZCxcclxuICBUZW1wbGF0ZVJlZixcclxuICBWaWV3Q2hpbGQsXHJcbiAgVmlld0NvbnRhaW5lclJlZixcclxuICBPbkluaXQsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vblV0aWxzU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2NvbW1vbi11dGlscy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zaGFyZS1pbmZvLWJld2Vlbi1jb21wb25lbnRzLnNlcnZpY2UnO1xyXG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdsaWItY29tbW9uLWRhdGEtdGFibGUnLFxyXG4gIHRlbXBsYXRlOiBgPGRpdiAqbmdJZj1cImlzRGF0YUF2YWlsYWJsZVwiIHN0eWxlPVwiaGVpZ2h0OjUwcHhcIiBjbGFzcz1cIm1haW4tYm94XCIgKGNsaWNrT3V0c2lkZSk9XCJvbkNsaWNrZWRPdXRzaWRlKCRldmVudClcIj5cclxuXHJcbiAgPGRpdiAqbmdJZj1cImhlYWRlclNldHRpbmdcIiBjbGFzcz1cIm1vcmUtaWNvblwiPlxyXG4gICAgPGJ1dHRvbiBtYXQtaWNvbi1idXR0b24gW21hdE1lbnVUcmlnZ2VyRm9yXT1cIm1lbnVcIj5cclxuICAgICAgPG1hdC1pY29uIHN2Z0ljb249XCJtb3JlXCI+PC9tYXQtaWNvbj5cclxuICAgIDwvYnV0dG9uPlxyXG4gICAgPG1hdC1tZW51ICNtZW51PVwibWF0TWVudVwiIFtvdmVybGFwVHJpZ2dlcl09J2ZhbHNlJz5cclxuICAgICAgPGJ1dHRvbiBtYXQtbWVudS1pdGVtIFttYXRNZW51VHJpZ2dlckZvcl09XCJhZGp1c3RSb3dIZWlnaHRcIj5cclxuICAgICAgICA8c3Bhbj5Sb3cgSGVpZ2h0PC9zcGFuPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAgPGJ1dHRvbiAqbmdJZj0nIWlzRGF0YVRhYmxlUGF1c2VkJyBtYXQtbWVudS1pdGVtIChjbGljayk9XCJ0b2dnbGVQYXVzZUZsYWcoKVwiPlxyXG4gICAgICAgIDxzcGFuPlBhdXNlPC9zcGFuPlxyXG4gICAgICA8L2J1dHRvbj4gIFxyXG4gICAgICA8YnV0dG9uICpuZ0lmPSdpc0RhdGFUYWJsZVBhdXNlZCcgbWF0LW1lbnUtaXRlbSAoY2xpY2spPVwidG9nZ2xlUGF1c2VGbGFnKClcIj5cclxuICAgICAgICA8c3Bhbj5Vbi1QYXVzZTwvc3Bhbj5cclxuICAgICAgPC9idXR0b24+ICAgIFxyXG4gICAgPC9tYXQtbWVudT5cclxuXHJcbiAgICA8bWF0LW1lbnUgI2FkanVzdFJvd0hlaWdodD1cIm1hdE1lbnVcIj5cclxuICAgICAgPGJ1dHRvbiBtYXQtbWVudS1pdGVtIChjbGljayk9XCJnZXRSb3dIZWlnaHQoJ3N0YW5kYXJkJylcIj5TdGFuZGFyZFxyXG4gICAgICAgIDxtYXQtaWNvbiAqbmdJZj0ncm93SGVpZ2h0PT01MCcgc3ZnSWNvbj1cImNoZWNrXCIgY2xhc3M9XCJjaGVjay1pY29uXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICAgIDxidXR0b24gbWF0LW1lbnUtaXRlbSAoY2xpY2spPVwiZ2V0Um93SGVpZ2h0KCdzbWFsbCcpXCI+U21hbGxcclxuICAgICAgICA8bWF0LWljb24gKm5nSWY9J3Jvd0hlaWdodD09NDAnIHN2Z0ljb249XCJjaGVja1wiIGNsYXNzPVwiY2hlY2staWNvblwiPjwvbWF0LWljb24+XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9tYXQtbWVudT5cclxuICA8L2Rpdj5cclxuICA8IS0tcm93SGVpZ2h0IHNldHRpbmctLT5cclxuXHJcbiAgPCEtLWNvbHVtbiBtZW51IGRyb3Bkb3ctLT5cclxuICA8ZGl2PlxyXG4gICAgPG1hdC1tZW51ICNjb2x1bW5IZWFkZXJNZW51PVwibWF0TWVudVwiIFtvdmVybGFwVHJpZ2dlcl09J2ZhbHNlJz5cclxuICAgICAgPHNwYW4gKm5nRm9yPVwibGV0IGl0ZW0gb2YgY29sdW1uTWVudURyb3BEb3duU2V0dGluZ1wiPlxyXG4gICAgICAgIDxidXR0b24gbWF0LW1lbnUtaXRlbSAqbmdJZj1cIiFpdGVtLmhhc1N1Yk1lbnVcIj5cclxuICAgICAgICAgIDxzcGFuIChjbGljayk9XCJoYW5kbGVNZW51SXRlbUNsaWNrKGl0ZW0udHlwZSlcIj57e2dldE1hdE1lbnVJdGVtRGlzcGxheW5hbWUoaXRlbS5uYW1lKX19PC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gbWF0LW1lbnUtaXRlbSAqbmdJZj1cIml0ZW0uaGFzU3ViTWVudVwiIFttYXRNZW51VHJpZ2dlckZvcl09XCJhZGRpdGlvbmFsRnVuY3Rpb25zXCI+XHJcbiAgICAgICAgICA8c3Bhbj57e2l0ZW0ubmFtZX19PC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L21hdC1tZW51PlxyXG5cclxuXHJcbiAgICA8bWF0LW1lbnUgI2FkZGl0aW9uYWxGdW5jdGlvbnM9XCJtYXRNZW51XCI+XHJcbiAgICAgIDxidXR0b24gKm5nRm9yPVwibGV0IGNvbCBvZiBub3JtYWxDb2x1bW47bGV0IGk9aW5kZXg7XCIgbWF0LW1lbnUtaXRlbSAoY2xpY2spPVwicmVtb3ZlT3JBZGRDb2x1bW4oY29sLCBpKVwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwiZHJvcGRvd01lbnVMaXN0U3R5XCI+e3tjb2wubmFtZX19PC9zcGFuPlxyXG4gICAgICAgIDxtYXQtaWNvbiAqbmdJZj0nMT09PTEnIHN2Z0ljb249XCJjaGVja1wiIGNsYXNzPVwiY2hlY2staWNvblwiPjwvbWF0LWljb24+XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9tYXQtbWVudT5cclxuICA8L2Rpdj5cclxuXHJcblxyXG4gIDxuZ3gtZGF0YXRhYmxlIFxyXG4gICAgI215ZGF0YXRhYmxlIFxyXG4gICAgY2xhc3M9XCJtYXRlcmlhbCBleHBhbmRhYmxlXCIgXHJcbiAgICBbaGVhZGVySGVpZ2h0XT1cImhlYWRlckhlaWdodFwiIFxyXG4gICAgW2xpbWl0XT1cImxpbWl0XCJcclxuICAgIFtzY3JvbGxiYXJIXT0ndHJ1ZScgXHJcbiAgICBbY29sdW1uTW9kZV09XCInZm9yY2UnXCIgXHJcbiAgICBbZm9vdGVySGVpZ2h0XT1cImZvb3RlckhlaWdodFwiIFxyXG4gICAgW3Jvd0hlaWdodF09XCJyb3dIZWlnaHRcIlxyXG4gICAgW3RyYWNrQnlQcm9wXT1cIid1cGRhdGVkJ1wiIFxyXG4gICAgW3Jvd3NdPVwicm93c1wiPlxyXG4gICAgPG5neC1kYXRhdGFibGUtY29sdW1uICpuZ0lmPVwiZXhwYW5kQ2hpbGRcIiBbd2lkdGhdPVwiMzBcIiBbcmVzaXplYWJsZV09XCJmYWxzZVwiIFtzb3J0YWJsZV09XCJmYWxzZVwiIFtkcmFnZ2FibGVdPVwiZmFsc2VcIlxyXG4gICAgICBbZnJvemVuTGVmdF09XCJ0cnVlXCIgW2NhbkF1dG9SZXNpemVdPVwiZmFsc2VcIj5cclxuICAgICAgPG5nLXRlbXBsYXRlIGxldC1yb3c9XCJyb3dcIiBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9J3NpZGVDb2xvclN0eWxlJyBbc3R5bGUuYmFja2dyb3VuZF09J2dldFNpZGVDb2xvclN0eWxlKHJvdyknPjwvc3Bhbj5cclxuICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJleHBhbmRlZC1pY29uXCIgKm5nSWY9XCJoYXNDaGlsZHJlbihyb3cpXCIgW3N2Z0ljb25dPVwiZ2V0RXhwYW5kQ29sbGFwc2VJY29uKHJvdylcIiAoY2xpY2spPVwidG9nZ2xlRXhwYW5kUm93KHJvdylcIj5cclxuICAgICAgICA8L21hdC1pY29uPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgPC9uZ3gtZGF0YXRhYmxlLWNvbHVtbj5cclxuICAgIDxuZ3gtZGF0YXRhYmxlLWNvbHVtbiAqbmdJZj1cImhlYWRlckNoZWNrQm94XCIgW3dpZHRoXT1cIjUwXCIgW3NvcnRhYmxlXT1cImZhbHNlXCIgW2NhbkF1dG9SZXNpemVdPVwiZmFsc2VcIlxyXG4gICAgICBbZHJhZ2dhYmxlXT1cImZhbHNlXCIgW2Zyb3plbkxlZnRdPVwidHJ1ZVwiIFtyZXNpemVhYmxlXT1cImZhbHNlXCI+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSBsZXQtcm93PVwicm93XCIgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XHJcbiAgICAgICAgPHNwYW4gKm5nSWY9XCIhZXhwYW5kQ2hpbGRcIiBjbGFzcz0nc2lkZUNvbG9yU3R5bGUnIFtzdHlsZS5iYWNrZ3JvdW5kXT0nZ2V0U2lkZUNvbG9yU3R5bGUocm93KSc+PC9zcGFuPlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBbZGlzYWJsZWRdPVwiZ2V0QWxsUm93c0Rpc2FibGVkKClcIiBbY2hlY2tlZF09XCJnZXRBbGxSb3dDaGVja2VkKHJvd3MpXCJcclxuICAgICAgICAgIChjaGFuZ2UpPVwib25TZWxlY3RBbGwoIWFsbFJvd3NTZWxlY3RlZCwgcm93cylcIiAvPlxyXG4gICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICA8bmctdGVtcGxhdGUgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlIGxldC1yb3c9XCJyb3dcIj5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgW2Rpc2FibGVkXT1cImdldFNpbmdsZVJvd0Rpc2FibGVkKHJvdylcIiBbY2hlY2tlZF09XCJnZXRTaW5nbGVSb3dDaGVja2VkKHJvd1snZnVuZFRpY2tlciddKVwiXHJcbiAgICAgICAgICAoY2hhbmdlKT1cIm9uQ2hlY2tib3hDaGFuZ2Uocm93WydmdW5kVGlja2VyJ10pXCIgLz5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XHJcbiAgICA8bmd4LWRhdGF0YWJsZS1jb2x1bW4gKm5nRm9yPVwibGV0IGNvbCBvZiBjdXN0b21Db2x1bW5cIiBcclxuICAgICAgW3dpZHRoXT1cIjU1XCIgXHJcbiAgICAgIFtzb3J0YWJsZV09XCJmYWxzZVwiIFxyXG4gICAgICBbY2FuQXV0b1Jlc2l6ZV09XCJmYWxzZVwiXHJcbiAgICAgIFtkcmFnZ2FibGVdPVwiZmFsc2VcIiBcclxuICAgICAgW3Jlc2l6ZWFibGVdPVwiZmFsc2VcIiBcclxuICAgICAgW2Zyb3plbkxlZnRdPVwidHJ1ZVwiPlxyXG4gICAgICA8bmctdGVtcGxhdGUgKm5nSWY9XCJjb2wudHlwZT09PSdyZWRBbGVydCcgXCIgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XHJcbiAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwiYWxlcnRIZWFkZXJcIiBzdmdJY29uPVwiZmxhZ1wiPjwvbWF0LWljb24+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC50eXBlPT09J3llbGxvd0FsZXJ0JyBcIiBuZ3gtZGF0YXRhYmxlLWhlYWRlci10ZW1wbGF0ZT5cclxuICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJhbGVydEhlYWRlclwiIHN2Z0ljb249XCJmbGFnXCI+PC9tYXQtaWNvbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLnR5cGU9PT0nbmV3cycgXCIgbmd4LWRhdGF0YWJsZS1oZWFkZXItdGVtcGxhdGU+XHJcbiAgICAgICAgPHNwYW4+TmV3czwvc3Bhbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLnR5cGU9PT0ncmVkQWxlcnQnIFwiIGxldC1yb3c9XCJyb3dcIiBsZXQtY29sdW1uPVwiY29sXCIgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlPlxyXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImFsZXJ0Q2xhc3NcIiBzdmdJY29uPVwiY2lyY2xlX2FsZXJ0XCJcclxuICAgICAgICAgIFtzdHlsZS5kaXNwbGF5XT1cInNob3dSZWRBbGVydChyb3dbJ2Z1bmRpZCddLHJvd1snY2xhc3NJRCddKSA/ICdpbmxpbmUtZmxleCcgOiAnbm9uZScgXCJcclxuICAgICAgICAgIChjbGljayk9XCJvcGVuQWxlcnRNb2RhbChyb3csY29sLnR5cGUpXCI+XHJcbiAgICAgICAgPC9tYXQtaWNvbj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLnR5cGU9PT0neWVsbG93QWxlcnQnIFwiIGxldC1yb3c9XCJyb3dcIiBsZXQtY29sdW1uPVwiY29sXCIgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlPlxyXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImFsZXJ0Q2xhc3NcIiBzdmdJY29uPVwidHJpYW5nbGVhbGVydFwiXHJcbiAgICAgICAgICBbc3R5bGUuZGlzcGxheV09XCJzaG93WWVsbG93QWxlcnQocm93WydmdW5kaWQnXSxyb3dbJ2NsYXNzSUQnXSkgPyAnaW5saW5lLWZsZXgnIDogJ25vbmUnIFwiXHJcbiAgICAgICAgICAoY2xpY2spPVwib3BlbkFsZXJ0TW9kYWwocm93LGNvbC50eXBlKVwiPlxyXG4gICAgICAgIDwvbWF0LWljb24+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC50eXBlPT09J25ld3MnIFwiIGxldC1yb3c9XCJyb3dcIiBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPG1hdC1pY29uIGNsYXNzPVwic2hvd05ld3NDbGFzc1wiIFtzdHlsZS5kaXNwbGF5XT1cInNob3dOZXdzKHJvdykgPyAnaW5saW5lLWZsZXgnIDogJ25vbmUnIFwiIHN2Z0ljb249XCJnbG9iZVwiPlxyXG4gICAgICAgIDwvbWF0LWljb24+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICA8L25neC1kYXRhdGFibGUtY29sdW1uPlxyXG4gICAgPG5neC1kYXRhdGFibGUtY29sdW1uICpuZ0Zvcj1cImxldCBjb2wgb2Ygbm9ybWFsQ29sdW1uXCIgXHJcbiAgICAgIFtwcm9wXT1cImNvbC5wcm9wXCIgXHJcbiAgICAgIFtkcmFnZ2FibGVdPVwiY29sLmRyYWdnYWJsZVwiXHJcbiAgICAgIFtjYW5BdXRvUmVzaXplXT1cImNvbC5jYW5BdXRvUmVzaXplXCIgXHJcbiAgICAgIFtzb3J0YWJsZV09XCJmYWxzZVwiIFxyXG4gICAgICBbZnJvemVuTGVmdF09XCJjb2wuZnJvemVuTGVmdFwiXHJcbiAgICAgIFt3aWR0aF09XCJnZXRDb2xTZXR0aW5nV2lkdGgoY29sKVwiPlxyXG4gICAgICA8bmctdGVtcGxhdGUgbGV0LWNvbHVtbj1cImNvbFwiIG5neC1kYXRhdGFibGUtaGVhZGVyLXRlbXBsYXRlPlxyXG4gICAgICAgIDxkaXYgW2NsYXNzXT1cImdldEhlYWRlckNsYXNzKGNvbClcIiAgXHJcbiAgICAgICAgKGNsaWNrKT1cInNlbGVjdEN1cnJlbnRDb2woJGV2ZW50LCBjb2wucHJvcClcIiAobWVudUNsb3NlZCk9XCJjbG9zZU1lbnUoKVwiICBbbWF0TWVudVRyaWdnZXJGb3JdPVwiY29sdW1uSGVhZGVyTWVudVwiXHJcbiAgICAgICAgICAqbmdJZj1cIihjb2wuY29sdW1uU2V0dGluZyAmJiBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nLmxlbmd0aCA+IDApIGVsc2UgZWxzZUJsb2NrXCI+XHJcbiAgICAgICAgICA8IS0tIHNvcnQgaWNvbiBzdGFydC0tPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJzb3J0SWNvblN0eUNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8bWF0LWljb24gW2NsYXNzXT1cImdldFNvcnRJY29uRGlzcGxheVN0eShjb2wucHJvcClcIiBbc3ZnSWNvbl09XCJnZXRTb3J0SWNvbihjb2wucHJvcClcIlxyXG4gICAgICAgICAgICAgIChjbGljayk9XCJjaGFuZ2VBc2NBbmREZXNjU29ydCgkZXZlbnQsIGNvbC5wcm9wKVwiPjwvbWF0LWljb24+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgPCEtLSBzb3J0IGljb24gZW5kLS0+XHJcblxyXG4gICAgICAgICAgPCEtLSBoZWFkZXIgbmFtZSBzdGFydC0tPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJoZWFkZXItY2VsbC1sYWJlbC1zdHlcIj5cclxuICAgICAgICAgICAge3tjb2wubmFtZX19XHJcbiAgICAgICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImRyb3Bkb3dJY29uU3R5XCIgc3ZnSWNvbj1cImFycm93X2Rvd25cIj48L21hdC1pY29uPlxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgPCEtLSBoZWFkZXIgbmFtZSBlbmQtLT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8bmctdGVtcGxhdGUgI2Vsc2VCbG9jaz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY29sdW1uSGVhZGVyXCI+XHJcbiAgICAgICAgICAgIHt7Y29sLm5hbWV9fVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC5jZWxsVGVtcGxhdGU9PT0naHlwZXJMaW5rJyBcIiBsZXQtcm93PVwicm93XCIgbGV0LXZhbHVlPVwidmFsdWVcIiBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPGRpdiBbY2xhc3NdPVwiZ2V0Q2VsbENsYXNzKHJvdywgY29sLCB2YWx1ZSlcIj5cclxuICAgICAgICAgIDxzcGFuICpuZ0lmPVwicm93LmNoaWxkID09PSAncGFyZW50J1wiIGNsYXNzPVwiaHlwZXJMaW5rQ2VsbFN0eVwiXHJcbiAgICAgICAgICAgIChjbGljayk9XCJoeXBlckxpbmtOYXZpZ2F0ZShyb3cpXCI+e3tyb3cubmFtZX19PC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gKm5nSWY9XCJyb3cuY2hpbGQgPT09ICdjaGlsZCdcIj57e3Jvdy5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC5jZWxsVGVtcGxhdGU9PT0nbnVtYmVyRm9ybWF0U2hvcnQnIFwiIGxldC1yb3c9XCJyb3dcIiBsZXQtdmFsdWU9XCJ2YWx1ZVwiIGxldC1pPVwiaW5kZXhcIlxyXG4gICAgICAgIG5neC1kYXRhdGFibGUtY2VsbC10ZW1wbGF0ZT5cclxuICAgICAgICA8ZGl2IFtjbGFzc109XCJnZXRDZWxsQ2xhc3Mocm93LCBjb2wsIHZhbHVlKVwiPlxyXG4gICAgICAgICAge3t2YWx1ZSB8IG51bWJlclJvdW5kVXA6MiB8IG51bWJlcjogJzEuMi0yJ319XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC5jZWxsVGVtcGxhdGU9PT0nbnVtYmVyRm9ybWF0TG9uZycgXCIgbGV0LXJvdz1cInJvd1wiIGxldC12YWx1ZT1cInZhbHVlXCIgbGV0LWk9XCJpbmRleFwiXHJcbiAgICAgICAgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlPlxyXG4gICAgICAgIDxkaXYgW2NsYXNzXT1cImdldENlbGxDbGFzcyhyb3csIGNvbCwgdmFsdWUpXCI+XHJcbiAgICAgICAgICB7e3ZhbHVlIHwgbnVtYmVyUm91bmRVcDo1IHwgbnVtYmVyOiAnMS41LTUnfX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgPG5nLXRlbXBsYXRlICpuZ0lmPVwiY29sLmNlbGxUZW1wbGF0ZT09PSdwZXJjZW50Rm9ybWF0JyBcIiBsZXQtcm93PVwicm93XCIgbGV0LXZhbHVlPVwidmFsdWVcIiBsZXQtaT1cImluZGV4XCJcclxuICAgICAgICBuZ3gtZGF0YXRhYmxlLWNlbGwtdGVtcGxhdGU+XHJcbiAgICAgICAgPGRpdiBbY2xhc3NdPVwiZ2V0Q2VsbENsYXNzKHJvdywgY29sLCB2YWx1ZSlcIj5cclxuICAgICAgICAgIHt7dmFsdWUgfCBudW1iZXJSb3VuZFVwOjUgfCBwZXJjZW50OiAnMS4zLTMnIHwgcGVyY2VudEZvcm1hdH19XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgIDxuZy10ZW1wbGF0ZSAqbmdJZj1cImNvbC5jZWxsVGVtcGxhdGU9PT0nZGVmYXVsdCcgXCIgbGV0LXJvdz1cInJvd1wiIGxldC12YWx1ZT1cInZhbHVlXCIgbGV0LWk9XCJpbmRleFwiXHJcbiAgICAgICAgbmd4LWRhdGF0YWJsZS1jZWxsLXRlbXBsYXRlPlxyXG4gICAgICAgIDxkaXYgW2NsYXNzXT1cImdldENlbGxDbGFzcyhyb3csIGNvbCwgdmFsdWUpXCI+XHJcbiAgICAgICAgICB7e3ZhbHVlfX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgIDwvbmd4LWRhdGF0YWJsZS1jb2x1bW4+XHJcbiAgPC9uZ3gtZGF0YXRhYmxlPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2Aubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zdHJpcGVkIC5kYXRhdGFibGUtcm93LW9kZHtiYWNrZ3JvdW5kOiNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2VlZTt0cmFuc2l0aW9uLXByb3BlcnR5OmJhY2tncm91bmQ7dHJhbnNpdGlvbi1kdXJhdGlvbjouM3M7dHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246bGluZWFyfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZGRkfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMzA0ZmZlO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMxOTNhZTQ7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzIwNDFlZjtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5lbXB0eS1yb3d7aGVpZ2h0OjUwcHg7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmxvYWRpbmctcm93e3RleHQtYWxpZ246bGVmdDtwYWRkaW5nOi41cmVtIDEuMnJlbTt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LWxlZnR7YmFja2dyb3VuZC1jb2xvcjojZmZmO2JhY2tncm91bmQtcG9zaXRpb246MTAwJSAwO2JhY2tncm91bmQtcmVwZWF0OnJlcGVhdC15O2JhY2tncm91bmQtaW1hZ2U6dXJsKGRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQVFBQUFBQkNBWUFBQUQ1UEEvTkFBQUFGa2xFUVZRSUhXUFNrTmVTQm1KaFRRVnRiaUROQ2dBU2FnSUl1Slg4T2dBQUFBQkpSVTVFcmtKZ2dnPT0pfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodHtiYWNrZ3JvdW5kLXBvc2l0aW9uOjAgMDtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJMTJQUWtOZGkxVlRRNWdiU3drQXNEUUFSTEFJR3RPU0ZVQUFBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXJ7Ym94LXNoYWRvdzowIDJweCA0cHggMCByZ2JhKDAsMCwwLC4xNSk7cG9zaXRpb246c3RpY2t5O3Bvc2l0aW9uOi13ZWJraXQtc3RpY2t5O3RvcDowO3otaW5kZXg6OTk5O2JhY2tncm91bmQtY29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxse3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt2ZXJ0aWNhbC1hbGlnbjpib3R0b207Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NTAwfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVye3Bvc2l0aW9uOnJlbGF0aXZlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwubG9uZ3ByZXNzIC5kcmFnZ2FibGU6OmFmdGVye3RyYW5zaXRpb246dHJhbnNmb3JtIC40cyxvcGFjaXR5IC40cywtd2Via2l0LXRyYW5zZm9ybSAuNHM7b3BhY2l0eTouNTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgxKTt0cmFuc2Zvcm06c2NhbGUoMSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZHJhZ2dhYmxlOjphZnRlcntjb250ZW50OlwiIFwiO3Bvc2l0aW9uOmFic29sdXRlO3RvcDo1MCU7bGVmdDo1MCU7bWFyZ2luOi0zMHB4IDAgMCAtMzBweDtoZWlnaHQ6NjBweDt3aWR0aDo2MHB4O2JhY2tncm91bmQ6I2VlZTtib3JkZXItcmFkaXVzOjEwMCU7b3BhY2l0eToxOy13ZWJraXQtZmlsdGVyOm5vbmU7ZmlsdGVyOm5vbmU7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoMCk7dHJhbnNmb3JtOnNjYWxlKDApO3otaW5kZXg6OTk5OTtwb2ludGVyLWV2ZW50czpub25lfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwuZHJhZ2dpbmcgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0Om5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjZWVlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1kZXRhaWx7YmFja2dyb3VuZDojZjVmNWY1O3BhZGRpbmc6MTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ncm91cC1oZWFkZXJ7YmFja2dyb3VuZDojZjVmNWY1O2JvcmRlci1ib3R0b206MXB4IHNvbGlkICNkOWQ4ZDk7Ym9yZGVyLXRvcDoxcHggc29saWQgI2Q5ZDhkOX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktY2VsbHt0ZXh0LWFsaWduOmNlbnRlcjt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMzNTM1MzU7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO2xpbmUtaGVpZ2h0OjUwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWdyb3VwLWNlbGx7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjlyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXJ7ZGlzcGxheTpibG9jazt3aWR0aDoxMDAlO2hlaWdodDo1cHg7cGFkZGluZzowO21hcmdpbjowO3Bvc2l0aW9uOmFic29sdXRlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXJ7ZGlzcGxheTpibG9jaztwb3NpdGlvbjpyZWxhdGl2ZTtvdmVyZmxvdzpoaWRkZW47d2lkdGg6MTAwJTtoZWlnaHQ6NXB4Oy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7YmFja2dyb3VuZC1jb2xvcjojYWFkMWY5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXIgLmJhcnt0cmFuc2l0aW9uOnRyYW5zZm9ybSAuMnMgbGluZWFyOy13ZWJraXQtYW5pbWF0aW9uOi44cyBjdWJpYy1iZXppZXIoLjM5LC41NzUsLjU2NSwxKSBpbmZpbml0ZSBxdWVyeTthbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXIsLXdlYmtpdC10cmFuc2Zvcm0gLjJzIGxpbmVhcjtiYWNrZ3JvdW5kLWNvbG9yOiMxMDZjYzg7cG9zaXRpb246YWJzb2x1dGU7bGVmdDowO3RvcDowO2JvdHRvbTowO3dpZHRoOjEwMCU7aGVpZ2h0OjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3Rlcntib3JkZXItdG9wOjFweCBzb2xpZCByZ2JhKDAsMCwwLC4xMik7Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NDAwO2NvbG9yOnJnYmEoMCwwLDAsLjU0KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAucGFnZS1jb3VudHtsaW5lLWhlaWdodDo1MHB4O2hlaWdodDo1MHB4O3BhZGRpbmc6MCAxLjJyZW19Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlcnttYXJnaW46MCAxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGl7dmVydGljYWwtYWxpZ246bWlkZGxlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuZGlzYWJsZWQgYXtjb2xvcjpyZ2JhKDAsMCwwLC4yNikhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQhaW1wb3J0YW50fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuYWN0aXZlIGF7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKTtmb250LXdlaWdodDo3MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhe2hlaWdodDoyMnB4O21pbi13aWR0aDoyNHB4O2xpbmUtaGVpZ2h0OjIycHg7cGFkZGluZzowIDZweDtib3JkZXItcmFkaXVzOjNweDttYXJnaW46NnB4IDNweDt0ZXh0LWFsaWduOmNlbnRlcjtjb2xvcjpyZ2JhKDAsMCwwLC41NCk7dGV4dC1kZWNvcmF0aW9uOm5vbmU7dmVydGljYWwtYWxpZ246Ym90dG9tfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgYTpob3Zlcntjb2xvcjpyZ2JhKDAsMCwwLC43NSk7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLXByZXYsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcmlnaHQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tc2tpcHtmb250LXNpemU6MjBweDtsaW5lLWhlaWdodDoyMHB4O3BhZGRpbmc6MCAzcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtc3VtbWFyeS1yb3cgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3ZlcntiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse2ZvbnQtd2VpZ2h0OjcwMH0uZGF0YXRhYmxlLWNoZWNrYm94e3Bvc2l0aW9uOnJlbGF0aXZlO21hcmdpbjowO2N1cnNvcjpwb2ludGVyO3ZlcnRpY2FsLWFsaWduOm1pZGRsZTtkaXNwbGF5OmlubGluZS1ibG9jaztib3gtc2l6aW5nOmJvcmRlci1ib3g7cGFkZGluZzowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF17cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjAgMXJlbSAwIDA7Y3Vyc29yOnBvaW50ZXI7b3V0bGluZTowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06YmVmb3Jle3RyYW5zaXRpb246LjNzIGVhc2UtaW4tb3V0O2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7ei1pbmRleDoxO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07Ym9yZGVyOjJweCBzb2xpZCAjZjJmMmYyfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZDpiZWZvcmV7LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7dHJhbnNmb3JtOnJvdGF0ZSgtNDVkZWcpO2hlaWdodDouNXJlbTtib3JkZXItY29sb3I6IzAwOTY4ODtib3JkZXItdG9wLXN0eWxlOm5vbmU7Ym9yZGVyLXJpZ2h0LXN0eWxlOm5vbmV9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTphZnRlcntjb250ZW50OlwiXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDowO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07YmFja2dyb3VuZDojZmZmO2N1cnNvcjpwb2ludGVyfUAtd2Via2l0LWtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fUBrZXlmcmFtZXMgcXVlcnl7MCV7b3BhY2l0eToxOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpfTEwMCV7b3BhY2l0eTowOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpfX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtemVyb3t0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtbmFnZXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiNiOTEyMjQ7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtcG9zaXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMyODc0M2U7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tbGVmdHt0ZXh0LWFsaWduOmxlZnQ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItY2VudGVye2NvbG9yOiMzNTM1MzV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1jb2x1bW4taGVhZGVyLWFsaWduLXJpZ2h0e3RleHQtYWxpZ246cmlnaHQ7Y29sb3I6IzM1MzUzNX1idXR0b24ubWF0LW1lbnUtaXRlbXtoZWlnaHQ6MzBweDtsaW5lLWhlaWdodDozMHB4O2ZvbnQtc2l6ZToxM3B4O2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXJ9Lm1hdC1tZW51LWl0ZW06aG92ZXI6bm90KFtkaXNhYmxlZF0pe2JhY2tncm91bmQ6I2UxZWNmMn0uY2hlY2staWNvbi5tYXQtaWNvbnt3aWR0aDoxNHB4O2hlaWdodDoxNHB4O21hcmdpbi1sZWZ0OjIwcHg7Y29sb3I6IzAwMH0ubmd4LWRhdGF0YWJsZS5maXhlZC1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItaW5uZXJ7aGVpZ2h0OjEwMCV9YCwgYC5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbHtiYWNrZ3JvdW5kOiNmZmZ9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5zaG93TmV3c0NsYXNze2Rpc3BsYXk6aW5saW5lLWJsb2NrO3dpZHRoOjIwcHg7aGVpZ2h0OjIwcHg7dHJhbnNpdGlvbjp3aWR0aCAuM3N9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6aG92ZXIsLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZTFlY2YyO2N1cnNvcjpwb2ludGVyfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuYWxlcnRDbGFzc3t0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmlubGluZS1ibG9jazt3aWR0aDoyMnB4O2hlaWdodDoyMnB4O3RyYW5zaXRpb246d2lkdGggLjNzO2N1cnNvcjpwb2ludGVyO21hcmdpbi1sZWZ0Oi0xMHB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHktY2VsbCAuZXhwYW5kZWQtaWNvbnt0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmlubGluZS1ibG9jazt3aWR0aDoyMHB4O2hlaWdodDoyMHB4O2N1cnNvcjpwb2ludGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTtmb250LXNpemU6MTJweDt0cmFuc2l0aW9uOndpZHRoIC4zc30ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbHtsaW5lLWhlaWdodDo1MHB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwtdGVtcGxhdGUtd3JhcHtjdXJzb3I6cG9pbnRlcjtoZWlnaHQ6MTAwJTtsaW5lLWhlaWdodDo1MHB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwtdGVtcGxhdGUtd3JhcCAuYWxlcnRIZWFkZXJ7ZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MjBweDtoZWlnaHQ6MjBweDt0cmFuc2l0aW9uOndpZHRoIC4zczttYXJnaW4tbGVmdDotMTBweH0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsLXRlbXBsYXRlLXdyYXAgLmNvbHVtbkhlYWRlcntjb2xvcjojMDAwO3Bvc2l0aW9uOnJlbGF0aXZlO3BhZGRpbmctcmlnaHQ6NXB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5oZWFkZXItYWxpZ24tY2VudGVyLC5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5oZWFkZXItYWxpZ24tbGVmdCwubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuaGVhZGVyLWFsaWduLXJpZ2h0e2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXJ9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmhlYWRlci1hbGlnbi1sZWZ0e2p1c3RpZnktY29udGVudDpmbGV4LXN0YXJ0fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIC5oZWFkZXItYWxpZ24tY2VudGVye2p1c3RpZnktY29udGVudDpjZW50ZXJ9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmhlYWRlci1hbGlnbi1yaWdodHtqdXN0aWZ5LWNvbnRlbnQ6ZmxleC1lbmR9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kcm9wZG93SWNvblN0eXt2aXNpYmlsaXR5OmhpZGRlbn0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRyb3Bkb3dJY29uU3R5LC5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuc29ydEljb25TdHlDb250YWluZXIgc3Zne3dpZHRoOjE1cHghaW1wb3J0YW50O2hlaWdodDoxNXB4IWltcG9ydGFudDttaW4td2lkdGg6MTVweCFpbXBvcnRhbnQ7bWF4LXdpZHRoOjE1cHghaW1wb3J0YW50fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZHJvcGRvd0ljb25TdHkgc3ZnLC5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuc29ydEljb25TdHlDb250YWluZXIgc3Zne3ZlcnRpY2FsLWFsaWduOm1pZGRsZX0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmNvbHVtbkhlYWRlciAuaGVhZGVyLWNlbGwtbGFiZWwtc3R5e3BhZGRpbmctbGVmdDozcHh9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5jb2x1bW5IZWFkZXIgLmRyb3Bkb3dJY29uU3R5e3Zpc2liaWxpdHk6aGlkZGVufS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuY29sdW1uSGVhZGVyLmRyb3AtaXMtdmlzaWJsZSAuZHJvcGRvd0ljb25TdHksLm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5jb2x1bW5IZWFkZXI6aG92ZXIgLmRyb3Bkb3dJY29uU3R5e3Zpc2liaWxpdHk6dmlzaWJsZX0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmNvbHVtbkhlYWRlci5kcm9wLWlzLXZpc2libGV7YmFja2dyb3VuZC1jb2xvcjojZTFlY2YyfS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuY29sdW1uSGVhZGVyIC50cnVle3Zpc2liaWxpdHk6dmlzaWJsZX0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmNvbHVtbkhlYWRlciAuZmFsc2V7dmlzaWJpbGl0eTpoaWRkZW59Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keXtvdmVyZmxvdy15OmF1dG8haW1wb3J0YW50fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmFsaWduLXJpZ2h0e3BhZGRpbmctcmlnaHQ6MjVweDt0ZXh0LWFsaWduOnJpZ2h0fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmFsaWduLWxlZnR7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmctbGVmdDoxOXB4fS5tYWluLWJveCAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLnNpZGVDb2xvclN0eWxle3Bvc2l0aW9uOmFic29sdXRlO3dpZHRoOjRweDtoZWlnaHQ6NDVweDt0b3A6M3B4O2xlZnQ6MH0ubWFpbi1ib3ggLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5oeXBlckxpbmtDZWxsU3R5e2N1cnNvcjpwb2ludGVyO2NvbG9yOiMyZjc0OTE7dGV4dC1kZWNvcmF0aW9uOm5vbmV9Lm1haW4tYm94IC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LWxlZnR7YmFja2dyb3VuZC1pbWFnZTpub25lO2Rpc3BsYXk6ZmxleH0ubWFpbi1ib3ggLm1vcmUtaWNvbntwb3NpdGlvbjphYnNvbHV0ZTt0b3A6NnB4O3JpZ2h0OjU4cHg7Y3Vyc29yOnBvaW50ZXJ9Lm1haW4tYm94IC5tb3JlLWljb24gLm1hdC1pY29uLWJ1dHRvbntiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7Y3Vyc29yOnBvaW50ZXJ9LnRhYmxlLWxheW91dCAuYWRqdXN0LWZvci1zaG93LWhlYWRlcntvdmVyZmxvdy15OmhpZGRlbiFpbXBvcnRhbnR9YF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSAvL0lmIHlvdSBhcmUgdXNpbmcgUHJpbWVORyBvciBBbmd1bGFyIE1hdGVyaWFsIGluIHlvdXIgcHJvamVjdCB0aGF0IHN0eWxlVXJsIHdpbGwgbm90IHdvcmsgbGlrZSB0aGlzLiBZb3UgbmVlZCB0byBpbXBvcnQgVmlld0VuY2Fwc3VsYXRpb24gYW5kIHB1dCBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lIGluIHRoZSBAY29tcG9uZW50IGRlZmluaXRpb24uXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDb21tb25EYXRhVGFibGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBAVmlld0NoaWxkKCdteWRhdGF0YWJsZScpIG15ZGF0YXRhYmxlOiBhbnk7XHJcblxyXG4gIC8vIGRhdGFcclxuICBASW5wdXQoKSBoZWFkZXJTZXR0aW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICBASW5wdXQoKSBoZWFkZXJIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIEBJbnB1dCgpIGlzRGF0YVRhYmxlUGF1c2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgQElucHV0KCkgcm93czogYW55W10gPSBbXTtcclxuICBASW5wdXQoKSBjaGlsZFJvd3M6IGFueVtdID0gW107XHJcbiAgQElucHV0KCkgYWxlcnREYXRhOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIHJvd0hlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgQElucHV0KCkgY3VzdG9tQ29sdW1uOiBhbnkgPSBbXTsgLy90eXBlIE5vLiBEZXRhaWxzXHJcbiAgQElucHV0KCkgbm9ybWFsQ29sdW1uOiBhbnkgPSBbXTsgLy8gd2lkdGgsIGRyYWdnYWJsZSwgY2FuQXV0b1Jlc2l6ZSAgcHJvcCBoZWFkZXJDbGFzcyBjZWxsQ2xhc3MgaGVhZGVyVGVtcGxhdGUgY2VsbFRlbXBsYXRlIGNvbHVtblNldHRpbmcgZXRjLlxyXG4gIEBJbnB1dCgpIGxpbWl0OiBudW1iZXIgPSA1O1xyXG4gIEBJbnB1dCgpIGZvb3RlckhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgQElucHV0KCkgaGVhZGVyQ2hlY2tCb3g6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBASW5wdXQoKSBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nOiBhbnlbXSA9IFtdO1xyXG4gIEBJbnB1dCgpIGFsbFJvd3NTZWxlY3RlZDogYm9vbGVhbjtcclxuXHJcbiAgLy8gZnVuY3Rpb25cclxuICBASW5wdXQoKSBnZXRBbGxSb3dzRGlzYWJsZWQ6IGFueTtcclxuICBASW5wdXQoKSBnZXRTaW5nbGVSb3dEaXNhYmxlZDogYW55O1xyXG4gIEBJbnB1dCgpIGdldEFsbFJvd0NoZWNrZWQ6IGFueTtcclxuICBASW5wdXQoKSBnZXRTaW5nbGVSb3dDaGVja2VkOiBhbnk7XHJcbiAgQElucHV0KCkgb25TZWxlY3RBbGw6IGFueTtcclxuICBASW5wdXQoKSBvbkNoZWNrYm94Q2hhbmdlOiBhbnk7XHJcbiAgQElucHV0KCkgZGVmYXVsdFNvcnRDb2w6IHN0cmluZztcclxuXHJcbiAgQE91dHB1dCgpIG1lbnVDbG9zZWQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gIEBPdXRwdXQoKSB0b2dnbGVQYXVzZUZsYWdFdmVudDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG5cclxuICBleHBhbmRDaGlsZCA9IGZhbHNlO1xyXG4gIHNlbGVjdGVkQ29sOiAnJztcclxuICBpc1NlbGVjdGVkTWFwOiBhbnlbXSA9IFtdO1xyXG4gIGV4cGFuZENvbGxhcHNlSWNvbk1hcDogYW55W10gPSBbXTtcclxuICBnZXRTb3J0SWNvbkRpc3BsYXlGbGFnOiBhbnkgPSB7fTtcclxuICBpc0RhdGFBdmFpbGFibGUgPSBmYWxzZTtcclxuICBhc2NGbGFnID0gJ2FzYyc7XHJcblxyXG4gIHByaXZhdGUgaW50ZXJ2YWw6IGFueTtcclxuXHJcbiAgaGFzQ2hpbGRyZW4ocm93KSB7ICAgXHJcbiAgICByZXR1cm4gdGhpcy5jaGlsZFJvd3MuZmluZEluZGV4KGl0ZW0gPT4geyByZXR1cm4gaXRlbS5mdW5kaWQgPT09IHJvdy5mdW5kaWQgfSk9PT0tMSA/IGZhbHNlIDogdHJ1ZTtcclxuICB9XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgcHJpdmF0ZSB2aWV3Q29udGFpbmVyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgcHJpdmF0ZSBzaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHM6IFNoYXJlSW5mb0Jld2VlbkNvbXBvbmVudHNTZXJ2aWNlLFxyXG4gICAgcHVibGljIGNvbW1vblV0aWxzOiBDb21tb25VdGlsc1NlcnZpY2UpIHtcclxuICAgIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5jbGlja2VkT3V0U2lkZS5zdWJzY3JpYmUoZSA9PiB7XHJcbiAgICAgLy8gdGhpcy5zZWxlY3RlZENvbCA9ICcnO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIHRoaXMuZXhwYW5kQ29sbGFwc2VJY29uTWFwID0gdGhpcy5zZXREZWZhdWx0RXhwYW5kQ29sbGFwc2VNYXBwaW5nKHRoaXMucm93cyk7XHJcbiAgICB0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWcgPSB0aGlzLnNldERlZmF1bHRTb3J0SWNvbkRpc3BsYXlGbGFnKHRoaXMubm9ybWFsQ29sdW1uKTtcclxuICAgIHRoaXMuZXhwYW5kQ2hpbGQgPSB0aGlzLmNoaWxkUm93cy5sZW5ndGggPiAwID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgdGhpcy5pc0RhdGFBdmFpbGFibGUgPSB0aGlzLnJvd3MubGVuZ3RoID4gMCA/IHRydWUgOiBmYWxzZTtcclxuICAgIGxldCBkYXRhID0gdGhpcy5nZXRTb3J0Q29sdW1uRGV0YWlsc0luZm8oKTtcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNvcnREYXRhdGFibGVDb2x1bW4uZW1pdChkYXRhKTtcclxuICB9XHJcblxyXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcclxuICAgIGNvbnN0IGxheU91dENvbXAgPWRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2xheW91dC1pdGVtJylbMV07XHJcbiAgICBpZihsYXlPdXRDb21wKSB7XHJcbiAgICAgIGxheU91dENvbXAuY2xhc3NMaXN0LmFkZCgndGFibGUtbGF5b3V0JylcclxuICAgICAgdGhpcy5vblJlc2l6ZShldmVudClcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBzZXREZWZhdWx0RXhwYW5kQ29sbGFwc2VNYXBwaW5nKGRhdGEpOiBhbnlbXSB7XHJcbiAgICBsZXQgbWFwcGluZ0FyciA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBsZXQgb2JqID0ge1xyXG4gICAgICAgIGZ1bmRpZDogaXRlbS5mdW5kaWQsXHJcbiAgICAgICAgZXhwYW5kOiBmYWxzZVxyXG4gICAgICB9O1xyXG4gICAgICBtYXBwaW5nQXJyLnB1c2gob2JqKTtcclxuICAgIH0pXHJcbiAgICByZXR1cm4gbWFwcGluZ0FycjtcclxuICB9XHJcblxyXG4gIHNldERlZmF1bHRTb3J0SWNvbkRpc3BsYXlGbGFnKGNvbHVtbik6IGFueSB7XHJcbiAgICBsZXQgdGVtcE1hcCA9IHt9O1xyXG4gICAgY29sdW1uLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGxldCBvYmogPSBuZXcgT2JqZWN0KCk7XHJcbiAgICAgIG9ialtpdGVtLnByb3BdID0gZmFsc2U7XHJcbiAgICAgIHRlbXBNYXAgPSBPYmplY3QuYXNzaWduKF8uY2xvbmVEZWVwKHRlbXBNYXApLCBvYmopO1xyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wTWFwO1xyXG4gIH1cclxuXHJcbiAgZ2V0U29ydENvbHVtbkRldGFpbHNJbmZvKCkge1xyXG4gICAgbGV0IG9iaiA9IHtcclxuICAgICAgbWFwOiB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcCxcclxuICAgICAgcHJvcDogdGhpcy5kZWZhdWx0U29ydENvbCxcclxuICAgICAgYXNjRmxhZzogdHJ1ZVxyXG4gICAgfTtcclxuICAgIHRoaXMubm9ybWFsQ29sdW1uLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnNvcnRDb2x1bW5Bc2NPckRlc2MpIHtcclxuICAgICAgb2JqID0ge1xyXG4gICAgICAgIG1hcDogdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAsXHJcbiAgICAgICAgcHJvcDogaXRlbS5wcm9wLFxyXG4gICAgICAgIGFzY0ZsYWc6IGl0ZW0uc29ydENvbHVtbkFzY09yRGVzYyA9PT0gJ2FzYycgPyB0cnVlIDogZmFsc2VcclxuICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIG9iajtcclxuICB9XHJcblxyXG4gIGdldEhlYWRlckNsYXNzKGNvbHVtbik6IGFueSB7XHJcbiAgICBzd2l0Y2ggKGNvbHVtbi5oZWFkZXJDbGFzc0Zvcm1hdCkge1xyXG4gICAgICBjYXNlICdoZWFkZXJMZWZ0JzpcclxuICAgICAgICByZXR1cm4gJ2NvbHVtbkhlYWRlciBoZWFkZXItYWxpZ24tbGVmdCc7XHJcbiAgICAgIGNhc2UgJ2hlYWRlckNlbnRlcic6XHJcbiAgICAgICAgcmV0dXJuICdjb2x1bW5IZWFkZXIgaGVhZGVyLWFsaWduLWNlbnRlcic7XHJcbiAgICAgIGNhc2UgJ2hlYWRlclJpZ2h0JzpcclxuICAgICAgICByZXR1cm4gJ2NvbHVtbkhlYWRlciBoZWFkZXItYWxpZ24tcmlnaHQnO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAnY29sdW1uSGVhZGVyJztcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldENlbGxDbGFzcyhyb3csIGNvbHVtbiwgdmFsdWUpOiBhbnkge1xyXG4gICAgc3dpdGNoIChjb2x1bW4uY2VsbENsYXNzRm9ybWF0KSB7XHJcbiAgICAgIGNhc2UgJ2NlbGxMZWZ0JzpcclxuICAgICAgICByZXR1cm4gJyBhbGlnbi1sZWZ0J1xyXG4gICAgICBjYXNlICdjZWxsUmlnaHQnOlxyXG4gICAgICAgIHJldHVybiAnIGFsaWduLXJpZ2h0JztcclxuICAgICAgY2FzZSAnY2VsbE51bWJlcic6ICAvLyBuZWVkIG1vcmUgYW5seXplIGhlcmVcclxuICAgICAgICBpZiAodmFsdWUgIT09IDApIHtcclxuICAgICAgICAgIGlmICh2YWx1ZS50b1N0cmluZygpLmluZGV4T2YoJy0nKSAhPT0gLTEgJiYgdmFsdWUudG9TdHJpbmcoKS5pbmRleE9mKCctJykgPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtbmFnZXRpdmUnO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtcG9zaXRpdmUnO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAoY29sdW1uLnByb3AgPT09ICduYXZDaGFuZ2VQZXJjZW50Jykge1xyXG4gICAgICAgICAgaWYgKHJvd1snbmF2Q2hhbmdlJ10udG9TdHJpbmcoKS5pbmRleE9mKCctJykgIT09IC0xICYmIHJvd1snbmF2Q2hhbmdlJ10udG9TdHJpbmcoKS5pbmRleE9mKCctJykgPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtbmFnZXRpdmUnO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtcG9zaXRpdmUnO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAoY29sdW1uLnByb3AgPT09ICdmdW5kbXZDaGFuZ2VQZXJjZW50Jykge1xyXG4gICAgICAgICAgaWYgKHJvd1snZnVuZG12Q2hhbmdlJ10udG9TdHJpbmcoKS5pbmRleE9mKCctJykgIT09IC0xICYmIHJvd1snZnVuZG12Q2hhbmdlJ10udG9TdHJpbmcoKS5pbmRleE9mKCctJykgPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtbmFnZXRpdmUnO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuICcgaXMtcG9zaXRpdmUnO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZih2YWx1ZSA9PT0gMCkge1xyXG4gICAgICAgICAgcmV0dXJuICcgaXMtemVybyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tc3dpdGNoLWNhc2UtZmFsbC10aHJvdWdoXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0Q29sU2V0dGluZ1dpZHRoKGNvbCkge1xyXG4gICAgaWYgKGNvbCAmJiBjb2wud2lkdGggJiYgIWlzTmFOKE51bWJlcihjb2wud2lkdGgpKSkge1xyXG4gICAgICByZXR1cm4gY29sLndpZHRoO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIDE1MDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHNob3dZZWxsb3dBbGVydChmdW5kLCBjbGFzc0lEKTogYm9vbGVhbiB7XHJcbiAgICBsZXQgc2hvdyA9IGZhbHNlO1xyXG4gICAgc2hvdyA9IHRoaXMuYWxlcnREYXRhLmZpbmQoaXRlbSA9PiBpdGVtLm5hbWUgPT09IGZ1bmQgJiYgaXRlbS5jbGFzc0lEID09PSBjbGFzc0lEICYmaXRlbS5hbGVydFR5cGUgPT09IDEpXHJcbiAgICByZXR1cm4gc2hvdztcclxuICB9XHJcblxyXG4gIHNob3dSZWRBbGVydChmdW5kLCBjbGFzc0lEKTogYm9vbGVhbiB7XHJcbiAgICBsZXQgc2hvdyA9IGZhbHNlO1xyXG4gICAgc2hvdyA9IHRoaXMuYWxlcnREYXRhLmZpbmQoaXRlbSA9PiBpdGVtLm5hbWUgPT09IGZ1bmQgJiYgaXRlbS5jbGFzc0lEID09PSBjbGFzc0lEICYmIGl0ZW0uYWxlcnRUeXBlID09PSAyKVxyXG4gICAgcmV0dXJuIHNob3c7XHJcbiAgfVxyXG5cclxuICBzaG93TmV3cyhyb3cpOiBib29sZWFuIHtcclxuICAgIC8vIGFjY29yZGluZyB0byByb3cgaW5mbyB0byBkZXRlcm1pbmUgc2hvdyBuZXdzIGljb24gb3Igbm90IFxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG5cclxuICBnZXRTaWRlQ29sb3JTdHlsZShyb3cpOiBzdHJpbmcge1xyXG4gICAgbGV0IGJhY2tncm91bmRDb2xvciA9ICcnO1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuY29sb3JTY2hlbWEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKHJvdyAmJiByb3dbJ2Z1bmRpZCddICYmIGl0ZW1bJ2Z1bmRpZCddID09PSByb3dbJ2Z1bmRpZCddKSB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yID0gaXRlbVsnY29sb3InXTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gYmFja2dyb3VuZENvbG9yO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlRXhwYW5kUm93KHJvdykge1xyXG4gICAgY29uc3QgcGFyZW50RnVuZElkID0gcm93LmZ1bmRpZDtcclxuICAgIGxldCBjdXJyZW50RXhwYW5kO1xyXG4gICAgdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKHBhcmVudEZ1bmRJZCA9PT0gaXRlbS5mdW5kaWQpIHtcclxuICAgICAgICBpdGVtLmV4cGFuZCA9ICFpdGVtLmV4cGFuZDtcclxuICAgICAgICBjdXJyZW50RXhwYW5kID0gaXRlbS5leHBhbmQ7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgY29uc3QgaW5kZXggPSB0aGlzLnJvd3MuZmluZEluZGV4KGl0ZW0gPT4geyByZXR1cm4gaXRlbS5mdW5kaWQgPT09IHBhcmVudEZ1bmRJZCB9KTtcclxuICAgIHRoaXMuY2hpbGRSb3dzLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLmZ1bmRpZCA9PT0gcGFyZW50RnVuZElkKSB7XHJcbiAgICAgICAgY3VycmVudEV4cGFuZCA/IHRoaXMucm93cy5zcGxpY2UoaW5kZXggKyAxLCAwLCBpdGVtKSA6IHRoaXMucm93cy5zcGxpY2UoaW5kZXggKyAxLCAxKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBnZXRFeHBhbmRDb2xsYXBzZUljb24ocm93KTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGZ1bmRpZCA9IHJvdy5mdW5kaWQ7XHJcbiAgICBsZXQgZXhwYW5kRmxhZyA9IGZhbHNlO1xyXG4gICAgdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGZ1bmRpZCA9PT0gaXRlbS5mdW5kaWQpIGV4cGFuZEZsYWcgPSBpdGVtLmV4cGFuZDtcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJvdy5jaGlsZCA9PT0gXCJjaGlsZFwiID8gXCJcIiA6IGV4cGFuZEZsYWcgPyBcImFycm93X2Rvd25cIiA6IFwiYXJyb3dfcmlnaHRcIjtcclxuICB9XHJcblxyXG4gIGdldFJvd0hlaWdodChwYXJhKSB7XHJcbiAgIC8vIGRlYnVnZ2VyO1xyXG4gICAgcGFyYSA9PT0gJ3N0YW5kYXJkJyA/IHRoaXMucm93SGVpZ2h0ID0gNTAgOiB0aGlzLnJvd0hlaWdodCA9IDQwO1xyXG4gIH1cclxuXHJcbiAgb25DbGlja2VkT3V0c2lkZShlOiBFdmVudCkge1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuY2xpY2tlZE91dFNpZGUuZW1pdChlKTtcclxuICB9XHJcblxyXG4gIHNlbGVjdEN1cnJlbnRDb2woZXZlbnQsIHByb3ApIHtcclxuICAgIHRoaXMuc2VsZWN0ZWRDb2wgPSBwcm9wO1xyXG4gICAgZXZlbnQuY3VycmVudFRhcmdldC5jbGFzc0xpc3QuYWRkKFwiZHJvcC1pcy12aXNpYmxlXCIpO1xyXG4gIH1cclxuXHJcbiAgY2xvc2VNZW51KCkge1xyXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImRyb3AtaXMtdmlzaWJsZVwiKVswXS5jbGFzc0xpc3QucmVtb3ZlKFwiZHJvcC1pcy12aXNpYmxlXCIpO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgb25SZXNpemUoZXZlbnQpIHtcclxuICAgLy9jYWxjdXRlICBkYXRhdGFibGUtYm9keSBoZWlnaHQgYWNjb3JkaW5nIHRvIGdyaWRzdGVyLWl0ZW0gaGVpZ2h0IFxyXG4gICB2YXIgaGVpZ2h0PU51bWJlcigoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgndGFibGUtbGF5b3V0JylbMF0gYXMgSFRNTEVsZW1lbnQpLnN0eWxlLmhlaWdodC5zbGljZSgwLCBsZW5ndGgtMikpO1xyXG4gICB2YXIgdGFibGVCb2R5SGVpZ2h0PTI2MDtcclxuXHJcbiAgICBoZWlnaHQgPSAoaGVpZ2h0LTE0OCApPiB0YWJsZUJvZHlIZWlnaHQgPyB0YWJsZUJvZHlIZWlnaHQgOiBoZWlnaHQtMTQ4O1xyXG4gICAgaWYoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnZGF0YXRhYmxlLWJvZHknKVswXSl7XHJcbiAgICAoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnZGF0YXRhYmxlLWJvZHknKVswXSBhcyBIVE1MRWxlbWVudCkuc3R5bGUuaGVpZ2h0ID0gaGVpZ2h0ICsgJ3B4JztcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldE1hdE1lbnVJdGVtRGlzcGxheW5hbWUobmFtZSkge1xyXG4gICAgc3dpdGNoIChuYW1lKSB7XHJcbiAgICAgIGNhc2UgJ1NvcnQgQ29sdW1uJzpcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRTb3J0SWNvbkRpc3BsYXlGbGFnW3RoaXMuc2VsZWN0ZWRDb2xdID8gJ0Rpc2FibGUgU29ydCcgOiAnU29ydCBDb2x1bW4nO1xyXG4gICAgICBjYXNlICdGcmVlemUgQ29sdW1uJzpcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRGcm96ZW5JY29uRGlzcGxheUZhbGcodGhpcy5zZWxlY3RlZENvbCkgPyAnVW5mcmVlemUgQ29sdW1uJyA6ICdGcmVlemUgQ29sdW1uJ1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiBuYW1lO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0RnJvemVuSWNvbkRpc3BsYXlGYWxnKGNvbFByb3ApIHtcclxuICAgIGxldCBmcmVlemVGbGFnID0gZmFsc2U7XHJcbiAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5wcm9wID09PSBjb2xQcm9wICYmIGl0ZW0uZnJvemVuTGVmdCkge1xyXG4gICAgICAgIGZyZWV6ZUZsYWcgPSB0cnVlXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gZnJlZXplRmxhZztcclxuICB9XHJcblxyXG4gIGhhbmRsZU1lbnVJdGVtQ2xpY2sodHlwZSkge1xyXG4gICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgIGNhc2UgJ3Jlc2l6ZVRvRml0JzpcclxuICAgICAgICB0aGlzLnJlc2l6ZVRvRml0KCk7XHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIGNhc2UgJ2ZyZWV6ZUNvbHVtbic6XHJcbiAgICAgICAgdGhpcy5mcmVlemVDb2x1bW4oKTtcclxuICAgICAgICByZXR1cm5cclxuICAgICAgY2FzZSAnc29ydENvbHVtbic6XHJcbiAgICAgICAgdGhpcy5zb3J0Q29sdW1uKCk7XHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy90b2RvLi4uXHJcbiAgcmVzaXplVG9GaXQoKSB7XHJcbiAgICBjb25zb2xlLmxvZyh0aGlzLnNlbGVjdGVkQ29sKTtcclxuICAgIHRoaXMuc2VsZWN0ZWRDb2wgPSBcIlwiO1xyXG4gIH1cclxuXHJcbiAgZnJlZXplQ29sdW1uKCkge1xyXG4gICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaCgoaXRlbSwgaSkgPT4ge1xyXG4gICAgICBpZiAoaXRlbS5wcm9wID09IHRoaXMuc2VsZWN0ZWRDb2wpIHtcclxuICAgICAgICBpdGVtLmZyb3plbkxlZnQgPSAhaXRlbS5mcm96ZW5MZWZ0O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgfVxyXG5cclxuICBzeW5jQ29sdW1uU2V0dGluZ0ZvclNvcnRGbGFnKHNlbGVjdGVkQ29sKSB7XHJcbiAgICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaCgoaXRlbSwgaSkgPT4ge1xyXG4gICAgICBpZiAoaXRlbS5wcm9wID09PSBzZWxlY3RlZENvbCApIHtcclxuICAgICAgICBpdGVtLnNvcnRDb2x1bW5Bc2NPckRlc2MgPSB0aGlzLmFzY0ZsYWc7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaXRlbS5zb3J0Q29sdW1uQXNjT3JEZXNjID0gJyc7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgc29ydENvbHVtbigpIHtcclxuICAgdGhpcy5zeW5jQ29sdW1uU2V0dGluZ0ZvclNvcnRGbGFnKHRoaXMuc2VsZWN0ZWRDb2wpO1xyXG4gICAgZm9yIChsZXQga2V5IGluIHRoaXMuZ2V0U29ydEljb25EaXNwbGF5RmxhZykge1xyXG4gICAgICBpZiAoa2V5ID09PSB0aGlzLnNlbGVjdGVkQ29sKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmdldFNvcnRJY29uRGlzcGxheUZsYWdba2V5XSkge1xyXG4gICAgICAgICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgICAgICAgIG1hcDogdGhpcy5leHBhbmRDb2xsYXBzZUljb25NYXAsXHJcbiAgICAgICAgICAgIHByb3A6IHRoaXMuc2VsZWN0ZWRDb2wsXHJcbiAgICAgICAgICAgIGFzY0ZsYWc6IHRydWVcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zb3J0RGF0YXRhYmxlQ29sdW1uLmVtaXQoZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIHRoZSBkZWZhdWx0IG9yZGVyIGlzIHNvcnRlZCBieSBmdW5kaWQuXHJcbiAgICAgICAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgICAgICAgbWFwOiB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcCxcclxuICAgICAgICAgICAgcHJvcDogdGhpcy5kZWZhdWx0U29ydENvbCxcclxuICAgICAgICAgICAgYXNjRmxhZzogdHJ1ZVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNvcnREYXRhdGFibGVDb2x1bW4uZW1pdChkYXRhKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5nZXRTb3J0SWNvbkRpc3BsYXlGbGFnW2tleV0gPSAhdGhpcy5nZXRTb3J0SWNvbkRpc3BsYXlGbGFnW2tleV07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5nZXRTb3J0SWNvbkRpc3BsYXlGbGFnW2tleV0gPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5zZWxlY3RlZENvbCA9IFwiXCI7XHJcbiAgfVxyXG5cclxuICBjaGFuZ2VBc2NBbmREZXNjU29ydChlLCBwcm9wKSB7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgaWYgKHRoaXMuYXNjRmxhZyA9PT0gXCJhc2NcIikge1xyXG4gICAgICB0aGlzLmFzY0ZsYWcgPSBcImRlc2NcIjtcclxuICAgICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgICAgbWFwOiB0aGlzLmV4cGFuZENvbGxhcHNlSWNvbk1hcCxcclxuICAgICAgICBwcm9wOiBwcm9wLFxyXG4gICAgICAgIGFzY0ZsYWc6IGZhbHNlXHJcbiAgICAgIH07XHJcbiAgICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLnNvcnREYXRhdGFibGVDb2x1bW4uZW1pdChkYXRhKTtcclxuICAgIH0gZWxzZSBpZiAodGhpcy5hc2NGbGFnID09PSBcImRlc2NcIikge1xyXG4gICAgICB0aGlzLmFzY0ZsYWcgPSBcImFzY1wiO1xyXG4gICAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgICBtYXA6IHRoaXMuZXhwYW5kQ29sbGFwc2VJY29uTWFwLFxyXG4gICAgICAgIHByb3A6IHByb3AsXHJcbiAgICAgICAgYXNjRmxhZzogdHJ1ZVxyXG4gICAgICB9O1xyXG4gICAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zb3J0RGF0YXRhYmxlQ29sdW1uLmVtaXQoZGF0YSk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnN5bmNDb2x1bW5TZXR0aW5nRm9yU29ydEZsYWcocHJvcCk7XHJcbiAgICB0aGlzLnNlbGVjdGVkQ29sID0gXCJcIjtcclxuICB9XHJcblxyXG4gIGdldFNvcnRJY29uRGlzcGxheVN0eShwcm9wKSB7XHJcbiAgICBsZXQgdmlzaWJpbGl0eSA9IGZhbHNlO1xyXG4gICAgdGhpcy5ub3JtYWxDb2x1bW4uZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0ucHJvcCA9PT0gcHJvcCAmJiBpdGVtLnNvcnRDb2x1bW5Bc2NPckRlc2MpIHZpc2liaWxpdHkgPSB0cnVlO1xyXG4gICAgfSlcclxuICAgIHJldHVybiB2aXNpYmlsaXR5O1xyXG4gIH1cclxuXHJcbiAgZ2V0U29ydEljb24ocHJvcCkge1xyXG4gICAgbGV0IGljb24gPSAnJztcclxuICAgIHRoaXMubm9ybWFsQ29sdW1uLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtLnByb3AgPT09IHByb3ApXHJcbiAgICAgIGljb24gPSBpdGVtLnNvcnRDb2x1bW5Bc2NPckRlc2NcclxuICAgIH0pXHJcbiAgICBpZiAoaWNvbiAhPT0gJycpIHtcclxuICAgICAgcmV0dXJuIGljb24gPT09IFwiYXNjXCIgPyBcImNpcmNsZV9hcnJvd191cFwiIDogXCJjaXJjbGVfYXJyb3dfZG93blwiO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHRoaXMuYXNjRmxhZyA9PT0gXCJhc2NcIiA/IFwiY2lyY2xlX2Fycm93X3VwXCIgOiBcImNpcmNsZV9hcnJvd19kb3duXCI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZW1vdmVPckFkZENvbHVtbihjb2wsIGluZGV4KSB7XHJcbiAgICBjb25zb2xlLmxvZyhjb2wucHJvcCArIFwiLS0tXCIgKyBpbmRleCArIFwiLS1cIiArIHRoaXMuc2VsZWN0ZWRDb2wpO1xyXG4gICAgdGhpcy5zZWxlY3RlZENvbCA9IFwiXCI7XHJcbiAgfVxyXG5cclxuICBoeXBlckxpbmtOYXZpZ2F0ZShyb3cpIHtcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmh5cGVyTGlua05hdmlnYXRlLmVtaXQocm93KTtcclxuICB9XHJcblxyXG4gIG9wZW5BbGVydE1vZGFsKHJvdywgdHlwZSkge1xyXG4gICAgbGV0IG9iaiA9IHtcclxuICAgICAgcm93RGF0YTogcm93LFxyXG4gICAgICB0eXBlOiB0eXBlXHJcbiAgICB9O1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMub3Blbk1vZGFsRGF0YS5lbWl0KG9iailcclxuICB9XHJcblxyXG4gIHRvZ2dsZVBhdXNlRmxhZygpIHtcclxuICAgIHRoaXMuaXNEYXRhVGFibGVQYXVzZWQgPSAhdGhpcy5pc0RhdGFUYWJsZVBhdXNlZDtcclxuICAgIHRoaXMudG9nZ2xlUGF1c2VGbGFnRXZlbnQuZW1pdCgpO1xyXG4gIH1cclxuXHJcbn1cclxuIiwiZXhwb3J0IGNvbnN0IGN1c3RvbUNvbHVtbiA9IFtcclxuICAgIHtcclxuICAgICAgdHlwZTogXCJyZWRBbGVydFwiLFxyXG4gICAgICBkZXRhaWxzOiBcIlwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdHlwZTogXCJ5ZWxsb3dBbGVydFwiLFxyXG4gICAgICBkZXRhaWxzOiBcIlwiLFxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGV4cG9ydCBjb25zdCBub3JtYWxDb2x1bW4gPSAgW1xyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbmFtZScsXHJcbiAgICAgIG5hbWU6ICdFbnRpdHkgTmFtZScsXHJcbiAgICAgIHdpZHRoOiAyMDAsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2h5cGVyTGluaycsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyQ2VudGVyJyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbENlbnRlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnZnVuZGlkJyxcclxuICAgICAgbmFtZTogJ0VudGl0eSBJZCBSZWYnLFxyXG4gICAgICB3aWR0aDogMTIwLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IGZhbHNlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdkZWZhdWx0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJMZWZ0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbExlZnQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ2Z1bmRUaWNrZXInLFxyXG4gICAgICBuYW1lOiAnRW50aXR5IFRpY2tlcicsXHJcbiAgICAgIHdpZHRoOiAxMjAsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogZmFsc2UsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ2RlZmF1bHQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlckxlZnQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTGVmdCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnY2xhc3NJRCcsXHJcbiAgICAgIG5hbWU6ICdDbGFzcyBJRCcsXHJcbiAgICAgIHdpZHRoOiA4MCxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdkZWZhdWx0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJMZWZ0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbExlZnQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ3NvZE5hdicsXHJcbiAgICAgIG5hbWU6ICdOQVYgUHJldmlvdXMnLFxyXG4gICAgICB3aWR0aDogMTI1LFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdExvbmcnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbFJpZ2h0JyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICduYXYnLFxyXG4gICAgICBuYW1lOiAnTkFWIEN1cnJlbnQnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0TG9uZycsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsUmlnaHQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ25hdkNoYW5nZScsXHJcbiAgICAgIG5hbWU6ICdOQVYgQ2hhbmdlJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdExvbmcnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbE51bWJlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnbmF2Q2hhbmdlUGVyY2VudCcsXHJcbiAgICAgIG5hbWU6ICdOQVYgJSBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAncGVyY2VudEZvcm1hdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdzb2RUbmEnLFxyXG4gICAgICBuYW1lOiAnVE5BIFByZXZpb3VzJyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAndG5hJyxcclxuICAgICAgbmFtZTogJ1ROQSBDdXJyZW50JyxcclxuICAgICAgd2lkdGg6ICcnLFxyXG4gICAgICBkcmFnZ2FibGU6IHRydWUsXHJcbiAgICAgIGNhbkF1dG9SZXNpemU6IHRydWUsXHJcbiAgICAgIGNvbHVtblNldHRpbmc6IHRydWUsXHJcbiAgICAgIGNlbGxUZW1wbGF0ZTogJ251bWJlckZvcm1hdFNob3J0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxSaWdodCcsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAndG5hQ2hhbmdlJyxcclxuICAgICAgbmFtZTogJ1ROQSBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbE51bWJlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAndG5hQ2hhbmdlUGVyY2VudCcsXHJcbiAgICAgIG5hbWU6ICdUTkEgJSBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAncGVyY2VudEZvcm1hdCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsTnVtYmVyJyxcclxuICAgICAgdHJlZVRvZ2dsZVRlbXBsYXRlOiAnY29sdW1uSGVhZGVyTWVudScsXHJcbiAgICAgIGZyb3plbkxlZnQ6IGZhbHNlLFxyXG4gICAgICBzb3J0Q29sdW1uQXNjT3JEZXNjOiAnJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByb3A6ICdzb2RNdicsXHJcbiAgICAgIG5hbWU6ICdNViBBbXQgQmFzZSBQcmV2aW91cycsXHJcbiAgICAgIHdpZHRoOiAnMjAwJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRTaG9ydCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsUmlnaHQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ2Z1bmRtdicsXHJcbiAgICAgIG5hbWU6ICdNViBBbXQgQmFzZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdudW1iZXJGb3JtYXRTaG9ydCcsXHJcbiAgICAgIGhlYWRlckNsYXNzRm9ybWF0OiAnaGVhZGVyUmlnaHQnLFxyXG4gICAgICBjZWxsQ2xhc3NGb3JtYXQ6ICdjZWxsUmlnaHQnLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcHJvcDogJ2Z1bmRtdkNoYW5nZScsXHJcbiAgICAgIG5hbWU6ICdNViBDaGFuZ2UnLFxyXG4gICAgICB3aWR0aDogJycsXHJcbiAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcclxuICAgICAgY2FuQXV0b1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgY29sdW1uU2V0dGluZzogdHJ1ZSxcclxuICAgICAgY2VsbFRlbXBsYXRlOiAnbnVtYmVyRm9ybWF0U2hvcnQnLFxyXG4gICAgICBoZWFkZXJDbGFzc0Zvcm1hdDogJ2hlYWRlclJpZ2h0JyxcclxuICAgICAgY2VsbENsYXNzRm9ybWF0OiAnY2VsbE51bWJlcicsXHJcbiAgICAgIHRyZWVUb2dnbGVUZW1wbGF0ZTogJ2NvbHVtbkhlYWRlck1lbnUnLFxyXG4gICAgICBmcm96ZW5MZWZ0OiBmYWxzZSxcclxuICAgICAgc29ydENvbHVtbkFzY09yRGVzYzogJycsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwcm9wOiAnZnVuZG12Q2hhbmdlUGVyY2VudCcsXHJcbiAgICAgIG5hbWU6ICdNViAlIENoYW5nZScsXHJcbiAgICAgIHdpZHRoOiAnJyxcclxuICAgICAgZHJhZ2dhYmxlOiB0cnVlLFxyXG4gICAgICBjYW5BdXRvUmVzaXplOiB0cnVlLFxyXG4gICAgICBjb2x1bW5TZXR0aW5nOiB0cnVlLFxyXG4gICAgICBjZWxsVGVtcGxhdGU6ICdwZXJjZW50Rm9ybWF0JyxcclxuICAgICAgaGVhZGVyQ2xhc3NGb3JtYXQ6ICdoZWFkZXJSaWdodCcsXHJcbiAgICAgIGNlbGxDbGFzc0Zvcm1hdDogJ2NlbGxOdW1iZXInLFxyXG4gICAgICB0cmVlVG9nZ2xlVGVtcGxhdGU6ICdjb2x1bW5IZWFkZXJNZW51JyxcclxuICAgICAgZnJvemVuTGVmdDogZmFsc2UsXHJcbiAgICAgIHNvcnRDb2x1bW5Bc2NPckRlc2M6ICcnLFxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGV4cG9ydCBjb25zdCBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nID0gW1xyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBcIlJlc2l6ZSB0byBGaXRcIixcclxuICAgIC8vICAgdHlwZTogXCJyZXNpemVUb0ZpdFwiLFxyXG4gICAgLy8gICBoYXNTdWJNZW51OiBmYWxzZSxcclxuICAgIC8vIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6IFwiRnJlZXplIENvbHVtblwiLFxyXG4gICAgICB0eXBlOiBcImZyZWV6ZUNvbHVtblwiLFxyXG4gICAgICBoYXNTdWJNZW51OiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIG5hbWU6IFwiU29ydCBDb2x1bW5cIixcclxuICAgICAgdHlwZTogXCJzb3J0Q29sdW1uXCIsXHJcbiAgICAgIGhhc1N1Yk1lbnU6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogXCJWaWV3IE1vcmUgQ29sdW1uc1wiLFxyXG4gICAgLy8gICB0eXBlOiBcInZpZXdNb3JlQ29sdW1uc1wiLFxyXG4gICAgLy8gICBoYXNTdWJNZW51OiB0cnVlLFxyXG4gICAgLy8gfSxcclxuICBdOyIsImltcG9ydCB7XHJcbiAgQ29tcG9uZW50LFxyXG4gIFZpZXdDaGlsZCxcclxuICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICBDaGFuZ2VEZXRlY3RvclJlZixcclxuICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gIEhvc3RMaXN0ZW5lclxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBCYXNlV2lkZ2V0Q29tcG9uZW50LCBBcHBDb250ZXh0LCBBcHBSZWdpc3RyeSB9IGZyb20gJ0BvbW5pYS91aS1jb21tb24nO1xyXG5pbXBvcnQgeyBOYXZTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvbmF2LXNlcnZpY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdlNvY2tldFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9uYXYtc29ja2V0LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDb21tb25VdGlsc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb21tb24tdXRpbHMuc2VydmljZSc7XHJcbmltcG9ydCB7IE1hdERpYWxvZyB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsJztcclxuaW1wb3J0IHsgQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCB9IGZyb20gJy4uL2N1c3RvbS1hbGVydC1tb2RhbC9jdXN0b20tYWxlcnQtbW9kYWwuY29tcG9uZW50JztcclxuaW1wb3J0IHsgU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zaGFyZS1pbmZvLWJld2Vlbi1jb21wb25lbnRzLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUmVzb3VyY2VNYW5hZ2VyU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL3Jlc291cmNlLW1hbmFnZXIuc2VydmljZSc7XHJcbmltcG9ydCB7IGN1c3RvbUNvbHVtbiwgbm9ybWFsQ29sdW1uLCBjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nIH0gZnJvbSAnLi9jb2x1bW4tZGF0YSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2xpYi1tYWluLWRhdGF0YWJsZScsXHJcbiAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPVwiZGF0YXRhYmxlQ29udGFpbmVyXCIgKm5nSWY9XCJpc0RhdGFBdmFpbGFibGVcIiAoY2xpY2tPdXRzaWRlKT1cIm9uQ2xpY2tlZE91dHNpZGUoJGV2ZW50KVwiPlxyXG5cclxuICA8ZGl2IGNsYXNzPVwibGl2ZS10aW1lLWZvci10aXRsZVwiPlxyXG4gICAgPHAgKm5nSWY9XCJjb21tb25VdGlscy5pc0FmdGVyTWFya2V0Q2xvc2UgZWxzZSBlbHNlQmxvY2tcIj5GaW5hbCBEYXRhIChcclxuICAgICAge3tjb21tb25VdGlscy5saXZlVGltZSB8IGRhdGU6XCJNTS9kZC95eXl5LCBoOm1tIGFhYWFhJ20nXCJ9fSApPC9wPlxyXG4gICAgPG5nLXRlbXBsYXRlICNlbHNlQmxvY2s+XHJcbiAgICAgIDxwPlxyXG4gICAgICAgIFJlYWwgVGltZSBEYXRhICh7e2NvbW1vblV0aWxzLmxpdmVUaW1lIHwgZGF0ZTpcIk1NL2RkL3l5eXksIGg6bW0gYWFhYWEnbSdcIn19KVxyXG4gICAgICA8L3A+XHJcbiAgICA8L25nLXRlbXBsYXRlPlxyXG4gIDwvZGl2PlxyXG4gIFxyXG48bGliLWNvbW1vbi1kYXRhLXRhYmxlXHJcbltoZWFkZXJTZXR0aW5nXT1cImhlYWRlclNldHRpbmdcIlxyXG5baXNEYXRhVGFibGVQYXVzZWRdPVwiaXNEYXRhVGFibGVQYXVzZWRcIlxyXG5baGVhZGVySGVpZ2h0XT1cImhlYWRlckhlaWdodFwiXHJcbltyb3dzXT1cInJvd3NcIlxyXG5bY2hpbGRSb3dzXT1cImNoaWxkUm93c1wiXHJcblthbGVydERhdGFdPVwiYWxlcnREYXRhXCJcclxuW3Jvd0hlaWdodF09XCJyb3dIZWlnaHRcIlxyXG5bY3VzdG9tQ29sdW1uXT1cImN1c3RvbUNvbHVtblwiXHJcbltub3JtYWxDb2x1bW5dPVwibm9ybWFsQ29sdW1uXCJcclxuW2xpbWl0XT1cImxpbWl0XCJcclxuW2Zvb3RlckhlaWdodF09XCJmb290ZXJIZWlnaHRcIlxyXG5baGVhZGVyQ2hlY2tCb3hdPVwiaGVhZGVyQ2hlY2tCb3hcIlxyXG5bZ2V0QWxsUm93c0Rpc2FibGVkXT1cImdldEFsbFJvd3NEaXNhYmxlZFwiXHJcbltnZXRTaW5nbGVSb3dEaXNhYmxlZF09XCJnZXRTaW5nbGVSb3dEaXNhYmxlZFwiXHJcbltnZXRBbGxSb3dDaGVja2VkXT1cImdldEFsbFJvd0NoZWNrZWRcIlxyXG5bZ2V0U2luZ2xlUm93Q2hlY2tlZF09XCJnZXRTaW5nbGVSb3dDaGVja2VkXCJcclxuW29uU2VsZWN0QWxsXT1cIm9uU2VsZWN0QWxsXCJcclxuW29uQ2hlY2tib3hDaGFuZ2VdPVwib25DaGVja2JveENoYW5nZVwiXHJcblthbGxSb3dzU2VsZWN0ZWRdPVwiYWxsUm93c1NlbGVjdGVkXCJcclxuW2NvbHVtbk1lbnVEcm9wRG93blNldHRpbmddPSdjb2x1bW5NZW51RHJvcERvd25TZXR0aW5nJ1xyXG5bZGVmYXVsdFNvcnRDb2xdPVwiJ2Z1bmRpZCdcIlxyXG4odG9nZ2xlUGF1c2VGbGFnRXZlbnQpPVwidG9nZ2xlUGF1c2VGbGFnKClcIlxyXG4+XHJcbjwvbGliLWNvbW1vbi1kYXRhLXRhYmxlPlxyXG48L2Rpdj5gLFxyXG4gIHN0eWxlczogW2Aubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zdHJpcGVkIC5kYXRhdGFibGUtcm93LW9kZHtiYWNrZ3JvdW5kOiNlZWV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmUsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZSAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMzMDRmZmU7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktY2xpY2stc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3VwLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuc2luZ2xlLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzE5M2FlNDtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLWNsaWNrLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cywubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5tdWx0aS1jbGljay1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwubXVsdGktc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLm11bHRpLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktcm93LmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5zaW5nbGUtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1yb3cuYWN0aXZlOmZvY3VzLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLnNpbmdsZS1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LXJvdy5hY3RpdmU6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMjA0MWVmO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3Zlciwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbDpub3QoLmNlbGwtc2VsZWN0aW9uKSAuZGF0YXRhYmxlLWJvZHktcm93OmhvdmVyIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6I2VlZTt0cmFuc2l0aW9uLXByb3BlcnR5OmJhY2tncm91bmQ7dHJhbnNpdGlvbi1kdXJhdGlvbjouM3M7dHJhbnNpdGlvbi10aW1pbmctZnVuY3Rpb246bGluZWFyfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsOm5vdCguY2VsbC1zZWxlY3Rpb24pIC5kYXRhdGFibGUtYm9keS1yb3c6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWw6bm90KC5jZWxsLXNlbGVjdGlvbikgLmRhdGF0YWJsZS1ib2R5LXJvdzpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZWVlO3RyYW5zaXRpb24tcHJvcGVydHk6YmFja2dyb3VuZDt0cmFuc2l0aW9uLWR1cmF0aW9uOi4zczt0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjpsaW5lYXJ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGw6Zm9jdXMgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojZGRkfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZSwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXB7YmFja2dyb3VuZC1jb2xvcjojMzA0ZmZlO2NvbG9yOiNmZmZ9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmhvdmVyLC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsLmNlbGwtc2VsZWN0aW9uIC5kYXRhdGFibGUtYm9keS1jZWxsLmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cHtiYWNrZ3JvdW5kLWNvbG9yOiMxOTNhZTQ7Y29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbC5jZWxsLXNlbGVjdGlvbiAuZGF0YXRhYmxlLWJvZHktY2VsbC5hY3RpdmU6Zm9jdXMsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwuY2VsbC1zZWxlY3Rpb24gLmRhdGF0YWJsZS1ib2R5LWNlbGwuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3Vwe2JhY2tncm91bmQtY29sb3I6IzIwNDFlZjtjb2xvcjojZmZmfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5lbXB0eS1yb3d7aGVpZ2h0OjUwcHg7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjVyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmxvYWRpbmctcm93e3RleHQtYWxpZ246bGVmdDtwYWRkaW5nOi41cmVtIDEuMnJlbTt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LWxlZnR7YmFja2dyb3VuZC1jb2xvcjojZmZmO2JhY2tncm91bmQtcG9zaXRpb246MTAwJSAwO2JhY2tncm91bmQtcmVwZWF0OnJlcGVhdC15O2JhY2tncm91bmQtaW1hZ2U6dXJsKGRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQVFBQUFBQkNBWUFBQUQ1UEEvTkFBQUFGa2xFUVZRSUhXUFNrTmVTQm1KaFRRVnRiaUROQ2dBU2FnSUl1Slg4T2dBQUFBQkpSVTVFcmtKZ2dnPT0pfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1yaWdodCwubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodHtiYWNrZ3JvdW5kLXBvc2l0aW9uOjAgMDtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7YmFja2dyb3VuZC1yZXBlYXQ6cmVwZWF0LXk7YmFja2dyb3VuZC1pbWFnZTp1cmwoZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBUUFBQUFCQ0FZQUFBRDVQQS9OQUFBQUZrbEVRVlFJMTJQUWtOZGkxVlRRNWdiU3drQXNEUUFSTEFJR3RPU0ZVQUFBQUFCSlJVNUVya0pnZ2c9PSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXJ7Ym94LXNoYWRvdzowIDJweCA0cHggMCByZ2JhKDAsMCwwLC4xNSk7cG9zaXRpb246c3RpY2t5O3Bvc2l0aW9uOi13ZWJraXQtc3RpY2t5O3RvcDowO3otaW5kZXg6OTk5O2JhY2tncm91bmQtY29sb3I6I2ZmZn0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWhlYWRlci1jZWxse3RleHQtYWxpZ246Y2VudGVyO2NvbG9yOnJnYmEoMCwwLDAsLjU0KTt2ZXJ0aWNhbC1hbGlnbjpib3R0b207Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NTAwfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVye3Bvc2l0aW9uOnJlbGF0aXZlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwubG9uZ3ByZXNzIC5kcmFnZ2FibGU6OmFmdGVye3RyYW5zaXRpb246dHJhbnNmb3JtIC40cyxvcGFjaXR5IC40cywtd2Via2l0LXRyYW5zZm9ybSAuNHM7b3BhY2l0eTouNTstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgxKTt0cmFuc2Zvcm06c2NhbGUoMSl9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCAuZHJhZ2dhYmxlOjphZnRlcntjb250ZW50OlwiIFwiO3Bvc2l0aW9uOmFic29sdXRlO3RvcDo1MCU7bGVmdDo1MCU7bWFyZ2luOi0zMHB4IDAgMCAtMzBweDtoZWlnaHQ6NjBweDt3aWR0aDo2MHB4O2JhY2tncm91bmQ6I2VlZTtib3JkZXItcmFkaXVzOjEwMCU7b3BhY2l0eToxOy13ZWJraXQtZmlsdGVyOm5vbmU7ZmlsdGVyOm5vbmU7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoMCk7dHJhbnNmb3JtOnNjYWxlKDApO3otaW5kZXg6OTk5OTtwb2ludGVyLWV2ZW50czpub25lfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwuZHJhZ2dpbmcgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0Om5vbmV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLnJlc2l6ZS1oYW5kbGV7Ym9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjZWVlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXJvdy1kZXRhaWx7YmFja2dyb3VuZDojZjVmNWY1O3BhZGRpbmc6MTBweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ncm91cC1oZWFkZXJ7YmFja2dyb3VuZDojZjVmNWY1O2JvcmRlci1ib3R0b206MXB4IHNvbGlkICNkOWQ4ZDk7Ym9yZGVyLXRvcDoxcHggc29saWQgI2Q5ZDhkOX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuZGF0YXRhYmxlLWJvZHktY2VsbHt0ZXh0LWFsaWduOmNlbnRlcjt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMzNTM1MzU7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO2xpbmUtaGVpZ2h0OjUwcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtYm9keS1yb3cgLmRhdGF0YWJsZS1ib2R5LWdyb3VwLWNlbGx7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6LjlyZW0gMS4ycmVtO3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7Y29sb3I6IzM1MzUzNTt0cmFuc2l0aW9uOndpZHRoIC4zcztmb250LXNpemU6MTRweDtmb250LXdlaWdodDo0MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1ib2R5IC5wcm9ncmVzcy1saW5lYXJ7ZGlzcGxheTpibG9jazt3aWR0aDoxMDAlO2hlaWdodDo1cHg7cGFkZGluZzowO21hcmdpbjowO3Bvc2l0aW9uOmFic29sdXRlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXJ7ZGlzcGxheTpibG9jaztwb3NpdGlvbjpyZWxhdGl2ZTtvdmVyZmxvdzpoaWRkZW47d2lkdGg6MTAwJTtoZWlnaHQ6NXB4Oy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7dHJhbnNmb3JtOnRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7YmFja2dyb3VuZC1jb2xvcjojYWFkMWY5fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtYm9keSAucHJvZ3Jlc3MtbGluZWFyIC5jb250YWluZXIgLmJhcnt0cmFuc2l0aW9uOnRyYW5zZm9ybSAuMnMgbGluZWFyOy13ZWJraXQtYW5pbWF0aW9uOi44cyBjdWJpYy1iZXppZXIoLjM5LC41NzUsLjU2NSwxKSBpbmZpbml0ZSBxdWVyeTthbmltYXRpb246LjhzIGN1YmljLWJlemllciguMzksLjU3NSwuNTY1LDEpIGluZmluaXRlIHF1ZXJ5O3RyYW5zaXRpb246dHJhbnNmb3JtIC4ycyBsaW5lYXIsLXdlYmtpdC10cmFuc2Zvcm0gLjJzIGxpbmVhcjtiYWNrZ3JvdW5kLWNvbG9yOiMxMDZjYzg7cG9zaXRpb246YWJzb2x1dGU7bGVmdDowO3RvcDowO2JvdHRvbTowO3dpZHRoOjEwMCU7aGVpZ2h0OjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3Rlcntib3JkZXItdG9wOjFweCBzb2xpZCByZ2JhKDAsMCwwLC4xMik7Zm9udC1zaXplOjEycHg7Zm9udC13ZWlnaHQ6NDAwO2NvbG9yOnJnYmEoMCwwLDAsLjU0KX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAucGFnZS1jb3VudHtsaW5lLWhlaWdodDo1MHB4O2hlaWdodDo1MHB4O3BhZGRpbmc6MCAxLjJyZW19Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlcnttYXJnaW46MCAxMHB4fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGl7dmVydGljYWwtYWxpZ246bWlkZGxlfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuZGlzYWJsZWQgYXtjb2xvcjpyZ2JhKDAsMCwwLC4yNikhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQhaW1wb3J0YW50fS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgbGkuYWN0aXZlIGF7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKTtmb250LXdlaWdodDo3MDB9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciBhe2hlaWdodDoyMnB4O21pbi13aWR0aDoyNHB4O2xpbmUtaGVpZ2h0OjIycHg7cGFkZGluZzowIDZweDtib3JkZXItcmFkaXVzOjNweDttYXJnaW46NnB4IDNweDt0ZXh0LWFsaWduOmNlbnRlcjtjb2xvcjpyZ2JhKDAsMCwwLC41NCk7dGV4dC1kZWNvcmF0aW9uOm5vbmU7dmVydGljYWwtYWxpZ246Ym90dG9tfS5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgYTpob3Zlcntjb2xvcjpyZ2JhKDAsMCwwLC43NSk7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE1OCwxNTgsMTU4LC4yKX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWZvb3RlciAuZGF0YXRhYmxlLXBhZ2VyIC5kYXRhdGFibGUtaWNvbi1sZWZ0LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtZm9vdGVyIC5kYXRhdGFibGUtcGFnZXIgLmRhdGF0YWJsZS1pY29uLXByZXYsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tcmlnaHQsLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1mb290ZXIgLmRhdGF0YWJsZS1wYWdlciAuZGF0YXRhYmxlLWljb24tc2tpcHtmb250LXNpemU6MjBweDtsaW5lLWhlaWdodDoyMHB4O3BhZGRpbmc6MCAzcHh9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93LC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtc3VtbWFyeS1yb3cgLmRhdGF0YWJsZS1ib2R5LXJvdzpob3ZlcntiYWNrZ3JvdW5kLWNvbG9yOiNkZGR9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1zdW1tYXJ5LXJvdyAuZGF0YXRhYmxlLWJvZHktcm93IC5kYXRhdGFibGUtYm9keS1jZWxse2ZvbnQtd2VpZ2h0OjcwMH0uZGF0YXRhYmxlLWNoZWNrYm94e3Bvc2l0aW9uOnJlbGF0aXZlO21hcmdpbjowO2N1cnNvcjpwb2ludGVyO3ZlcnRpY2FsLWFsaWduOm1pZGRsZTtkaXNwbGF5OmlubGluZS1ibG9jaztib3gtc2l6aW5nOmJvcmRlci1ib3g7cGFkZGluZzowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF17cG9zaXRpb246cmVsYXRpdmU7bWFyZ2luOjAgMXJlbSAwIDA7Y3Vyc29yOnBvaW50ZXI7b3V0bGluZTowfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06YmVmb3Jle3RyYW5zaXRpb246LjNzIGVhc2UtaW4tb3V0O2NvbnRlbnQ6XCJcIjtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7ei1pbmRleDoxO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07Ym9yZGVyOjJweCBzb2xpZCAjZjJmMmYyfS5kYXRhdGFibGUtY2hlY2tib3ggaW5wdXRbdHlwZT1jaGVja2JveF06Y2hlY2tlZDpiZWZvcmV7LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7dHJhbnNmb3JtOnJvdGF0ZSgtNDVkZWcpO2hlaWdodDouNXJlbTtib3JkZXItY29sb3I6IzAwOTY4ODtib3JkZXItdG9wLXN0eWxlOm5vbmU7Ym9yZGVyLXJpZ2h0LXN0eWxlOm5vbmV9LmRhdGF0YWJsZS1jaGVja2JveCBpbnB1dFt0eXBlPWNoZWNrYm94XTphZnRlcntjb250ZW50OlwiXCI7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDowO3dpZHRoOjFyZW07aGVpZ2h0OjFyZW07YmFja2dyb3VuZDojZmZmO2N1cnNvcjpwb2ludGVyfUAtd2Via2l0LWtleWZyYW1lcyBxdWVyeXswJXtvcGFjaXR5OjE7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKDM1JSkgc2NhbGUoLjMsMSl9MTAwJXtvcGFjaXR5OjA7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpO3RyYW5zZm9ybTp0cmFuc2xhdGVYKC01MCUpIHNjYWxlKDAsMSl9fUBrZXlmcmFtZXMgcXVlcnl7MCV7b3BhY2l0eToxOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoMzUlKSBzY2FsZSguMywxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLDEpfTEwMCV7b3BhY2l0eTowOy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwxKTt0cmFuc2Zvcm06dHJhbnNsYXRlWCgtNTAlKSBzY2FsZSgwLDEpfX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtemVyb3t0ZXh0LWFsaWduOnJpZ2h0O3ZlcnRpY2FsLWFsaWduOnRvcDtib3JkZXItdG9wOjA7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtbmFnZXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiNiOTEyMjQ7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWJvZHkgLmRhdGF0YWJsZS1ib2R5LXJvdyAuaXMtcG9zaXRpdmV7dGV4dC1hbGlnbjpyaWdodDt2ZXJ0aWNhbC1hbGlnbjp0b3A7Ym9yZGVyLXRvcDowO2NvbG9yOiMyODc0M2U7dHJhbnNpdGlvbjp3aWR0aCAuM3M7Zm9udC1zaXplOjE0cHg7Zm9udC13ZWlnaHQ6NDAwO3BhZGRpbmctcmlnaHQ6MjVweH0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItYWxpZ24tbGVmdHt0ZXh0LWFsaWduOmxlZnQ7Y29sb3I6IzM1MzUzNX0ubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLWNvbHVtbi1oZWFkZXItY2VudGVye2NvbG9yOiMzNTM1MzV9Lm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1jb2x1bW4taGVhZGVyLWFsaWduLXJpZ2h0e3RleHQtYWxpZ246cmlnaHQ7Y29sb3I6IzM1MzUzNX1idXR0b24ubWF0LW1lbnUtaXRlbXtoZWlnaHQ6MzBweDtsaW5lLWhlaWdodDozMHB4O2ZvbnQtc2l6ZToxM3B4O2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXJ9Lm1hdC1tZW51LWl0ZW06aG92ZXI6bm90KFtkaXNhYmxlZF0pe2JhY2tncm91bmQ6I2UxZWNmMn0uY2hlY2staWNvbi5tYXQtaWNvbnt3aWR0aDoxNHB4O2hlaWdodDoxNHB4O21hcmdpbi1sZWZ0OjIwcHg7Y29sb3I6IzAwMH0ubmd4LWRhdGF0YWJsZS5maXhlZC1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1oZWFkZXItaW5uZXJ7aGVpZ2h0OjEwMCV9YCwgYC5kYXRhdGFibGVDb250YWluZXIgLmxpdmUtdGltZS1mb3ItdGl0bGV7cG9zaXRpb246YWJzb2x1dGU7dG9wOjJweDtsZWZ0OjE1cHg7Zm9udC1zaXplOjE2cHg7Zm9udC1mYW1pbHk6RElOTmV4dExUUHJvLU1lZGl1bTtjb2xvcjojNDY0NjQ2fWBdLFxyXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcclxufSlcclxuZXhwb3J0IGNsYXNzIE1haW5EYXRhdGFibGVDb21wb25lbnQgZXh0ZW5kcyBCYXNlV2lkZ2V0Q29tcG9uZW50IHtcclxuXHJcbiAgcHJpdmF0ZSBzdWJzOiBTdWJzY3JpcHRpb25bXTtcclxuICByb3dzOiBhbnlbXSA9IFtdO1xyXG4gIGNoaWxkUm93czogYW55W10gPSBbXTtcclxuICBpc0RhdGFBdmFpbGFibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBpc0RhdGFUYWJsZVBhdXNlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIHJvd0hlaWdodDpudW1iZXI9NTA7XHJcbiAgYWxlcnREYXRhOiBhbnlbXSA9IFtdO1xyXG4gIGFsbFJvd3NTZWxlY3RlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGlzU2VsZWN0ZWRNYXA6IGFueVtdID0gW107XHJcbiAgaGVhZGVyU2V0dGluZzogYm9vbGVhbiA9IHRydWU7XHJcbiAgaGVhZGVySGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICAvLyB0ZW1wIGRhdGEgc3RydWN0dXJlXHJcbiAgY3VzdG9tQ29sdW1uOiBhbnlbXSA9IGN1c3RvbUNvbHVtbjtcclxuICBub3JtYWxDb2x1bW46IGFueVtdID0gbm9ybWFsQ29sdW1uO1xyXG4gIGNvbHVtbk1lbnVEcm9wRG93blNldHRpbmc6IGFueVtdID0gY29sdW1uTWVudURyb3BEb3duU2V0dGluZztcclxuICBsaW1pdDogbnVtYmVyID0gNTtcclxuICBmb290ZXJIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gIGhlYWRlckNoZWNrQm94OiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgcHJpdmF0ZSBpbnRlcnZhbDogYW55O1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNkOiBDaGFuZ2VEZXRlY3RvclJlZiwgcHJpdmF0ZSBuYXZTZXJ2aWNlOiBOYXZTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBhcHBSZWdpc3RyeTogQXBwUmVnaXN0cnksIHByaXZhdGUgYXBwQ29udGV4dDogQXBwQ29udGV4dCxcclxuICAgIHByaXZhdGUgbmF2U29ja2V0U2VydmljZTogTmF2U29ja2V0U2VydmljZSxcclxuICAgIHByaXZhdGUgZGlhbG9nOiBNYXREaWFsb2csXHJcbiAgICBwcml2YXRlIHZpZXdDb250YWluZXI6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBwcml2YXRlIHNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50czogU2hhcmVJbmZvQmV3ZWVuQ29tcG9uZW50c1NlcnZpY2UsXHJcbiAgICBwdWJsaWMgY29tbW9uVXRpbHM6IENvbW1vblV0aWxzU2VydmljZSxcclxuICAgIHByaXZhdGUgcmVzb3VyY2VNYW5nZXI6IFJlc291cmNlTWFuYWdlclNlcnZpY2UpIHtcclxuICAgIHN1cGVyKCk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIC8vcmVzZXQgY29tcG9uZW50IGRhdGEgYW5kIHVzZXIgdmFsaWRhdGlvbjtcclxuICAgIHRoaXMuY29tbW9uVXRpbHMudmFsaWRhdGVVc2VyKCk7XHJcbiAgICB0aGlzLnN1YnMgPSBbXTtcclxuICAgIHRoaXMucm93cyA9IFtdO1xyXG4gICAgdGhpcy5pc0RhdGFBdmFpbGFibGUgPSBmYWxzZTtcclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U2VydmljZS5nZXRGdW5kTGlzdCgpLnN1YnNjcmliZShcclxuICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgdGhpcy5yb3dzID0gdGhpcy5jb21tb25VdGlscy5leHRyYWN0RnVuZExldmVsRGF0YShkYXRhKTtcclxuICAgICAgICB0aGlzLmNoaWxkUm93cyA9IHRoaXMuY29tbW9uVXRpbHMuZXh0cmFjdENsYXNzTGV2ZWxEYXRhKGRhdGEpO1xyXG4gICAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIC8vdGhpcy5hbGVydERhdGEgPSBbLi4udGhpcy51cGRhdGVBbGVydERhdGEodGhpcy5yb3dzKV07XHJcbiAgICAgICAgICB0aGlzLmFsZXJ0RGF0YSA9IFsuLi50aGlzLnVwZGF0ZUFsZXJ0RGF0YUF0Q2xhc3NMZXZlbChkYXRhKV07XHJcbiAgICAgICAgICB0aGlzLmlzRGF0YUF2YWlsYWJsZSA9IHRydWU7XHJcbiAgICAgICAgICAvLyBzZXRpbmcgcG9zaXRpb24gcGFnZSBkZWZhdWx0IGZ1bmQgaW5mbyBpZiBmdW5kSW5mbyBpcyBudWxsXHJcbiAgICAgICAgICBpZiAodGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZnVuZEluZm8ubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZ1bmRJbmZvID0gW107XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5mdW5kaWQpO1xyXG4gICAgICAgICAgICBmdW5kSW5mby5wdXNoKGRhdGFbMF0ubmFtZSk7XHJcbiAgICAgICAgICAgIGZ1bmRJbmZvLnB1c2goZGF0YVswXS5mdW5kVGlja2VyKVxyXG4gICAgICAgICAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5zYXZlUG9zaXRpb25EZXRhaWxzRnVuZEluZm8oZnVuZEluZm8pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnJvd3MgPSBbLi4udGhpcy5yb3dzXTtcclxuICAgICAgICB0aGlzLnJvd3MuZm9yRWFjaChyb3cgPT4ge1xyXG4gICAgICAgICAgdGhpcy5uYXZTb2NrZXRTZXJ2aWNlLnJlZ2lzdGVyRnVuZHMoW3Jvd1snZnVuZGlkJ11dKTtcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICApKTtcclxuICAgIHRoaXMuc3Vicy5wdXNoKHRoaXMubmF2U29ja2V0U2VydmljZS5nZXROYXYoKS5zdWJzY3JpYmUoXHJcbiAgICAgIChkYXRhKSA9PiB7XHJcbiAgICAgICAgaWYgKGRhdGFbJ2V2ZW50VHlwZSddID09PSAnZnVuZENoYW5nZScpIHtcclxuICAgICAgICAgIGNvbnN0IGZ1bmRMZXZlbFJvdyA9IHRoaXMuY29tbW9uVXRpbHMuZXh0cmFjdFdTRGF0YShkYXRhW1wiZXZlbnREYXRhXCJdLCBmYWxzZSk7XHJcbiAgICAgICAgICBjb25zdCBjaGlsZExldmVsUm93ID0gdGhpcy5jb21tb25VdGlscy5leHRyYWN0V1NEYXRhKGRhdGFbXCJldmVudERhdGFcIl0sIHRydWUpO1xyXG4gICAgICAgICAgdGhpcy51cGRhdGVSb3coZnVuZExldmVsUm93KTtcclxuICAgICAgICAgIGNoaWxkTGV2ZWxSb3cuZm9yRWFjaChyb3cgPT4gdGhpcy51cGRhdGVSb3cocm93KSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChkYXRhWydldmVudFR5cGUnXSA9PT0gJ3NvZENoYW5nZScpIHtcclxuICAgICAgICAgIHRoaXMuZG91cGRhdGUoZGF0YVtcImV2ZW50RGF0YVwiXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApKTtcclxuICAgIHRoaXMucmVzb3VyY2VNYW5nZXIucmVnaXN0SW50ZXJ2YWwoKCkgPT4geyB0aGlzLnJvd3MgPSBbLi4udGhpcy5yb3dzXTsgfSwgMzAwKTtcclxuXHJcbiAgICB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5oeXBlckxpbmtOYXZpZ2F0ZS5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiaHlwZXJsaW5rIG5hdmlnYXRlXCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgdGhpcy5oeXBlckxpbmtOYXZpZ2F0ZVRvKGRhdGEpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMub3Blbk1vZGFsRGF0YS5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgIHRoaXMub3BlbkFsZXJ0TW9kYWwoZGF0YS5yb3dEYXRhLCBkYXRhLnR5cGUpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc29ydERhdGF0YWJsZUNvbHVtbi5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgIHRoaXMucm93cyA9IFsuLi50aGlzLmNvbW1vblV0aWxzLnNvcnRDb2x1bW5CeVByb3AodGhpcy5yb3dzLCB0aGlzLmNoaWxkUm93cywgZGF0YS5tYXAsIGRhdGEucHJvcCwgZGF0YS5hc2NGbGFnKV07XHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICB0aGlzLnJvd3MuZm9yRWFjaChyb3cgPT4ge1xyXG4gICAgICB0aGlzLm5hdlNvY2tldFNlcnZpY2UudW5SZWdpc3RlckZ1bmRzKFtyb3dbJ2Z1bmRpZCddXSk7XHJcbiAgICB9KVxyXG4gICAgdGhpcy5zdWJzLmZvckVhY2goc3ViID0+IHN1Yi51bnN1YnNjcmliZSgpKTtcclxuICAgIHRoaXMucmVzb3VyY2VNYW5nZXIuY2xlYW5SZXNvdXJjZXMoKTtcclxuXHJcbiAgfVxyXG5cclxuICB1cGRhdGVSb3coZGF0YSkge1xyXG4gICAgaWYgKGRhdGEgJiYgIXRoaXMuaXNEYXRhVGFibGVQYXVzZWQgJiYgdGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShkYXRhWydwcmljZXRpbWUnXSkpKSB7XHJcbiAgICAgIGlmIChkYXRhWydhbGVydFR5cGUnXSAmJiAoZGF0YVsnYWxlcnRUeXBlJ10gPT0gMSB8fCBkYXRhWydhbGVydFR5cGUnXSA9PT0gMikpIHtcclxuICAgICAgICBjb25zdCBhbGVydE9iaiA9IHtcclxuICAgICAgICAgIFwibmFtZVwiOiBkYXRhWydmdW5kaWQnXSxcclxuICAgICAgICAgIFwiY2xhc3NJRFwiOmRhdGFbJ2NsYXNzSUQnXSxcclxuICAgICAgICAgIFwiYWxlcnRUeXBlXCI6IGRhdGFbJ2FsZXJ0VHlwZSddLFxyXG4gICAgICAgICAgXCJuYXZcIjogZGF0YVsnbmF2J10sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBkYXRhWydmdW5kbXYnXSxcclxuICAgICAgICAgIFwidmFsdWVcIjogZGF0YVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJmdW5kbXZDaGFuZ2VQZXJjZW50XCI6IGRhdGFbJ2Z1bmRtdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgIFwicHJpY2V0aW1lXCI6IGRhdGFbJ3ByaWNldGltZSddLFxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmFsZXJ0RGF0YS5wdXNoKGFsZXJ0T2JqKTtcclxuICAgICAgICB0aGlzLmFsZXJ0RGF0YSA9IFsuLi50aGlzLmFsZXJ0RGF0YV07XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5kb3VwZGF0ZShkYXRhKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGRvdXBkYXRlKGRhdGEpIHtcclxuICAgIGlmICh0aGlzLnJvd3MubGVuZ3RoKSB7XHJcbiAgICAgIGNvbnN0IGZ1bmRJZCA9IGRhdGFbJ2Z1bmRpZCddO1xyXG4gICAgICBjb25zdCBmdW5kVGlja2VyID0gZGF0YVsnZnVuZFRpY2tlciddO1xyXG4gICAgICBjb25zdCBjbGFzc0lEID0gZGF0YVsnY2xhc3NJRCddO1xyXG4gICAgICB0aGlzLnJvd3MuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICBpZiAoaXRlbVsnZnVuZGlkJ10gPT09IGZ1bmRJZCAmJiBpdGVtWydmdW5kVGlja2VyJ10gPT09IGZ1bmRUaWNrZXIgJiYgaXRlbVsnY2xhc3NJRCddID09PSBjbGFzc0lEKSB7XHJcbiAgICAgICAgICB0aGlzLm5vcm1hbENvbHVtbi5mb3JFYWNoKGNvbEl0ZW0gPT4geyBpZiAobnVsbCAhPSBkYXRhW2NvbEl0ZW0ucHJvcF0gJiYgKFsnZnVuZGlkJywgJ25hbWUnLCAnZnVuZFRpY2tlcicsICdjbGFzc0lEJ10uaW5kZXhPZihjb2xJdGVtLnByb3ApID09PSAtMSkpIHsgaXRlbVtjb2xJdGVtLnByb3BdID0gZGF0YVtjb2xJdGVtLnByb3BdIH0gfSk7XHJcbiAgICAgICAgICBjb25zdCBjb3VudHMgPSB0aGlzLmdldEFsZXJ0Q291bnRzKGZ1bmRJZCwgY2xhc3NJRCwgdGhpcy5hbGVydERhdGEpO1xyXG4gICAgICAgICAgaXRlbVsncmVkQWxlcnQnXSA9IGNvdW50c1swXTtcclxuICAgICAgICAgIGl0ZW1bJ3llbGxvd0FsZXJ0J10gPSBjb3VudHNbMV07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0QWxlcnRDb3VudHMoZnVuZGlkOiBzdHJpbmcsIGNsYXNzSUQ6IHN0cmluZyAsYWxlcnRzOiBhbnlbXSk6IGFueVtdIHtcclxuICAgIGxldCBjb3VudHMgPSBbMCwgMF07XHJcbiAgICBhbGVydHMuZm9yRWFjaChhbGVydCA9PiB7XHJcbiAgICAgIGlmIChhbGVydFsnbmFtZSddID09PSBmdW5kaWQgJiYgYWxlcnRbJ2NsYXNzSUQnXSA9PT0gY2xhc3NJRCkge1xyXG4gICAgICAgIGlmIChhbGVydFsnYWxlcnRUeXBlJ10gPT09IDIpIHtcclxuICAgICAgICAgIGNvdW50c1swXSArPSAxO1xyXG4gICAgICAgIH0gaWYgKGFsZXJ0WydhbGVydFR5cGUnXSA9PT0gMSkge1xyXG4gICAgICAgICAgY291bnRzWzFdICs9IDE7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIC8vY29uc29sZS5sb2coXCJhbGVydCBjb3VudHMgZm9yIGZ1bmQgOlwiK2Z1bmRpZCtcIiBjbGFzczpcIitjbGFzc0lEK1wiIGNvdW50cyBmb3IgdHlwZSAxOlwiK2NvdW50c1swXSArXCIgY291bnRzIGZvciB0eXBlIDE6XCIrY291bnRzWzFdKTtcclxuICAgIHJldHVybiBjb3VudHM7XHJcbiAgfVxyXG4gIFxyXG4gICB1cGRhdGVBbGVydERhdGFBdENsYXNzTGV2ZWwoZGF0YSkgOiBhbnlbXSB7XHJcbiAgICBsZXQgYWxlcnRBcnkgPSBbXTtcclxuICAgIGNvbnN0IGZ1bmRMZXZlbERhdGEgPSAoZGF0YSBhcyBhbnlbXSkubWFwKGQgPT4ge1xyXG4gICAgICBmb3IobGV0IGtleSBpbiBkLmNsYXNzTGV2ZWxUcmlhbERhdGEpIHtcclxuICAgICAgICBhbGVydEFyeSA9IGFsZXJ0QXJ5LmNvbmNhdCh0aGlzLmZpbHRlckFsZXJ0RGF0YUJ5Q2xhc3MoZC5mdW5kaWQsIGtleSAsZC5jbGFzc0xldmVsVHJpYWxEYXRhW2tleV0ucHJpY2VDaGFuZ2VzKSk7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gYWxlcnRBcnk7XHJcbiAgfVxyXG4gIC8vIGNvbGxsZWN0cyB0aGUgYWxlcnQgZGF0YSBmcm9tIGdldEZ1bmRMaXN0IGNhbGxcclxuICB1cGRhdGVBbGVydERhdGEoZGF0YSk6IGFueVtdIHtcclxuICAgIGxldCBhbGVydEFyeSA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBhbGVydEFyeSA9IGFsZXJ0QXJ5LmNvbmNhdCh0aGlzLmZpbHRlckFsZXJ0RGF0YShpdGVtWydmdW5kaWQnXSwgaXRlbVsncHJpY2VDaGFuZ2VzJ10pKTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGFsZXJ0QXJ5O1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyQWxlcnREYXRhQnlDbGFzcyhmdW5kSUQsIGNsYXNzSUQsIGRhdGEpIHtcclxuICAgIGNvbnN0IHRlbXBBbGVydENyaWNsZURhdGEgPSBbXTtcclxuICAgIGRhdGEuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKHRoaXMuY29tbW9uVXRpbHMuaXNWYWxpZFRpbWUobmV3IERhdGUoaXRlbVsncHJpY2V0aW1lJ10pKSBcclxuICAgICAgICAmJiBpdGVtWydhbGVydFR5cGUnXSAmJiAoaXRlbVsnYWxlcnRUeXBlJ10gPT0gMSB8fCBpdGVtWydhbGVydFR5cGUnXSA9PT0gMikpIHtcclxuICAgICAgICBjb25zdCBhbGVydE9iaiA9IHtcclxuICAgICAgICAgIFwibmFtZVwiOiBmdW5kSUQsXHJcbiAgICAgICAgICBcImNsYXNzSURcIjogY2xhc3NJRCwgXHJcbiAgICAgICAgICBcImFsZXJ0VHlwZVwiOiBpdGVtWydhbGVydFR5cGUnXSxcclxuICAgICAgICAgIFwibmF2XCI6IGl0ZW1bJ25hdiddLFxyXG4gICAgICAgICAgXCJtYXJrZXR2YWxcIjogaXRlbVsnZnVuZG12J10sXHJcbiAgICAgICAgICBcInZhbHVlXCI6IGl0ZW1bJ25hdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgIFwiZnVuZG12Q2hhbmdlUGVyY2VudFwiOiBpdGVtWydmdW5kbXZDaGFuZ2VQZXJjZW50J10sXHJcbiAgICAgICAgICBcInByaWNldGltZVwiOiBpdGVtWydwcmljZXRpbWUnXSxcclxuICAgICAgICB9XHJcbiAgICAgICAgdGVtcEFsZXJ0Q3JpY2xlRGF0YS5wdXNoKGFsZXJ0T2JqKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiB0ZW1wQWxlcnRDcmljbGVEYXRhO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyQWxlcnREYXRhKGZ1bmRJRCwgZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcEFsZXJ0Q3JpY2xlRGF0YSA9IFtdO1xyXG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAodGhpcy5jb21tb25VdGlscy5pc1ZhbGlkVGltZShuZXcgRGF0ZShpdGVtWydwcmljZXRpbWUnXSkpICYmIGl0ZW1bJ2FsZXJ0VHlwZSddICYmIChpdGVtWydhbGVydFR5cGUnXSA9PSAxIHx8IGl0ZW1bJ2FsZXJ0VHlwZSddID09PSAyKSkge1xyXG4gICAgICAgIGNvbnN0IGFsZXJ0T2JqID0ge1xyXG4gICAgICAgICAgXCJuYW1lXCI6IGZ1bmRJRCxcclxuICAgICAgICAgIFwiYWxlcnRUeXBlXCI6IGl0ZW1bJ2FsZXJ0VHlwZSddLFxyXG4gICAgICAgICAgXCJuYXZcIjogaXRlbVsnbmF2J10sXHJcbiAgICAgICAgICBcIm1hcmtldHZhbFwiOiBpdGVtWydmdW5kbXYnXSxcclxuICAgICAgICAgIFwidmFsdWVcIjogaXRlbVsnbmF2Q2hhbmdlUGVyY2VudCddLFxyXG4gICAgICAgICAgXCJmdW5kbXZDaGFuZ2VQZXJjZW50XCI6IGl0ZW1bJ2Z1bmRtdkNoYW5nZVBlcmNlbnQnXSxcclxuICAgICAgICAgIFwicHJpY2V0aW1lXCI6IGl0ZW1bJ3ByaWNldGltZSddLFxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZW1wQWxlcnRDcmljbGVEYXRhLnB1c2goYWxlcnRPYmopO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIHRlbXBBbGVydENyaWNsZURhdGE7XHJcbiAgfVxyXG5cclxuICBvcGVuQWxlcnRNb2RhbChyb3csIHR5cGUpIHtcclxuICAgIGNvbnN0IGRpYWxvZ1JlZiA9IHRoaXMuZGlhbG9nLm9wZW4oQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCwge1xyXG4gICAgICB3aWR0aDogJzY4MHB4JyxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIFwidHlwZVwiOiB0eXBlID09PSAneWVsbG93QWxlcnQnID8gJycgOiAnQ3JpdGljYWwnLFxyXG4gICAgICAgIFwibm93XCI6IG5ldyBEYXRlKCkgPiB0aGlzLmNvbW1vblV0aWxzLmVuZFRpbWUgPyB0aGlzLmNvbW1vblV0aWxzLmVuZFRpbWUgOiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIFwidGl0bGVcIjogcm93WyduYW1lJ10rXCIgY2xhc3MtXCIgK3Jvd1snY2xhc3NJRCddLFxyXG4gICAgICAgIFwiZnVuZElkXCI6IHJvd1snZnVuZGlkJ10sXHJcbiAgICAgICAgXCJhbGVydERhdGFcIjogdGhpcy5nZXRBbGVydERhdGFGb3JGdW5kQnlDbGFzcyhyb3dbJ2Z1bmRpZCddLCByb3dbJ2NsYXNzSUQnXSwgdHlwZSA9PT0gJ3llbGxvd0FsZXJ0JyA/IDEgOiAyKVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuLy8gICAgY29uc29sZS5sb2coXCJsZW5ndGggZnVuZDpcIityb3crXCJjbGFzczogYWxlcnR0eXBlOlwiKTsgIFxyXG4gICAgZGlhbG9nUmVmLmFmdGVyQ2xvc2VkKCkuc3Vic2NyaWJlKHJlc3VsdCA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdUaGUgZGlhbG9nIHdhcyBjbG9zZWQnKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZ2V0QWxlcnREYXRhRm9yRnVuZEJ5Q2xhc3MoZnVuZElkLCBjbGFzc0lELCBhbGVydFR5cGUpIHtcclxuICAgIGNvbnN0IGFsZXJ0RGF0YUZvckZ1bmQ6IGFueVtdID0gW107XHJcbiAgICB0aGlzLmFsZXJ0RGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbVsnbmFtZSddID09PSBmdW5kSWQgXHJcbiAgICAgICAgICAgICYmIGl0ZW1bJ2NsYXNzSUQnXSA9PT0gY2xhc3NJRFxyXG4gICAgICAgICAgICAmJiBpdGVtWydhbGVydFR5cGUnXSA9PT0gYWxlcnRUeXBlKSB7XHJcbiAgICAgICAgYWxlcnREYXRhRm9yRnVuZC5wdXNoKGl0ZW0pO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgY29uc29sZS5sb2coXCJGdW5kOlwiK2Z1bmRJZCtcIixjbGFzczpcIitjbGFzc0lEK1wiLGNvdW50OlwiK2FsZXJ0RGF0YUZvckZ1bmQubGVuZ3RoKTtcclxuICAgIHJldHVybiBhbGVydERhdGFGb3JGdW5kLnJldmVyc2UoKTtcclxuICB9XHJcblxyXG4gIGdldEFsZXJ0RGF0YUZvckZ1bmQoZnVuZElkLCBhbGVydFR5cGUpIHtcclxuICAgIGNvbnN0IGFsZXJ0RGF0YUZvckZ1bmQ6IGFueVtdID0gW107XHJcbiAgICB0aGlzLmFsZXJ0RGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbVsnbmFtZSddID09PSBmdW5kSWQgJiYgaXRlbVsnYWxlcnRUeXBlJ10gPT09IGFsZXJ0VHlwZSkge1xyXG4gICAgICAgIGFsZXJ0RGF0YUZvckZ1bmQucHVzaChpdGVtKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHJldHVybiBhbGVydERhdGFGb3JGdW5kLnJldmVyc2UoKTtcclxuICB9XHJcblxyXG4gIGh5cGVyTGlua05hdmlnYXRlVG8ocm93KSB7XHJcbiAgICBjb25zdCBmdW5kSW5mbyA9IFtdO1xyXG4gICAgY29uc3QgZnVuZElEID0gcm93WydmdW5kaWQnXTtcclxuICAgIGZ1bmRJbmZvLnB1c2goZnVuZElEKTtcclxuICAgIGNvbnN0IGZ1bmROYW1lID0gcm93WyduYW1lJ107XHJcbiAgICBmdW5kSW5mby5wdXNoKGZ1bmROYW1lKTtcclxuICAgIGZ1bmRJbmZvLnB1c2gocm93WydmdW5kVGlja2VyJ10pO1xyXG4gICAgdGhpcy5uYWdhdGl2YXRlVG9Qb3NpdGlvbihmdW5kSW5mbyk7XHJcbiAgfVxyXG5cclxuICBuYWdhdGl2YXRlVG9Qb3NpdGlvbihmdW5kSW5mbyk6IHZvaWQge1xyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuc2F2ZVBvc2l0aW9uRGV0YWlsc0Z1bmRJbmZvKGZ1bmRJbmZvKTtcclxuICAgIHRoaXMuYXBwQ29udGV4dC5jdXJyZW50RGFzaGJvYXJkID0gdGhpcy5hcHBSZWdpc3RyeS5nZXREYXNoYm9hcmQoJ1FOQVYtMDAyJyk7XHJcbiAgfVxyXG5cclxuICBnZXRBbGxSb3dzRGlzYWJsZWQoKSB7XHJcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKTtcclxuICAgIGxldCBkaXNhYmxlQWxsID0gdHJ1ZTtcclxuICAgIGxpc3QuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uY2hlY2tlZCkgZGlzYWJsZUFsbCA9IGZhbHNlO1xyXG4gICAgfSlcclxuICAgIHJldHVybiBkaXNhYmxlQWxsO1xyXG4gIH1cclxuXHJcbiAgZ2V0U2luZ2xlUm93RGlzYWJsZWQocm93KSB7XHJcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuZ2V0RnVuZExpc3QoKTtcclxuICAgIGxldCBkaXNhYmxlU2luZ2xlUm93ID0gdHJ1ZTtcclxuICAgIGxpc3QuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uY2hlY2tlZCAmJiBpdGVtLmZ1bmRJRCA9PT0gcm93WydmdW5kaWQnXSAmJiByb3cuY2hpbGQgPT09IFwicGFyZW50XCIpIGRpc2FibGVTaW5nbGVSb3cgPSBmYWxzZTtcclxuICAgIH0pXHJcbiAgICByZXR1cm4gZGlzYWJsZVNpbmdsZVJvdztcclxuICB9XHJcblxyXG4gIGdldEFsbFJvd0NoZWNrZWQocm93cyk6IGJvb2xlYW4ge1xyXG4gICAgY29uc3QgbGlzdCA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmlsdGVyKGl0ZW0gPT4gaXRlbS5jaGVja2VkKTtcclxuICAgIGxldCB0ZW1wRmxhZyA9IHRydWU7XHJcbiAgICBsZXQgbm9GdW5kU2hvd0luQ2hhcnQgPSBsaXN0Lmxlbmd0aCA9PT0gMCA/IHRydWUgOiBmYWxzZTtcclxuXHJcbiAgICBpZiAobGlzdC5sZW5ndGggPiB0aGlzLmlzU2VsZWN0ZWRNYXAubGVuZ3RoKSB7XHJcbiAgICAgIHRlbXBGbGFnID0gZmFsc2U7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsaXN0LmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgdGhpcy5pc1NlbGVjdGVkTWFwLmZvckVhY2gocyA9PiB7XHJcbiAgICAgICAgICBpZiAoaXRlbS5mdW5kVGlja2VyID09PSBzLm5hbWUgJiYgIXMuY2hlY2tlZCkge1xyXG4gICAgICAgICAgICB0ZW1wRmxhZyA9IGZhbHNlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBpZiAodGhpcy5pc1NlbGVjdGVkTWFwLmxlbmd0aCA9PT0gMCkgdGVtcEZsYWcgPSBmYWxzZTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5hbGxSb3dzU2VsZWN0ZWQgPSBub0Z1bmRTaG93SW5DaGFydCA/ICFub0Z1bmRTaG93SW5DaGFydCA6IHRlbXBGbGFnO1xyXG4gICAgcmV0dXJuIHRoaXMuYWxsUm93c1NlbGVjdGVkO1xyXG4gIH1cclxuXHJcbiAgZ2V0U2luZ2xlUm93Q2hlY2tlZChmdW5kKSB7XHJcbiAgICBsZXQgaXNDaGVja2VkID0gZmFsc2U7XHJcbiAgICB0aGlzLmlzU2VsZWN0ZWRNYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0ubmFtZSA9PT0gZnVuZCkge1xyXG4gICAgICAgIGlzQ2hlY2tlZCA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmluZChsaXN0ID0+IChsaXN0LmZ1bmRUaWNrZXIgPT09IGZ1bmQgJiYgbGlzdC5jaGVja2VkKSkgPyBpdGVtLmNoZWNrZWQgOiBmYWxzZTtcclxuICAgICAgICBpdGVtLmNoZWNrZWQgPSB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpLmZpbmQobGlzdCA9PiAobGlzdC5mdW5kVGlja2VyID09PSBmdW5kICYmIGxpc3QuY2hlY2tlZCkpID8gaXRlbS5jaGVja2VkIDogZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gaXNDaGVja2VkO1xyXG4gIH1cclxuXHJcbiAgb25TZWxlY3RBbGwoY2hlY2tlZCwgcm93cykge1xyXG4gICAgdGhpcy5hbGxSb3dzU2VsZWN0ZWQgPSBjaGVja2VkO1xyXG4gICAgcm93cy5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBsZXQgb2JqID0ge1xyXG4gICAgICAgIG5hbWU6IGl0ZW0uZnVuZFRpY2tlcixcclxuICAgICAgICBjaGVja2VkOiB0aGlzLnNoYXJlSW5mb3JCZXd0ZWVuQ29tcG9uZW50cy5nZXRGdW5kTGlzdCgpLmZpbmQobGlzdCA9PiAobGlzdC5mdW5kSUQgPT09IGl0ZW0uZnVuZGlkICYmIGxpc3QuY2hlY2tlZCkpID8gY2hlY2tlZCA6IGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgaWYgKCF0aGlzLmlzU2VsZWN0ZWRNYXAuZmluZChzID0+IHMubmFtZSA9PT0gaXRlbS5mdW5kVGlja2VyKSkge1xyXG4gICAgICAgIHRoaXMuaXNTZWxlY3RlZE1hcC5wdXNoKG9iailcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBpID0gdGhpcy5pc1NlbGVjdGVkTWFwLmZpbmRJbmRleChzID0+IHMubmFtZSA9PT0gaXRlbS5mdW5kVGlja2VyKTtcclxuICAgICAgICB0aGlzLmlzU2VsZWN0ZWRNYXBbaV1bJ2NoZWNrZWQnXSA9IHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmdldEZ1bmRMaXN0KCkuZmluZChsaXN0ID0+IChsaXN0LmZ1bmRJRCA9PT0gaXRlbS5mdW5kaWQgJiYgbGlzdC5jaGVja2VkKSkgPyBjaGVja2VkIDogZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgLy8gdGhpcy5zZXRIaWdoTGlnaHRBY3RpdmVFbnRyaWVzKHRoaXMuaXNTZWxlY3RlZE1hcCk7XHJcbiAgICBjb25zdCBhY3RpdmVFbnRyaWVzID0gW107XHJcbiAgICB0aGlzLmlzU2VsZWN0ZWRNYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uY2hlY2tlZCkge1xyXG4gICAgICAgIGFjdGl2ZUVudHJpZXMucHVzaCh7IG5hbWU6IGl0ZW0ubmFtZSB9KTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMuZW1pdChhY3RpdmVFbnRyaWVzKTtcclxuICB9XHJcblxyXG4gIG9uQ2hlY2tib3hDaGFuZ2UoZnVuZCkge1xyXG4gICAgaWYgKHRoaXMuaXNTZWxlY3RlZE1hcC5sZW5ndGggPiAwICYmIHRoaXMuaXNTZWxlY3RlZE1hcC5maW5kKHMgPT4gcy5uYW1lID09PSBmdW5kKSkge1xyXG4gICAgICBjb25zdCBpID0gdGhpcy5pc1NlbGVjdGVkTWFwLmZpbmRJbmRleChzID0+IHMubmFtZSA9PT0gZnVuZCk7XHJcbiAgICAgIHRoaXMuaXNTZWxlY3RlZE1hcFtpXVsnY2hlY2tlZCddID0gIXRoaXMuaXNTZWxlY3RlZE1hcFtpXVsnY2hlY2tlZCddO1xyXG4gICAgICBpZiAodGhpcy5pc1NlbGVjdGVkTWFwW2ldWydjaGVja2VkJ10pIHtcclxuICAgICAgICB0aGlzLmFsbFJvd3NTZWxlY3RlZCA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgb2JqID0ge1xyXG4gICAgICAgIG5hbWU6IGZ1bmQsXHJcbiAgICAgICAgY2hlY2tlZDogdHJ1ZVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuaXNTZWxlY3RlZE1hcC5wdXNoKG9iailcclxuICAgIH1cclxuXHJcbiAgICAvLyB0aGlzLnNldEhpZ2hMaWdodEFjdGl2ZUVudHJpZXModGhpcy5pc1NlbGVjdGVkTWFwKTtcclxuICAgIGNvbnN0IGFjdGl2ZUVudHJpZXMgPSBbXTtcclxuICAgIHRoaXMuaXNTZWxlY3RlZE1hcC5mb3JFYWNoKGl0ZW0gPT4ge1xyXG4gICAgICBpZiAoaXRlbS5jaGVja2VkKSB7XHJcbiAgICAgICAgYWN0aXZlRW50cmllcy5wdXNoKHsgbmFtZTogaXRlbS5uYW1lIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgdGhpcy5zaGFyZUluZm9yQmV3dGVlbkNvbXBvbmVudHMuaGlnaExpZ2h0QWN0aXZlRW50cmllcy5lbWl0KGFjdGl2ZUVudHJpZXMpO1xyXG4gIH1cclxuXHJcbiAgc2V0SGlnaExpZ2h0QWN0aXZlRW50cmllcyhzZWxlY3RlZE1hcCkge1xyXG4gICAgY29uc3QgYWN0aXZlRW50cmllcyA9IFtdO1xyXG4gICAgc2VsZWN0ZWRNYXAuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgaWYgKGl0ZW0uY2hlY2tlZCkge1xyXG4gICAgICAgIGFjdGl2ZUVudHJpZXMucHVzaCh7IG5hbWU6IGl0ZW0ubmFtZSB9KTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmhpZ2hMaWdodEFjdGl2ZUVudHJpZXMuZW1pdChhY3RpdmVFbnRyaWVzKTtcclxuICB9XHJcblxyXG4gIG9uQ2xpY2tlZE91dHNpZGUoZTogRXZlbnQpIHtcclxuICAgIHRoaXMuc2hhcmVJbmZvckJld3RlZW5Db21wb25lbnRzLmNsaWNrZWRPdXRTaWRlLmVtaXQoZSk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVQYXVzZUZsYWcoKSB7XHJcbiAgICB0aGlzLmlzRGF0YVRhYmxlUGF1c2VkID0gIXRoaXMuaXNEYXRhVGFibGVQYXVzZWQ7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQgeyBOZ01vZHVsZSAsIEluamVjdGlvblRva2VufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQXBwUmVnaXN0cnksIEFwcENvbnRleHQsIFVpQ29tbW9uTW9kdWxlIH0gZnJvbSAnQG9tbmlhL3VpLWNvbW1vbic7XHJcbmltcG9ydCB7IER5bmFtaWNNb2R1bGUgfSBmcm9tICduZy1keW5hbWljLWNvbXBvbmVudCc7XHJcbmltcG9ydCB7IE5neERhdGF0YWJsZU1vZHVsZSB9IGZyb20gJ0Bzd2ltbGFuZS9uZ3gtZGF0YXRhYmxlJztcclxuaW1wb3J0IHsgTmd4Q2hhcnRzTW9kdWxlIH0gZnJvbSAnQHN3aW1sYW5lL25neC1jaGFydHMnO1xyXG5pbXBvcnQgeyBMaW5lQ2hhcnRDb21wb25lbnQgfSBmcm9tICcuL2xpbmUtY2hhcnQvbGluZS1jaGFydC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBDdXN0b21MZWdlbmRDb21wb25lbnQgfSBmcm9tICcuL2N1c3RvbS1sZWdlbmQvY3VzdG9tLWxlZ2VuZC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBNYXRDaGlwc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NoaXBzJztcclxuaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSwgTWF0QnV0dG9uTW9kdWxlLCBNYXRDaGVja2JveE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsJztcclxuaW1wb3J0IHtNYXRNZW51TW9kdWxlfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9tZW51JztcclxuaW1wb3J0IHtCcm93c2VyQW5pbWF0aW9uc01vZHVsZX0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlci9hbmltYXRpb25zJztcclxuaW1wb3J0IHsgSHR0cENsaWVudE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSHR0cENsaWVudEluTWVtb3J5V2ViQXBpTW9kdWxlIH0gZnJvbSAnYW5ndWxhci1pbi1tZW1vcnktd2ViLWFwaSc7XHJcbi8vaW1wb3J0IHsgZW52aXJvbm1lbnQgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9zcmMvZW52aXJvbm1lbnRzL2Vudmlyb25tZW50J1xyXG4vLyBpbXBvcnQgeyBRbmF2TGluZUNoYXJ0Q29tcG9uZW50IH0gZnJvbSAnLi9xbmF2LWxpbmUtY2hhcnQvcW5hdi1saW5lLWNoYXJ0LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFFuYXZQb3NpdGlvbkNvbXBvbmVudCB9IGZyb20gJy4vcW5hdi1wb3NpdGlvbi9xbmF2LXBvc2l0aW9uLmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFFuYXZMaW5lQ2hhcnRDb21wb25lbnQgfSBmcm9tICcuL3FuYXYtbGluZS1jaGFydC1vbGQvcW5hdi1saW5lLWNoYXJ0LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IFBlcmNlbnRGb3JtYXRQaXBlIH0gZnJvbSAnLi9waXBlL3BlcmNlbnQtZm9ybWF0LnBpcGUnO1xyXG5pbXBvcnQgeyBOdW1iZXJSb3VuZFVwUGlwZSB9IGZyb20gJy4vcGlwZS9udW1iZXItcm91bmR1cC5waXBlJztcclxuaW1wb3J0IHsgQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCB9IGZyb20gJy4vY3VzdG9tLWFsZXJ0LW1vZGFsL2N1c3RvbS1hbGVydC1tb2RhbC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBSZXNvdXJjZU1hbmFnZXJTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9yZXNvdXJjZS1tYW5hZ2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDbGlja091dHNpZGVNb2R1bGUgfSBmcm9tICduZy1jbGljay1vdXRzaWRlJztcclxuaW1wb3J0IHsgQWRkRnVuZE1vZGFsQ29tcG9uZW50IH0gZnJvbSAnLi9hZGQtZnVuZC1tb2RhbC9hZGQtZnVuZC1tb2RhbC5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBNYXREaWFsb2dNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9kaWFsb2cnO1xyXG5pbXBvcnQgeyBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCB9IGZyb20gJy4vcG9zaXRpb24taGVhdC1tYXAvcG9zaXRpb24taGVhdC1tYXAuY29tcG9uZW50JztcclxuaW1wb3J0IHsgSGVhdE1hcENvbXBvbmVudCB9IGZyb20gJy4vaGVhdC1tYXAvaGVhdC1tYXAuY29tcG9uZW50JztcclxuaW1wb3J0IHsgUG9zaXRpb25GdW5kU3VtbWFyeUNvbXBvbmVudCB9IGZyb20gJy4vcG9zaXRpb24tZnVuZC1zdW1tYXJ5L3Bvc2l0aW9uLWZ1bmQtc3VtbWFyeS5jb21wb25lbnQnO1xyXG5pbXBvcnQgeyBTaW5nbGVMaW5lQ2hhcnRDb21wb25lbnQgfSBmcm9tICcuL3NpbmdsZS1saW5lLWNoYXJ0L3NpbmdsZS1saW5lLWNoYXJ0LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IENvbW1vbkRhdGFUYWJsZUNvbXBvbmVudCB9IGZyb20gJy4vY29tbW9uLWRhdGEtdGFibGUvY29tbW9uLWRhdGEtdGFibGUuY29tcG9uZW50JztcclxuaW1wb3J0IHsgTWFpbkRhdGF0YWJsZUNvbXBvbmVudCB9IGZyb20gJy4vbWFpbi1kYXRhdGFibGUvbWFpbi1kYXRhdGFibGUuY29tcG9uZW50JztcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgaW1wb3J0czogW1xyXG4gICAgQnJvd3NlckFuaW1hdGlvbnNNb2R1bGUsXHJcbiAgICBNYXRCdXR0b25Nb2R1bGUsXHJcbiAgICBNYXRDaGVja2JveE1vZHVsZSxcclxuICAgIFVpQ29tbW9uTW9kdWxlLFxyXG4gICAgRHluYW1pY01vZHVsZS53aXRoQ29tcG9uZW50cyhbXHJcbiAgICAgIFFuYXZMaW5lQ2hhcnRDb21wb25lbnQsIFxyXG4gICAgICBNYWluRGF0YXRhYmxlQ29tcG9uZW50LFxyXG4gICAgICBRbmF2UG9zaXRpb25Db21wb25lbnQsXHJcbiAgICAgIFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCxcclxuICAgICAgUG9zaXRpb25GdW5kU3VtbWFyeUNvbXBvbmVudFxyXG4gICAgICBdKSxcclxuICAgIE5neERhdGF0YWJsZU1vZHVsZSxcclxuICAgIE5neENoYXJ0c01vZHVsZSxcclxuICAgIE1hdENoaXBzTW9kdWxlLFxyXG4gICAgTWF0SWNvbk1vZHVsZSxcclxuICAgIEh0dHBDbGllbnRNb2R1bGUsXHJcbiAgICBNYXREaWFsb2dNb2R1bGUsXHJcbiAgICBNYXRNZW51TW9kdWxlLFxyXG4gICAgQ2xpY2tPdXRzaWRlTW9kdWxlXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIFFuYXZMaW5lQ2hhcnRDb21wb25lbnQsXHJcbiAgICBMaW5lQ2hhcnRDb21wb25lbnQsXHJcbiAgICBDdXN0b21MZWdlbmRDb21wb25lbnQsXHJcbiAgICBRbmF2UG9zaXRpb25Db21wb25lbnQsXHJcbiAgICBQZXJjZW50Rm9ybWF0UGlwZSxcclxuICAgIE51bWJlclJvdW5kVXBQaXBlLFxyXG4gICAgQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCxcclxuICAgIEFkZEZ1bmRNb2RhbENvbXBvbmVudCxcclxuICAgIFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCxcclxuICAgIEhlYXRNYXBDb21wb25lbnQsXHJcbiAgICBQb3NpdGlvbkZ1bmRTdW1tYXJ5Q29tcG9uZW50LFxyXG4gICAgU2luZ2xlTGluZUNoYXJ0Q29tcG9uZW50LFxyXG4gICAgQ29tbW9uRGF0YVRhYmxlQ29tcG9uZW50LFxyXG4gICAgTWFpbkRhdGF0YWJsZUNvbXBvbmVudFxyXG4gIF0sXHJcbiAgcHJvdmlkZXJzOltEYXRlUGlwZSwgQXBwUmVnaXN0cnldLFxyXG4gIGV4cG9ydHM6IFtcclxuICAgIFFuYXZMaW5lQ2hhcnRDb21wb25lbnQsIFxyXG4gICAgUW5hdlBvc2l0aW9uQ29tcG9uZW50LCBcclxuICAgIFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCxcclxuICAgIFBvc2l0aW9uRnVuZFN1bW1hcnlDb21wb25lbnQsXHJcbiAgICBNYWluRGF0YXRhYmxlQ29tcG9uZW50XHJcbiAgXSxcclxuICBlbnRyeUNvbXBvbmVudHM6IFtcclxuICAgIFFuYXZMaW5lQ2hhcnRDb21wb25lbnQsIFxyXG4gICAgUW5hdlBvc2l0aW9uQ29tcG9uZW50LFxyXG4gICAgQ3VzdG9tQWxlcnRNb2RhbENvbXBvbmVudCxcclxuICAgIEFkZEZ1bmRNb2RhbENvbXBvbmVudCxcclxuICAgIFBvc2l0aW9uSGVhdE1hcENvbXBvbmVudCxcclxuICAgIFBvc2l0aW9uRnVuZFN1bW1hcnlDb21wb25lbnQsXHJcbiAgICBNYWluRGF0YXRhYmxlQ29tcG9uZW50XHJcbiAgICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBVaVFOYXZNb2R1bGUge1xyXG4gIHN0YXRpYyBmb3JSb290KGVudmlyb25tZW50OiBhbnkpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIG5nTW9kdWxlIDogVWlRTmF2TW9kdWxlLFxyXG4gICAgICBwcm92aWRlcnM6W1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIHByb3ZpZGU6ICdlbnYnLFxyXG4gICAgICAgICAgdXNlVmFsdWU6IGVudmlyb25tZW50XHJcbiAgICAgICAgfVxyXG4gICAgICBdXHJcbiAgICB9XHJcbiAgfVxyXG4gIHBlcm1pc3Npb25zOiBzdHJpbmdbXSA9IFsnQXBwbGljYXRpb24vbmF2ZGV2ZWxvcGVyJywnQXBwbGljYXRpb24vbmF2YW5hbHlzdCddO1xyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSBhcHBSZWdpc3RyeTogQXBwUmVnaXN0cnlcclxuICApIHtcclxuXHJcbiAgICBhcHBSZWdpc3RyeS5yZWdpc3RlckNvbXBvbmVudCgnbGluZUNoYXJ0JywgUW5hdkxpbmVDaGFydENvbXBvbmVudCk7XHJcbiAgICBhcHBSZWdpc3RyeS5yZWdpc3RlckNvbXBvbmVudCgnbGl2ZURhdGFUYWJsZScsIE1haW5EYXRhdGFibGVDb21wb25lbnQpO1xyXG4gICAgYXBwUmVnaXN0cnkucmVnaXN0ZXJDb21wb25lbnQoJ2xpdmVQb3NpdGlvbicsIFFuYXZQb3NpdGlvbkNvbXBvbmVudCk7XHJcbiAgICBhcHBSZWdpc3RyeS5yZWdpc3RlckNvbXBvbmVudCgncG9zaXRpb25IZWF0TWFwJywgUG9zaXRpb25IZWF0TWFwQ29tcG9uZW50KTtcclxuICAgIGFwcFJlZ2lzdHJ5LnJlZ2lzdGVyQ29tcG9uZW50KCdwb3NpdGlvbkZ1bmRTdW1tYXJ5JywgUG9zaXRpb25GdW5kU3VtbWFyeUNvbXBvbmVudCk7XHJcblxyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuIFxyXG5cclxuICAgIGFwcFJlZ2lzdHJ5LnJlZ2lzdGVyRGFzaGJvYXJkKCdRTkFWLTAwMScsICdRTkFWIEVudGl0eSBMaXN0JyxcclxuICAgICAgW1xyXG4gICAgICAgIHsgeDogMCwgeTogMCwgcm93czogMSwgY29sczogMSwgY29uZmlnOiB7fSwgY29tcDogJ2xpbmVDaGFydCcsIHRpdGxlOiBudWxsLCBzaG93SGVhZGVyOiB0cnVlIH0sXHJcbiAgICAgICAgeyB4OiAwLCB5OiAxLCByb3dzOiAxLCBjb2xzOiAxLCBjb25maWc6IHt9LCBjb21wOiAnbGl2ZURhdGFUYWJsZScsIHRpdGxlOiBudWxsLCBzaG93SGVhZGVyOiB0cnVlIH1cclxuICAgICAgXSwgdHJ1ZSwgdHJ1ZSwgJ3FuZicsJ1FOQVYnLCB0aGlzLnBlcm1pc3Npb25zXHJcbiAgICApXHJcblxyXG4gICAgYXBwUmVnaXN0cnkucmVnaXN0ZXJEYXNoYm9hcmQoJ1FOQVYtMDAyJywgJ1FOQVYgUG9zaXRpb24nLFxyXG4gICAgICBbXHJcbiAgICAgICAgeyB4OiAwLCB5OiAwLCByb3dzOiAxLCBjb2xzOiAxLCBjb25maWc6IHt9LCBjb21wOiAncG9zaXRpb25IZWF0TWFwJywgdGl0bGU6IG51bGwsIHNob3dIZWFkZXI6IHRydWUgfSxcclxuICAgICAgICAvLyB7IHg6IDAsIHk6IDEsIHJvd3M6IDEsIGNvbHM6IDEsIGNvbmZpZzoge30sIGNvbXA6ICdwb3NpdGlvbkZ1bmRTdW1tYXJ5JywgdGl0bGU6IG51bGwsIHNob3dIZWFkZXI6IHRydWUgfSxcclxuICAgICAgICB7IHg6IDAsIHk6IDEsIHJvd3M6IDEsIGNvbHM6IDEsIGNvbmZpZzoge30sIGNvbXA6ICdsaXZlUG9zaXRpb24nLCB0aXRsZTogbnVsbCwgc2hvd0hlYWRlcjogdHJ1ZSB9XHJcbiAgICAgIF0sIHRydWUsIHRydWUsICdxbnAnLCdRTkFWJyx0aGlzLnBlcm1pc3Npb25zXHJcbiAgICApXHJcblxyXG4gIH1cclxuXHJcbn1cclxuIl0sIm5hbWVzIjpbImN1c3RvbUNvbHVtbiIsIm5vcm1hbENvbHVtbiIsImNvbHVtbk1lbnVEcm9wRG93blNldHRpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0lBa0JFO1FBVk8sYUFBUSxHQUFTLEVBQUUsQ0FBQztRQUNuQixxQkFBZ0IsR0FBUSxFQUFFLENBQUM7UUFDNUIsZ0JBQVcsR0FBVSxFQUFFLENBQUM7UUFDeEIsMkJBQXNCLEdBQXNCLElBQUssWUFBWSxFQUFPLENBQUM7UUFDckUsbUJBQWMsR0FBc0IsSUFBSyxZQUFZLEVBQU8sQ0FBQzs7UUFFN0Qsc0JBQWlCLEdBQXNCLElBQUksWUFBWSxFQUFPLENBQUM7UUFDL0Qsa0JBQWEsR0FBc0IsSUFBSSxZQUFZLEVBQU8sQ0FBQztRQUMzRCx3QkFBbUIsR0FBc0IsSUFBSSxZQUFZLEVBQU8sQ0FBQztLQUV2RDs7Ozs7SUFFViwyQkFBMkIsQ0FBQyxRQUFRO1FBQ3pDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0tBQzFCOzs7OztJQUVNLG1CQUFtQixDQUFDLElBQUk7UUFDN0IsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztLQUM5Qjs7Ozs7SUFFTSxjQUFjLENBQUMsV0FBbUI7UUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7S0FDaEM7Ozs7SUFFTSxXQUFXO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0tBQzlCOzs7O0lBQ00sS0FBSztRQUNWLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7UUFDM0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUssWUFBWSxFQUFPLENBQUM7UUFDdkQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksWUFBWSxFQUFPLENBQUM7UUFDakQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO1FBQzdDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0tBQ3BEOzs7WUF4Q0YsVUFBVSxTQUFDO2dCQUNWLFVBQVUsRUFBRSxNQUFNO2FBQ25COzs7Ozs7Ozs7QUNMRDs7OztJQWFFLFlBQW9CLDJCQUE2RDtRQUE3RCxnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQWtDO1FBTGpGLGNBQVMsR0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQzdCLFlBQU8sR0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQzNCLGlCQUFZLEdBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQyxhQUFRLEdBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUM1Qix1QkFBa0IsR0FBWSxLQUFLLENBQUM7UUFHbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7O1lBQ3JDLFFBQVEsR0FBRyxXQUFXLENBQUM7WUFDekIsSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQTthQUMzQjtpQkFBTTtnQkFDTCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQzdCLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUN6QjtTQUNGLEVBQUUsSUFBSSxDQUFDO1FBQ1IsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDbEU7Ozs7O0lBQ0Qsa0JBQWtCLENBQUMsSUFBVTtRQUMzQixJQUFLLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ3pCLE9BQU8sS0FBSyxDQUFDO1NBQ2Q7UUFDRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7OztJQUNELGtCQUFrQixDQUFDLElBQVU7UUFDM0IsSUFBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUMzQixPQUFPLEtBQUssQ0FBQztTQUNkO1FBQ0QsT0FBTyxJQUFJLENBQUM7S0FDYjs7Ozs7SUFFRCxXQUFXLENBQUMsSUFBVTtRQUVwQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2xELE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFDRCxPQUFPLEtBQUssQ0FBQztLQUNkOzs7OztJQUVNLGdCQUFnQixDQUFDLElBQVU7UUFDaEMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUM3QixPQUFPLElBQUksQ0FBQztTQUNiO1FBQ0QsT0FBTyxLQUFLLENBQUM7S0FDZDs7OztJQUVNLGNBQWM7O2NBQ2IsT0FBTyxHQUFHLGtCQUFrQjs7WUFDOUIsS0FBSyxHQUFHLEdBQUc7UUFDZixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFCLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNsRDtRQUNELE9BQU8sS0FBSyxDQUFDO0tBQ2Q7Ozs7O0lBRU0sZUFBZSxDQUFDLE1BQWM7UUFDbkMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQy9CLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTtZQUM3RCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxTQUFTLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLENBQUM7Z0JBQ3hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3RCO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztLQUU5Qjs7Ozs7SUFDTSxpQkFBaUIsQ0FBQyxNQUFjO1FBQ3JDLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTtZQUM3RCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxNQUFNLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUM7YUFDNUI7U0FDRjtLQUNGOzs7Ozs7SUFFTSxnQkFBZ0IsQ0FBQyxNQUFjLEVBQUUsU0FBa0I7O2NBQ2xELEtBQUssR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FBQztRQUM1RyxJQUFJLFNBQVMsS0FBSyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbEYsT0FBTztTQUNSO1FBQ0QsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLFNBQVMsQ0FBQzs7UUFFN0UsSUFBSSxTQUFTLEtBQUssS0FBSyxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQzthQUFNO1lBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5QjtLQUVGOzs7OztJQUVNLFVBQVUsQ0FBQyxJQUFVOztZQUN0QixDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDOztZQUNsQixNQUFNLEdBQUcsSUFBSTtRQUNqQixJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDeEIsTUFBTSxHQUFHLElBQUksQ0FBQztTQUNmO2FBQU0sSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDdEQsTUFBTSxHQUFHLElBQUksQ0FBQztTQUNmO2FBQU07WUFDTCxNQUFNLEdBQUcsSUFBSSxDQUFDO1NBQ2Y7UUFDRCxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUM7S0FDL0Y7Ozs7O0lBQ00sY0FBYyxDQUFDLElBQUk7O1lBQ3BCLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7UUFFdEIsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ3hCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QjthQUFNLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ3RELENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDakIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QjthQUFNO1lBQ0wsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNqQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3RCO1FBQ0QsT0FBTyxDQUFDLENBQUM7S0FDVjs7Ozs7SUFFTSxZQUFZO1FBQ2pCLElBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTtZQUMvQyxJQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUssSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTtnQkFDMUYsT0FBTyxJQUFJLENBQUM7YUFDYjtTQUNGO1FBQ0QsSUFBSSxDQUFDLDJCQUEyQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN0RixPQUFPLEtBQUssQ0FBQztLQUNkOzs7OztJQUVNLG9CQUFvQixDQUFDLElBQUk7O2NBQ3hCLGFBQWEsR0FBRyxvQkFBQyxJQUFJLElBQVcsR0FBRyxDQUFDLENBQUM7O2tCQUMvQixPQUFPLEdBQUc7O2dCQUVaLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTTtnQkFDaEIsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRO2dCQUNwQixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7Z0JBQ1osT0FBTyxFQUFFLEdBQUc7Z0JBQ1osS0FBSyxFQUFFLFFBQVE7YUFDaEI7O2tCQUNLLGNBQWMsR0FBRyxDQUFDLENBQUMsbUJBQW1COztrQkFDdEMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDLENBQUM7WUFDcEQsT0FBTyxHQUFHLENBQUM7U0FDWixDQUFDO1FBQ1IsT0FBTyxhQUFhLENBQUM7S0FDdEI7Ozs7O0lBRU0scUJBQXFCLENBQUMsSUFBSTs7Y0FDekIsY0FBYyxHQUFHLEVBQUU7UUFDekIsb0JBQUMsSUFBSSxJQUFXLE9BQU8sQ0FBQyxDQUFDOztrQkFDWixPQUFPLEdBQUc7O2dCQUVmLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTTtnQkFDaEIsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRO2dCQUNwQixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7Z0JBQ1osS0FBSyxFQUFFLE9BQU87YUFDZjs7a0JBQ0ssY0FBYyxHQUFHLENBQUMsQ0FBQyxtQkFBbUI7WUFDNUMsS0FBSSxJQUFJLEdBQUcsSUFBSSxjQUFjLEVBQUU7Z0JBQzdCLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTs7MEJBQ1QsUUFBUSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUMsQ0FBQztvQkFDNUUsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7aUJBQzVDO2FBQ0Y7U0FFRixDQUFDLENBQUM7UUFDSCxPQUFPLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztLQUNyQzs7Ozs7O0lBRU0sYUFBYSxDQUFDLElBQUksRUFBQyxVQUFVOztZQUM5QixVQUFVLEdBQUcsRUFBRTs7Y0FDYixJQUFJLEdBQUc7WUFDWCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZOztZQUUvQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGtCQUFrQjtZQUMzQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDdkIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixrQkFBa0IsRUFBRSxJQUFJLENBQUMsa0JBQWtCO1lBQzNDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDdkIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1NBQzVCO1FBQ0QsSUFBSSxVQUFVLEVBQUU7WUFDWixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksRUFBRTtnQkFDdEIsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUU7OzBCQUNULEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBQyxPQUFPLEVBQUUsR0FBRyxFQUFDLENBQUM7b0JBQzFELFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNuQzthQUNGO1NBQ0Y7YUFBTTtZQUNMLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdkIsVUFBVSxHQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUMsQ0FBQyxDQUFDO1NBQy9EO1FBQ0QsT0FBTyxVQUFVLENBQUM7S0FDbkI7Ozs7Ozs7OztJQUVNLGdCQUFnQixDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLE9BQU87O2NBQ3JFLEtBQUssR0FBRyxFQUFFO1FBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNmLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxHQUFHO2dCQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDM0MsSUFBSSxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUM7Z0JBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM5QyxDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDekYsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJOztrQkFDZCxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07WUFDMUIscUJBQXFCLENBQUMsT0FBTyxDQUFDLFVBQVU7Z0JBQ3RDLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxNQUFNLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTs7MEJBQy9DLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssTUFBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFBLEVBQUMsQ0FBQztvQkFDeEUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQTtpQkFDakM7YUFDRixDQUFDLENBQUE7U0FDSCxDQUFDLENBQUM7UUFDSCxPQUFPLEtBQUssQ0FBQztLQUNkOzs7OztJQUVPLGNBQWMsQ0FBQyxJQUFJO1FBQ3pCLE9BQU8sVUFBVSxJQUFJLEVBQUUsSUFBSTs7Z0JBQ3JCLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOztnQkFDZixFQUFFLEdBQUksSUFBSSxDQUFDLElBQUksQ0FBQztZQUNwQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUM1QyxFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNoQixFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ2pCO1lBRUQsSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQy9CLE9BQU8sQ0FBQyxDQUFDLENBQUE7YUFDVjtpQkFBTSxJQUFJLEVBQUUsS0FBSyxTQUFTLElBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDdkMsT0FBTyxDQUFDLENBQUM7YUFDVjtpQkFBTTtnQkFDTCxPQUFPLENBQUMsQ0FBQTthQUNUO1NBQ0YsQ0FBQTtLQUNGOzs7OztJQUVPLGVBQWUsQ0FBQyxJQUFJO1FBQzFCLE9BQU8sVUFBVSxJQUFJLEVBQUUsSUFBSTs7Z0JBQ3JCLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDOztnQkFDZixFQUFFLEdBQUksSUFBSSxDQUFDLElBQUksQ0FBQztZQUNwQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUM1QyxFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNoQixFQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ2pCO1lBQ0QsSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FBRyxFQUFHLEVBQUU7Z0JBQ2hDLE9BQU8sQ0FBQyxDQUFBO2FBQ1Q7aUJBQU0sSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQ3RDLE9BQU8sQ0FBQyxDQUFDLENBQUM7YUFDWDtpQkFBTTtnQkFDTCxPQUFPLENBQUMsQ0FBQTthQUNUO1NBQ0YsQ0FBQTtLQUNGOzs7WUFsUUYsVUFBVSxTQUFDO2dCQUNWLFVBQVUsRUFBRSxNQUFNO2FBQ25COzs7WUFMUSxnQ0FBZ0M7Ozs7Ozs7O0FDRHpDLHdCQStNZ0MsU0FBUSxrQkFBa0I7Ozs7Ozs7O0lBZ0Z4RCxZQUFZLFlBQXdCLEVBQ2hCLElBQVksRUFDWixFQUFxQixFQUNiLFdBQStCLEVBQy9CLFFBQWtCO1FBQzVDLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRkosZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1FBQy9CLGFBQVEsR0FBUixRQUFRLENBQVU7UUFsRnJDLGdCQUFXLEdBQVcsUUFBUSxDQUFDO1FBUS9CLGtCQUFhLEdBQVksSUFBSSxDQUFDO1FBQzlCLFVBQUssR0FBUSxXQUFXLENBQUM7UUFPekIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsbUJBQWMsR0FBUSxFQUFFLENBQUM7UUFDekIsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFTL0IsZ0JBQVcsR0FBVSxFQUFFLENBQUM7UUFFeEIsZUFBVSxHQUFVLEVBQUUsQ0FBQztRQUV2QixlQUFVLEdBQVUsRUFBRSxDQUFDO1FBRXZCLGtCQUFhLEdBQVUsRUFBRSxDQUFDO1FBQzFCLDJCQUFzQixHQUFVLEVBQUUsQ0FBQztRQUVsQyxhQUFRLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDakQsZUFBVSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBbUI3RCxnQkFBVyxHQUFXLENBQUMsQ0FBQztRQUN4QixlQUFVLEdBQVcsQ0FBQyxDQUFDO1FBS3ZCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBSzVCLG9CQUFlLEdBQVcsRUFBRSxDQUFDO1FBRzdCLGlCQUFZLEdBQVcsQ0FBQyxDQUFDO1FBQ3pCLGVBQVUsR0FBUSxFQUFFLENBQUM7UUFHckIsd0JBQW1CLEdBQVUsRUFBRSxDQUFDO0tBUS9COzs7O0lBRUQsTUFBTTtRQUVKLElBQUksQ0FBQyxJQUFJLEdBQUcsdUJBQXVCLENBQUM7WUFDbEMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDcEIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO1lBQzdCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWM7WUFDL0IsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjO1lBQy9CLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTTtZQUN2QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7U0FDNUIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDbkY7UUFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNqQyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDdkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQ3BDO1FBRUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFM0MsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU1RCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTdELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRTdDLElBQUksQ0FBQyxTQUFTLEdBQUcsYUFBYSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFFdkUsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLEdBQUcsRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQzs7UUFHM0MsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsU0FBUyxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0tBRWxEOzs7OztJQUdELFNBQVMsQ0FBQyxVQUFVOztZQUNkLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTTs7WUFDcEIsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNOztZQUNwQixHQUFHLEdBQUcsRUFBRTtRQUVaLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSzs7Z0JBQ3pCLEdBQUcsR0FBRztnQkFDUixDQUFDLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLElBQUksRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFDLG1CQUFtQixDQUFDO2dCQUNqRSxLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ3pCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFDckQsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN6QixTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUs7Z0JBQ3JCLFFBQVEsRUFBRSxJQUFJLENBQUMsbUJBQW1CO2dCQUNsQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7YUFDMUI7WUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2YsQ0FBQyxDQUFDO1FBRUgsT0FBTyxHQUFHLENBQUM7S0FDWjs7OztJQUVELGVBQWU7O1lBQ1QsR0FBRyxHQUFHLEVBQUU7UUFDWixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUs7Z0JBQzVCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRTs7d0JBQ2hDLEdBQUcsR0FBRzt3QkFDUixJQUFJLEVBQUUsS0FBSyxDQUFDLE1BQU07d0JBQ2xCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztxQkFDbkI7b0JBQ0QsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtpQkFDZDthQUNGLENBQUMsQ0FBQTtTQUNILENBQUMsQ0FBQztRQUNILE9BQU8sR0FBRyxDQUFDO0tBQ1o7Ozs7SUFFRCxVQUFVOztZQUNKLE1BQU0sR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQ2pELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7WUFDdkMsTUFBTSxHQUFHLEVBQUU7UUFFZixJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQy9CLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNyQzs7WUFFRyxHQUFHOztZQUNILEdBQUc7UUFDUCxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQzVELEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUztrQkFDaEIsSUFBSSxDQUFDLFNBQVM7a0JBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1lBRXhCLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUztrQkFDaEIsSUFBSSxDQUFDLFNBQVM7a0JBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1NBQ3pCO1FBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtZQUM3QixNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDOztzQkFDMUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUU7O3NCQUNuQixLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTtnQkFDekIsSUFBSSxLQUFLLEdBQUcsS0FBSztvQkFBRSxPQUFPLENBQUMsQ0FBQztnQkFDNUIsSUFBSSxLQUFLLEdBQUcsS0FBSztvQkFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixPQUFPLENBQUMsQ0FBQzthQUNWLENBQUMsQ0FBQztTQUNKO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUN0QyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7O1lBRXBCLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDakQ7YUFBTTtZQUNMLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDaEIsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDcEI7UUFFRCxPQUFPLE1BQU0sQ0FBQztLQUNmOzs7O0lBRUQsVUFBVTs7Y0FDRixNQUFNLEdBQUcsRUFBRTtRQUNqQixLQUFLLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDbEMsS0FBSyxNQUFNLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUM5QixJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUMxQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDdEI7Z0JBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQkFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDcEI7aUJBQ0Y7Z0JBQ0QsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRTtvQkFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3JCLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDcEI7aUJBQ0Y7YUFDRjtTQUNGOztjQUVLLE1BQU0sR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ25CLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDaEI7O2NBRUssR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO2NBQ3RCLElBQUksQ0FBQyxTQUFTO2NBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQzs7Y0FFakIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO2NBQ3RCLElBQUksQ0FBQyxTQUFTO2NBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQztRQUVyQixJQUFJLEdBQUcsS0FBSyxTQUFTLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUMxQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ25CO2FBQUs7WUFDSixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDcEI7S0FDSjs7OztJQUVELGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDdEM7Ozs7OztJQUVELFNBQVMsQ0FBQyxNQUFNLEVBQUUsS0FBSzs7WUFDakIsS0FBSztRQUVULElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUU7WUFDN0IsS0FBSyxHQUFHLFNBQVMsRUFBRTtpQkFDaEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUNqQixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbkI7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQ3RDLEtBQUssR0FBRyxXQUFXLEVBQUU7aUJBQ2xCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDakIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWxCLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDckIsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUN0QjtTQUNGO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRTtZQUN2QyxLQUFLLEdBQUcsVUFBVSxFQUFFO2lCQUNqQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUM7aUJBQ1osTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ25CO1FBRUQsT0FBTyxLQUFLLENBQUM7S0FDZDs7Ozs7O0lBRUQsU0FBUyxDQUFDLE1BQU0sRUFBRSxNQUFNOztjQUNoQixLQUFLLEdBQUcsV0FBVyxFQUFFO2FBQ3hCLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNsQixNQUFNLENBQUMsTUFBTSxDQUFDO1FBRWpCLE9BQU8sSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDO0tBQ2pEOzs7OztJQUVELFlBQVksQ0FBQyxNQUFNOztZQUNiLElBQUksR0FBRyxJQUFJOztZQUNYLEdBQUcsR0FBRyxJQUFJO1FBRWQsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUU7WUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3ZCLElBQUksR0FBRyxLQUFLLENBQUM7YUFDZDtZQUVELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO2dCQUM3QixHQUFHLEdBQUcsS0FBSyxDQUFDO2FBQ2I7U0FDRjtRQUVELElBQUksSUFBSTtZQUFFLE9BQU8sTUFBTSxDQUFDO1FBQ3hCLElBQUksR0FBRztZQUFFLE9BQU8sUUFBUSxDQUFDO1FBQ3pCLE9BQU8sU0FBUyxDQUFDO0tBQ2xCOzs7OztJQUVELE1BQU0sQ0FBQyxLQUFLO1FBQ1YsSUFBSSxLQUFLLFlBQVksSUFBSSxFQUFFO1lBQ3pCLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFFRCxPQUFPLEtBQUssQ0FBQztLQUNkOzs7OztJQUVELGdCQUFnQixDQUFDLEVBQUUsS0FBSyxFQUFFO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztLQUNmOzs7OztJQUVELGlCQUFpQixDQUFDLEVBQUUsTUFBTSxFQUFFO1FBQzFCLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztLQUNmOzs7OztJQUVELHFCQUFxQixDQUFDLElBQUk7UUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUE7UUFFdEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztLQUN0Qjs7OztJQUdELFdBQVc7UUFDVCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUM7S0FDbEQ7Ozs7O0lBR0QsWUFBWSxDQUFDLE1BQU07UUFDakIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDNUI7Ozs7O0lBR0QsWUFBWSxDQUFDLE1BQU07UUFDakIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDOUI7Ozs7OztJQUVELE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTztRQUNuQixJQUFJLE1BQU0sRUFBRTtZQUNWLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztTQUMzQjtRQUVELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3hCOzs7Ozs7SUFFRCxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUk7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ2xCOzs7O0lBRUQsU0FBUzs7WUFDSCxNQUFNO1FBQ1YsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLFNBQVMsRUFBRTtZQUNqQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUM1QjthQUFNO1lBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7U0FDdkI7UUFFRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0tBQ3hGOzs7O0lBRUQsZ0JBQWdCOztjQUNSLElBQUksR0FBRztZQUNYLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUMxQixNQUFNLEVBQUUsU0FBUztZQUNqQixNQUFNLEVBQUUsRUFBRTtZQUNWLEtBQUssRUFBRSxTQUFTO1NBQ2pCO1FBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRTtZQUNoQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDaEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztTQUMvQjthQUFNO1lBQ0wsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQzNCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7U0FDakM7UUFDRCxPQUFPLElBQUksQ0FBQztLQUNiOzs7OztJQUVELFVBQVUsQ0FBQyxJQUFJO1FBQ2IsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDOztjQUVmLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hDLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztTQUN2RCxDQUFDO1FBQ0YsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDWixPQUFPO1NBQ1I7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztRQUVqRSxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQTtRQUN0RCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7S0FDdkI7Ozs7O0lBRUQsWUFBWSxDQUFDLElBQUk7O2NBQ1QsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDeEMsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ3ZELENBQUM7UUFFRixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTdDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7S0FDcEU7Ozs7SUFFRCxhQUFhO1FBQ1gsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzdDLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDckQ7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztLQUN6Qjs7OztJQUVELGNBQWM7O1lBQ1IsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1FBQzVDLElBQUksU0FBUyxFQUFFO1lBQ2IsSUFBSSxTQUFTLElBQUksQ0FBQyxFQUFFO2dCQUNsQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFBO2FBQ25DO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUE7YUFDbkM7U0FDRjtLQUVGOzs7O0lBRUQsaUJBQWlCOztZQUNYLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTzs7WUFDbEIsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDOztZQUNsQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7O1lBQ25DLFVBQVUsR0FBRyxFQUFFOztZQUNmLEdBQUc7UUFFUCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxRQUFRLEVBQUU7Z0JBQy9CLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsTUFBTTthQUNQO1NBQ0Y7O1lBRUcsTUFBTSxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUM7UUFFakMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUNsQyxHQUFHLEdBQUc7b0JBQ0osS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZCLFdBQVcsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO2lCQUNwQyxDQUFBO2dCQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFBO2dCQUNyRCxNQUFNO2FBQ1A7U0FDRjtLQUNGOzs7Ozs7SUFHQSxrQkFBa0IsQ0FBQyxJQUFJO1FBQ3RCLElBQUksSUFBSSxFQUFFOztnQkFDSixnQkFBZ0IsR0FBRyxLQUFLO1lBQzVCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDbkMsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUNoRCxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2lCQUN4QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztpQkFDbkI7YUFDRixDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsZ0JBQWdCLEVBQUM7O29CQUNoQixHQUFHLEdBQUc7b0JBQ1IsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNULElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUk7aUJBQzFDO2dCQUNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDcEM7U0FDRjtLQUNGOzs7OztJQUVELG1CQUFtQixDQUFDLElBQUk7O1lBQ2xCLFNBQVMsR0FBRyxLQUFLO1FBQ3JCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNuQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ2hELFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxTQUFTLENBQUM7S0FDbEI7Ozs7O0lBRUQsZ0JBQWdCLENBQUMsTUFBTTs7WUFDakIsU0FBUyxHQUFHLENBQUM7UUFDZixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7WUFDbkUsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUUsR0FBRyxDQUFBO1NBQzFCO2FBQU07WUFDTCxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRSxFQUFFLENBQUE7U0FDekI7UUFDRCxPQUFPLFNBQVMsQ0FBQztLQUNsQjs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxNQUFNOztZQUNqQixTQUFTLEdBQUcsQ0FBQztRQUNqQixJQUFHLE1BQU0sQ0FBQyxTQUFTLElBQUcsQ0FBQyxFQUFFO1lBQ3ZCLFNBQVMsR0FBRyxNQUFNLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQTtTQUM5QjthQUFNO1lBQ0wsU0FBUyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUUsR0FBRyxDQUFBO1NBQzlCO1FBQ0QsT0FBTyxTQUFTLENBQUE7S0FDakI7OztZQWhzQkYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxxQkFBcUI7Z0JBQy9CLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdLTDtnQkFDTCxNQUFNLEVBQUUsQ0FBQywrOUxBQSs5TCxDQUFDO2dCQUN6K0wsYUFBYSxFQUFFLGlCQUFpQixDQUFDLFNBQVM7Z0JBQzFDLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2dCQUMvQyxVQUFVLEVBQUU7b0JBQ1YsT0FBTyxDQUFDLGdCQUFnQixFQUFFO3dCQUN4QixVQUFVLENBQUMsUUFBUSxFQUFFOzRCQUNuQixLQUFLLENBQUM7Z0NBQ0osT0FBTyxFQUFFLENBQUM7NkJBQ1gsQ0FBQzs0QkFDRixPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztnQ0FDakIsT0FBTyxFQUFFLENBQUM7NkJBQ1gsQ0FBQyxDQUFDO3lCQUNKLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDthQUNGOzs7WUE3TUMsVUFBVTtZQUFFLE1BQU07WUFBRSxpQkFBaUI7WUF5QjlCLGtCQUFrQjtZQVJsQixRQUFROzs7cUJBOExkLEtBQUs7MEJBQ0wsS0FBSzs2QkFDTCxLQUFLOzZCQUNMLEtBQUs7eUJBQ0wsS0FBSzt5QkFDTCxLQUFLO3dCQUNMLEtBQUs7dUJBQ0wsS0FBSzt1QkFDTCxLQUFLOzRCQUNMLEtBQUs7b0JBQ0wsS0FBSzt5QkFDTCxLQUFLOytCQUNMLEtBQUs7a0NBQ0wsS0FBSztrQ0FDTCxLQUFLO3lCQUNMLEtBQUs7eUJBQ0wsS0FBSzsyQkFDTCxLQUFLOzhCQUNMLEtBQUs7MkJBQ0wsS0FBSzs2QkFDTCxLQUFLOzRCQUNMLEtBQUs7d0JBQ0wsS0FBSzt3QkFDTCxLQUFLO3dCQUNMLEtBQUs7d0JBQ0wsS0FBSzt5QkFDTCxLQUFLO3FCQUNMLEtBQUs7b0JBQ0wsS0FBSztxQkFDTCxLQUFLOzBCQUNMLEtBQUs7c0JBQ0wsS0FBSzt5QkFDTCxLQUFLOzhCQUNMLEtBQUs7eUJBQ0wsS0FBSzs4QkFDTCxLQUFLOzRCQUNMLEtBQUs7cUNBQ0wsS0FBSzt1QkFFTCxNQUFNO3lCQUNOLE1BQU07OEJBRU4sWUFBWSxTQUFDLGlCQUFpQjtvQ0FDOUIsWUFBWSxTQUFDLHVCQUF1QjswQkF1U3BDLFlBQVksU0FBQyxZQUFZOzJCQU96QixZQUFZLFNBQUMsWUFBWSxFQUFFLENBQUMsUUFBUSxDQUFDOzJCQUtyQyxZQUFZLFNBQUMsWUFBWSxFQUFFLENBQUMsUUFBUSxDQUFDOzs7Ozs7O0FDOWlCeEM7Ozs7O0lBK0JFLFlBQXdCLDJCQUE4RCxFQUMzRSxXQUFnQztRQURuQixnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQW1DO1FBQzNFLGdCQUFXLEdBQVgsV0FBVyxDQUFxQjtLQUN2Qzs7OztJQUVKLFFBQVE7S0FFUDs7OztJQUVELFdBQVc7S0FDVjs7Ozs7SUFFRCwwQkFBMEIsQ0FBQyxJQUFJO1FBRTdCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUU7WUFDcEIsT0FBTyxLQUFLLENBQUE7U0FDYjthQUFNOztrQkFDQyxJQUFJLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTs7Z0JBQ3ZELElBQUksR0FBRyxLQUFLO1lBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDZixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUM3QyxJQUFJLEdBQUcsSUFBSSxDQUFDO2lCQUNiO2FBQ0YsQ0FBQyxDQUFBO1lBQ0YsT0FBTyxJQUFJLENBQUE7U0FDWjtLQUNGOzs7OztJQUNELG1CQUFtQixDQUFDLElBQUk7O1lBQ2xCLFFBQVEsR0FBRyxFQUFFO1FBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDM0IsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQzFCO1NBQ0YsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxRQUFRLENBQUM7S0FDakI7Ozs7O0lBR0QsTUFBTSxDQUFDLElBQUk7UUFDVCxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzs7WUFDckQsU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLO1lBQy9CLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDakMsU0FBUyxHQUFHLEtBQUssQ0FBQzthQUNuQjtTQUNGLENBQUMsQ0FBQztRQUVILElBQUksU0FBUyxJQUFJLENBQUMsRUFBRTtZQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDbkM7UUFFRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3BDOzs7WUE5RUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxtQkFBbUI7Z0JBQzdCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7aUJBY0s7Z0JBQ2YsTUFBTSxFQUFFLENBQUMsZ1ZBQWdWLENBQUM7YUFDM1Y7OztZQXBCUSxnQ0FBZ0M7WUFEaEMsa0JBQWtCOzs7c0JBdUJ4QixLQUFLO3lCQUNMLEtBQUs7d0JBQ0wsS0FBSzswQkFDTCxLQUFLO29CQUNMLEtBQUs7aUNBQ0wsS0FBSzs7Ozs7OztBQzdCUjtBQVFBOzs7Ozs7SUFNRSxZQUFvQixJQUFnQjtRQUFoQixTQUFJLEdBQUosSUFBSSxDQUFZO1FBSjVCLFNBQUksR0FBNEIsSUFBSSxlQUFlLG9CQUFDLEVBQUUsR0FBVSxDQUFDO0tBSWhDOzs7OztJQUd6QyxXQUFXLENBQUMsS0FBSztRQUNmLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQVEsWUFBWSxDQUFDLENBQUM7S0FDM0M7Ozs7O0lBRUQsYUFBYTs7UUFFWCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksZUFBZSxvQkFBQyxFQUFFLEdBQVUsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBUSxvREFBb0QsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMvRyxTQUFTLENBQUMsQ0FBQztZQUNWLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxvQkFBQyxDQUFDLEdBQVUsQ0FBQTtTQUMzQixFQUNDLEtBQUs7WUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO1NBQ25CLENBQUMsQ0FBQztLQUNSOzs7OztJQUVELFdBQVc7UUFDUCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7S0FDbkM7Ozs7O0lBQ0Qsa0JBQWtCLENBQUMsSUFBWTs7UUFFN0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBUSw4Q0FBOEMsR0FBQyxJQUFJLENBQUMsQ0FBQztLQUNsRjs7O1lBbENGLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7O1lBTlEsVUFBVTs7Ozs7Ozs7OztJQ0FmLFVBQVcsVUFBVTtJQUNyQixRQUFTLFFBQVE7SUFDakIsZUFBZ0IsZUFBZTtJQUMvQixXQUFZLFdBQVc7Ozs7Ozs7QUNKM0I7QUFVQTs7Ozs7SUFXSTtRQVBRLFFBQUcsR0FBK0IsSUFBSSxlQUFlLG9CQUFDLEVBQUUsR0FBYSxDQUFDO1FBUXRFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7S0FDOUI7Ozs7SUFFTSxVQUFVO1FBQ2IsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsUUFBUSxHQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFDLEdBQUcsR0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksR0FBQywyQkFBMkIsQ0FBQyxDQUFDOztRQUVqSCxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FDbEIsQ0FBQyxHQUFHLE9BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLG9CQUFDLEdBQUcsR0FBYSxDQUFDLEVBQUMsRUFDMUMsQ0FBQyxHQUFHLEtBQUssT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUMsR0FBRyxDQUFDLEVBQ3JDLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUNqRCxDQUFDOztLQUVMOzs7O0lBRU0sTUFBTTtRQUNULE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztLQUNsQzs7Ozs7SUFDTSxJQUFJLENBQUMsT0FBZ0I7UUFDeEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDOUI7Ozs7O0lBRU0sYUFBYSxDQUFDLEtBQVk7UUFFN0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxRQUFRLEVBQUMsTUFBTSxDQUFDLFNBQVMsRUFBQyxRQUFRLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQTtTQUNyRCxDQUFDLENBQUM7S0FDTjs7Ozs7SUFDTSxlQUFlLENBQUMsS0FBWTtRQUMvQixLQUFLLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLFFBQVEsRUFBQyxNQUFNLENBQUMsYUFBYSxFQUFDLFFBQVEsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFBO1NBQ3pELENBQUMsQ0FBQztLQUNOOzs7O0lBQ00sZUFBZTtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsTUFBTSxFQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUMsU0FBUyxFQUFDLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxFQUFDLGNBQWMsRUFBQyxJQUFJLElBQUksRUFBRSxDQUFDLGlCQUFpQixFQUFFLElBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7S0FDOUg7OztZQW5ESixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckI7Ozs7Ozs7OztBQ1JEO0lBU0U7UUFZUSxzQkFBaUIsR0FBVSxFQUFFLENBQUM7UUFDOUIsa0JBQWEsR0FBVSxFQUFFLENBQUM7OztRQVY5QixNQUFNLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUMsQ0FBQyxLQUFLO1lBQy9DLElBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRTtnQkFDbEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN0QjtpQkFBTTtnQkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3BCO1NBQ0YsQ0FBQyxDQUFBO0tBQ0o7Ozs7O0lBSU0sUUFBUSxDQUFDLEtBQVU7O1FBRXhCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztLQUNwQjs7OztJQUNPLFVBQVU7UUFDZCxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFHLElBQUk7O2dCQUMvQixJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUU7WUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUM7WUFDckUsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3ZCLENBQUMsQ0FBQTtLQUNIOzs7OztJQUNPLE1BQU0sQ0FBQyxLQUFVOztRQUV2QixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBRSxJQUFJOztZQUc5QixJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMxRSxDQUFDLENBQUE7S0FDSDs7Ozs7O0lBQ0QsY0FBYyxDQUFDLFlBQVksRUFBRSxRQUFnQjs7WUFDdkMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDO1FBQ2xELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBQyxNQUFNLEVBQUMsWUFBWSxFQUFFLFVBQVUsRUFBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDO0tBQ3JFOzs7OztJQUVELGNBQWM7UUFDWixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztLQUN6Qjs7O1lBaERGLFVBQVUsU0FBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQjs7Ozs7Ozs7OztBQ05ELE1BQWEsWUFBWSxHQUFHLEVBQUU7O0FBRTVCLE1BQWEsWUFBWSxHQUFJO0lBQzNCO1FBQ0UsSUFBSSxFQUFFLE9BQU87UUFDYixJQUFJLEVBQUUsbUJBQW1CO1FBQ3pCLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsU0FBUztRQUN2QixpQkFBaUIsRUFBRSxZQUFZO1FBQy9CLGVBQWUsRUFBRSxVQUFVO1FBQzNCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsb0JBQW9CO1FBQzFCLElBQUksRUFBRSxZQUFZO1FBQ2xCLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsU0FBUztRQUN2QixpQkFBaUIsRUFBRSxZQUFZO1FBQy9CLGVBQWUsRUFBRSxVQUFVO1FBQzNCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsVUFBVTtRQUNoQixJQUFJLEVBQUUsT0FBTztRQUNiLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsbUJBQW1CO1FBQ2pDLGlCQUFpQixFQUFFLGFBQWE7UUFDaEMsZUFBZSxFQUFFLFdBQVc7UUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1FBQ3RDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLG1CQUFtQixFQUFFLEVBQUU7S0FDeEI7SUFDRDtRQUNFLElBQUksRUFBRSxVQUFVO1FBQ2hCLElBQUksRUFBRSxnQkFBZ0I7UUFDdEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLGFBQWEsRUFBRSxJQUFJO1FBQ25CLGFBQWEsRUFBRSxJQUFJO1FBQ25CLFlBQVksRUFBRSxtQkFBbUI7UUFDakMsaUJBQWlCLEVBQUUsYUFBYTtRQUNoQyxlQUFlLEVBQUUsV0FBVztRQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLE9BQU87UUFDYixJQUFJLEVBQUUsZUFBZTtRQUNyQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtRQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxXQUFXO1FBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsSUFBSTtRQUNWLElBQUksRUFBRSxjQUFjO1FBQ3BCLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsSUFBSTtRQUNuQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsbUJBQW1CO1FBQ2pDLGlCQUFpQixFQUFFLGFBQWE7UUFDaEMsZUFBZSxFQUFFLFdBQVc7UUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1FBQ3RDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLG1CQUFtQixFQUFFLEVBQUU7S0FDeEI7SUFDRDtRQUNFLElBQUksRUFBRSxvQkFBb0I7UUFDMUIsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLGVBQWU7UUFDN0IsaUJBQWlCLEVBQUUsYUFBYTtRQUNoQyxlQUFlLEVBQUUsWUFBWTtRQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLFdBQVc7UUFDakIsSUFBSSxFQUFFLFlBQVk7UUFDbEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLGFBQWEsRUFBRSxJQUFJO1FBQ25CLGFBQWEsRUFBRSxJQUFJO1FBQ25CLFlBQVksRUFBRSxrQkFBa0I7UUFDaEMsaUJBQWlCLEVBQUUsYUFBYTtRQUNoQyxlQUFlLEVBQUUsWUFBWTtRQUM3QixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtDQUNGOztBQUVELE1BQWEseUJBQXlCLEdBQUc7Ozs7OztJQU12QztRQUNFLElBQUksRUFBRSxlQUFlO1FBQ3JCLElBQUksRUFBRSxjQUFjO1FBQ3BCLFVBQVUsRUFBRSxLQUFLO0tBQ2xCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsYUFBYTtRQUNuQixJQUFJLEVBQUUsWUFBWTtRQUNsQixVQUFVLEVBQUUsS0FBSztLQUNsQjtDQU1GOzs7Ozs7QUMxSUgsMkJBa0RtQyxTQUFRLG1CQUFtQjs7Ozs7Ozs7O0lBcUI1RCxZQUFvQixVQUFzQixFQUVkLFVBQXNCLEVBQ3RCLGdCQUFrQyxFQUNsQyxnQ0FBa0UsRUFDbEUsV0FBK0IsRUFDL0IsY0FBc0M7UUFDaEUsS0FBSyxFQUFFLENBQUM7UUFQVSxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBRWQsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1FBQ2xDLHFDQUFnQyxHQUFoQyxnQ0FBZ0MsQ0FBa0M7UUFDbEUsZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1FBQy9CLG1CQUFjLEdBQWQsY0FBYyxDQUF3QjtRQXhCbEUsU0FBSSxHQUFVLEVBQUUsQ0FBQztRQUNqQixjQUFTLEdBQVUsRUFBRSxDQUFDO1FBQ3RCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGNBQVMsR0FBUSxFQUFFLENBQUM7UUFDcEIsY0FBUyxHQUFVLEVBQUUsQ0FBQztRQUN0QixvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQyxrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUMxQixrQkFBYSxHQUFZLElBQUksQ0FBQztRQUM5QixpQkFBWSxHQUFXLEVBQUUsQ0FBQzs7UUFFMUIsc0JBQWlCLEdBQVcsS0FBSyxDQUFDO1FBQ2xDLGlCQUFZLEdBQVUsWUFBWSxDQUFDO1FBQ25DLGlCQUFZLEdBQVUsWUFBWSxDQUFDO1FBQ25DLDhCQUF5QixHQUFVLHlCQUF5QixDQUFDO1FBQzdELFVBQUssR0FBVyxDQUFDLENBQUM7UUFDbEIsaUJBQVksR0FBVyxFQUFFLENBQUM7UUFDMUIsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsYUFBUSxHQUFRLEVBQUUsQ0FBQztLQVNsQjs7OztJQUVELFFBQVE7O1FBRU4sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7UUFFN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsUUFBUSxDQUFDO1FBQy9ELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzdCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQzdCO2FBQ0c7O1lBRUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQ3JDLElBQUk7Z0JBQ0QsSUFBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7MEJBRWIsUUFBUSxHQUFHLEVBQUU7b0JBQ25CLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUE7b0JBQ2pDLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDNUUsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7aUJBQzlCO2FBRUYsQ0FBQyxDQUFDO1NBQ047UUFDRCxJQUFJLENBQUMsZ0NBQWdDLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLElBQUk7WUFDdEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEgsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1NBQ2xILENBQUMsQ0FBQztLQUNKOzs7O0lBSUQscUJBQXFCO1FBQ25CLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGdDQUFnQyxDQUFDLFFBQVEsQ0FBQztRQUMvRCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNFLElBQUk7Z0JBQ0YsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUM3QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDNUIsQ0FDRixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxDQUFDLElBQUk7Z0JBQ0gsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssWUFBWSxFQUFFOzswQkFDaEMsWUFBWSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLENBQUM7b0JBQzdFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUE7aUJBQzdCO3FCQUFNO29CQUNMLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUE7aUJBQ3JCO2FBQ0YsQ0FDRixDQUNBLENBQUM7WUFFRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFMUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzdFO0tBQ0Y7Ozs7SUFHRCxXQUFXO1FBQ1QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFFLEdBQUcsSUFBSSxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7S0FDdEM7Ozs7O0lBRUQsU0FBUyxDQUFDLElBQUk7UUFDWixJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ2hHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFOztzQkFDdEIsTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7O3NCQUN2QixLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQzs7c0JBQ3JCLGtCQUFrQixHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztnQkFDckQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtvQkFDcEIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLGtCQUFrQixFQUFFO3dCQUMvRyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTs0QkFBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7eUJBQUUsRUFBQyxDQUFDLENBQUM7cUJBQ3JIO2lCQUNGLENBQUMsQ0FBQzthQUNKO1NBQ0Y7UUFDRCxJQUFHLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssV0FBVyxFQUFFO1lBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDNUQsSUFBSTtnQkFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzVCLENBQ0gsQ0FBQTtTQUNGO0tBQ0Y7Ozs7Ozs7SUFLRCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO0tBQ2xEOzs7WUEzS0YsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxtQkFBbUI7Z0JBQzdCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BaUNMO2dCQUNMLE1BQU0sRUFBRSxDQUFDLDAvVUFBMC9VLEVBQUUsOGNBQThjLENBQUM7YUFFcjlWOzs7WUEvQ1EsVUFBVTtZQURXLFVBQVU7WUFFL0IsZ0JBQWdCO1lBR2hCLGdDQUFnQztZQUZoQyxrQkFBa0I7WUFJbEIsc0JBQXNCOzs7Ozs7O0FDUi9COzs7Ozs7SUEyQ0csWUFDVSxXQUErQixFQUNqQyxTQUE4QyxFQUNyQixJQUFTO1FBRmhDLGdCQUFXLEdBQVgsV0FBVyxDQUFvQjtRQUNqQyxjQUFTLEdBQVQsU0FBUyxDQUFxQztRQUNyQixTQUFJLEdBQUosSUFBSSxDQUFLO1FBQ3ZDLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztRQUM5QyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztLQUMzQzs7OztJQUVELFFBQVE7S0FDVDs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxJQUFJOztjQUNiLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7UUFDekMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDcEU7Ozs7SUFFRCxvQkFBb0I7O2NBQ1osY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQzs7Y0FDckUsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUksQ0FBQztRQUN2RSxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDeEIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ25DLENBQUMsQ0FBQztRQUVILFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUN0QixJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDbkMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMxQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7S0FDbkI7Ozs7O0lBRUQsc0JBQXNCLENBQUMsSUFBSTtRQUV6QixJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztLQUNuRTs7OztJQUVELFNBQVM7UUFDUCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO0tBQ3hCOzs7WUE1RUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTRCTDtnQkFDTCxNQUFNLEVBQUUsQ0FBQyxxWUFBcVksQ0FBQzthQUNoWjs7O1lBbkNRLGtCQUFrQjtZQURuQixZQUFZOzRDQTZDZixNQUFNLFNBQUMsZUFBZTs7Ozs7Ozs7O0FDN0MzQixNQUFhLHNCQUFzQixHQUFHO0lBQ2xDO1FBQ0ksTUFBTSxFQUFFLFNBQVM7UUFDakIsS0FBSyxFQUFDLFNBQVM7S0FDbEI7SUFDRDtRQUNJLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLEtBQUssRUFBQyxTQUFTO0tBQ2xCO0lBQ0Q7UUFDSSxNQUFNLEVBQUUsU0FBUztRQUNqQixLQUFLLEVBQUMsU0FBUztLQUNsQjtJQUNEO1FBQ0ksTUFBTSxFQUFFLFNBQVM7UUFDakIsS0FBSyxFQUFDLFNBQVM7S0FDbEI7Q0FDSjs7O0FBT0QsTUFBYSxtQkFBbUIsR0FBRztJQUMvQjtRQUNJLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDVCxLQUFLLEVBQUUsU0FBUztLQUNuQjtJQUNEO1FBQ0ksS0FBSyxFQUFFLENBQUMsQ0FBQztRQUNULEtBQUssRUFBRSxTQUFTO0tBQ25CO0lBQ0Q7UUFDSSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ1QsS0FBSyxFQUFFLFNBQVM7S0FDbkI7SUFDRDtRQUNJLEtBQUssRUFBRSxDQUFDO1FBQ1IsS0FBSyxFQUFFLFNBQVM7S0FDbkI7SUFDRDtRQUNJLEtBQUssRUFBRSxDQUFDO1FBQ1IsS0FBSyxFQUFFLFNBQVM7S0FDbkI7SUFDRDtRQUNJLEtBQUssRUFBRSxDQUFDO1FBQ1IsS0FBSyxFQUFFLFNBQVM7S0FDbkI7Q0FDSjs7QUFFRCxNQUFhLGtCQUFrQixHQUFHO0lBQzlCLE1BQU0sRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxTQUFTLEVBQUMsU0FBUyxDQUFDO0NBQ3pFOzs7Ozs7O0FDdERILE1BQWEsZUFBZSxHQUFHO0lBRTdCO1FBQ0UsTUFBTSxFQUFFLEVBQUU7UUFDVixRQUFRLEVBQUU7WUFDUjtnQkFDRSxNQUFNLEVBQUUsVUFBVTtnQkFDbEIsT0FBTyxFQUFFLEdBQUc7Z0JBQ1osS0FBSyxFQUFFLEtBQUs7Z0JBQ1osV0FBVyxFQUFFLEtBQUs7YUFDbkI7U0FDRjtLQUNGO0NBQ0Y7O0FBRUQsTUFBYSxVQUFVLEdBQUc7SUFDdEIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDN0IsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDOUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7Q0FDN0I7Ozs7OztBQ3hCTCw0QkF3RW9DLFNBQVEsbUJBQW1COzs7Ozs7Ozs7Ozs7O0lBNEI3RCxZQUFZLFlBQXdCLEVBQUUsSUFBWSxFQUFFLEVBQXFCLEVBQy9ELFVBQXNCLEVBQVUsZ0JBQWtDLEVBQ2xFLE1BQWlCLEVBQ2pCLGFBQStCLEVBQy9CLDJCQUE4RCxFQUMvRCxXQUErQixFQUM5QixjQUFzQztRQUM5QyxLQUFLLEVBQUUsQ0FBQztRQU5BLGVBQVUsR0FBVixVQUFVLENBQVk7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1FBQ2xFLFdBQU0sR0FBTixNQUFNLENBQVc7UUFDakIsa0JBQWEsR0FBYixhQUFhLENBQWtCO1FBQy9CLGdDQUEyQixHQUEzQiwyQkFBMkIsQ0FBbUM7UUFDL0QsZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1FBQzlCLG1CQUFjLEdBQWQsY0FBYyxDQUF3QjtRQWpDaEQsY0FBUyxHQUFZLElBQUksQ0FBQztRQUMxQixlQUFVLEdBQVksS0FBSyxDQUFDO1FBRTVCLFlBQU8sR0FBVSxFQUFFLENBQUM7UUFDcEIscUJBQWdCLEdBQVUsRUFBRSxDQUFDO1FBQzdCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLFdBQU0sR0FBVyxHQUFHLENBQUM7UUFDckIsV0FBTSxHQUFVLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbkMsZ0JBQVcsR0FBVSxFQUFFLENBQUM7UUFFeEIsZUFBVSxHQUFVLFVBQVUsQ0FBQztRQUcvQixlQUFVLEdBQVUsRUFBRSxDQUFDO1FBQ3ZCLHdCQUFtQixHQUFVLEVBQUUsQ0FBQztRQUloQyxtQkFBYyxHQUFHLElBQUksQ0FBQztRQUN0QixlQUFVLEdBQUcsY0FBYyxDQUFBO1FBQzNCLGlCQUFZLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUMxQixrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUMxQiwyQkFBc0IsR0FBVSxFQUFFLENBQUM7UUFFbkMsZUFBVSxHQUF1QixJQUFLLFlBQVksRUFBTyxDQUFDO1FBQzFELGlCQUFZLEdBQVUsRUFBRSxDQUFDO1FBVXZCLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUM1RixJQUFJLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUM7UUFDdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQztRQUU3QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQztZQUNqQyxJQUFJLElBQUksSUFBSSxFQUFFLEdBQUcsV0FBVyxDQUFDLE9BQU8sRUFBRTtnQkFDcEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO2FBQ2xDO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQzthQUM1QztTQUNGLEVBQUMsSUFBSSxDQUFDLENBQUM7S0FDVDs7OztJQUVELFFBQVE7O1FBRU4sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7UUFFaEMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1FBQzdCLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDOztRQUU1QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUNwRCxJQUFJO1lBQ0YsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7c0JBQ2IsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO2dCQUNqRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO2dCQUNsRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO2dCQUNyRSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0JBQzVELElBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztnQkFDNUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7O3dCQUN6QixNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7b0JBQzVFLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDdEUsQ0FBQyxDQUFDO2dCQUNILElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7YUFDbkU7U0FDRixDQUNGLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQ3JELENBQUMsSUFBSTtZQUNILElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTs7c0JBQ3ZCLG1CQUFtQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLENBQUM7Z0JBQ3BGLElBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQzthQUN2QztTQUNGLENBQ0YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDJCQUEyQixDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQyxJQUFJOztrQkFDOUQsa0JBQWtCLEdBQUcsRUFBRTs7a0JBQ3ZCLEtBQUssR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFO1lBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDZixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRTtvQkFDbkUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUMvQjthQUNGLENBQUMsQ0FBQTtZQUNGLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxrQkFBa0IsQ0FBQztZQUNqRCxJQUFJLENBQUMsYUFBYSxHQUFHLGtCQUFrQixDQUFDO1NBQ3pDLENBQUMsQ0FBQTtRQUVBLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUk7WUFDNUIsSUFBSSxDQUFDLDJCQUEyQixDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUMxRixJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFFLElBQUk7Z0JBQzFELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUUsTUFBTTtvQkFDbkMsSUFBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDdkQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQzNCO2lCQUNGLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLE1BQU07b0JBQ3JDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQ3hELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUM5QjtpQkFDRixDQUFDLENBQUE7YUFDSCxDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7S0FDTjs7Ozs7SUFFRCxhQUFhLENBQUMsY0FBYzs7WUFDdEIsZUFBZSxHQUFHLEVBQUU7UUFDdkIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxNQUFNO1lBQzNCLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDekQsSUFBSyxNQUFNLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDaEQsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDOUI7YUFDSCxDQUFDLENBQUE7U0FDSCxDQUFDLENBQUE7UUFDRixPQUFPLGVBQWUsQ0FBQztLQUN4Qjs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxtQkFBbUI7O1lBQzlCLGtCQUFrQixHQUFHLEVBQUU7UUFDMUIsbUJBQW1CLENBQUMsT0FBTyxDQUFDLE1BQU07WUFDaEMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJO2dCQUN6RCxJQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUNoRCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2pDO2FBQ0gsQ0FBQyxDQUFBO1NBQ0gsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxrQkFBa0IsQ0FBQztLQUMzQjs7Ozs7SUFFRCxlQUFlLENBQUMsSUFBSTs7Y0FDWixJQUFJLEdBQUcsRUFBRTs7Y0FDVCxLQUFLLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRTtRQUM1RCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7O2dCQUNYLFFBQVEsR0FBRyxLQUFLO1lBQ3BCLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDakIsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU87b0JBQUUsUUFBUSxHQUFHLElBQUksQ0FBQzthQUNqRSxDQUFDLENBQUE7WUFDRCxJQUFJLFFBQVEsRUFBRTs7c0JBQ04sR0FBRyxHQUFHO29CQUNYLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtvQkFDbkIsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7aUJBQ3JEO2dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7YUFDZDtpQkFBTTs7c0JBQ0MsR0FBRyxHQUFHO29CQUNYLE1BQU0sRUFBRSxTQUFTO29CQUNqQixLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztpQkFDckQ7Z0JBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTthQUNkO1NBQ0gsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxJQUFJLENBQUM7S0FDYjs7Ozs7SUFJRCxXQUFXO1FBQ1QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7S0FDdEM7Ozs7O0lBRUQsYUFBYSxDQUFDLEtBQUs7UUFDakIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7S0FDNUM7Ozs7O0lBRU8sVUFBVSxDQUFDLE9BQWM7UUFDL0IsSUFBRyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUNyQixPQUFPLGVBQWUsQ0FBQztTQUMxQjthQUFNO1lBQ0wsT0FBTyxPQUFPLENBQUM7U0FDaEI7S0FDRjs7Ozs7SUFFRCxXQUFXLENBQUMsSUFBSTtRQUNkLElBQUksSUFBSSxFQUFFOztrQkFDRixNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7Z0JBQ3pCLElBQUk7O2dCQUNKLFdBQWlCO1lBQ3JCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUNyQixXQUFXLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQzFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQzdDLElBQUksR0FBRyxXQUFXLENBQUM7aUJBQ3BCO2FBQ0Y7WUFDRCxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRTtnQkFDMUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQzthQUNqRDs7WUFFRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFOztzQkFDbkksUUFBUSxHQUFHO29CQUNmLE1BQU0sRUFBRSxNQUFNO29CQUNkLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ2hDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO29CQUM5QixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUNqQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7b0JBQ2xELEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUNsQixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQztvQkFDM0IsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7aUJBQy9CO2dCQUNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7O2dCQUV4QyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQzthQUN4RTtZQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDaEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssTUFBTSxFQUFFOztvQkFFM0IsSUFBSSxJQUFJLEVBQUU7d0JBQ1IsSUFBSSxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxLQUFLLEVBQUU7NEJBQ3pGLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7O2tDQUM3QyxHQUFHLEdBQUc7Z0NBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7O2dDQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0NBQzdFLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO2dDQUNsQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dDQUNqQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQzs2QkFDL0I7NEJBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDMUI7NkJBQU0sSUFBRyxXQUFXLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBRyxJQUFJLEVBQUM7NEJBQ25FLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDOzs7a0NBRTFCLEdBQUcsR0FBRztnQ0FDVixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQ0FDM0IsTUFBTSxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dDQUNsRCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQ0FDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7NkJBQy9COzs0QkFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7NEJBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQzFCO3FCQUNGO2lCQUNGO2FBQ0YsQ0FBQyxDQUFBO1NBRUg7S0FFRjs7Ozs7O0lBRUQsZ0JBQWdCLENBQUMsSUFBVzs7Y0FDcEIsT0FBTyxHQUFVLEVBQUU7O2NBQ25CLGdCQUFnQixHQUFVLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7UUFDOUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJOztZQUVmLElBQUksZ0JBQWdCLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDeEUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO29CQUN0QixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQztvQkFDeEIsWUFBWSxFQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQy9CLFNBQVMsRUFBRSxJQUFJO2lCQUNoQixDQUFDLENBQUE7YUFDSDs7a0JBQ0ssR0FBRyxHQUFHO2dCQUNWLE1BQU0sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUN0QixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDeEIsWUFBWSxFQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7Z0JBQy9CLFFBQVEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQzthQUNsQztZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkIsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDdkUsT0FBTyxPQUFPLENBQUM7S0FDaEI7Ozs7O0lBQ0QsWUFBWSxDQUFDLElBQVM7O2NBQ2QsTUFBTSxHQUFVLEVBQUU7UUFDeEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQy9CLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRTs7c0JBQ3ZELEdBQUcsR0FBRztvQkFDVixXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7b0JBQzNCLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ25DLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUNsQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUNqQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztpQkFDL0I7Z0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNsQjtTQUNGLENBQ0EsQ0FBQTtRQUNELElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7O2tCQUNoQixHQUFHLEdBQUc7Z0JBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7O2dCQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3RCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUNsQixPQUFPLEVBQUUsQ0FBQztnQkFDVixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTO2FBQ3hDO1lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNsQjtRQUNELE9BQU8sTUFBTSxDQUFDO0tBQ2Y7Ozs7OztJQUdELGdCQUFnQixDQUFDLElBQUk7O1lBQ2YsVUFBVSxHQUFHLEVBQUU7UUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ2YsVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1RixDQUFDLENBQUE7UUFDRixPQUFPLFVBQVUsQ0FBQztLQUNuQjs7Ozs7O0lBRUQsZUFBZSxDQUFDLE1BQU0sRUFBRSxJQUFJOztjQUNwQixtQkFBbUIsR0FBRyxFQUFFO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNmLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7O3NCQUNuSSxRQUFRLEdBQUc7b0JBQ2YsTUFBTSxFQUFFLE1BQU07b0JBQ2QsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDaEMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7b0JBQzlCLE9BQU8sRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUM7b0JBQ2pDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUNsQixxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7b0JBQ2xELFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMzQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztpQkFDL0I7Z0JBQ0QsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3BDO1NBQ0YsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxtQkFBbUIsQ0FBQztLQUM1Qjs7Ozs7Ozs7SUFJRCxlQUFlLENBQUMsZUFBa0MsRUFBRSxNQUFjLEVBQUUsSUFBSTtRQUN0RSxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNsQyxPQUFPLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3ZCOzs7OztJQUVELGdCQUFnQixDQUFDLEtBQUs7O2NBQ2QsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFO1lBQ3hELEtBQUssRUFBRSxPQUFPO1lBQ2QsSUFBSSxFQUFFO2dCQUNGLFVBQVUsRUFBRSxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFO2dCQUMxRCxZQUFZLEVBQUUsSUFBSSxDQUFDLFVBQVU7YUFDOUI7U0FDSixDQUFDO1FBQ0YsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNO1lBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztTQUN0QyxDQUFDLENBQUM7S0FDSjs7Ozs7SUFFRCxtQkFBbUIsQ0FBQyxDQUFDOztjQUNkLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUIsT0FBTyxVQUFVLENBQUMsUUFBUSxFQUFDLGVBQWUsRUFBQyxPQUFPLENBQUMsQ0FBQztLQUNyRDs7O1lBeFpELFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUscUJBQXFCO2dCQUMvQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVDWDtnQkFDQyxNQUFNLEVBQUUsQ0FBQyx3bkJBQXduQixDQUFDO2FBQ25vQjs7O1lBdEVDLFVBQVU7WUFBRSxNQUFNO1lBQUUsaUJBQWlCO1lBZ0I5QixVQUFVO1lBQ1YsZ0JBQWdCO1lBSGpCLFNBQVM7WUFKZixnQkFBZ0I7WUFZVCxnQ0FBZ0M7WUFKaEMsa0JBQWtCO1lBT2xCLHNCQUFzQjs7Ozs7OztBQzFCL0I7Ozs7O0lBT0UsU0FBUyxDQUFDLEtBQVU7UUFDbEIsSUFBSSxLQUFLLElBQUksQ0FBQyxFQUFFO1lBQ2QsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDdkMsT0FBTyxLQUFLLENBQUM7YUFDZDtpQkFBTTtnQkFDTCxPQUFPLEdBQUcsR0FBRyxLQUFLLENBQUM7YUFDcEI7U0FDRjthQUFNO1lBQ0wsT0FBTyxRQUFRLENBQUM7U0FDakI7S0FDRjs7O1lBZkYsSUFBSSxTQUFDO2dCQUNKLElBQUksRUFBRSxlQUFlO2FBQ3RCOzs7Ozs7O0FDSkQ7Ozs7OztJQU9FLFNBQVMsQ0FBQyxLQUFVLEVBQUUsaUJBQXlCO1FBQzdDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFBLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQSxHQUFDLEtBQUssQ0FBQyxHQUFDLFNBQUEsRUFBRSxFQUFFLGlCQUFpQixDQUFBLENBQUM7S0FDdEU7OztZQVBGLElBQUksU0FBQztnQkFDSixJQUFJLEVBQUUsZUFBZTthQUN0Qjs7Ozs7OztBQ0pEOzs7Ozs7SUFvREUsWUFDVyxXQUErQixFQUNqQyxTQUFrRCxFQUN6QixJQUFTO1FBRmhDLGdCQUFXLEdBQVgsV0FBVyxDQUFvQjtRQUNqQyxjQUFTLEdBQVQsU0FBUyxDQUF5QztRQUN6QixTQUFJLEdBQUosSUFBSSxDQUFLO1FBTDNDLGNBQVMsR0FBVyxFQUFFLENBQUM7UUFNckIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDcEM7Ozs7SUFFRCxRQUFRO0tBQ1A7Ozs7SUFFRCxTQUFTO1FBQ1AsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztLQUN4Qjs7O1lBNURGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsd0JBQXdCO2dCQUNsQyxRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXVDTDtnQkFDTCxNQUFNLEVBQUUsQ0FBQyw2bUJBQTZtQixDQUFDO2FBQ3huQjs7O1lBN0NRLGtCQUFrQjtZQURuQixZQUFZOzRDQXNEZixNQUFNLFNBQUMsZUFBZTs7Ozs7OztBQ3ZEM0IsOEJBa0ZzQyxTQUFRLG1CQUFtQjs7Ozs7Ozs7Ozs7SUFjL0QsWUFBWSxZQUF3QixFQUNoQixJQUFZLEVBQ1osRUFBcUIsRUFDYixnQkFBa0MsRUFDbEMsZ0NBQWtFLEVBQ2xFLFdBQStCLEVBQy9CLFVBQXNCLEVBQ3RCLGNBQXNDO1FBQ2hFLEtBQUssRUFBRSxDQUFDO1FBTGtCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMscUNBQWdDLEdBQWhDLGdDQUFnQyxDQUFrQztRQUNsRSxnQkFBVyxHQUFYLFdBQVcsQ0FBb0I7UUFDL0IsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixtQkFBYyxHQUFkLGNBQWMsQ0FBd0I7UUFsQnBFLGdCQUFXLEdBQVUsRUFBRSxDQUFDO1FBQ3hCLG1CQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLFdBQU0sR0FBVyxHQUFHLENBQUM7UUFFckIsV0FBTSxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDMUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsd0JBQW1CLEdBQVUsbUJBQW1CLENBQUM7UUFDakQsWUFBTyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDckIsZ0JBQVcsR0FBRyxrQkFBa0IsQ0FBQztRQUNqQyxhQUFRLEdBQVEsRUFBRSxDQUFDO1FBV2YsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO0tBQzVGOzs7O0lBRUYsUUFBUTtRQUNOLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7UUFFN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsUUFBUSxDQUFDO1FBQy9ELElBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzNCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1NBQzFCO2FBQUk7WUFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUNyQyxJQUFJO2dCQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ25CLElBQUcsSUFBSSxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUU7b0JBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7OzBCQUNYLFFBQVEsR0FBRyxFQUFFO29CQUNwQixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFBO29CQUNqQyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzVFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2lCQUMxQjthQUVGLENBQUMsQ0FBQztTQUNOO0tBQ0Y7Ozs7SUFHRCxpQkFBaUI7UUFDZixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxRQUFRLENBQUM7UUFDL0QsSUFBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUMzRSxJQUFJO2dCQUNGLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO2dCQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDbEUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7YUFDdEUsQ0FDRixDQUFDLENBQUE7WUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxJQUFJO2dCQUNGLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ3BDLENBQUMsQ0FBQyxDQUFDO1lBRUwsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhELElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFBLEVBQUMsRUFBQyxHQUFHLENBQUMsQ0FBQztTQUUxRjtLQUNGOzs7OztJQUVELHVCQUF1QixDQUFDLElBQUk7O2NBQ3BCLFdBQVcsR0FBRyxFQUFFO1FBQ3RCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTs7a0JBQ1QsR0FBRyxHQUFHO2dCQUNWLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSztnQkFDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTO2FBQzVCO1lBQ0QsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2QixDQUFDLENBQUE7UUFDRixPQUFPLFdBQVcsQ0FBQztLQUNwQjs7Ozs7SUFFRCx1QkFBdUIsQ0FBQyxJQUFJOztjQUNwQixXQUFXLEdBQUcsRUFBRTtRQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUs7WUFDckIsT0FBTyxLQUFLLENBQUMsU0FBUyxHQUFJLEtBQUssQ0FBQyxTQUFTLENBQUM7O1NBRTNDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNmLElBQUksV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7O29CQUN0QixHQUFHLEdBQUc7b0JBQ1IsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSTtvQkFDM0MsT0FBTyxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUM7aUJBQ3hEO2dCQUNELFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDdkI7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLFdBQVcsQ0FBQztLQUNwQjs7Ozs7SUFFRCxhQUFhLENBQUMsSUFBSTtRQUNoQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3JFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUk7Z0JBQzNCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFFO29CQUM1QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUN0QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUE7aUJBQ2hDO2FBQ0YsQ0FBQyxDQUFDO1NBQ0o7S0FDRjs7Ozs7SUFFRCxlQUFlLENBQUMsS0FBSztRQUNuQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQztLQUM1Qzs7Ozs7O0lBR0Qsc0JBQXNCLENBQUMsS0FBSzs7O1FBRzFCLE9BQU87S0FDUjs7Ozs7SUFFRCxzQkFBc0IsQ0FBQyxHQUFHOztjQUNsQixXQUFXLEdBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQztRQUM5RCxPQUFPLEdBQUcsR0FBRyxDQUFDLEtBQUssY0FBYyxHQUFHLEdBQUcsV0FBVyxVQUFVLENBQUM7O0tBRTlEOzs7O0lBRUEsV0FBVztRQUNWLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzVCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxRCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBRSxHQUFHLElBQUksR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7U0FDOUM7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO0tBQ3RDOzs7WUF6TUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSx1QkFBdUI7Z0JBQ2pDLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0RYO2dCQUNDLE1BQU0sRUFBRSxDQUFDLHczREFBdzNELENBQUM7YUFDbjREOzs7WUFoRkMsVUFBVTtZQUFFLE1BQU07WUFBRSxpQkFBaUI7WUFpQjlCLGdCQUFnQjtZQUZoQixnQ0FBZ0M7WUFHaEMsa0JBQWtCO1lBRmxCLFVBQVU7WUFJVixzQkFBc0I7Ozs7Ozs7QUNyQi9CLHNCQXVDOEIsU0FBUSxrQkFBa0I7SUF6QnhEOztRQTRCVyxvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUdqQyxhQUFRLEdBQVksS0FBSyxDQUFDO1FBRzFCLFdBQU0sR0FBUSxFQUFFLENBQUM7UUFFakIsZUFBVSxHQUFZLElBQUksQ0FBQztRQUUxQixXQUFNLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztLQWtHdkM7Ozs7SUFyRkMsTUFBTTtRQUNKLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVmLElBQUksQ0FBQyxJQUFJLEdBQUcsdUJBQXVCLENBQUM7WUFDbEMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLE1BQU0sRUFBRSxHQUFHO1lBQ1gsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNO1NBQ3JCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBRWxCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRS9CLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxFQUFPO2FBQzFCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzs7Y0FFdkMsUUFBUSxHQUFHO1lBQ2YsSUFBSSxFQUFFLE1BQU07WUFDWixLQUFLLEVBQUUsQ0FBQztZQUNSLE1BQU0sRUFBRSxJQUFJO1NBQ2I7O2NBRUssSUFBSSxHQUFHLFFBQVEsRUFBTzthQUN6QixFQUFFLENBQUMsQ0FBQzs7Z0JBQ0MsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJO1lBRWxCLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNyQyxLQUFLLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixFQUFFLENBQUM7YUFDcEM7aUJBQU07Z0JBQ0wsS0FBSyxHQUFHLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQzthQUNoQztZQUNELE9BQU8sS0FBSyxDQUFDO1NBQ2QsQ0FBQzthQUNELFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQ3ZDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ2hDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUVwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFM0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRWpCLElBQUksQ0FBQyxTQUFTLEdBQUcsYUFBYyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQVEsTUFBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBRSxHQUFHLENBQUM7S0FDNUU7Ozs7SUFFRCxlQUFlOztjQUNQLEdBQUcsR0FBRyxFQUFFO1FBQ2QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSTs7Z0JBQ3ZCLEtBQUssR0FBVyxFQUFFO1lBQ3RCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFDeEIsS0FBSyxHQUFHLFNBQVMsQ0FBQzthQUNuQjtpQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTtnQkFDdEQsS0FBSyxHQUFHLFNBQVMsQ0FBQzthQUNuQjtpQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3JELEtBQUssR0FBRyxTQUFTLENBQUM7YUFDbkI7aUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRTtnQkFDcEQsS0FBSyxHQUFHLFNBQVMsQ0FBQzthQUNuQjtpQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxFQUFFO2dCQUNwRCxLQUFLLEdBQUcsU0FBUyxDQUFDO2FBQ25CO2lCQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEVBQUU7Z0JBQzlCLEtBQUssR0FBRyxTQUFTLENBQUM7YUFDbkI7aUJBQU07Z0JBQ0wsS0FBSyxHQUFHLEVBQUUsQ0FBQzthQUNaOztnQkFDRyxHQUFHLEdBQUc7Z0JBQ1IsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLEtBQUssRUFBRSxLQUFLO2FBQ2I7WUFDRCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2YsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxHQUFHLENBQUM7S0FDWjs7OztJQUVELFNBQVM7UUFDUCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDMUM7Ozs7O0lBRUQsT0FBTyxDQUFDLElBQUk7UUFDVixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN4Qjs7OztJQUVELFNBQVM7UUFDUCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0tBQ3ZGOzs7WUF0SUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSx5QkFBeUI7Z0JBQ25DLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O3dCQWtCWTtnQkFDdEIsTUFBTSxFQUFFLENBQUMsOEtBQThLLENBQUM7Z0JBQ3hMLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxlQUFlLEVBQUUsdUJBQXVCLENBQUMsTUFBTTthQUNoRDs7OzBCQUdFLEtBQUs7OEJBQ0wsS0FBSzs4QkFDTCxLQUFLOzhCQUNMLEtBQUs7dUJBQ0wsS0FBSztxQkFDTCxLQUFLO29CQUNMLEtBQUs7cUJBQ0wsS0FBSztxQkFDTCxLQUFLO3lCQUNMLEtBQUs7cUJBRUwsTUFBTTs4QkFFTixZQUFZLFNBQUMsaUJBQWlCOzs7Ozs7OztBQ3REakMsTUFBYSxvQkFBb0IsR0FBRztJQUNoQyxJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3QixJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUM1Qjs7Ozs7O0FDTEwsa0NBdUcwQyxTQUFRLG1CQUFtQjs7Ozs7Ozs7O0lBK0VuRSxZQUNFLFlBQXdCLEVBQUUsSUFBWSxFQUN0QyxFQUFxQixFQUNiLFdBQStCLEVBQzlCLFVBQXNCLEVBQ3RCLDJCQUE4RDtRQUN2RSxLQUFLLEVBQUUsQ0FBQztRQUhBLGdCQUFXLEdBQVgsV0FBVyxDQUFvQjtRQUM5QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGdDQUEyQixHQUEzQiwyQkFBMkIsQ0FBbUM7UUFsRnpFLFlBQU8sR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDOztRQUVyQix1QkFBa0IsR0FBRztZQUNuQjtnQkFDRSxLQUFLLEVBQUUsdUJBQXVCO2dCQUM5QixLQUFLLEVBQUUsT0FBTzthQUNmO1lBQ0Q7Z0JBQ0UsS0FBSyxFQUFFLG1CQUFtQjtnQkFDMUIsS0FBSyxFQUFFLE9BQU87YUFDZjtTQUNGLENBQUM7UUFDRixzQkFBaUIsR0FBVTtZQUN6QjtnQkFDRSxHQUFHLEVBQUUsSUFBSSxJQUFJLEVBQUU7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQO3dCQUNFLEtBQUssRUFBRSxXQUFXO3dCQUNsQixLQUFLLEVBQUUsSUFBSTtxQkFDWjtvQkFDRDt3QkFDRSxLQUFLLEVBQUUsY0FBYzt3QkFDckIsS0FBSyxFQUFFLE1BQU07cUJBQ2Q7b0JBQ0Q7d0JBQ0UsS0FBSyxFQUFFLFlBQVk7d0JBQ25CLEtBQUssRUFBRSxRQUFRO3FCQUNoQjtpQkFDRjtnQkFDRCxLQUFLLEVBQUUsRUFBRTthQUNWO1lBQ0Q7Z0JBQ0UsR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFO2dCQUNmLE9BQU8sRUFBRTtvQkFDUDt3QkFDRSxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLEtBQUs7cUJBQ2I7b0JBQ0Q7d0JBQ0UsS0FBSyxFQUFFLGNBQWM7d0JBQ3JCLEtBQUssRUFBRSxPQUFPO3FCQUNmO29CQUNEO3dCQUNFLEtBQUssRUFBRSxZQUFZO3dCQUNuQixLQUFLLEVBQUUsUUFBUTtxQkFDaEI7aUJBQ0Y7Z0JBQ0QsS0FBSyxFQUFFLFNBQVM7YUFDakI7WUFDRDtnQkFDRSxHQUFHLEVBQUUsSUFBSSxJQUFJLEVBQUU7Z0JBQ2YsT0FBTyxFQUFFO29CQUNQO3dCQUNFLEtBQUssRUFBRSxXQUFXO3dCQUNsQixLQUFLLEVBQUUsS0FBSztxQkFDYjtvQkFDRDt3QkFDRSxLQUFLLEVBQUUsY0FBYzt3QkFDckIsS0FBSyxFQUFFLE9BQU87cUJBQ2Y7b0JBQ0Q7d0JBQ0UsS0FBSyxFQUFFLFlBQVk7d0JBQ25CLEtBQUssRUFBRSxPQUFPO3FCQUNmO2lCQUNGO2dCQUNELEtBQUssRUFBRSxTQUFTO2FBQ2pCO1NBQ0YsQ0FBQztRQUNGLFlBQU8sR0FBVSxFQUFFLENBQUM7UUFDcEIsV0FBTSxHQUFXLEdBQUcsQ0FBQztRQUVyQixXQUFNLEdBQVUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNsQyxnQkFBVyxHQUFVLEVBQUUsQ0FBQztRQUN4QixlQUFVLEdBQVUsb0JBQW9CLENBQUM7UUFXdkMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQzdGLElBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQztRQUN2QyxJQUFJLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUM7S0FDdEM7Ozs7SUFFRCxRQUFRO1FBQ04sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSTtZQUMxQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNuQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7YUFDOUM7U0FDRixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0tBQ25EOzs7O0lBRUQsdUJBQXVCOzs7Y0FFZixLQUFLLEdBQUcsRUFBRTs7Y0FDVixrQkFBa0IsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7Y0FDakUsR0FBRyxHQUFHO1lBQ1YsVUFBVSxFQUFFLGtCQUFrQjtZQUM5QixLQUFLLEVBQUUsU0FBUztTQUNqQjtRQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDaEIsT0FBTyxLQUFLLENBQUM7S0FDZDs7Ozs7O0lBR0QsY0FBYyxDQUFDLElBQVc7O2NBQ2xCLE9BQU8sR0FBVSxFQUFFOztjQUNuQixrQkFBa0IsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDZixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxrQkFBa0IsRUFBRTs7c0JBQ3ZDLEdBQUcsR0FBRztvQkFDVixNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQztvQkFDMUIsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQ3hCLFFBQVEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztpQkFDbEM7Z0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNuQjtTQUNGLENBQUMsQ0FBQTtRQUNGLE9BQU8sT0FBTyxDQUFDO0tBQ2hCOzs7OztJQUVELFlBQVksQ0FBQyxJQUFTOztjQUNkLE1BQU0sR0FBVSxFQUFFO1FBQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUMvQixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUU7O3NCQUN2RCxHQUFHLEdBQUc7b0JBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQzNCLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ25DLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUNsQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUNqQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztpQkFDL0I7Z0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNsQjtTQUNGLENBQ0EsQ0FBQTtRQUNELElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7O2tCQUNoQixHQUFHLEdBQUc7Z0JBQ1YsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQzNCLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDdEIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ2xCLE9BQU8sRUFBRSxDQUFDO2dCQUNWLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVM7YUFDeEM7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsT0FBTyxNQUFNLENBQUM7S0FDZjs7Ozs7SUFFQSxtQkFBbUIsQ0FBQyxDQUFDOztjQUNmLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUIsT0FBTyxVQUFVLENBQUMsUUFBUSxFQUFDLGVBQWUsRUFBQyxPQUFPLENBQUMsQ0FBQztLQUNyRDs7Ozs7SUFFRCxXQUFXLENBQUMsS0FBSzs7WUFDWCxLQUFLLEdBQUcsRUFBRTtRQUNkLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUN4QyxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2pDLEtBQUssR0FBRyxTQUFTLENBQUE7YUFDbEI7aUJBQU07Z0JBQ0wsS0FBSyxHQUFDLFNBQVMsQ0FBQTthQUNoQjtTQUNGO1FBQ0QsT0FBTyxLQUFLLENBQUM7S0FDZDs7OztJQUVELFdBQVc7UUFDUixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztLQUN2Qjs7Ozs7SUFFRCx1QkFBdUIsQ0FBQyxLQUFLO1FBQzNCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0tBQzdDOzs7WUF4UUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSwyQkFBMkI7Z0JBQ3JDLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BOEVMO2dCQUNMLE1BQU0sRUFBRSxDQUFDLCsrR0FBKytHLENBQUM7YUFDMS9HOzs7WUFyR0MsVUFBVTtZQUFFLE1BQU07WUFBRSxpQkFBaUI7WUFlOUIsa0JBQWtCO1lBQ2xCLFVBQVU7WUFDVixnQ0FBZ0M7Ozs7Ozs7QUNsQnpDLDhCQTJJc0MsU0FBUSxrQkFBa0I7Ozs7Ozs7O0lBdUU5RCxZQUFZLFlBQXdCLEVBQ2hCLElBQVksRUFDWixFQUFxQixFQUNiLFdBQStCLEVBQy9CLFFBQWtCO1FBQzVDLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRkosZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1FBQy9CLGFBQVEsR0FBUixRQUFRLENBQVU7UUF6RXJDLGdCQUFXLEdBQVcsUUFBUSxDQUFDO1FBUS9CLGtCQUFhLEdBQVksSUFBSSxDQUFDO1FBQzlCLFVBQUssR0FBUSxXQUFXLENBQUM7UUFPekIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsb0JBQWUsR0FBWSxJQUFJLENBQUM7UUFDaEMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFFOUIsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFTL0IsZ0JBQVcsR0FBVSxFQUFFLENBQUM7UUFFeEIsZUFBVSxHQUFVLEVBQUUsQ0FBQztRQUN2QixrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUV6QixhQUFRLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDakQsZUFBVSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBbUI3RCxnQkFBVyxHQUFXLENBQUMsQ0FBQztRQUN4QixlQUFVLEdBQVcsQ0FBQyxDQUFDO1FBS3ZCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBSzVCLG9CQUFlLEdBQVcsRUFBRSxDQUFDO1FBRTdCLGVBQVUsR0FBUSxFQUFFLENBQUM7S0FRcEI7Ozs7SUFFRCxNQUFNO1FBRUosSUFBSSxDQUFDLElBQUksR0FBRyx1QkFBdUIsQ0FBQztZQUNsQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNwQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7WUFDN0IsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsY0FBYztZQUMvQixVQUFVLEVBQUUsSUFBSSxDQUFDLGNBQWM7WUFDL0IsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ3ZCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtTQUM1QixDQUFDLENBQUM7UUFFSCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztTQUNuRjtRQUVELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2pDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDcEM7UUFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNqQyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUUzQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTVELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFN0QsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFN0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxhQUFhLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUV2RSxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sR0FBRyxFQUFFLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMzQyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO0tBRTVDOzs7O0lBR0QsZUFBZTs7WUFDVCxHQUFHLEdBQUcsRUFBRTtRQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSztnQkFDNUIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFOzt3QkFDcEMsR0FBRyxHQUFHO3dCQUNSLElBQUksRUFBRSxLQUFLLENBQUMsVUFBVTt3QkFDdEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO3FCQUNuQjtvQkFDRCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2lCQUNkO2FBQ0YsQ0FBQyxDQUFBO1NBQ0gsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUM7S0FDWjs7OztJQUVELFVBQVU7O1lBQ0osTUFBTSxHQUFHLHNCQUFzQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDakQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDOztZQUN2QyxNQUFNLEdBQUcsRUFBRTtRQUVmLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUU7WUFDL0IsTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3JDOztZQUVHLEdBQUc7O1lBQ0gsR0FBRztRQUNQLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUU7WUFDNUQsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO2tCQUNoQixJQUFJLENBQUMsU0FBUztrQkFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFFeEIsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTO2tCQUNoQixJQUFJLENBQUMsU0FBUztrQkFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7U0FDekI7UUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFO1lBQzdCLE1BQU0sR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7O3NCQUMxQixLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7c0JBQ25CLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFO2dCQUN6QixJQUFJLEtBQUssR0FBRyxLQUFLO29CQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUM1QixJQUFJLEtBQUssR0FBRyxLQUFLO29CQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzdCLE9BQU8sQ0FBQyxDQUFDO2FBQ1YsQ0FBQyxDQUFDO1NBQ0o7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQ3RDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQzs7WUFFcEIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNqRDthQUFNO1lBQ0wsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUNoQixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztTQUNwQjtRQUVELE9BQU8sTUFBTSxDQUFDO0tBQ2Y7Ozs7SUFFRCxVQUFVOztjQUNGLE1BQU0sR0FBRyxFQUFFO1FBQ2pCLEtBQUssTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNsQyxLQUFLLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN0QjtnQkFDRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssU0FBUyxFQUFFO29CQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDckIsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNwQjtpQkFDRjtnQkFDRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssU0FBUyxFQUFFO29CQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDckIsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNwQjtpQkFDRjthQUNGO1NBQ0Y7O2NBRUssTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUM7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNoQjs7Y0FFSyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVM7Y0FDdEIsSUFBSSxDQUFDLFNBQVM7Y0FDZCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDOztjQUVqQixHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVM7Y0FDdEIsSUFBSSxDQUFDLFNBQVM7Y0FDZCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBRXJCLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRTtZQUNkLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDbkI7YUFBSztZQUNKLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUNwQjtLQUNKOzs7O0lBRUQsZUFBZTtRQUNiLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN0Qzs7Ozs7O0lBRUQsU0FBUyxDQUFDLE1BQU0sRUFBRSxLQUFLOztZQUNqQixLQUFLO1FBRVQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRTtZQUM3QixLQUFLLEdBQUcsU0FBUyxFQUFFO2lCQUNoQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNuQjthQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUU7WUFDdEMsS0FBSyxHQUFHLFdBQVcsRUFBRTtpQkFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUNqQixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFbEIsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUNyQixLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3RCO1NBQ0Y7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFO1lBQ3ZDLEtBQUssR0FBRyxVQUFVLEVBQUU7aUJBQ2pCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQztpQkFDWixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbkI7UUFFRCxPQUFPLEtBQUssQ0FBQztLQUNkOzs7Ozs7SUFFRCxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU07O2NBQ2hCLEtBQUssR0FBRyxXQUFXLEVBQUU7YUFDeEIsS0FBSyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2xCLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFFakIsT0FBTyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUM7S0FDakQ7Ozs7O0lBRUQsWUFBWSxDQUFDLE1BQU07O1lBQ2IsSUFBSSxHQUFHLElBQUk7O1lBQ1gsR0FBRyxHQUFHLElBQUk7UUFFZCxLQUFLLE1BQU0sS0FBSyxJQUFJLE1BQU0sRUFBRTtZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDdkIsSUFBSSxHQUFHLEtBQUssQ0FBQzthQUNkO1lBRUQsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0JBQzdCLEdBQUcsR0FBRyxLQUFLLENBQUM7YUFDYjtTQUNGO1FBRUQsSUFBSSxJQUFJO1lBQUUsT0FBTyxNQUFNLENBQUM7UUFDeEIsSUFBSSxHQUFHO1lBQUUsT0FBTyxRQUFRLENBQUM7UUFDekIsT0FBTyxTQUFTLENBQUM7S0FDbEI7Ozs7O0lBRUQsTUFBTSxDQUFDLEtBQUs7UUFDVixJQUFJLEtBQUssWUFBWSxJQUFJLEVBQUU7WUFDekIsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUVELE9BQU8sS0FBSyxDQUFDO0tBQ2Q7Ozs7O0lBRUQsZ0JBQWdCLENBQUMsRUFBRSxLQUFLLEVBQUU7UUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDeEIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0tBQ2Y7Ozs7O0lBRUQsaUJBQWlCLENBQUMsRUFBRSxNQUFNLEVBQUU7UUFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0tBQ2Y7Ozs7O0lBRUQscUJBQXFCLENBQUMsSUFBSTtRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbEMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0tBQ3RCOzs7O0lBR0QsV0FBVztRQUNULElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzVCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztLQUN0Qjs7Ozs7SUFHRCxZQUFZLENBQUMsTUFBTTtRQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUM1Qjs7Ozs7SUFHRCxZQUFZLENBQUMsTUFBTTtRQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUM5Qjs7Ozs7O0lBRUQsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFPO1FBQ25CLElBQUksTUFBTSxFQUFFO1lBQ1YsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO1NBQzNCO1FBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDeEI7Ozs7OztJQUVELE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSTtRQUNqQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7S0FDbEI7Ozs7SUFFRCxTQUFTOztZQUNILE1BQU07UUFDVixJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFO1lBQ2pDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQzVCO2FBQU07WUFDTCxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUN2QjtRQUVELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7S0FDeEY7Ozs7SUFFRCxnQkFBZ0I7O2NBQ1IsSUFBSSxHQUFHO1lBQ1gsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzFCLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLE1BQU0sRUFBRSxFQUFFO1lBQ1YsS0FBSyxFQUFFLFNBQVM7U0FDakI7UUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFO1lBQ2hDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNoQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDMUIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1NBQy9CO2FBQU07WUFDTCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDM0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUNqQztRQUNELE9BQU8sSUFBSSxDQUFDO0tBQ2I7Ozs7O0lBRUQsVUFBVSxDQUFDLElBQUk7UUFDYixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7O2NBRWYsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDeEMsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ3ZELENBQUM7UUFDRixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRTtZQUNaLE9BQU87U0FDUjtRQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO0tBRWxFOzs7OztJQUVELFlBQVksQ0FBQyxJQUFJOztjQUNULEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hDLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztTQUN2RCxDQUFDO1FBRUYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO0tBQ3BFOzs7O0lBRUQsYUFBYTtRQUNYLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3QyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7S0FDekI7OztZQXBmRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLHVCQUF1QjtnQkFDakMsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQTRGTDtnQkFDTCxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ1osYUFBYSxFQUFFLGlCQUFpQixDQUFDLFNBQVM7Z0JBQzFDLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2dCQUMvQyxVQUFVLEVBQUU7b0JBQ1YsT0FBTyxDQUFDLGdCQUFnQixFQUFFO3dCQUN4QixVQUFVLENBQUMsUUFBUSxFQUFFOzRCQUNuQixLQUFLLENBQUM7Z0NBQ0osT0FBTyxFQUFFLENBQUM7NkJBQ1gsQ0FBQzs0QkFDRixPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztnQ0FDakIsT0FBTyxFQUFFLENBQUM7NkJBQ1gsQ0FBQyxDQUFDO3lCQUNKLENBQUM7cUJBQ0gsQ0FBQztpQkFDSDthQUNGOzs7WUF6SUMsVUFBVTtZQUFFLE1BQU07WUFBRSxpQkFBaUI7WUF5QjlCLGtCQUFrQjtZQVJsQixRQUFROzs7cUJBMEhkLEtBQUs7MEJBQ0wsS0FBSzs2QkFDTCxLQUFLOzZCQUNMLEtBQUs7eUJBQ0wsS0FBSzt5QkFDTCxLQUFLO3dCQUNMLEtBQUs7dUJBQ0wsS0FBSzt1QkFDTCxLQUFLOzRCQUNMLEtBQUs7b0JBQ0wsS0FBSzt5QkFDTCxLQUFLOytCQUNMLEtBQUs7a0NBQ0wsS0FBSztrQ0FDTCxLQUFLO3lCQUNMLEtBQUs7eUJBQ0wsS0FBSzsyQkFDTCxLQUFLOzhCQUNMLEtBQUs7MkJBQ0wsS0FBSzs2QkFDTCxLQUFLOzRCQUNMLEtBQUs7d0JBQ0wsS0FBSzt3QkFDTCxLQUFLO3dCQUNMLEtBQUs7d0JBQ0wsS0FBSzt5QkFDTCxLQUFLO3FCQUNMLEtBQUs7b0JBQ0wsS0FBSztxQkFDTCxLQUFLOzBCQUNMLEtBQUs7c0JBQ0wsS0FBSzt5QkFDTCxLQUFLOzRCQUNMLEtBQUs7dUJBRUwsTUFBTTt5QkFDTixNQUFNOzhCQUVOLFlBQVksU0FBQyxpQkFBaUI7MEJBcVE5QixZQUFZLFNBQUMsWUFBWTsyQkFNekIsWUFBWSxTQUFDLFlBQVksRUFBRSxDQUFDLFFBQVEsQ0FBQzsyQkFLckMsWUFBWSxTQUFDLFlBQVksRUFBRSxDQUFDLFFBQVEsQ0FBQzs7Ozs7OztBQ2xjeEM7Ozs7Ozs7SUE0UEUsWUFBb0IsRUFBcUIsRUFDL0IsYUFBK0IsRUFDL0IsMkJBQTZELEVBQzlELFdBQStCO1FBSHBCLE9BQUUsR0FBRixFQUFFLENBQW1CO1FBQy9CLGtCQUFhLEdBQWIsYUFBYSxDQUFrQjtRQUMvQixnQ0FBMkIsR0FBM0IsMkJBQTJCLENBQWtDO1FBQzlELGdCQUFXLEdBQVgsV0FBVyxDQUFvQjs7UUE3Qy9CLGtCQUFhLEdBQVksSUFBSSxDQUFDO1FBQzlCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLHNCQUFpQixHQUFZLEtBQUssQ0FBQztRQUNuQyxTQUFJLEdBQVUsRUFBRSxDQUFDO1FBQ2pCLGNBQVMsR0FBVSxFQUFFLENBQUM7UUFDdEIsY0FBUyxHQUFVLEVBQUUsQ0FBQztRQUN0QixjQUFTLEdBQVcsRUFBRSxDQUFDO1FBQ3ZCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLFVBQUssR0FBVyxDQUFDLENBQUM7UUFDbEIsaUJBQVksR0FBVyxFQUFFLENBQUM7UUFDMUIsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsOEJBQXlCLEdBQVUsRUFBRSxDQUFDO1FBWXJDLGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNuRCx5QkFBb0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUd2RSxnQkFBVyxHQUFHLEtBQUssQ0FBQztRQUVwQixrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUMxQiwwQkFBcUIsR0FBVSxFQUFFLENBQUM7UUFDbEMsMkJBQXNCLEdBQVEsRUFBRSxDQUFDO1FBQ2pDLG9CQUFlLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLFlBQU8sR0FBRyxLQUFLLENBQUM7UUFZZCwyQkFBMkIsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7O1NBRXJELENBQUMsQ0FBQztLQUNKOzs7OztJQVhELFdBQVcsQ0FBQyxHQUFHO1FBQ2IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLE1BQU0sT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLEdBQUcsQ0FBQyxNQUFNLENBQUEsRUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQztLQUNwRzs7OztJQVdELFFBQVE7UUFDTixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLCtCQUErQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNwRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQzVELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLLENBQUM7O1lBQ3ZELElBQUksR0FBRyxJQUFJLENBQUMsd0JBQXdCLEVBQUU7UUFDMUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNqRTs7OztJQUVELGVBQWU7O2NBQ1AsVUFBVSxHQUFFLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkUsSUFBRyxVQUFVLEVBQUU7WUFDYixVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtZQUN4QyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO1NBQ3JCO0tBQ0Y7Ozs7O0lBRUQsK0JBQStCLENBQUMsSUFBSTs7WUFDOUIsVUFBVSxHQUFHLEVBQUU7UUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJOztnQkFDWCxHQUFHLEdBQUc7Z0JBQ1IsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO2dCQUNuQixNQUFNLEVBQUUsS0FBSzthQUNkO1lBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN0QixDQUFDLENBQUE7UUFDRixPQUFPLFVBQVUsQ0FBQztLQUNuQjs7Ozs7SUFFRCw2QkFBNkIsQ0FBQyxNQUFNOztZQUM5QixPQUFPLEdBQUcsRUFBRTtRQUNoQixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUk7O2dCQUNiLEdBQUcsR0FBRyxJQUFJLE1BQU0sRUFBRTtZQUN0QixHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUN2QixPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3BELENBQUMsQ0FBQTtRQUNGLE9BQU8sT0FBTyxDQUFDO0tBQ2hCOzs7O0lBRUQsd0JBQXdCOztZQUNsQixHQUFHLEdBQUc7WUFDUixHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtZQUMvQixJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWM7WUFDekIsT0FBTyxFQUFFLElBQUk7U0FDZDtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDNUIsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7Z0JBQzlCLEdBQUcsR0FBRztvQkFDSixHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtvQkFDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLE9BQU8sRUFBRSxJQUFJLENBQUMsbUJBQW1CLEtBQUssS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLO2lCQUMzRCxDQUFBO2FBQ0E7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLEdBQUcsQ0FBQztLQUNaOzs7OztJQUVELGNBQWMsQ0FBQyxNQUFNO1FBQ25CLFFBQVEsTUFBTSxDQUFDLGlCQUFpQjtZQUM5QixLQUFLLFlBQVk7Z0JBQ2YsT0FBTyxnQ0FBZ0MsQ0FBQztZQUMxQyxLQUFLLGNBQWM7Z0JBQ2pCLE9BQU8sa0NBQWtDLENBQUM7WUFDNUMsS0FBSyxhQUFhO2dCQUNoQixPQUFPLGlDQUFpQyxDQUFDO1lBQzNDO2dCQUNFLE9BQU8sY0FBYyxDQUFDO1NBQ3pCO0tBQ0Y7Ozs7Ozs7SUFFRCxZQUFZLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLO1FBQzdCLFFBQVEsTUFBTSxDQUFDLGVBQWU7WUFDNUIsS0FBSyxVQUFVO2dCQUNiLE9BQU8sYUFBYSxDQUFBO1lBQ3RCLEtBQUssV0FBVztnQkFDZCxPQUFPLGNBQWMsQ0FBQztZQUN4QixLQUFLLFlBQVk7Z0JBQ2YsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFO29CQUNmLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDL0UsT0FBTyxjQUFjLENBQUM7cUJBQ3ZCO3lCQUFNO3dCQUNMLE9BQU8sY0FBYyxDQUFDO3FCQUN2QjtpQkFDRjtxQkFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssa0JBQWtCLEVBQUU7b0JBQzdDLElBQUksR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDckcsT0FBTyxjQUFjLENBQUM7cUJBQ3ZCO3lCQUFNO3dCQUNMLE9BQU8sY0FBYyxDQUFDO3FCQUN2QjtpQkFDRjtxQkFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUsscUJBQXFCLEVBQUU7b0JBQ2hELElBQUksR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDM0csT0FBTyxjQUFjLENBQUM7cUJBQ3ZCO3lCQUFNO3dCQUNMLE9BQU8sY0FBYyxDQUFDO3FCQUN2QjtpQkFDRjtxQkFBTSxJQUFHLEtBQUssS0FBSyxDQUFDLEVBQUU7b0JBQ3JCLE9BQU8sVUFBVSxDQUFDO2lCQUNuQjs7WUFFSDtnQkFDRSxPQUFPO1NBQ1Y7S0FDRjs7Ozs7SUFFRCxrQkFBa0IsQ0FBQyxHQUFHO1FBQ3BCLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO1lBQ2pELE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQztTQUNsQjthQUFNO1lBQ0wsT0FBTyxHQUFHLENBQUM7U0FDWjtLQUNGOzs7Ozs7SUFFRCxlQUFlLENBQUMsSUFBSSxFQUFFLE9BQU87O1lBQ3ZCLElBQUksR0FBRyxLQUFLO1FBQ2hCLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxPQUFPLElBQUcsSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQTtRQUN6RyxPQUFPLElBQUksQ0FBQztLQUNiOzs7Ozs7SUFFRCxZQUFZLENBQUMsSUFBSSxFQUFFLE9BQU87O1lBQ3BCLElBQUksR0FBRyxLQUFLO1FBQ2hCLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQTtRQUMxRyxPQUFPLElBQUksQ0FBQztLQUNiOzs7OztJQUVELFFBQVEsQ0FBQyxHQUFHOztRQUVWLE9BQU8sSUFBSSxDQUFDO0tBQ2I7Ozs7O0lBRUQsaUJBQWlCLENBQUMsR0FBRzs7WUFDZixlQUFlLEdBQUcsRUFBRTtRQUN4QixJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZELElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUM1RCxlQUFlLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2pDO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxlQUFlLENBQUM7S0FDeEI7Ozs7O0lBRUQsZUFBZSxDQUFDLEdBQUc7O2NBQ1gsWUFBWSxHQUFHLEdBQUcsQ0FBQyxNQUFNOztZQUMzQixhQUFhO1FBQ2pCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNyQyxJQUFJLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNoQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDM0IsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7YUFDN0I7U0FDRixDQUFDLENBQUM7O2NBQ0csS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksTUFBTSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUFBLEVBQUUsQ0FBQztRQUNsRixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3pCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxZQUFZLEVBQUU7Z0JBQ2hDLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3ZGO1NBQ0YsQ0FBQyxDQUFDO0tBQ0o7Ozs7O0lBRUQscUJBQXFCLENBQUMsR0FBRzs7Y0FDakIsTUFBTSxHQUFHLEdBQUcsQ0FBQyxNQUFNOztZQUNyQixVQUFVLEdBQUcsS0FBSztRQUN0QixJQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDckMsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDLE1BQU07Z0JBQUUsVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDdEQsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsS0FBSyxLQUFLLE9BQU8sR0FBRyxFQUFFLEdBQUcsVUFBVSxHQUFHLFlBQVksR0FBRyxhQUFhLENBQUM7S0FDL0U7Ozs7O0lBRUQsWUFBWSxDQUFDLElBQUk7O1FBRWYsSUFBSSxLQUFLLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztLQUNqRTs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxDQUFRO1FBQ3ZCLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3pEOzs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsSUFBSTtRQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixLQUFLLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztLQUN0RDs7OztJQUVELFNBQVM7UUFDUCxRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7S0FDM0Y7Ozs7O0lBR0QsUUFBUSxDQUFDLEtBQUs7OztZQUVULE1BQU0sR0FBQyxNQUFNLENBQUMsb0JBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFpQixLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDOztZQUNsSCxlQUFlLEdBQUMsR0FBRztRQUV0QixNQUFNLEdBQUcsQ0FBQyxNQUFNLEdBQUMsR0FBRyxJQUFJLGVBQWUsR0FBRyxlQUFlLEdBQUcsTUFBTSxHQUFDLEdBQUcsQ0FBQztRQUN2RSxJQUFHLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO1lBQ3hELG9CQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFpQixLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDbEc7S0FDRjs7Ozs7SUFFRCx5QkFBeUIsQ0FBQyxJQUFJO1FBQzVCLFFBQVEsSUFBSTtZQUNWLEtBQUssYUFBYTtnQkFDaEIsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLGNBQWMsR0FBRyxhQUFhLENBQUM7WUFDeEYsS0FBSyxlQUFlO2dCQUNsQixPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsaUJBQWlCLEdBQUcsZUFBZSxDQUFBO1lBQzlGO2dCQUNFLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7S0FDRjs7Ozs7SUFFRCx3QkFBd0IsQ0FBQyxPQUFPOztZQUMxQixVQUFVLEdBQUcsS0FBSztRQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQzVCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDNUMsVUFBVSxHQUFHLElBQUksQ0FBQTthQUNsQjtTQUNGLENBQUMsQ0FBQTtRQUNGLE9BQU8sVUFBVSxDQUFDO0tBQ25COzs7OztJQUVELG1CQUFtQixDQUFDLElBQUk7UUFDdEIsUUFBUSxJQUFJO1lBQ1YsS0FBSyxhQUFhO2dCQUNoQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25CLE9BQU07WUFDUixLQUFLLGNBQWM7Z0JBQ2pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDcEIsT0FBTTtZQUNSLEtBQUssWUFBWTtnQkFDZixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xCLE9BQU07WUFDUjtnQkFDRSxPQUFPO1NBQ1Y7S0FDRjs7Ozs7SUFHRCxXQUFXO1FBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7S0FDdkI7Ozs7SUFFRCxZQUFZO1FBQ1YsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNoQyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDakMsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7YUFDcEM7U0FDRixDQUFDLENBQUM7S0FFSjs7Ozs7SUFFRCw0QkFBNEIsQ0FBQyxXQUFXO1FBQ3JDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDakMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVksRUFBRTtnQkFDOUIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDekM7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQzthQUMvQjtTQUNGLENBQUMsQ0FBQztLQUNKOzs7O0lBRUQsVUFBVTtRQUNULElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbkQsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDM0MsSUFBSSxHQUFHLEtBQUssSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsRUFBRTs7d0JBQ2pDLElBQUksR0FBRzt3QkFDVCxHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjt3QkFDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXO3dCQUN0QixPQUFPLEVBQUUsSUFBSTtxQkFDZDtvQkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNqRTtxQkFBTTs7O3dCQUVELElBQUksR0FBRzt3QkFDVCxHQUFHLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjt3QkFDL0IsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjO3dCQUN6QixPQUFPLEVBQUUsSUFBSTtxQkFDZDtvQkFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNqRTtnQkFDRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDdEU7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUMxQztTQUNGO1FBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7S0FDdkI7Ozs7OztJQUVELG9CQUFvQixDQUFDLENBQUMsRUFBRSxJQUFJO1FBQzFCLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUNwQixJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxFQUFFO1lBQzFCLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDOztnQkFDbEIsSUFBSSxHQUFHO2dCQUNULEdBQUcsRUFBRSxJQUFJLENBQUMscUJBQXFCO2dCQUMvQixJQUFJLEVBQUUsSUFBSTtnQkFDVixPQUFPLEVBQUUsS0FBSzthQUNmO1lBQ0QsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqRTthQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxNQUFNLEVBQUU7WUFDbEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7O2dCQUNqQixJQUFJLEdBQUc7Z0JBQ1QsR0FBRyxFQUFFLElBQUksQ0FBQyxxQkFBcUI7Z0JBQy9CLElBQUksRUFBRSxJQUFJO2dCQUNWLE9BQU8sRUFBRSxJQUFJO2FBQ2Q7WUFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO0tBQ3ZCOzs7OztJQUVELHFCQUFxQixDQUFDLElBQUk7O1lBQ3BCLFVBQVUsR0FBRyxLQUFLO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsbUJBQW1CO2dCQUFFLFVBQVUsR0FBRyxJQUFJLENBQUM7U0FDdkUsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxVQUFVLENBQUM7S0FDbkI7Ozs7O0lBRUQsV0FBVyxDQUFDLElBQUk7O1lBQ1YsSUFBSSxHQUFHLEVBQUU7UUFDYixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQzVCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJO2dCQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFBO1NBQ2hDLENBQUMsQ0FBQTtRQUNGLElBQUksSUFBSSxLQUFLLEVBQUUsRUFBRTtZQUNmLE9BQU8sSUFBSSxLQUFLLEtBQUssR0FBRyxpQkFBaUIsR0FBRyxtQkFBbUIsQ0FBQztTQUNqRTthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLEtBQUssR0FBRyxpQkFBaUIsR0FBRyxtQkFBbUIsQ0FBQztTQUN6RTtLQUNGOzs7Ozs7SUFFRCxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsS0FBSztRQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO0tBQ3ZCOzs7OztJQUVELGlCQUFpQixDQUFDLEdBQUc7UUFDbkIsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM5RDs7Ozs7O0lBRUQsY0FBYyxDQUFDLEdBQUcsRUFBRSxJQUFJOztZQUNsQixHQUFHLEdBQUc7WUFDUixPQUFPLEVBQUUsR0FBRztZQUNaLElBQUksRUFBRSxJQUFJO1NBQ1g7UUFDRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtLQUN6RDs7OztJQUVELGVBQWU7UUFDYixJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDakQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxDQUFDO0tBQ2xDOzs7WUFobEJGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsdUJBQXVCO2dCQUNqQyxRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9MTDtnQkFDTCxNQUFNLEVBQUUsQ0FBQywwL1VBQTAvVSxFQUFFLDhtSEFBOG1ILENBQUM7Z0JBQ3BuYyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTthQUN0Qzs7O1lBM01xQixpQkFBaUI7WUFXckMsZ0JBQWdCO1lBSVQsZ0NBQWdDO1lBRGhDLGtCQUFrQjs7OzBCQWdNeEIsU0FBUyxTQUFDLGFBQWE7NEJBR3ZCLEtBQUs7MkJBQ0wsS0FBSztnQ0FDTCxLQUFLO21CQUNMLEtBQUs7d0JBQ0wsS0FBSzt3QkFDTCxLQUFLO3dCQUNMLEtBQUs7MkJBQ0wsS0FBSzsyQkFDTCxLQUFLO29CQUNMLEtBQUs7MkJBQ0wsS0FBSzs2QkFDTCxLQUFLO3dDQUNMLEtBQUs7OEJBQ0wsS0FBSztpQ0FHTCxLQUFLO21DQUNMLEtBQUs7K0JBQ0wsS0FBSztrQ0FDTCxLQUFLOzBCQUNMLEtBQUs7K0JBQ0wsS0FBSzs2QkFDTCxLQUFLO3lCQUVMLE1BQU07bUNBQ04sTUFBTTt1QkFrTk4sWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQzs7Ozs7Ozs7QUM3YjNDLE1BQWFBLGNBQVksR0FBRztJQUN4QjtRQUNFLElBQUksRUFBRSxVQUFVO1FBQ2hCLE9BQU8sRUFBRSxFQUFFO0tBQ1o7SUFDRDtRQUNFLElBQUksRUFBRSxhQUFhO1FBQ25CLE9BQU8sRUFBRSxFQUFFO0tBQ1o7Q0FDRjs7QUFFRCxNQUFhQyxjQUFZLEdBQUk7SUFDM0I7UUFDRSxJQUFJLEVBQUUsTUFBTTtRQUNaLElBQUksRUFBRSxhQUFhO1FBQ25CLEtBQUssRUFBRSxHQUFHO1FBQ1YsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsV0FBVztRQUN6QixpQkFBaUIsRUFBRSxjQUFjO1FBQ2pDLGVBQWUsRUFBRSxZQUFZO1FBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsUUFBUTtRQUNkLElBQUksRUFBRSxlQUFlO1FBQ3JCLEtBQUssRUFBRSxHQUFHO1FBQ1YsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsU0FBUztRQUN2QixpQkFBaUIsRUFBRSxZQUFZO1FBQy9CLGVBQWUsRUFBRSxVQUFVO1FBQzNCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsWUFBWTtRQUNsQixJQUFJLEVBQUUsZUFBZTtRQUNyQixLQUFLLEVBQUUsR0FBRztRQUNWLFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLEtBQUs7UUFDcEIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLFNBQVM7UUFDdkIsaUJBQWlCLEVBQUUsWUFBWTtRQUMvQixlQUFlLEVBQUUsVUFBVTtRQUMzQixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLFNBQVM7UUFDZixJQUFJLEVBQUUsVUFBVTtRQUNoQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLFNBQVM7UUFDdkIsaUJBQWlCLEVBQUUsWUFBWTtRQUMvQixlQUFlLEVBQUUsVUFBVTtRQUMzQixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLFFBQVE7UUFDZCxJQUFJLEVBQUUsY0FBYztRQUNwQixLQUFLLEVBQUUsR0FBRztRQUNWLFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLGtCQUFrQjtRQUNoQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxXQUFXO1FBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsS0FBSztRQUNYLElBQUksRUFBRSxhQUFhO1FBQ25CLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsSUFBSTtRQUNuQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsa0JBQWtCO1FBQ2hDLGlCQUFpQixFQUFFLGFBQWE7UUFDaEMsZUFBZSxFQUFFLFdBQVc7UUFDNUIsa0JBQWtCLEVBQUUsa0JBQWtCO1FBQ3RDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLG1CQUFtQixFQUFFLEVBQUU7S0FDeEI7SUFDRDtRQUNFLElBQUksRUFBRSxXQUFXO1FBQ2pCLElBQUksRUFBRSxZQUFZO1FBQ2xCLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsSUFBSTtRQUNuQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsa0JBQWtCO1FBQ2hDLGlCQUFpQixFQUFFLGFBQWE7UUFDaEMsZUFBZSxFQUFFLFlBQVk7UUFDN0Isa0JBQWtCLEVBQUUsa0JBQWtCO1FBQ3RDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLG1CQUFtQixFQUFFLEVBQUU7S0FDeEI7SUFDRDtRQUNFLElBQUksRUFBRSxrQkFBa0I7UUFDeEIsSUFBSSxFQUFFLGNBQWM7UUFDcEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLGFBQWEsRUFBRSxJQUFJO1FBQ25CLGFBQWEsRUFBRSxJQUFJO1FBQ25CLFlBQVksRUFBRSxlQUFlO1FBQzdCLGlCQUFpQixFQUFFLGFBQWE7UUFDaEMsZUFBZSxFQUFFLFlBQVk7UUFDN0Isa0JBQWtCLEVBQUUsa0JBQWtCO1FBQ3RDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLG1CQUFtQixFQUFFLEVBQUU7S0FDeEI7SUFDRDtRQUNFLElBQUksRUFBRSxRQUFRO1FBQ2QsSUFBSSxFQUFFLGNBQWM7UUFDcEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLGFBQWEsRUFBRSxJQUFJO1FBQ25CLGFBQWEsRUFBRSxJQUFJO1FBQ25CLFlBQVksRUFBRSxtQkFBbUI7UUFDakMsaUJBQWlCLEVBQUUsYUFBYTtRQUNoQyxlQUFlLEVBQUUsV0FBVztRQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLEtBQUs7UUFDWCxJQUFJLEVBQUUsYUFBYTtRQUNuQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtRQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxXQUFXO1FBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsV0FBVztRQUNqQixJQUFJLEVBQUUsWUFBWTtRQUNsQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtRQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxZQUFZO1FBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsa0JBQWtCO1FBQ3hCLElBQUksRUFBRSxjQUFjO1FBQ3BCLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsSUFBSTtRQUNuQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsZUFBZTtRQUM3QixpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxZQUFZO1FBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsT0FBTztRQUNiLElBQUksRUFBRSxzQkFBc0I7UUFDNUIsS0FBSyxFQUFFLEtBQUs7UUFDWixTQUFTLEVBQUUsSUFBSTtRQUNmLGFBQWEsRUFBRSxJQUFJO1FBQ25CLGFBQWEsRUFBRSxJQUFJO1FBQ25CLFlBQVksRUFBRSxtQkFBbUI7UUFDakMsaUJBQWlCLEVBQUUsYUFBYTtRQUNoQyxlQUFlLEVBQUUsV0FBVztRQUM1QixrQkFBa0IsRUFBRSxrQkFBa0I7UUFDdEMsVUFBVSxFQUFFLEtBQUs7UUFDakIsbUJBQW1CLEVBQUUsRUFBRTtLQUN4QjtJQUNEO1FBQ0UsSUFBSSxFQUFFLFFBQVE7UUFDZCxJQUFJLEVBQUUsYUFBYTtRQUNuQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtRQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxXQUFXO1FBQzVCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsY0FBYztRQUNwQixJQUFJLEVBQUUsV0FBVztRQUNqQixLQUFLLEVBQUUsRUFBRTtRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsYUFBYSxFQUFFLElBQUk7UUFDbkIsYUFBYSxFQUFFLElBQUk7UUFDbkIsWUFBWSxFQUFFLG1CQUFtQjtRQUNqQyxpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxZQUFZO1FBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUscUJBQXFCO1FBQzNCLElBQUksRUFBRSxhQUFhO1FBQ25CLEtBQUssRUFBRSxFQUFFO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixhQUFhLEVBQUUsSUFBSTtRQUNuQixhQUFhLEVBQUUsSUFBSTtRQUNuQixZQUFZLEVBQUUsZUFBZTtRQUM3QixpQkFBaUIsRUFBRSxhQUFhO1FBQ2hDLGVBQWUsRUFBRSxZQUFZO1FBQzdCLGtCQUFrQixFQUFFLGtCQUFrQjtRQUN0QyxVQUFVLEVBQUUsS0FBSztRQUNqQixtQkFBbUIsRUFBRSxFQUFFO0tBQ3hCO0NBQ0Y7O0FBRUQsTUFBYUMsMkJBQXlCLEdBQUc7Ozs7OztJQU12QztRQUNFLElBQUksRUFBRSxlQUFlO1FBQ3JCLElBQUksRUFBRSxjQUFjO1FBQ3BCLFVBQVUsRUFBRSxLQUFLO0tBQ2xCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsYUFBYTtRQUNuQixJQUFJLEVBQUUsWUFBWTtRQUNsQixVQUFVLEVBQUUsS0FBSztLQUNsQjtDQU1GOzs7Ozs7QUNuUUgsNEJBOERvQyxTQUFRLG1CQUFtQjs7Ozs7Ozs7Ozs7OztJQXVCN0QsWUFBb0IsRUFBcUIsRUFBVSxVQUFzQixFQUMvRCxXQUF3QixFQUFVLFVBQXNCLEVBQ3hELGdCQUFrQyxFQUNsQyxNQUFpQixFQUNqQixhQUErQixFQUMvQiwyQkFBNkQsRUFDOUQsV0FBK0IsRUFDOUIsY0FBc0M7UUFDOUMsS0FBSyxFQUFFLENBQUM7UUFSVSxPQUFFLEdBQUYsRUFBRSxDQUFtQjtRQUFVLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDL0QsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFBVSxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3hELHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsV0FBTSxHQUFOLE1BQU0sQ0FBVztRQUNqQixrQkFBYSxHQUFiLGFBQWEsQ0FBa0I7UUFDL0IsZ0NBQTJCLEdBQTNCLDJCQUEyQixDQUFrQztRQUM5RCxnQkFBVyxHQUFYLFdBQVcsQ0FBb0I7UUFDOUIsbUJBQWMsR0FBZCxjQUFjLENBQXdCO1FBM0JoRCxTQUFJLEdBQVUsRUFBRSxDQUFDO1FBQ2pCLGNBQVMsR0FBVSxFQUFFLENBQUM7UUFDdEIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsc0JBQWlCLEdBQVksS0FBSyxDQUFDO1FBQ25DLGNBQVMsR0FBUSxFQUFFLENBQUM7UUFDcEIsY0FBUyxHQUFVLEVBQUUsQ0FBQztRQUN0QixvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQyxrQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUMxQixrQkFBYSxHQUFZLElBQUksQ0FBQztRQUM5QixpQkFBWSxHQUFXLEVBQUUsQ0FBQzs7UUFFMUIsaUJBQVksR0FBVUYsY0FBWSxDQUFDO1FBQ25DLGlCQUFZLEdBQVVDLGNBQVksQ0FBQztRQUNuQyw4QkFBeUIsR0FBVUMsMkJBQXlCLENBQUM7UUFDN0QsVUFBSyxHQUFXLENBQUMsQ0FBQztRQUNsQixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQUMxQixtQkFBYyxHQUFZLElBQUksQ0FBQztLQWE5Qjs7OztJQUVELFFBQVE7O1FBRU4sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2YsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQ3BELElBQUk7WUFDRixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzlELElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7O2dCQUVuQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDN0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7O2dCQUU1QixJQUFJLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTs7MEJBQ3BELFFBQVEsR0FBRyxFQUFFO29CQUNuQixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFBO29CQUNqQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3hFO2FBQ0Y7WUFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRztnQkFDbkIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEQsQ0FBQyxDQUFBO1NBQ0gsQ0FDRixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUNyRCxDQUFDLElBQUk7WUFDSCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxZQUFZLEVBQUU7O3NCQUNoQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssQ0FBQzs7c0JBQ3ZFLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDO2dCQUM3RSxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUM3QixhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDbkQ7aUJBQU0sSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUM1QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO2FBQ2xDO1NBQ0YsQ0FDRixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFL0UsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxJQUFJO1lBQy9ELE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2xCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNoQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJO1lBQzNELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxJQUFJO1lBQ2pFLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUNsSCxDQUFDLENBQUE7S0FDSDs7OztJQUVELFdBQVc7UUFDVCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO1lBQ25CLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hELENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO0tBRXRDOzs7OztJQUVELFNBQVMsQ0FBQyxJQUFJO1FBQ1osSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNoRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7c0JBQ3RFLFFBQVEsR0FBRztvQkFDZixNQUFNLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQztvQkFDdEIsU0FBUyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ3pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO29CQUM5QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztvQkFDbEIsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBQzNCLE9BQU8sRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUM7b0JBQ2pDLHFCQUFxQixFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztvQkFDbEQsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7aUJBQy9CO2dCQUNELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM5QixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDdEM7WUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JCO0tBQ0Y7Ozs7O0lBRUQsUUFBUSxDQUFDLElBQUk7UUFDWCxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFOztrQkFDZCxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7a0JBQ3ZCLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDOztrQkFDL0IsT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtnQkFDcEIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxVQUFVLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtvQkFDakcsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsT0FBTyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO3FCQUFFLEVBQUUsQ0FBQyxDQUFDOzswQkFDOUwsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuRSxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM3QixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqQzthQUNGLENBQUMsQ0FBQztTQUNKO0tBQ0Y7Ozs7Ozs7SUFFTyxjQUFjLENBQUMsTUFBYyxFQUFFLE9BQWUsRUFBRSxNQUFhOztZQUMvRCxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ25CLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSztZQUNsQixJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtnQkFDNUQsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUM1QixNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNoQjtnQkFBQyxJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQzlCLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2hCO2FBQ0Y7U0FDRixDQUFDLENBQUM7O1FBRUgsT0FBTyxNQUFNLENBQUM7S0FDZjs7Ozs7SUFFQSwyQkFBMkIsQ0FBQyxJQUFJOztZQUMzQixRQUFRLEdBQUcsRUFBRTs7Y0FDWCxhQUFhLEdBQUcsb0JBQUMsSUFBSSxJQUFXLEdBQUcsQ0FBQyxDQUFDO1lBQ3pDLEtBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLG1CQUFtQixFQUFFO2dCQUNwQyxRQUFRLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7YUFDakg7U0FFRixDQUFDO1FBRUYsT0FBTyxRQUFRLENBQUM7S0FDakI7Ozs7OztJQUVELGVBQWUsQ0FBQyxJQUFJOztZQUNkLFFBQVEsR0FBRyxFQUFFO1FBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUNmLFFBQVEsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDeEYsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxRQUFRLENBQUM7S0FDakI7Ozs7Ozs7SUFFRCxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUk7O2NBQ3BDLG1CQUFtQixHQUFHLEVBQUU7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ2YsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzttQkFDeEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFOztzQkFDdkUsUUFBUSxHQUFHO29CQUNmLE1BQU0sRUFBRSxNQUFNO29CQUNkLFNBQVMsRUFBRSxPQUFPO29CQUNsQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFDOUIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQ2xCLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUNqQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7b0JBQ2xELFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO2lCQUMvQjtnQkFDRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDcEM7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLG1CQUFtQixDQUFDO0tBQzVCOzs7Ozs7SUFFRCxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUk7O2NBQ3BCLG1CQUFtQixHQUFHLEVBQUU7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ2YsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7c0JBQ25JLFFBQVEsR0FBRztvQkFDZixNQUFNLEVBQUUsTUFBTTtvQkFDZCxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFDOUIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQ2xCLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUNqQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUM7b0JBQ2xELFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO2lCQUMvQjtnQkFDRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDcEM7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLG1CQUFtQixDQUFDO0tBQzVCOzs7Ozs7SUFFRCxjQUFjLENBQUMsR0FBRyxFQUFFLElBQUk7O2NBQ2hCLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtZQUM1RCxLQUFLLEVBQUUsT0FBTztZQUNkLElBQUksRUFBRTtnQkFDSixNQUFNLEVBQUUsSUFBSSxLQUFLLGFBQWEsR0FBRyxFQUFFLEdBQUcsVUFBVTtnQkFDaEQsS0FBSyxFQUFFLElBQUksSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUU7Z0JBQ3BGLE9BQU8sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUMsU0FBUyxHQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzlDLFFBQVEsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDO2dCQUN2QixXQUFXLEVBQUUsSUFBSSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxLQUFLLGFBQWEsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzVHO1NBQ0YsQ0FBQzs7UUFFRixTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU07WUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQ3RDLENBQUMsQ0FBQztLQUNKOzs7Ozs7O0lBRUQsMEJBQTBCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxTQUFTOztjQUM3QyxnQkFBZ0IsR0FBVSxFQUFFO1FBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDekIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssTUFBTTttQkFDbEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLE9BQU87bUJBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxTQUFTLEVBQUU7Z0JBQ3hDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUM3QjtTQUNGLENBQUMsQ0FBQTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFDLE1BQU0sR0FBQyxTQUFTLEdBQUMsT0FBTyxHQUFDLFNBQVMsR0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNoRixPQUFPLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO0tBQ25DOzs7Ozs7SUFFRCxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsU0FBUzs7Y0FDN0IsZ0JBQWdCLEdBQVUsRUFBRTtRQUNsQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3pCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssU0FBUyxFQUFFO2dCQUM5RCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDN0I7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO0tBQ25DOzs7OztJQUVELG1CQUFtQixDQUFDLEdBQUc7O2NBQ2YsUUFBUSxHQUFHLEVBQUU7O2NBQ2IsTUFBTSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7Y0FDaEIsUUFBUSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7UUFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN4QixRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNyQzs7Ozs7SUFFRCxvQkFBb0IsQ0FBQyxRQUFRO1FBQzNCLElBQUksQ0FBQywyQkFBMkIsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQzlFOzs7O0lBRUQsa0JBQWtCOztjQUNWLElBQUksR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFOztZQUN2RCxVQUFVLEdBQUcsSUFBSTtRQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDZixJQUFJLElBQUksQ0FBQyxPQUFPO2dCQUFFLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDdEMsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxVQUFVLENBQUM7S0FDbkI7Ozs7O0lBRUQsb0JBQW9CLENBQUMsR0FBRzs7Y0FDaEIsSUFBSSxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUU7O1lBQ3ZELGdCQUFnQixHQUFHLElBQUk7UUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ2YsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssUUFBUTtnQkFBRSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7U0FDdkcsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxnQkFBZ0IsQ0FBQztLQUN6Qjs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxJQUFJOztjQUNiLElBQUksR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDOztZQUNwRixRQUFRLEdBQUcsSUFBSTs7WUFDZixpQkFBaUIsR0FBRyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FBSztRQUV4RCxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUU7WUFDM0MsUUFBUSxHQUFHLEtBQUssQ0FBQztTQUNsQjthQUFNO1lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO2dCQUNmLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzFCLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRTt3QkFDNUMsUUFBUSxHQUFHLEtBQUssQ0FBQTtxQkFDakI7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEtBQUssQ0FBQztvQkFBRSxRQUFRLEdBQUcsS0FBSyxDQUFDO2FBQ3ZELENBQUMsQ0FBQztTQUNKO1FBRUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxpQkFBaUIsR0FBRyxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQztRQUN6RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7S0FDN0I7Ozs7O0lBRUQsbUJBQW1CLENBQUMsSUFBSTs7WUFDbEIsU0FBUyxHQUFHLEtBQUs7UUFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUM3QixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO2dCQUN0QixTQUFTLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQzNJLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7YUFDL0k7U0FDRixDQUFDLENBQUE7UUFDRixPQUFPLFNBQVMsQ0FBQztLQUNsQjs7Ozs7O0lBRUQsV0FBVyxDQUFDLE9BQU8sRUFBRSxJQUFJO1FBQ3ZCLElBQUksQ0FBQyxlQUFlLEdBQUcsT0FBTyxDQUFDO1FBQy9CLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTs7Z0JBQ1gsR0FBRyxHQUFHO2dCQUNSLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDckIsT0FBTyxFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxPQUFPLEdBQUcsS0FBSzthQUN0STtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQzdELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2FBQzdCO2lCQUFNOztzQkFDQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQzthQUNqSztTQUNGLENBQUMsQ0FBQTs7O2NBR0ksYUFBYSxHQUFHLEVBQUU7UUFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUM3QixJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ2hCLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7YUFDekM7U0FDRixDQUFDLENBQUE7UUFDRixJQUFJLENBQUMsMkJBQTJCLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBQzdFOzs7OztJQUVELGdCQUFnQixDQUFDLElBQUk7UUFDbkIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLEVBQUU7O2tCQUM1RSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDO1lBQzVELElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3JFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDcEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7YUFDOUI7U0FDRjthQUFNOztnQkFDRCxHQUFHLEdBQUc7Z0JBQ1IsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsT0FBTyxFQUFFLElBQUk7YUFDZDtZQUNELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1NBQzdCOzs7Y0FHSyxhQUFhLEdBQUcsRUFBRTtRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQzdCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDaEIsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUN6QztTQUNGLENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDN0U7Ozs7O0lBRUQseUJBQXlCLENBQUMsV0FBVzs7Y0FDN0IsYUFBYSxHQUFHLEVBQUU7UUFDeEIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3RCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDaEIsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUN6QztTQUNGLENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDN0U7Ozs7O0lBRUQsZ0JBQWdCLENBQUMsQ0FBUTtRQUN2QixJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6RDs7OztJQUVELGVBQWU7UUFDYixJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7S0FDbEQ7OztZQTNhRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLG9CQUFvQjtnQkFDOUIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BcUNMO2dCQUNMLE1BQU0sRUFBRSxDQUFDLDAvVUFBMC9VLEVBQUUsNElBQTRJLENBQUM7Z0JBQ2xwVixhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTthQUN0Qzs7O1lBekRDLGlCQUFpQjtZQUtWLFVBQVU7WUFEdUIsV0FBVztZQUF2QixVQUFVO1lBRS9CLGdCQUFnQjtZQUVoQixTQUFTO1lBUGhCLGdCQUFnQjtZQVNULGdDQUFnQztZQUhoQyxrQkFBa0I7WUFLbEIsc0JBQXNCOzs7Ozs7O0FDaEIvQjs7OztJQXFHRSxZQUNVLFdBQXdCO1FBQXhCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBRmxDLGdCQUFXLEdBQWEsQ0FBQywwQkFBMEIsRUFBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBSzVFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUNuRSxXQUFXLENBQUMsaUJBQWlCLENBQUMsZUFBZSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDdkUsV0FBVyxDQUFDLGlCQUFpQixDQUFDLGNBQWMsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3JFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO1FBQzNFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsRUFBRSw0QkFBNEIsQ0FBQyxDQUFDO1FBS25GLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsa0JBQWtCLEVBQzFEO1lBQ0UsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7WUFDOUYsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7U0FDbkcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FDOUMsQ0FBQTtRQUVELFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsZUFBZSxFQUN2RDtZQUNFLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7O1lBRXBHLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFO1NBQ2xHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxXQUFXLENBQzdDLENBQUE7S0FFRjs7Ozs7SUF4Q0QsT0FBTyxPQUFPLENBQUMsV0FBZ0I7UUFDN0IsT0FBTztZQUNMLFFBQVEsRUFBRyxZQUFZO1lBQ3ZCLFNBQVMsRUFBQztnQkFDUjtvQkFDRSxPQUFPLEVBQUUsS0FBSztvQkFDZCxRQUFRLEVBQUUsV0FBVztpQkFDdEI7YUFDRjtTQUNGLENBQUE7S0FDRjs7O1lBbkVGLFFBQVEsU0FBQztnQkFDUixPQUFPLEVBQUU7b0JBQ1AsdUJBQXVCO29CQUN2QixlQUFlO29CQUNmLGlCQUFpQjtvQkFDakIsY0FBYztvQkFDZCxhQUFhLENBQUMsY0FBYyxDQUFDO3dCQUMzQixzQkFBc0I7d0JBQ3RCLHNCQUFzQjt3QkFDdEIscUJBQXFCO3dCQUNyQix3QkFBd0I7d0JBQ3hCLDRCQUE0QjtxQkFDM0IsQ0FBQztvQkFDSixrQkFBa0I7b0JBQ2xCLGVBQWU7b0JBQ2YsY0FBYztvQkFDZCxhQUFhO29CQUNiLGdCQUFnQjtvQkFDaEIsZUFBZTtvQkFDZixhQUFhO29CQUNiLGtCQUFrQjtpQkFDbkI7Z0JBQ0QsWUFBWSxFQUFFO29CQUNaLHNCQUFzQjtvQkFDdEIsa0JBQWtCO29CQUNsQixxQkFBcUI7b0JBQ3JCLHFCQUFxQjtvQkFDckIsaUJBQWlCO29CQUNqQixpQkFBaUI7b0JBQ2pCLHlCQUF5QjtvQkFDekIscUJBQXFCO29CQUNyQix3QkFBd0I7b0JBQ3hCLGdCQUFnQjtvQkFDaEIsNEJBQTRCO29CQUM1Qix3QkFBd0I7b0JBQ3hCLHdCQUF3QjtvQkFDeEIsc0JBQXNCO2lCQUN2QjtnQkFDRCxTQUFTLEVBQUMsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDO2dCQUNqQyxPQUFPLEVBQUU7b0JBQ1Asc0JBQXNCO29CQUN0QixxQkFBcUI7b0JBQ3JCLHdCQUF3QjtvQkFDeEIsNEJBQTRCO29CQUM1QixzQkFBc0I7aUJBQ3ZCO2dCQUNELGVBQWUsRUFBRTtvQkFDZixzQkFBc0I7b0JBQ3RCLHFCQUFxQjtvQkFDckIseUJBQXlCO29CQUN6QixxQkFBcUI7b0JBQ3JCLHdCQUF3QjtvQkFDeEIsNEJBQTRCO29CQUM1QixzQkFBc0I7aUJBQ3JCO2FBQ0o7OztZQXRGUSxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7In0=