#!/bin/bash

cp -pr src/* stage/
cp -pr src/.npmrc stage/
if [ -e stage/package.json ]
then
    VERSION=$(cat stage/package.json \
        | grep version \
        | head -1 \
        | awk -F: '{ print $2 }' \
        | sed 's/[",]//g' \
        | tr -d '[[:space:]]')
else
    VERSION="0.1.0"
fi
GIT_BRANCH=$1
GIT_HASH=$(cd src && git rev-parse --short HEAD )
echo "${VERSION}-${GIT_BRANCH}.${GIT_HASH}" | tee stage/version

rm stage/package-lock.json

# install and cache app dependencies
cd stage
npm install
npm install -g npm-snapshot

# update snapshot version with commit hash
cd projects/omnia/ui-qnav
npm-snapshot ${GIT_HASH}

# generate build
cd ../../..
npm run lib-build

# publish snapshot version
npm publish --tag snapshot dist/omnia/ui-qnav
