// fund color map, need set color for each fund if add more funds
export const dataVisualFundColorMap = [
    {
        fundID: undefined,
        color:'#86BBD1',
    },
    {
        fundID: undefined,
        color:'#FC7C42'
    },
    {
        fundID: undefined,
        color:'#008198'
    },
    {
        fundID: undefined,
        color:'#CDDC39'
    }
]

export const dataVisualColor = [
    '#86BBD1','#FC7C42', '#008198','#CDDC39'
]

// for heatmap component color setting
export const heatMapColorSetting = [
    {
        value: -3,
        color: '#B91224',
    },
    {
        value: -2,
        color: '#EAB7BD',
    },
    {
        value: -1,
        color: '#F5DCDE',
    },
    {
        value: 1,
        color: '#DFEAE2',
    },
    {
        value: 2,
        color: '#BED5C5',
    },
    {
        value: 3,
        color: '#28743E',
    }
]

export const heatMapColorScheme = {
    domain: ['#B91224', '#EAB7BD', '#F5DCDE', '#DFEAE2','#BED5C5','#28743E']
  };