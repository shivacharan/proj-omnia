import {
  ElementRef, NgZone, ChangeDetectorRef,
  Component,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  HostListener,
  ChangeDetectionStrategy,
  ContentChild,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';
import { formatDate } from '@angular/common';
import { BaseWidgetComponent } from '@omnia/ui-common';
import {MatDialog} from '@angular/material';
import { AddFundModalComponent } from '../add-fund-modal/add-fund-modal.component';
import { NavService } from '../services/nav-service.service';
import { NavSocketService } from '../services/nav-socket.service';
import { CommonUtilsService } from '../services/common-utils.service';
import { dataVisualFundColorMap } from '../colors';
import { Nav } from '../model/qnav';
import { ticksValue, defaultFundList } from './line-data';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import { Subscription } from 'rxjs';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { ResourceManagerService } from '../services/resource-manager.service';

@Component({
  selector: 'lib-qnav-line-chart',
  templateUrl: './qnav-line-chart.component.html',
  styleUrls: ['./qnav-line-chart.component.scss']
})
export class QnavLineChartComponent extends BaseWidgetComponent {
  removable: boolean = true;
  selectable: boolean = false;

  results: any[] = [];
  permanentResults: any[] = [];
  isDataAvailable: boolean = false;
  height: number = 240;
  margin: any[] = [20, 100, 30, 100];
  colorDomain: any[] = [];
  width: number;
  tickValues: any[] = ticksValue;
  currentLineTime: Date;
  displayLiveTime: any;
  circleData: any[] = [];
  permanentCircleData: any[] = [];
  previousTimeMap: Map<String, Date>;
  xScaleMin: any;
  xScaleMax: any;
  showYAxisLabel = true;
  yAxisLabel = 'Nav % Change'
  previousTime = new Date();
  activeEntries: any[] = [];
  highLightActiveEntries: any[] = [];

  fundChange:  EventEmitter<any> = new  EventEmitter<any>();
  removeIndexs: any[] = [];
  private subs: Subscription[];
  constructor(chartElement: ElementRef, zone: NgZone, cd: ChangeDetectorRef,
    private navService: NavService, private navSocketService: NavSocketService,
    private dialog: MatDialog,
    private viewContainer: ViewContainerRef,
    private shareInforBewteenComponents : ShareInfoBeweenComponentsService,
    public commonUtils: CommonUtilsService,
    private resourceManger: ResourceManagerService) {
    super();
    this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width - 100;
    this.xScaleMin = commonUtils.startTime;
    this.xScaleMax = commonUtils.endTime;
    this.currentLineTime = commonUtils.startTime;

    this.resourceManger.registInterval(() => {
      if (new Date() < commonUtils.endTime) {
        this.displayLiveTime = new Date()
      } else {
        this.displayLiveTime = commonUtils.endTime;
      }
    },1000);
  }

  ngOnInit() {
    //need to reset value here when switch back from other dashboard like position or when switch users
    this.commonUtils.validateUser();
    //initialize the  colorDomain with predefined colors.
    this.shareInforBewteenComponents.setColorSchema(dataVisualFundColorMap);
    this.isDataAvailable = false;
    this.subs = [];
    this.results = [];
    this.permanentResults = [];
    this.colorDomain = [];
    this.circleData = [];
    this.permanentCircleData = [];
    this.previousTimeMap = null;
    //reset done
    this.navService.fetchFundList();
    this.subs.push(this.navService.getFundList().subscribe(
      data => {
        if (data.length > 0) {
          const fundLevelData = this.commonUtils.extractFundLevelData(data);
          this.permanentResults = [...this.convertToResults(fundLevelData)];
          this.permanentCircleData = [...this.updateCircleData(fundLevelData)];
          this.colorDomain = [...this.setFundColorMap(fundLevelData)];
          this.shareInforBewteenComponents.setColorSchema(this.colorDomain);
          this.isDataAvailable = true;
          this.previousTimeMap = new Map();
          this.permanentResults.forEach(f => {
            let series = f['series'];
            this.previousTimeMap.set(f['name'], series[series.length - 1]['pricetime']);
            this.currentLineTime = new Date(this.previousTimeMap.get(f['name']));
          });
          this.results = this.filterResults(this.permanentResults);
          this.circleData = this.filterCircleDate(this.permanentCircleData);
        }
      }
    ));

    this.subs.push(this.navSocketService.getNav().subscribe(
      (data) => {
        if (data && data["eventData"]) {
          const fundLevelUpdateData = this.commonUtils.extractWSData(data["eventData"], false);
          this.updateChart(fundLevelUpdateData);
        }
      }
    ));

    this.shareInforBewteenComponents.highLightActiveEntries.subscribe(data => {
      const filteredActiveData = [];
      const lists = this.shareInforBewteenComponents.getFundList();
      data.forEach(item => {
        if (lists.find(list => (list.fundID === item.name && list.checked))) {
          filteredActiveData.push(item);
        }
      })
      this.highLightActiveEntries = filteredActiveData;
      this.activeEntries = filteredActiveData;
    })

      this.fundChange.subscribe(data => {
        this.shareInforBewteenComponents.highLightActiveEntries.emit(this.highLightActiveEntries);
        this.results = [];
        this.circleData = [];
        this.shareInforBewteenComponents.getFundList().forEach (fund => {
          this.permanentResults.forEach (result => {
            if(fund['fundID'] === result['name'] && fund['checked']) {
              this.results.push(result);
            }
          });
          this.permanentCircleData.forEach(circle => {
            if (fund['fundID'] === circle['name'] && fund['checked']) {
              this.circleData.push(circle);
            }
          })
        });
      });
  }

  filterResults(permnantResult): any[] {
    let filteredResults = [];
     permnantResult.forEach(result => {
       this.shareInforBewteenComponents.getFundList().forEach(item => {
         if ( result.name === item.fundID && item.checked) {
           filteredResults.push(result);
         }
      })
    })
    return filteredResults;
  }

  filterCircleDate(permanentCircleData): any[] {
    let filteredCircleData = [];
     permanentCircleData.forEach(result => {
       this.shareInforBewteenComponents.getFundList().forEach(item => {
         if ( result.name === item.fundID && item.checked) {
           filteredCircleData.push(result);
         }
      })
    })
    return filteredCircleData;
  }

  setFundColorMap(data) {
    const temp = [];
    const lists = this.shareInforBewteenComponents.getFundList();
    data.forEach(item => {
      let setColor = false;
      lists.forEach(list => {
       if (item.fundid === list.fundID && list.checked) setColor = true;
      })
       if (setColor) {
         const obj = {
          fundid: item.fundid,
          color: this.commonUtils.getColorForFund(item.fundid)
        }
        temp.push(obj)
       } else {
         const obj = {
          fundid: undefined,
          color: this.commonUtils.getColorForFund(item.fundid)
        }
        temp.push(obj)
       }
    })
    return temp;
  }

  
  //need to unsubscribe to avoid potential memory leak.
  ngOnDestroy() {
    this.subs.forEach(sub => sub.unsubscribe());
    this.colorDomain = [];
    this.resourceManger.cleanResources();
  }

  resizingChart(event) {
    this.width = event.target.innerWidth - 100;
  }

  private getResults(results: any[]) : any[]{
    if(results.length === 0) {
        return defaultFundList;
    } else {
      return results;
    }
  }

  updateChart(data) {
    if (data) {
      const fundid = data['fundid'];
      let time
      let currentTime: Date;
      if (data['pricetime']) {
        currentTime = new Date(data['pricetime']);
        if (this.commonUtils.isValidTime(currentTime)) {
          time = currentTime;
        }
      }
      if (currentTime > this.commonUtils.endTime) {
        this.currentLineTime = this.commonUtils.endTime;
      }
      //for adding alert data if any.
      if (this.commonUtils.isValidTime(new Date(data['pricetime'])) && data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
        const alertObj = {
          "name": fundid,
          "x": new Date(data['pricetime']),
          "alertType": data['alertType'],
          "value": data['navChangePercent'],
          "fundmvChangePercent": data['fundmvChangePercent'],
          "nav": data['nav'],
          "marketval": data['fundmv'],
          "pricetime": data['pricetime']
        }
        this.permanentCircleData.push(alertObj);
        //this.permanentCircleData = [...this.permanentCircleData];
        this.circleData = [...this.filterCircleDate(this.permanentCircleData)];
      }
      this.permanentResults.forEach(item => {
        if (item['name'] === fundid) {
          //only shows data between 9:30AM to 4:30PM
          if (time) {
            if (currentTime.getTime() - new Date(this.previousTimeMap.get(fundid)).getTime() >= 20000) {
              this.currentLineTime = new Date(data['pricetime']);
              const obj = {
                'marketval': data['fundmv'], // fund market value
                'name': this.nextTimeForFund(this.previousTimeMap, fundid, data['pricetime']),
                'nav': data['nav'],
                'value': data['navChangePercent'],
                'pricetime': data['pricetime']
              };
              item['series'].push(obj);
            } else if(currentTime.getTime() - this.previousTime.getTime() >=2000){
              this.previousTime = currentTime;
              //this.currentLineTime = new Date(this.previousTimeMap.get(fundTicker)); //this will cause component re-render whenever this is ws data coming
              const obj = {
                'marketval': data['fundmv'],
                'name': new Date(this.previousTimeMap.get(fundid)),
                'nav': data['nav'],
                'value': data['navChangePercent'],
                'pricetime': data['pricetime']
              };
              //this will increase cpu usage as well, need to find better way to update results
              item['series'].pop();
              item['series'].push(obj);
            }
          }
        }
      })

    }

  }
  // the get fund list service will return the history chart data, using below functions to covert the data to expected result set
  convertToResults(data: any[]): any[] {
    const results: any[] = [];
    const variableFundList: any[] = this.shareInforBewteenComponents.getFundList();
    data.forEach(item => {
      // for persistent user selected funds in legend.
      if (variableFundList.findIndex(list => list.fundID === item.fundid) === -1) {        
          variableFundList.push({
          'fundID': item['fundid'],
          'fundTicker':item['fundTicker'],
          'checked': true
        })
      }
      const obj = {
        'name': item['fundid'],
        'fundID': item['fundid'],
        'fundTicker':item['fundTicker'],
        'series': this.createSeries(item)
      }
      results.push(obj);
    })
    this.shareInforBewteenComponents.setVariableFundList(variableFundList);
    return results;
  }
  createSeries(data: any): any[] {
    const series: any[] = [];
    data['priceChanges'].forEach(item => {
      if (this.commonUtils.isValidTime(new Date(item['pricetime']))) {
        const obj = {
          'marketval': item['fundmv'], //fund market value from history data
          'name': new Date(item['pricetime']),
          'nav': item['nav'],
          'value': item['navChangePercent'],
          'pricetime': item['pricetime']
        }
        series.push(obj);
      }
    }
    )
    if (series.length == 0) {
      const obj = {
        'marketval': data['fundmv'], //fund market value from history data
        'name': this.xScaleMin,
        'nav': data['nav'],
        'value': 0,
        'pricetime': this.commonUtils.startTime
      }
      series.push(obj);
    }
    return series;
  }

  // for collecting historic alert data
  updateCircleData(data) {
    let CricleData = [];
    data.forEach(item => {
      CricleData = CricleData.concat(this.filterAlertData(item['fundid'], item['priceChanges']));
    })
    return CricleData;
  }

  filterAlertData(fundid, data) {
    const tempAlertCricleData = [];
    data.forEach(item => {
      if (this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
        const alertObj = {
          "name": fundid,
          "x": new Date(item['pricetime']),
          "alertType": item['alertType'],
          "value": item['navChangePercent'],
          "nav": item['nav'],
          "fundmvChangePercent": item['fundmvChangePercent'],
          "marketval": item['fundmv'],
          "pricetime": item['pricetime'],
        }
        tempAlertCricleData.push(alertObj);
      }
    })
    return tempAlertCricleData;
  }


  // this method will return the next time and set the new time to the previous time map for the given fund
  nextTimeForFund(previousTimeMap: Map<String, Date>, fundid: String, time) {
    previousTimeMap.set(fundid, time); // set back to the map
    return new Date(time);
  }

  openAddFundModal(event): void {
    const dialogRef = this.dialog.open(AddFundModalComponent, {
      width: '300px',
      data: {
          'fundList': this.shareInforBewteenComponents.getFundList(),
          'dataChange': this.fundChange //create eventemitter ourself as closeDialogSubject is not working
        },
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  xAxisTickFormatting(v) {
   const tempDate = new Date(v);
   return formatDate(tempDate,"h:mm aaaaa'm'",'en-US');
 }

}
