import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomLegendComponent } from '../custom-legend/custom-legend.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material';
import { QnavLineChartComponent } from './qnav-line-chart.component';
import { LineChartComponent } from '../line-chart/line-chart.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HttpClientTestingModule } from '@angular/common/http/testing';


describe('QnavLineChartComponent', () => {
  let component: QnavLineChartComponent;
  let fixture: ComponentFixture<QnavLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomLegendComponent,LineChartComponent,QnavLineChartComponent ],
      imports: [
        MatChipsModule,
        MatIconModule, NgxChartsModule,
        HttpClientTestingModule,
        
      ],
      providers: [ CustomLegendComponent,LineChartComponent ] 
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnavLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
