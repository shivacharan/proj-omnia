import { MainDatatableComponent } from './../main-datatable/main-datatable.component';
import { defaultFundList } from './../qnav-line-chart-old/line-data';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';
import { SingleLineChartComponent } from '../single-line-chart/single-line-chart.component';
import { PositionFundSummaryComponent } from './position-fund-summary.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { assertDataInRangeInternal } from '@angular/core/src/render3/util';

describe('PositionFundSummaryComponent', () => {
  let component: PositionFundSummaryComponent;
  let fixture: ComponentFixture<PositionFundSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PositionFundSummaryComponent , SingleLineChartComponent],
      imports: [
        MatIconModule, HttpClientTestingModule,
        MatButtonModule, MatCheckboxModule, NgxChartsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PositionFundSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
