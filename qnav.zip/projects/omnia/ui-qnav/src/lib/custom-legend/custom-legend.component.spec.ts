import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';

import { CustomLegendComponent } from './custom-legend.component';

describe('CustomeLegendComponent', () => {
  let component: CustomLegendComponent;
  let fixture: ComponentFixture<CustomLegendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomLegendComponent ],
      imports: [
        MatChipsModule,
        MatIconModule
      ],
     
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomLegendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
