import {Component, OnInit } from '@angular/core';
import {BaseWidgetComponent} from '@omnia/ui-common';
import {NavService} from '../services/nav-service.service';
import {QnavChart} from '../services/qnav';
import {dataVisualColor} from '../colors';
import {ColorHelper} from '@swimlane/ngx-charts';

@Component({
  selector: 'lib-qnav-line-chart', // tslint:disable-line
  templateUrl: './qnav-line-chart.component.html',
  styleUrls: ['./qnav-line-chart.component.css']
})
export class QnavLineChartComponent extends BaseWidgetComponent implements OnInit {

  qnavData: QnavChart[];
  colorDomain: string[] = dataVisualColor;
  colors: ColorHelper;
  tickValues: string[] = ['09:30', '10:30', '11:30', '12:30', '13:30', '14:30', '15:30', '16:30'];

  constructor(private navService: NavService) {
    super();
  }

  ngOnInit() {
      this.getQnavData();
  }

  getQnavData() {
      const funds = 'Fund9';
      this.navService.getTodayNav(funds).subscribe(
          data => {
              let ii = 0;
              const myColors: Array<{name: string, value: string}> = new Array();
              data.map( d => {
                  d['customColor'] = this.colorDomain[ii];
                  myColors.push({
                      name: d.name,
                      value: d.customColor
                  });
                  ii++;
                  if (this.colorDomain.length === ii) {
                      ii = 0;
                  }
              });
              this.qnavData = data;
              // this.colors = new ColorHelper(this.scheme, 'ordinal', this.domain, this.customColors);
          });
  }

    customTimeAxisTickFormatting(mondayString: string) {

        console.log('monday string is', mondayString);
        const displayTimeMap = {
            '09:30':  '09:30 am',
            '10:30': '10:30 am',
            '11:30': '11:30 am',
            '12:30': '12:30 am',
            '13:30': '01:30 pm',
            '14:30': '02:30 pm',
            '15:30': '03:30 pm',
            '16:30': '04:30 pm'
        }
        return displayTimeMap[mondayString];
    }
}
