import { Injectable, EventEmitter } from '@angular/core';
import { isDate } from '@angular/common/src/i18n/format_date';

@Injectable({
  providedIn: 'root'
})
export class ShareInfoBeweenComponentsService {
  public accessToken;
  public fundInfo : any = [];
  private variableFundList: any = [];
  public colorSchema: any[] = [];
  public highLightActiveEntries: EventEmitter<any> = new  EventEmitter<any>();
  public clickedOutSide: EventEmitter<any> = new  EventEmitter<any>();
  // data-table components data communication
  public hyperLinkNavigate: EventEmitter<any> = new EventEmitter<any>();
  public openModalData: EventEmitter<any> = new EventEmitter<any>();
  public sortDatatableColumn: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  public savePositionDetailsFundInfo(fundInfo) {
    this.fundInfo = fundInfo;
  }

  public setVariableFundList(data) {
    this.variableFundList = data;
  }

  public setColorSchema(colorSchema : any[]) {
    this.colorSchema = colorSchema;
  }

  public getFundList() : any[]{
    return this.variableFundList;
  }
  public reset() {
    this.fundInfo = [];
    this.variableFundList = [];
    this.colorSchema = [];
    this.highLightActiveEntries = new  EventEmitter<any>();
    this.hyperLinkNavigate = new EventEmitter<any>();
    this.openModalData = new EventEmitter<any>();
    this.sortDatatableColumn = new EventEmitter<any>();
  }
}
