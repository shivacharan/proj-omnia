import { Injectable, OnInit, Inject} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
//import { dev, prod } from '../lib-env';

@Injectable({
  providedIn: 'root'
})
export class NavService {

  private data : BehaviorSubject<any[]> = new BehaviorSubject([] as any[]);

  //baseUrl = this.env.production? prod.service_base_url: dev.service_base_url;
  //constructor(private http: HttpClient, @Inject('env') private env) { }
  constructor(private http: HttpClient) { }


  getTodayNav(funds): Observable<any[]> {
    return this.http.get<any[]>('/api/today');// demo api, can be removed after merge qnav-line-chart
  }
  // call this one from chart component only to avoid multiple call request by different component
  fetchFundList() {
    //return this.http.get<any[]>('/api/fundList').subscribe(d => this.data.next(d as any[]));
    this.data = new BehaviorSubject([] as any[]);//reset data as the getFundList subcription may still get the old data if new call hasn't returned yet.
    this.http.get<any[]>('/qnav-web-multiclass/data/fundlist?timeZoneOffset=' + new Date().getTimezoneOffset() * (-1))
      .subscribe(d => {
        this.data.next(d as any[])
      },
        error => {
          console.log(error)
        });
  }
  // call this one for all components to get fundlist if it's already fetched.
  getFundList(): Observable<any[]> {
      return this.data.asObservable();
  }
  getPositionDetails(fund: string) : Observable<any[]> {
    //return this.http.get('api/positionDetails')
    return this.http.get<any[]>('/qnav-web-multiclass/data/fundDetail?fundId='+fund);;
  }

}
