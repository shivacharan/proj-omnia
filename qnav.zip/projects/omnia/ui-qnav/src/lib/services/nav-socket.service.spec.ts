import { TestBed, inject } from '@angular/core/testing';

import { NavSocketService } from './nav-socket.service';

describe('NavSocketService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NavSocketService]
    });
  });

  it('should be created', inject([NavSocketService], (service: NavSocketService) => {
    expect(service).toBeTruthy();
  }));
});
