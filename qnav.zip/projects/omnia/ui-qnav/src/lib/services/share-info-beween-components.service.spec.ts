import { TestBed, inject } from '@angular/core/testing';

import { ShareInfoBeweenComponentsService } from './share-info-beween-components.service';

describe('ShareInfoBeweenComponentsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShareInfoBeweenComponentsService]
    });
  });

  it('should be created', inject([ShareInfoBeweenComponentsService], (service: ShareInfoBeweenComponentsService) => {
    expect(service).toBeTruthy();
  }));
});
