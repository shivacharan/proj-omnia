import { Injectable } from '@angular/core';
import { CommonUtilsService } from '../services/common-utils.service';


@Injectable({
  providedIn: 'root'
})
export class ResourceManagerService {

  constructor() {
      //window.addEventListener('blur',(event)=>{this.deactive(event)});
      //window.addEventListener('focus',(event)=>{this.active(event)});
      window.addEventListener('visibilitychange',(event)=>{
        if(document.hidden) {
          this.deactive(event);
        } else {
          this.active(event);
        }
      })
   }

  private intervalInstances: any[] = [];
  private intervalFuncs: any[] = [];
  private deactive(event: any) {
    //console.log(event);
     this.doDeactive();  
  }
  private doDeactive() {
      this.intervalInstances.forEach ( item => {
        let time = new Date();
        console.log(`clear the setinterval for component: ${item}, ${time}`);
        clearInterval(item);
    })
  }
  private active(event: any) {
    //console.log(event);
    this.intervalFuncs.forEach( item => {
      let time = new Date();
      //console.log(`active the setinterval for component: ${item['func']}, interval:${item['interval']}, ${time}`);
      this.intervalInstances.push(setInterval(item['func'], item['interval']));
    })
  }
  registInterval(intervalFunc, interval: number) {
    let instance = setInterval(intervalFunc, interval);
    this.intervalInstances.push(instance);
    this.intervalFuncs.push({'func':intervalFunc, 'interval':interval});
  }
  //need call in component ngOnDestroy() to clear resources for current component
  cleanResources() {
    this.doDeactive();
    this.intervalInstances = [];
    this.intervalFuncs = [];
  }
}
