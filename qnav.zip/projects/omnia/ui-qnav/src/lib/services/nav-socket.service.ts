import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { webSocket, WebSocketSubject} from 'rxjs/webSocket' // for RxJS 6, for v5 use Observable.webSocket
import { Nav,Request, Action, NavEvent } from '../model/qnav';
//import { dev, prod } from '../lib-env';

@Injectable({
    providedIn: 'root'
})

export class NavSocketService {
   
    private subject; //: WebSocketSubject<NavEvent>;

    private nav : BehaviorSubject<NavEvent> = new BehaviorSubject({} as NavEvent);
    
    
    // constructor(@Inject('env') private env) {
    //     this.initSocket();
    //     this.registerService();
    // }
    constructor() {
            this.initSocket();
            this.registerService();
    }

    public initSocket()  {
        this.subject = webSocket('wss://'+window.location.hostname+":"+window.location.port+'/qnav-web-multiclass/conn'); //  proxy won't be able to function if the port not match with start port
        //return this.subject;
        this.subject.subscribe(
            (msg) => {this.nav.next(msg as NavEvent);},
            (err) => console.log("ERROR!!!!"+err),
            () => console.log("NAV Socket COMPLETED.....")
        );
       // console.log(new Date(1524823809200431));
    }

    public getNav() {
        return this.nav.asObservable();
    }
    public send(request: Request): void {
        this.subject.next(request);
    }

    public registerFunds(funds: any[]) {

        funds.forEach(fund => {
          this.send({"action":Action.WATCHFUND,"fundId":fund})      
        });
    }
    public unRegisterFunds(funds: any[]) {
        funds.forEach(fund => {
          this.send({"action":Action.STOPWATCHFUND,"fundId":fund})      
        });
    }
    public registerService() {
        this.send({action:Action.REGISTER,sessionId:new Date().valueOf() + '',timeZoneOffset:new Date().getTimezoneOffset()*(-1)});
    }
}
