import {
  ElementRef, NgZone, ChangeDetectorRef,
  Component,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  HostListener,
  ChangeDetectionStrategy,
  ContentChild,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
  OnInit,
} from '@angular/core';
import { CommonUtilsService } from '../services/common-utils.service';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import _ from 'lodash';

@Component({
  selector: 'lib-common-data-table',
  templateUrl: './common-data-table.component.html',
  styleUrls: ['../common-style/datatable-common.css', './common-data-table.component.scss'],
  encapsulation: ViewEncapsulation.None //If you are using PrimeNG or Angular Material in your project that styleUrl will not work like this. You need to import ViewEncapsulation and put encapsulation: ViewEncapsulation.None in the @component definition.
})
export class CommonDataTableComponent implements OnInit {

  @ViewChild('mydatatable') mydatatable: any;

  // data
  @Input() headerSetting: boolean = true;
  @Input() headerHeight: number = 50;
  @Input() isDataTablePaused: boolean = false;
  @Input() rows: any[] = [];
  @Input() childRows: any[] = [];
  @Input() alertData: any[] = [];
  @Input() rowHeight: number = 50;
  @Input() customColumn: any = []; //type No. Details
  @Input() normalColumn: any = []; // width, draggable, canAutoResize  prop headerClass cellClass headerTemplate cellTemplate columnSetting etc.
  @Input() limit: number = 5;
  @Input() footerHeight: number = 50;
  @Input() headerCheckBox: boolean = false;
  @Input() columnMenuDropDownSetting: any[] = [];
  @Input() allRowsSelected: boolean;

  // function
  @Input() getAllRowsDisabled: any;
  @Input() getSingleRowDisabled: any;
  @Input() getAllRowChecked: any;
  @Input() getSingleRowChecked: any;
  @Input() onSelectAll: any;
  @Input() onCheckboxChange: any;
  @Input() defaultSortCol: string;

  @Output() menuClosed: EventEmitter<any> = new EventEmitter();
  @Output() togglePauseFlagEvent: EventEmitter<any> = new EventEmitter();


  expandChild = false;
  selectedCol: '';
  isSelectedMap: any[] = [];
  expandCollapseIconMap: any[] = [];
  getSortIconDisplayFlag: any = {};
  isDataAvailable = false;
  ascFlag = 'asc';

  private interval: any;

  hasChildren(row) {   
    return this.childRows.findIndex(item => { return item.fundid === row.fundid })===-1 ? false : true;
  }

  constructor(private cd: ChangeDetectorRef,
    private viewContainer: ViewContainerRef,
    private shareInforBewteenComponents: ShareInfoBeweenComponentsService,
    public commonUtils: CommonUtilsService) {
    shareInforBewteenComponents.clickedOutSide.subscribe(e => {
     // this.selectedCol = '';
    });
  }

  ngOnInit() {
    this.expandCollapseIconMap = this.setDefaultExpandCollapseMapping(this.rows);
    this.getSortIconDisplayFlag = this.setDefaultSortIconDisplayFlag(this.normalColumn);
    this.expandChild = this.childRows.length > 0 ? true : false;
    this.isDataAvailable = this.rows.length > 0 ? true : false;
    let data = this.getSortColumnDetailsInfo();
    this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
  }

  ngAfterViewInit() {
    const layOutComp =document.getElementsByClassName('layout-item')[1];
    if(layOutComp) {
      layOutComp.classList.add('table-layout')
      this.onResize(event)
    };
  }

  setDefaultExpandCollapseMapping(data): any[] {
    let mappingArr = [];
    data.forEach(item => {
      let obj = {
        fundid: item.fundid,
        expand: false
      };
      mappingArr.push(obj);
    })
    return mappingArr;
  }

  setDefaultSortIconDisplayFlag(column): any {
    let tempMap = {};
    column.forEach(item => {
      let obj = new Object();
      obj[item.prop] = false;
      tempMap = Object.assign(_.cloneDeep(tempMap), obj);
    })
    return tempMap;
  }

  getSortColumnDetailsInfo() {
    let obj = {
      map: this.expandCollapseIconMap,
      prop: this.defaultSortCol,
      ascFlag: true
    };
    this.normalColumn.forEach(item => {
      if (item.sortColumnAscOrDesc) {
      obj = {
        map: this.expandCollapseIconMap,
        prop: item.prop,
        ascFlag: item.sortColumnAscOrDesc === 'asc' ? true : false
      }
      }
    })
    return obj;
  }

  getHeaderClass(column): any {
    switch (column.headerClassFormat) {
      case 'headerLeft':
        return 'columnHeader header-align-left';
      case 'headerCenter':
        return 'columnHeader header-align-center';
      case 'headerRight':
        return 'columnHeader header-align-right';
      default:
        return 'columnHeader';
    }
  }

  getCellClass(row, column, value): any {
    switch (column.cellClassFormat) {
      case 'cellLeft':
        return ' align-left'
      case 'cellRight':
        return ' align-right';
      case 'cellNumber':  // need more anlyze here
        if (value !== 0) {
          if (value.toString().indexOf('-') !== -1 && value.toString().indexOf('-') === 0) {
            return ' is-nagetive';
          } else {
            return ' is-positive';
          }
        } else if (column.prop === 'navChangePercent') {
          if (row['navChange'].toString().indexOf('-') !== -1 && row['navChange'].toString().indexOf('-') === 0) {
            return ' is-nagetive';
          } else {
            return ' is-positive';
          }
        } else if (column.prop === 'fundmvChangePercent') {
          if (row['fundmvChange'].toString().indexOf('-') !== -1 && row['fundmvChange'].toString().indexOf('-') === 0) {
            return ' is-nagetive';
          } else {
            return ' is-positive';
          }
        } else if(value === 0) {
          return ' is-zero';
        }
      // tslint:disable-next-line:no-switch-case-fall-through
      default:
        return;
    }
  }

  getColSettingWidth(col) {
    if (col && col.width && !isNaN(Number(col.width))) {
      return col.width;
    } else {
      return 150;
    }
  }

  showYellowAlert(fund, classID): boolean {
    let show = false;
    show = this.alertData.find(item => item.name === fund && item.classID === classID &&item.alertType === 1)
    return show;
  }

  showRedAlert(fund, classID): boolean {
    let show = false;
    show = this.alertData.find(item => item.name === fund && item.classID === classID && item.alertType === 2)
    return show;
  }

  showNews(row): boolean {
    // according to row info to determine show news icon or not 
    return true;
  }

  getSideColorStyle(row): string {
    let backgroundColor = '';
    this.shareInforBewteenComponents.colorSchema.forEach(item => {
      if (row && row['fundid'] && item['fundid'] === row['fundid']) {
        backgroundColor = item['color'];
      }
    });
    return backgroundColor;
  }

  toggleExpandRow(row) {
    const parentFundId = row.fundid;
    let currentExpand;
    this.expandCollapseIconMap.forEach(item => {
      if (parentFundId === item.fundid) {
        item.expand = !item.expand;
        currentExpand = item.expand;
      }
    });
    const index = this.rows.findIndex(item => { return item.fundid === parentFundId });
    this.childRows.forEach(item => {
      if (item.fundid === parentFundId) {
        currentExpand ? this.rows.splice(index + 1, 0, item) : this.rows.splice(index + 1, 1);
      }
    });
  }

  getExpandCollapseIcon(row): string {
    const fundid = row.fundid;
    let expandFlag = false;
    this.expandCollapseIconMap.forEach(item => {
      if (fundid === item.fundid) expandFlag = item.expand;
    })

    return row.child === "child" ? "" : expandFlag ? "arrow_down" : "arrow_right";
  }

  getRowHeight(para) {
   // debugger;
    para === 'standard' ? this.rowHeight = 50 : this.rowHeight = 40;
  }

  onClickedOutside(e: Event) {
    this.shareInforBewteenComponents.clickedOutSide.emit(e);
  }

  selectCurrentCol(event, prop) {
    this.selectedCol = prop;
    event.currentTarget.classList.add("drop-is-visible");
  }

  closeMenu() {
    document.getElementsByClassName("drop-is-visible")[0].classList.remove("drop-is-visible");
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
   //calcute  datatable-body height according to gridster-item height 
   var height=Number((document.getElementsByClassName('table-layout')[0] as HTMLElement).style.height.slice(0, length-2));
   var tableBodyHeight=260;

    height = (height-148 )> tableBodyHeight ? tableBodyHeight : height-148;
    if(document.getElementsByClassName('datatable-body')[0]){
    (document.getElementsByClassName('datatable-body')[0] as HTMLElement).style.height = height + 'px';
    }
  }

  getMatMenuItemDisplayname(name) {
    switch (name) {
      case 'Sort Column':
        return this.getSortIconDisplayFlag[this.selectedCol] ? 'Disable Sort' : 'Sort Column';
      case 'Freeze Column':
        return this.getFrozenIconDisplayFalg(this.selectedCol) ? 'Unfreeze Column' : 'Freeze Column'
      default:
        return name;
    }
  }

  getFrozenIconDisplayFalg(colProp) {
    let freezeFlag = false;
    this.normalColumn.forEach(item => {
      if (item.prop === colProp && item.frozenLeft) {
        freezeFlag = true
      }
    })
    return freezeFlag;
  }

  handleMenuItemClick(type) {
    switch (type) {
      case 'resizeToFit':
        this.resizeToFit();
        return
      case 'freezeColumn':
        this.freezeColumn();
        return
      case 'sortColumn':
        this.sortColumn();
        return
      default:
        return;
    }
  }

  //todo...
  resizeToFit() {
    console.log(this.selectedCol);
    this.selectedCol = "";
  }

  freezeColumn() {
    this.normalColumn.forEach((item, i) => {
      if (item.prop == this.selectedCol) {
        item.frozenLeft = !item.frozenLeft;
      }
    });

  }

  syncColumnSettingForSortFlag(selectedCol) {
     this.normalColumn.forEach((item, i) => {
      if (item.prop === selectedCol ) {
        item.sortColumnAscOrDesc = this.ascFlag;
      } else {
        item.sortColumnAscOrDesc = '';
      }
    });
  }

  sortColumn() {
   this.syncColumnSettingForSortFlag(this.selectedCol);
    for (let key in this.getSortIconDisplayFlag) {
      if (key === this.selectedCol) {
        if (!this.getSortIconDisplayFlag[key]) {
          let data = {
            map: this.expandCollapseIconMap,
            prop: this.selectedCol,
            ascFlag: true
          };
          this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
        } else {
          // the default order is sorted by fundid.
          let data = {
            map: this.expandCollapseIconMap,
            prop: this.defaultSortCol,
            ascFlag: true
          };
          this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
        }
        this.getSortIconDisplayFlag[key] = !this.getSortIconDisplayFlag[key];
      } else {
        this.getSortIconDisplayFlag[key] = false;
      }
    }
    this.selectedCol = "";
  }

  changeAscAndDescSort(e, prop) {
    e.stopPropagation();
    if (this.ascFlag === "asc") {
      this.ascFlag = "desc";
      let data = {
        map: this.expandCollapseIconMap,
        prop: prop,
        ascFlag: false
      };
      this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
    } else if (this.ascFlag === "desc") {
      this.ascFlag = "asc";
      let data = {
        map: this.expandCollapseIconMap,
        prop: prop,
        ascFlag: true
      };
      this.shareInforBewteenComponents.sortDatatableColumn.emit(data);
    }
    this.syncColumnSettingForSortFlag(prop);
    this.selectedCol = "";
  }

  getSortIconDisplaySty(prop) {
    let visibility = false;
    this.normalColumn.forEach(item => {
      if (item.prop === prop && item.sortColumnAscOrDesc) visibility = true;
    })
    return visibility;
  }

  getSortIcon(prop) {
    let icon = '';
    this.normalColumn.forEach(item => {
      if (item.prop === prop)
      icon = item.sortColumnAscOrDesc
    })
    if (icon !== '') {
      return icon === "asc" ? "circle_arrow_up" : "circle_arrow_down";
    } else {
      return this.ascFlag === "asc" ? "circle_arrow_up" : "circle_arrow_down";
    }
  }

  removeOrAddColumn(col, index) {
    console.log(col.prop + "---" + index + "--" + this.selectedCol);
    this.selectedCol = "";
  }

  hyperLinkNavigate(row) {
    this.shareInforBewteenComponents.hyperLinkNavigate.emit(row);
  }

  openAlertModal(row, type) {
    let obj = {
      rowData: row,
      type: type
    };
    this.shareInforBewteenComponents.openModalData.emit(obj)
  }

  togglePauseFlag() {
    this.isDataTablePaused = !this.isDataTablePaused;
    this.togglePauseFlagEvent.emit();
  }

}
