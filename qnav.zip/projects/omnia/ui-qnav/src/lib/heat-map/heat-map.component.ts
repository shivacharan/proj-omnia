import {
  Component,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  ChangeDetectionStrategy,
  ContentChild,
  TemplateRef
} from '@angular/core';

import { treemap, stratify } from 'd3-hierarchy';
import { calculateViewDimensions, ViewDimensions, BaseChartComponent, ColorHelper } from '@swimlane/ngx-charts';

@Component({
  selector: 'position-heat-map-chart',
  templateUrl: './heat-map.component.html',
  styleUrls: ['./heat-map.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeatMapComponent extends BaseChartComponent {

  @Input() syncResults;
  @Input() tooltipDisabled: boolean = false;
  @Input() valueFormatting: any;
  @Input() labelFormatting: any;
  @Input() gradient: boolean = false;
  @Input() height: number;
  @Input() width: number;
  @Input() scheme: any = {};
  @Input() margin: any[];
  @Input() animations: boolean = true;

  @Output() select = new EventEmitter();

  @ContentChild('tooltipTemplate') tooltipTemplate: TemplateRef<any>;

  dims: any;
  domain: any;
  transform: any;
  colors: ColorHelper;
  treemap: any;
  data: any;
  customColors: any;
  

  update(): void {
    super.update();

    this.dims = calculateViewDimensions({
      width: this.width,
      height: 260,
      margins: this.margin
    });
    this.height = 260;

    this.domain = this.getDomain();

    this.treemap = treemap<any>()
      .size([this.dims.width, this.dims.height]);

    const rootNode = {
      name: 'root',
      value: 0,
      isRoot: true
    };

    const root = stratify<any>()
      .id(d => {
        let label = d.name;

        if (label.constructor.name === 'Date') {
          label = label.toLocaleDateString();
        } else {
          label = label.toLocaleString();
        }
        return label;
      })
      .parentId(d => d.isRoot ? null : 'root')
      ([rootNode, ...this.syncResults])
      .sum(d => d.value);

    this.data = this.treemap(root);

    this.customColors = this.setCustomColors();

    this.setColors();

    this.transform = `translate(${ this.dims.xOffset } , ${ this.margin[0] })`;
  }

  setCustomColors(): any[] {
    const arr = [];
    this.syncResults.forEach(item => {
      let color: string = '';
      if (item.navImpact <= -3) { // -3
        color = '#B91224';
      } else if (item.navImpact > -3 && item.navImpact <= -2) { // -2
        color = '#EAB7BD';
      } else if (item.navImpact > -2 && item.navImpact <= 0) { // -1
        color = '#F5DCDE';
      } else if (item.navImpact >= 0 && item.navImpact < 2) {// 1
        color = '#DFEAE2';
      } else if (item.navImpact >= 2 && item.navImpact < 3) {// 2
        color = '#BED5C5';
      } else if (item.navImpact >= 3) { //3
        color = '#28743E';
      } else {
        color = '';
      }
      let obj = {
        name: item.name,
        value: color
      }
      arr.push(obj);
    })
    return arr;
  }

  getDomain(): any[] {
    return this.syncResults.map(d => d.name);
  }

  onClick(data): void {
    this.select.emit(data);
  }

  setColors(): void {
    this.colors = new ColorHelper(this.scheme, 'ordinal', this.domain, this.customColors);
  }

}
