import { stratify } from 'd3-hierarchy';
import { columnMenuDropDownSetting } from './../qnav-position/column-data';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleLineChartComponent } from './single-line-chart.component';
import { Domain } from 'domain';
import { sortByDomain } from '@swimlane/ngx-charts/release/utils';
import { stringify } from '@angular/compiler/src/util';
import { getQueryValue } from '@angular/core/src/view/query';

describe('SingleLineChartComponent', () => {
  let component: SingleLineChartComponent;
  let fixture: ComponentFixture<SingleLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleLineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
