import {
  ElementRef, NgZone, ChangeDetectorRef,
  Component,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  HostListener,
  ChangeDetectionStrategy,
  ContentChild,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';
import { formatNumber } from '@angular/common';
import { BaseWidgetComponent } from '@omnia/ui-common';
import { heatMapColorSetting, heatMapColorScheme } from '../colors';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import { NavService } from '../services/nav-service.service';
import { NavSocketService } from '../services/nav-socket.service';
import { CommonUtilsService } from '../services/common-utils.service';
import { Subscription } from 'rxjs';
import { ResourceManagerService } from '../services/resource-manager.service';

@Component({
  selector: 'lib-position-heat-map',
  templateUrl: './position-heat-map.component.html',
  styleUrls: ['./position-heat-map.component.scss']
})
export class PositionHeatMapComponent extends BaseWidgetComponent {

private subs: Subscription[];
syncResults: any[] = []; // it's results,  change name to syncResults
topFiveResults = [];
height: number = 260;
width: number;
margin = [20, 10, 10, 10];
isDataAvailable: boolean = false;
heatMapColorSetting: any[] = heatMapColorSetting;
dateNow = new Date();
colorScheme = heatMapColorScheme;
fundInfo: any = [];

  constructor(chartElement: ElementRef, 
                      zone: NgZone, 
                      cd: ChangeDetectorRef,
                      private navSocketService: NavSocketService,
                      private shareInfoBeweenComponentsService: ShareInfoBeweenComponentsService,
                      private commonUtils: CommonUtilsService,
                      private navService: NavService,
                      private resourceManger: ResourceManagerService) { 
    super();
    this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.7;
   }

  ngOnInit() {
    this.syncResults = [];
    this.topFiveResults = [];
    this.subs = [];
    this.isDataAvailable = false;

    this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
    if(this.fundInfo.length > 0) {
      this.renderPositionMap();
    }else{
      this.navService.fetchFundList();
      this.navService.getFundList().subscribe(
        data => {
          console.log("data");
           if(data.length>0) {
            console.log(data);
             const fundInfo = [];
            fundInfo.push(data[0].fundid);
            fundInfo.push(data[0].name);
            fundInfo.push(data[0].fundTicker)
            this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
            this.renderPositionMap();
          }

        });
    }
  }


  renderPositionMap(){
    this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
    if(this.fundInfo.length > 0) {
    this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(
      data => {
        this.isDataAvailable = true;
        this.syncResults = this.filterHoldingsToHeatMap(data['holdings']);
        this.topFiveResults = this.filterHoldingsToTopFive(data['holdings']);
      }
    ))
    this.subs.push(this.navSocketService.getNav().subscribe(
      data => {
        this.updateHeatMap(data.eventData);
      }));
    
     this.navSocketService.registerFunds([this.fundInfo[0]]);

     this.resourceManger.registInterval(() => { this.syncResults = [...this.syncResults]},400); // set interval time for 0.4 seconds temporarily

    }
  }

  filterHoldingsToHeatMap(data){
    const tempResults = [];
    data.forEach(item => {
      const obj = {
        "name": item.cusip,
        "value": Math.abs(item.navImpact),
        "navImpact": item.navImpact
      };
      tempResults.push(obj);
    })
    return tempResults;
  }

  filterHoldingsToTopFive(data) {
    const tempTopFive = [];
    data.sort((itema, itemb) => {
      return itemb.navImpact  - itema.navImpact;
      // return Math.abs(itemb.navImpact)  - Math.abs(itema.navImpact); TBC...  if we sort it using real value not absolute value, will make confusion between top five records and heat map chart.
    });
    data.forEach(item => {
      if (tempTopFive.length < 5) {
        let obj = {
          "name": item.cusip ? item.cusip : item.name,
          "value": formatNumber(item.navImpact, 'en-US', '1.5-5')
        }
        tempTopFive.push(obj);
      }
    })
    return tempTopFive;
  }

  updateHeatMap(data){
    if (data && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
      this.syncResults.forEach(item => {
        if (item.name === data.cusip) {
          item.value = Math.abs(data.navImpact);
          item.navImpact = data.navImpact
        }
      });
    }
  }

  resizingHeatMap(event) {
    this.width = event.target.innerWidth * 0.7;
  }

  // needs more analyze here
  heatMapValueFormatting(value) {
    // const formatValue =  formatNumber(value, 'en-US', '1.5-5');
    // return formatValue;
    return;
  }

  heatMapLabelFormatting(obj){
    const formatValue =  formatNumber(obj.value, 'en-US', '1.5-5');
    return `${obj.label}<br/><small>` + `${formatValue}</small>`;
    // return `${obj.label}<br/><small>Instrument Id Ref</small>`;
  }

   ngOnDestroy() {
    if (this.fundInfo.length > 0) {
      this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
      this.subs.forEach (sub => sub.unsubscribe());
    }
    this.resourceManger.cleanResources();
  }

}
