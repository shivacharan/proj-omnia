import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeatMapComponent } from '../heat-map/heat-map.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { PositionHeatMapComponent } from './position-heat-map.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { injectTemplateRef } from '@angular/core/src/render3';

describe('PositionHeatMapComponent', () => {
  let component: PositionHeatMapComponent;
  let fixture: ComponentFixture<PositionHeatMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeatMapComponent, PositionHeatMapComponent ],
      imports: [
        NgxChartsModule,
        HttpClientTestingModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PositionHeatMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
