import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'percentFormat'
})
export class PercentFormatPipe implements PipeTransform {

  transform(value: any): any {
    if (value != 0) {
      if (value.toString().indexOf('-') === 0) {
        return value;
      } else {
        return '+' + value;
      }
    } else {
      return "0.000%";
    }
  }

}
