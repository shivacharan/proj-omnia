import { Component, OnInit, Inject, EventEmitter } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { CommonUtilsService } from '../services/common-utils.service';
import _ from 'lodash';

@Component({
  selector: 'lib-add-fund-modal',
  templateUrl: './add-fund-modal.component.html',
  styleUrls: ['./add-fund-modal.component.css']
})
export class AddFundModalComponent implements OnInit {

  fundList: any[];
  selectedFundChange:  EventEmitter<any>;
  
   constructor(
     private commonUtils: CommonUtilsService,
    public dialogRef: MatDialogRef<AddFundModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.fundList = _.cloneDeep(data['fundList']);
      this.selectedFundChange = data.dataChange;
    }

    ngOnInit() {
  }

  handleSelectFund(fund) {
    const index = this.fundList.indexOf(fund);
    this.fundList[index]['checked'] = !this.fundList[index]['checked'];
  }

  handleClickSelectBtn() {
    const removeFundList = this.fundList.filter(item => item.checked === false);
    const addFundlist = this.fundList.filter(item => item.checked === true);
    removeFundList.forEach(item => {
       this.updateVariableFundList(item);
     });

     addFundlist.forEach(item => {
       this.updateVariableFundList(item);
     });

     this.selectedFundChange.emit(addFundlist);
     this.onNoClick();
  }

  updateVariableFundList(fund) {
    let index = -1;
    this.commonUtils.updateFundStatus(fund['fundID'],fund['checked']);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
