import {
  Component,
  ViewChild,
  ViewEncapsulation,
  ChangeDetectorRef,
  ViewContainerRef,
  HostListener
} from '@angular/core';
import { BaseWidgetComponent, AppContext, AppRegistry } from '@omnia/ui-common';
import { NavService } from '../services/nav-service.service';
import { NavSocketService } from '../services/nav-socket.service';
import { CommonUtilsService } from '../services/common-utils.service';
import { MatDialog } from '@angular/material';
import { CustomAlertModalComponent } from '../custom-alert-modal/custom-alert-modal.component';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import { Subscription } from 'rxjs';
import { ResourceManagerService } from '../services/resource-manager.service';
import { customColumn, normalColumn, columnMenuDropDownSetting } from './column-data';

@Component({
  selector: 'lib-main-datatable',
  templateUrl: './main-datatable.component.html',
  styleUrls: ['../common-style/datatable-common.css', './main-datatable.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MainDatatableComponent extends BaseWidgetComponent {

  private subs: Subscription[];
  rows: any[] = [];
  childRows: any[] = [];
  isDataAvailable: boolean = false;
  isDataTablePaused: boolean = false;
  rowHeight:number=50;
  alertData: any[] = [];
  allRowsSelected: boolean = false;
  isSelectedMap: any[] = [];
  headerSetting: boolean = true;
  headerHeight: number = 50;
  // temp data structure
  customColumn: any[] = customColumn;
  normalColumn: any[] = normalColumn;
  columnMenuDropDownSetting: any[] = columnMenuDropDownSetting;
  limit: number = 5;
  footerHeight: number = 50;
  headerCheckBox: boolean = true;

  private interval: any;

  constructor(private cd: ChangeDetectorRef, private navService: NavService,
    private appRegistry: AppRegistry, private appContext: AppContext,
    private navSocketService: NavSocketService,
    private dialog: MatDialog,
    private viewContainer: ViewContainerRef,
    private shareInforBewteenComponents: ShareInfoBeweenComponentsService,
    public commonUtils: CommonUtilsService,
    private resourceManger: ResourceManagerService) {
    super();
  }

  ngOnInit() {
    //reset component data and user validation;
    this.commonUtils.validateUser();
    this.subs = [];
    this.rows = [];
    this.isDataAvailable = false;
    this.subs.push(this.navService.getFundList().subscribe(
      data => {
        this.rows = this.commonUtils.extractFundLevelData(data);
        this.childRows = this.commonUtils.extractClassLevelData(data);
        if (data.length > 0) {
          //this.alertData = [...this.updateAlertData(this.rows)];
          this.alertData = [...this.updateAlertDataAtClassLevel(data)];
          this.isDataAvailable = true;
          // seting position page default fund info if fundInfo is null
          if (this.shareInforBewteenComponents.fundInfo.length === 0) {
            const fundInfo = [];
            fundInfo.push(data[0].fundid);
            fundInfo.push(data[0].name);
            fundInfo.push(data[0].fundTicker)
            this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
          }
        }
        this.rows = [...this.rows];
        this.rows.forEach(row => {
          this.navSocketService.registerFunds([row['fundid']]);
        })
      }
    ));
    this.subs.push(this.navSocketService.getNav().subscribe(
      (data) => {
        if (data['eventType'] === 'fundChange') {
          const fundLevelRow = this.commonUtils.extractWSData(data["eventData"], false);
          const childLevelRow = this.commonUtils.extractWSData(data["eventData"], true);
          this.updateRow(fundLevelRow);
          childLevelRow.forEach(row => this.updateRow(row));
        } else if (data['eventType'] === 'sodChange') {
          this.doupdate(data["eventData"]);
        }
      }
    ));
    this.resourceManger.registInterval(() => { this.rows = [...this.rows]; }, 300);

    this.shareInforBewteenComponents.hyperLinkNavigate.subscribe(data => {
      console.log("hyperlink navigate");
      console.log(data);
      this.hyperLinkNavigateTo(data);
    });

    this.shareInforBewteenComponents.openModalData.subscribe(data => {
      this.openAlertModal(data.rowData, data.type);
    });

    this.shareInforBewteenComponents.sortDatatableColumn.subscribe(data => {
      this.rows = [...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)];
    })
  }

  ngOnDestroy() {
    this.rows.forEach(row => {
      this.navSocketService.unRegisterFunds([row['fundid']]);
    })
    this.subs.forEach(sub => sub.unsubscribe());
    this.resourceManger.cleanResources();

  }

  updateRow(data) {
    if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
      if (data['alertType'] && (data['alertType'] == 1 || data['alertType'] === 2)) {
        const alertObj = {
          "name": data['fundid'],
          "classID":data['classID'],
          "alertType": data['alertType'],
          "nav": data['nav'],
          "marketval": data['fundmv'],
          "value": data['navChangePercent'],
          "fundmvChangePercent": data['fundmvChangePercent'],
          "pricetime": data['pricetime'],
        }
        this.alertData.push(alertObj);
        this.alertData = [...this.alertData];
      }
      this.doupdate(data);
    }
  }

  doupdate(data) {
    if (this.rows.length) {
      const fundId = data['fundid'];
      const fundTicker = data['fundTicker'];
      const classID = data['classID'];
      this.rows.forEach(item => {
        if (item['fundid'] === fundId && item['fundTicker'] === fundTicker && item['classID'] === classID) {
          this.normalColumn.forEach(colItem => { if (null != data[colItem.prop] && (['fundid', 'name', 'fundTicker', 'classID'].indexOf(colItem.prop) === -1)) { item[colItem.prop] = data[colItem.prop] } });
          const counts = this.getAlertCounts(fundId, classID, this.alertData);
          item['redAlert'] = counts[0];
          item['yellowAlert'] = counts[1];
        }
      });
    }
  }

  private getAlertCounts(fundid: string, classID: string ,alerts: any[]): any[] {
    let counts = [0, 0];
    alerts.forEach(alert => {
      if (alert['name'] === fundid && alert['classID'] === classID) {
        if (alert['alertType'] === 2) {
          counts[0] += 1;
        } if (alert['alertType'] === 1) {
          counts[1] += 1;
        }
      }
    });
    //console.log("alert counts for fund :"+fundid+" class:"+classID+" counts for type 1:"+counts[0] +" counts for type 1:"+counts[1]);
    return counts;
  }
  
   updateAlertDataAtClassLevel(data) : any[] {
    let alertAry = [];
    const fundLevelData = (data as any[]).map(d => {
      for(let key in d.classLevelTrialData) {
        alertAry = alertAry.concat(this.filterAlertDataByClass(d.fundid, key ,d.classLevelTrialData[key].priceChanges));
      }
      
    });

    return alertAry;
  }
  // colllects the alert data from getFundList call
  updateAlertData(data): any[] {
    let alertAry = [];
    data.forEach(item => {
      alertAry = alertAry.concat(this.filterAlertData(item['fundid'], item['priceChanges']));
    });
    return alertAry;
  }

  filterAlertDataByClass(fundID, classID, data) {
    const tempAlertCricleData = [];
    data.forEach(item => {
      if (this.commonUtils.isValidTime(new Date(item['pricetime'])) 
        && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
        const alertObj = {
          "name": fundID,
          "classID": classID, 
          "alertType": item['alertType'],
          "nav": item['nav'],
          "marketval": item['fundmv'],
          "value": item['navChangePercent'],
          "fundmvChangePercent": item['fundmvChangePercent'],
          "pricetime": item['pricetime'],
        }
        tempAlertCricleData.push(alertObj);
      }
    })
    return tempAlertCricleData;
  }

  filterAlertData(fundID, data) {
    const tempAlertCricleData = [];
    data.forEach(item => {
      if (this.commonUtils.isValidTime(new Date(item['pricetime'])) && item['alertType'] && (item['alertType'] == 1 || item['alertType'] === 2)) {
        const alertObj = {
          "name": fundID,
          "alertType": item['alertType'],
          "nav": item['nav'],
          "marketval": item['fundmv'],
          "value": item['navChangePercent'],
          "fundmvChangePercent": item['fundmvChangePercent'],
          "pricetime": item['pricetime'],
        }
        tempAlertCricleData.push(alertObj);
      }
    })
    return tempAlertCricleData;
  }

  openAlertModal(row, type) {
    const dialogRef = this.dialog.open(CustomAlertModalComponent, {
      width: '680px',
      data: {
        "type": type === 'yellowAlert' ? '' : 'Critical',
        "now": new Date() > this.commonUtils.endTime ? this.commonUtils.endTime : new Date(),
        "title": row['name']+" class-" +row['classID'],
        "fundId": row['fundid'],
        "alertData": this.getAlertDataForFundByClass(row['fundid'], row['classID'], type === 'yellowAlert' ? 1 : 2)
      }
    });
//    console.log("length fund:"+row+"class: alerttype:");  
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  getAlertDataForFundByClass(fundId, classID, alertType) {
    const alertDataForFund: any[] = [];
    this.alertData.forEach(item => {
      if (item['name'] === fundId 
            && item['classID'] === classID
            && item['alertType'] === alertType) {
        alertDataForFund.push(item);
      }
    })
    console.log("Fund:"+fundId+",class:"+classID+",count:"+alertDataForFund.length);
    return alertDataForFund.reverse();
  }

  getAlertDataForFund(fundId, alertType) {
    const alertDataForFund: any[] = [];
    this.alertData.forEach(item => {
      if (item['name'] === fundId && item['alertType'] === alertType) {
        alertDataForFund.push(item);
      }
    })
    return alertDataForFund.reverse();
  }

  hyperLinkNavigateTo(row) {
    const fundInfo = [];
    const fundID = row['fundid'];
    fundInfo.push(fundID);
    const fundName = row['name'];
    fundInfo.push(fundName);
    fundInfo.push(row['fundTicker']);
    this.nagativateToPosition(fundInfo);
  }

  nagativateToPosition(fundInfo): void {
    this.shareInforBewteenComponents.savePositionDetailsFundInfo(fundInfo);
    this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-002');
  }

  getAllRowsDisabled() {
    const list = this.shareInforBewteenComponents.getFundList();
    let disableAll = true;
    list.forEach(item => {
      if (item.checked) disableAll = false;
    })
    return disableAll;
  }

  getSingleRowDisabled(row) {
    const list = this.shareInforBewteenComponents.getFundList();
    let disableSingleRow = true;
    list.forEach(item => {
      if (item.checked && item.fundID === row['fundid'] && row.child === "parent") disableSingleRow = false;
    })
    return disableSingleRow;
  }

  getAllRowChecked(rows): boolean {
    const list = this.shareInforBewteenComponents.getFundList().filter(item => item.checked);
    let tempFlag = true;
    let noFundShowInChart = list.length === 0 ? true : false;

    if (list.length > this.isSelectedMap.length) {
      tempFlag = false;
    } else {
      list.forEach(item => {
        this.isSelectedMap.forEach(s => {
          if (item.fundTicker === s.name && !s.checked) {
            tempFlag = false
          }
        })
        if (this.isSelectedMap.length === 0) tempFlag = false;
      });
    }

    this.allRowsSelected = noFundShowInChart ? !noFundShowInChart : tempFlag;
    return this.allRowsSelected;
  }

  getSingleRowChecked(fund) {
    let isChecked = false;
    this.isSelectedMap.forEach(item => {
      if (item.name === fund) {
        isChecked = this.shareInforBewteenComponents.getFundList().find(list => (list.fundTicker === fund && list.checked)) ? item.checked : false;
        item.checked = this.shareInforBewteenComponents.getFundList().find(list => (list.fundTicker === fund && list.checked)) ? item.checked : false;
      }
    })
    return isChecked;
  }

  onSelectAll(checked, rows) {
    this.allRowsSelected = checked;
    rows.forEach(item => {
      let obj = {
        name: item.fundTicker,
        checked: this.shareInforBewteenComponents.getFundList().find(list => (list.fundID === item.fundid && list.checked)) ? checked : false
      }
      if (!this.isSelectedMap.find(s => s.name === item.fundTicker)) {
        this.isSelectedMap.push(obj)
      } else {
        const i = this.isSelectedMap.findIndex(s => s.name === item.fundTicker);
        this.isSelectedMap[i]['checked'] = this.shareInforBewteenComponents.getFundList().find(list => (list.fundID === item.fundid && list.checked)) ? checked : false;
      }
    })

    // this.setHighLightActiveEntries(this.isSelectedMap);
    const activeEntries = [];
    this.isSelectedMap.forEach(item => {
      if (item.checked) {
        activeEntries.push({ name: item.name });
      }
    })
    this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
  }

  onCheckboxChange(fund) {
    if (this.isSelectedMap.length > 0 && this.isSelectedMap.find(s => s.name === fund)) {
      const i = this.isSelectedMap.findIndex(s => s.name === fund);
      this.isSelectedMap[i]['checked'] = !this.isSelectedMap[i]['checked'];
      if (this.isSelectedMap[i]['checked']) {
        this.allRowsSelected = false;
      }
    } else {
      let obj = {
        name: fund,
        checked: true
      }
      this.isSelectedMap.push(obj)
    }

    // this.setHighLightActiveEntries(this.isSelectedMap);
    const activeEntries = [];
    this.isSelectedMap.forEach(item => {
      if (item.checked) {
        activeEntries.push({ name: item.name });
      }
    })
    this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
  }

  setHighLightActiveEntries(selectedMap) {
    const activeEntries = [];
    selectedMap.forEach(item => {
      if (item.checked) {
        activeEntries.push({ name: item.name });
      }
    })
    this.shareInforBewteenComponents.highLightActiveEntries.emit(activeEntries);
  }

  onClickedOutside(e: Event) {
    this.shareInforBewteenComponents.clickedOutSide.emit(e);
  }

  togglePauseFlag() {
    this.isDataTablePaused = !this.isDataTablePaused;
  }

}
