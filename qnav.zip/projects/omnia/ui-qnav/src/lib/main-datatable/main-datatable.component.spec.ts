import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MainDatatableComponent } from './main-datatable.component';
import { CommonDataTableComponent } from '../common-data-table/common-data-table.component';
import { MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DynamicModule } from 'ng-dynamic-component';
import { NumberRoundUpPipe } from '../pipe/number-roundup.pipe';
import { PercentFormatPipe } from '../pipe/percent-format.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {  AppRegistry } from '@omnia/ui-common';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';


describe('MainDatatableComponent', () => {
  let component: MainDatatableComponent;
  let fixture: ComponentFixture<MainDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [   MainDatatableComponent, CommonDataTableComponent, NumberRoundUpPipe, PercentFormatPipe ],
      imports: [
        HttpClientTestingModule,
        MatDialogModule,
        NgxDatatableModule,
        DynamicModule ,
        MatMenuModule , MatIconModule, MatButtonModule , MatCheckboxModule],
      providers: [NumberRoundUpPipe, PercentFormatPipe, AppRegistry ,
        {
          provide: MatDialogRef,
          useValue: {}
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {}
        } ]
      })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
