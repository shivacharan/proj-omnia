import { Component, OnInit, ViewChild, ViewEncapsulation, } from '@angular/core';
import { BaseWidgetComponent, AppContext, AppRegistry } from '@omnia/ui-common';
import { NavService } from '../services/nav-service.service';
import { NavSocketService } from '../services/nav-socket.service';
import { CommonUtilsService } from '../services/common-utils.service';
import { NavEvent } from '../model/qnav';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import { Subscription } from 'rxjs';
import { ResourceManagerService } from '../services/resource-manager.service';
import {customColumn, normalColumn, columnMenuDropDownSetting} from './column-data';

@Component({
  selector: 'lib-qnav-position',
  templateUrl: './qnav-position.component.html',
  styleUrls: ['../common-style/datatable-common.css', './qnav-position.component.scss'],
  //encapsulation: ViewEncapsulation.ShadowDom
})
export class QnavPositionComponent extends BaseWidgetComponent {

  private subs: Subscription[];
  rows: any[] = [];
  childRows: any[] = [];
  isDataAvailable: boolean = false;
  rowHeight:number=50;
  alertData: any[] = [];
  allRowsSelected: boolean = false;
  isSelectedMap: any[] = [];
  headerSetting: boolean = true;
  headerHeight: number = 50;
  // temp data structure
  isDataTablePaused:boolean = false;
  customColumn: any[] = customColumn;
  normalColumn: any[] = normalColumn;
  columnMenuDropDownSetting: any[] = columnMenuDropDownSetting;
  limit: number = 5;
  footerHeight: number = 50;
  headerCheckBox: boolean = false;
  fundInfo: any = [];
  constructor(private navService: NavService,  
                      // private appRegistry: AppRegistry, 
                      private appContext: AppContext, 
                      private navSocketService: NavSocketService,
                      private shareInfoBeweenComponentsService: ShareInfoBeweenComponentsService,
                      private commonUtils: CommonUtilsService,
                      private resourceManger: ResourceManagerService) { 
    super();
  }

  ngOnInit() {
    //reset component data and user validation;
    this.commonUtils.validateUser();
    this.rows = [];
    this.subs = [];
    this.isDataAvailable = false;

    this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
    if (this.fundInfo.length > 0) {
     this.renderPositionDetails();
    }
    else{
      //this.navService.fetchFundList();
      this.navService.getFundList().subscribe(
        data => {
           if(data.length > 0) {
        
            const fundInfo = [];
            fundInfo.push(data[0].fundid);
            fundInfo.push(data[0].name);
            fundInfo.push(data[0].fundTicker)
            this.shareInfoBeweenComponentsService.savePositionDetailsFundInfo(fundInfo);
            this.renderPositionDetails();
          }

        });
    }
    this.shareInfoBeweenComponentsService.sortDatatableColumn.subscribe(data => {
      console.log([...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)]);
      this.rows = [...this.commonUtils.sortColumnByProp(this.rows, this.childRows, data.map, data.prop, data.ascFlag)];
    });
  }



  renderPositionDetails(){
    this.fundInfo = this.shareInfoBeweenComponentsService.fundInfo;
    if (this.fundInfo.length > 0) {
      this.subs.push(this.navService.getPositionDetails(this.fundInfo[0]).subscribe(
        data => {
          this.isDataAvailable = true;
          this.rows = data["holdings"];
          this.rows = [...this.rows];
        }
      ));

      this.subs.push(this.navSocketService.getNav().subscribe(
        (data) => {
          if (data['eventType'] === 'fundChange') {
            const fundLevelRow = this.commonUtils.extractWSData(data["eventData"], false);
            this.updateRow(fundLevelRow)
          } else {
            this.updateRow(data)
          }
        }
      )
      );

      this.navSocketService.registerFunds([this.fundInfo[0]]);

    this.resourceManger.registInterval(() => { this.rows = [...this.rows]; },300);
    }
  }


  ngOnDestroy() {
    if (this.fundInfo.length > 0) {
      this.navSocketService.unRegisterFunds([this.fundInfo[0]]);
      this.subs.forEach (sub => sub.unsubscribe());
    }
    this.resourceManger.cleanResources();
  }

  updateRow(data) {
    if (data && !this.isDataTablePaused && this.commonUtils.isValidTime(new Date(data['pricetime']))) {
      if (this.rows.length && data) {
        const fundid = data['fundid'];
        const cusip = data['cusip'];
        const longShortIndicator = data['longShortIndicator'];
        this.rows.forEach(item => {
          if (this.fundInfo[0] === fundid && item['cusip'] === cusip && item['longShortIndicator'] === longShortIndicator) {
            this.normalColumn.forEach(colItem => { if (null != data[colItem.prop]) {item[colItem.prop] = data[colItem.prop] }});
          }
        });
      }
    }
    if(data && data['eventType'] === 'sodChange') {
      this.navService.getPositionDetails(this.fundInfo[0]).subscribe(
        data => {
           this.rows = data["holdings"];
           this.rows = [...this.rows];
         }
      )
    }
  }

  // returnBack(): any {
  //   this.appContext.currentDashboard = this.appRegistry.getDashboard('QNAV-001');
  // }
  togglePauseFlag() {
    this.isDataTablePaused = !this.isDataTablePaused;
  }
}
