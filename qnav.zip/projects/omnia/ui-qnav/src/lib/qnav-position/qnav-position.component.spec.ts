import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QnavPositionComponent } from './qnav-position.component';

describe('QnavPositionComponent', () => {
  let component: QnavPositionComponent;
  let fixture: ComponentFixture<QnavPositionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QnavPositionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnavPositionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
