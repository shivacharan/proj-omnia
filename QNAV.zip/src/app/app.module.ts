import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {UiCommonModule} from "@omnia/ui-common";
import {UiQNavModule} from "../../projects/omnia/ui-qnav/src/lib/ui-qnav.module";
import {HttpClientInMemoryWebApiModule} from 'angular-in-memory-web-api';
import {InMemoryDataService} from './in-memory-db/in-memory-data.service';

import {environment} from '../environments/environment';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    UiCommonModule,
    UiQNavModule,
    environment.production ?
    [] : HttpClientInMemoryWebApiModule.forRoot(InMemoryDataService, {delay: 1000, passThruUnknownUrl: true})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
