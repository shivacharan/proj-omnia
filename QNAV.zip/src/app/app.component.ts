import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {AppContext, AppRegistry} from '@omnia/ui-common';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
    context = this.appContext;

    constructor(private appRegistry: AppRegistry,
                private appContext: AppContext,
                private matIconRegistry: MatIconRegistry,
                private domSanitizer: DomSanitizer) {

        this.matIconRegistry.addSvgIcon(
            `circle_close`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Circle Close.svg')
        );
         this.matIconRegistry.addSvgIcon(
            `globe`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Globe.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `home`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Home.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `flag`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Flag.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `circle_plus`,
           this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Circle Plus.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `close`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Close.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `search`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Search.svg')
        );
         this.matIconRegistry.addSvgIcon(
            `arrow_right`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Arrow Right.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `arrow_down`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Arrow Down.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `trianglealert`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_TriangleAlert.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `circle_alert`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Circle Alert.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `more`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_More.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `check`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Check.svg')
        );
         this.matIconRegistry.addSvgIcon(
            `circle_arrow_up`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Circle Arrow Up.svg')
        );
        this.matIconRegistry.addSvgIcon(
            `circle_arrow_down`,
            this.domSanitizer.bypassSecurityTrustResourceUrl('../assets/icons/Icons 64x64_Updated_Circle Arrow Down.svg')
        );
    }

    ngOnInit(): void {
        this.appContext.userGroups = ['Application/navdeveloper'];
        const dashboard = this.appRegistry.getDashboard("QNAV-001");
        this.appContext.currentDashboard = dashboard;
        sessionStorage.setItem('access_token',JSON.stringify({user_token:'eyJ4NXQiOiJaR015WmpSbE0yVTJPV05qTVRFeE1tVTNaR1JtTnprNU5qTmhaVEJoTW1ObFltRTBZVFpoTnciLCJraWQiOiJaR015WmpSbE0yVTJPV05qTVRFeE1tVTNaR1JtTnprNU5qTmhaVEJoTW1ObFltRTBZVFpoTnciLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJuYXZkZXZlbG9wZXIwQGNhcmJvbi5zdXBlciIsImF1ZCI6ImdZSzViSjJXeTVndk1aOW5RbGZIdU5PUWZCOGEiLCJhenAiOiJnWUs1YkoyV3k1Z3ZNWjluUWxmSHVOT1FmQjhhIiwic2NvcGUiOiJvcGVuaWQiLCJpc3MiOiJodHRwczpcL1wvd3NvMmlzOjk0NDNcL29hdXRoMlwvdG9rZW4iLCJncm91cHMiOlsiSW50ZXJuYWxcL2V2ZXJ5b25lIiwiQXBwbGljYXRpb25cL25hdmRldmVsb3BlciJdLCJleHAiOjE1NDM1Mjk4MjIsImlhdCI6MTU0MzUyNjIyMiwianRpIjoiZWJlNTBkOTctMTAxMy00ZDMyLTkwNjUtZmE1YzZhZDlhNTVmIn0.QZLkyVgThYxXEqa4qR2qUdgg8pi0W1w8GzTtSahDi69uOGzkKnutvASEk69wzOdRe8x0vJmbSguCFhGt6yPkyPBKJjTUdG_763tGiENQmzPsbvphmamEseUSTL_RGgqdlz3OkaYbaU7sYyUfVW8zSG3oq3A6XB7dAoBAcRnXFpIw37UVXUxLYY5NJhR6CzPZrl7oUx3FF_-T18IiPBmAfhxqY1B3ebTohT8P7jP8zi6Q6ztCRJpQI6mAbptMTKj_4NeMlI2hYbbxa3Wok5an9IE_VzUfhDzu2H8HUjVIp0l1KDmJJgM0OWWXdcoLJvP3VhC7thJaNNK0ap-YI99a9g'}));
    }
}
