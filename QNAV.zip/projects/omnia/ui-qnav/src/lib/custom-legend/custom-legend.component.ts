import { Component, OnInit,  Input } from '@angular/core';
import { CommonUtilsService } from '../services/common-utils.service';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';

@Component({
  selector: 'app-custom-legend',
  templateUrl: './custom-legend.component.html',
  styleUrls: ['./custom-legend.component.scss']
})
export class CustomLegendComponent implements OnInit {
  @Input() results;
  @Input() selectable;
  @Input() removable;
  @Input() colorDomain;
  @Input() index;
  @Input() selectedFundChange

  constructor(    private shareInforBewteenComponents : ShareInfoBeweenComponentsService,  
     private commonUtils : CommonUtilsService) { 
     }

  ngOnInit() {
    
  }

  ngOnDestroy() {
  }

  getShowLegendAndConsistent(fund) {
    
    if (fund.name === "") {
      return false
    } else {
      const list = this.shareInforBewteenComponents.getFundList();
      let show = false;
      list.forEach(item => {
        if (item.fundID === fund.name && item.checked) {
          show = true;
        }
      })
      return show
    }
  }
  getFundRelatedColor(fund) {
    let colorStr = '';
    this.colorDomain.forEach(item => {
      if (item['fundid'] === fund['name']) {
        colorStr = item['color'];
      }
    })
    return colorStr;
  }
  

  remove(fund): void {
    this.commonUtils.updateFundStatus(fund['fundID'], false);
    let fundIndex = -1;
    this.results.forEach((item, index) => {
      if (item['name'] === fund['name']) {
        fundIndex = index;
      }
    });

    if (fundIndex >= 0) {
      this.results.splice(fundIndex, 1);
    }

    this.selectedFundChange.emit(fund);
  }

}
