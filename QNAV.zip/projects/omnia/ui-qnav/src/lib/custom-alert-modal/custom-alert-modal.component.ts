import { Component, OnInit, Inject, EventEmitter } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { CommonUtilsService } from '../services/common-utils.service';

@Component({
  selector: 'lib-custom-alert-modal',
  templateUrl: './custom-alert-modal.component.html',
  styleUrls: ['./custom-alert-modal.component.css']
})

export class CustomAlertModalComponent implements OnInit {
  alertData : any[] = [];

  constructor(
     private commonUtils: CommonUtilsService,
    public dialogRef: MatDialogRef<CustomAlertModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any)  {
    this.alertData = data['alertData'];    
  }

  ngOnInit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
