import { NgModule , InjectionToken} from '@angular/core';
import { AppRegistry, AppContext, UiCommonModule } from '@omnia/ui-common';
import { DynamicModule } from 'ng-dynamic-component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { LineChartComponent } from './line-chart/line-chart.component';
import { CustomLegendComponent } from './custom-legend/custom-legend.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
//import { environment } from '../../../../../src/environments/environment'
// import { QnavLineChartComponent } from './qnav-line-chart/qnav-line-chart.component';
import { QnavPositionComponent } from './qnav-position/qnav-position.component';
import { QnavLineChartComponent } from './qnav-line-chart-old/qnav-line-chart.component';
import { PercentFormatPipe } from './pipe/percent-format.pipe';
import { NumberRoundUpPipe } from './pipe/number-roundup.pipe';
import { CustomAlertModalComponent } from './custom-alert-modal/custom-alert-modal.component';
import { ResourceManagerService } from './services/resource-manager.service';
import { ClickOutsideModule } from 'ng-click-outside';
import { AddFundModalComponent } from './add-fund-modal/add-fund-modal.component';
import { MatDialogModule } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { PositionHeatMapComponent } from './position-heat-map/position-heat-map.component';
import { HeatMapComponent } from './heat-map/heat-map.component';
import { PositionFundSummaryComponent } from './position-fund-summary/position-fund-summary.component';
import { SingleLineChartComponent } from './single-line-chart/single-line-chart.component';
import { CommonDataTableComponent } from './common-data-table/common-data-table.component';
import { MainDatatableComponent } from './main-datatable/main-datatable.component';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    MatButtonModule,
    MatCheckboxModule,
    UiCommonModule,
    DynamicModule.withComponents([
      QnavLineChartComponent, 
      MainDatatableComponent,
      QnavPositionComponent,
      PositionHeatMapComponent,
      PositionFundSummaryComponent
      ]),
    NgxDatatableModule,
    NgxChartsModule,
    MatChipsModule,
    MatIconModule,
    HttpClientModule,
    MatDialogModule,
    MatMenuModule,
    ClickOutsideModule
  ],
  declarations: [
    QnavLineChartComponent,
    LineChartComponent,
    CustomLegendComponent,
    QnavPositionComponent,
    PercentFormatPipe,
    NumberRoundUpPipe,
    CustomAlertModalComponent,
    AddFundModalComponent,
    PositionHeatMapComponent,
    HeatMapComponent,
    PositionFundSummaryComponent,
    SingleLineChartComponent,
    CommonDataTableComponent,
    MainDatatableComponent
  ],
  providers:[DatePipe, AppRegistry],
  exports: [
    QnavLineChartComponent, 
    QnavPositionComponent, 
    PositionHeatMapComponent,
    PositionFundSummaryComponent,
    MainDatatableComponent
  ],
  entryComponents: [
    QnavLineChartComponent, 
    QnavPositionComponent,
    CustomAlertModalComponent,
    AddFundModalComponent,
    PositionHeatMapComponent,
    PositionFundSummaryComponent,
    MainDatatableComponent
    ]
})
export class UiQNavModule {
  static forRoot(environment: any) {
    return {
      ngModule : UiQNavModule,
      providers:[
        {
          provide: 'env',
          useValue: environment
        }
      ]
    }
  }
  permissions: string[] = ['Application/navdeveloper','Application/navanalyst'];
  constructor(
    private appRegistry: AppRegistry
  ) {

    appRegistry.registerComponent('lineChart', QnavLineChartComponent);
    appRegistry.registerComponent('liveDataTable', MainDatatableComponent);
    appRegistry.registerComponent('livePosition', QnavPositionComponent);
    appRegistry.registerComponent('positionHeatMap', PositionHeatMapComponent);
    appRegistry.registerComponent('positionFundSummary', PositionFundSummaryComponent);

    const now = new Date();
 

    appRegistry.registerDashboard('QNAV-001', 'QNAV Entity List',
      [
        { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'lineChart', title: null, showHeader: true },
        { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'liveDataTable', title: null, showHeader: true }
      ], true, true, 'qnf','QNAV', this.permissions
    )

    appRegistry.registerDashboard('QNAV-002', 'QNAV Position',
      [
        { x: 0, y: 0, rows: 1, cols: 1, config: {}, comp: 'positionHeatMap', title: null, showHeader: true },
        // { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'positionFundSummary', title: null, showHeader: true },
        { x: 0, y: 1, rows: 1, cols: 1, config: {}, comp: 'livePosition', title: null, showHeader: true }
      ], true, true, 'qnp','QNAV',this.permissions
    )

  }

}
