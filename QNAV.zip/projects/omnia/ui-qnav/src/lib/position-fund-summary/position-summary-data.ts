export const singleLineTicksValue = [
    new Date().setHours(9, 30, 0), 
    new Date().setHours(12, 0, 0),
    new Date().setHours(14, 0, 0),
    new Date().setHours(16, 0, 0)
    ];
    