import {
  ElementRef, NgZone, ChangeDetectorRef,
  Component,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  HostListener,
  ChangeDetectionStrategy,
  ContentChild,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';
import { BaseWidgetComponent } from '@omnia/ui-common';
import { formatDate } from '@angular/common';
import { singleLineTicksValue } from './position-summary-data';
import { CommonUtilsService } from '../services/common-utils.service';
import { NavService } from '../services/nav-service.service';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';

@Component({
  selector: 'lib-position-fund-summary',
  templateUrl: './position-fund-summary.component.html',
  styleUrls: ['./position-fund-summary.component.scss']
})
export class PositionFundSummaryComponent extends BaseWidgetComponent {

  dateNow = new Date();
  // temp mock data
  summaryAssetsValue = [
    {
      title: 'Total Net Assets: USD',
      value: 5000000
    },
    {
      title: 'Market Value: USD',
      value: 4400000
    }
  ];
  threeDayTrendData: any[] = [
    {
      day: new Date(),
      details: [
        {
          title: 'NAV Price',
          value: 9.91
        },
        {
          title: 'Market Value',
          value: '4.3M'
        },
        {
          title: 'NAV Change',
          value: '-2.05%'
        }
      ],
      color: ''
    },
    {
      day: new Date(),
      details: [
        {
          title: 'NAV Price',
          value: 10.11
        },
        {
          title: 'Market Value',
          value: '4.25M'
        },
        {
          title: 'NAV Change',
          value: '-1.19%'
        }
      ],
      color: '#DFEAE2'
    },
    {
      day: new Date(),
      details: [
        {
          title: 'NAV Price',
          value: 10.23
        },
        {
          title: 'Market Value',
          value: '4.05M'
        },
        {
          title: 'NAV Change',
          value: '1.81%'
        }
      ],
      color: '#BED5C5'
    }
  ];
  results: any[] = [];
  height: number = 240;
  width: number;
  margin: any[] = [20, 100, 30, 50];
  colorDomain: any[] = [];
  tickValues: any[] = singleLineTicksValue;
  xScaleMin: any;
  xScaleMax: any;

  constructor(
    chartElement: ElementRef, zone: NgZone, 
    cd: ChangeDetectorRef,
     public commonUtils: CommonUtilsService,
     private navService: NavService,
     private shareInforBewteenComponents : ShareInfoBeweenComponentsService,) { 
    super();
    this.width = document.getElementsByClassName('main')[0].getBoundingClientRect().width * 0.55;
    this.xScaleMin = commonUtils.startTime;
    this.xScaleMax = commonUtils.endTime;
  }

  ngOnInit() {
    this.navService.getFundList().subscribe(data => {
      if (data.length > 0) {
        this.results = [...this.filterFundData(data)]
      }
    });

    this.colorDomain = this.setColorForSelectedFund();
  }

  setColorForSelectedFund() {
    // need enhancemen here: if the line color should be as same as previous live-line-chart? Temporarily set the color #28743E.
    const color = [];
    const selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
    const obj = {
      fundTicker: selectedFundTicker,
      color: "#28743E"
    }
    color.push(obj);
    return color;
  }

// below function is duplicated with qnav-line-chart needs extract to a common class.
  filterFundData(data: any[]): any[] {
    const results: any[] = [];
    const selectedFundTicker = this.shareInforBewteenComponents.fundInfo[2];
    data.forEach(item => {
      if (item['fundTicker'] === selectedFundTicker) {
        const obj = {
          'name': item['fundTicker'],
          'fundID': item['fundid'],
          'series': this.createSeries(item)
        }
        results.push(obj);
      }
    })
    return results;
  }

  createSeries(data: any): any[] {
    const series: any[] = [];
    data['priceChanges'].forEach(item => {
      if (this.commonUtils.isValidTime(new Date(item['pricetime']))) {
        const obj = {
          'marketval': item['fundmv'],
          'name': new Date(item['pricetime']),
          'nav': item['nav'],
          'value': item['navChangePercent'],
          'pricetime': item['pricetime']
        }
        series.push(obj);
      }
    }
    )
    if (series.length == 0) {
      const obj = {
        'marketval': data['fundmv'], 
        'name': this.xScaleMin,
        'nav': data['nav'],
        'value': 0,
        'pricetime': this.commonUtils.startTime
      }
      series.push(obj);
    }
    return series;
  }

   xAxisTickFormatting(v) {
   const tempDate = new Date(v);
   return formatDate(tempDate,"h:mm aaaaa'm'",'en-US');
 }

 getValueSty(value): string {
   let color = '';
   if (value.toString().indexOf('%') !== -1) {
     if (value.toString().indexOf('-')) {
       color = '#28743E'
     } else {
       color='#B91224'
     }
   }
   return color;
 }

 ngOnDestroy() {
    this.colorDomain = [];
  }

  resizingSingleLineChart(event) {
    this.width = event.target.innerWidth * 0.55;
  }

}
