// envrionment variables for library module
export const dev = { 
    service_base_url : 'http://10.10.50.10:8888',
    ws_url : 'ws://10.10.50.10:8888/qnav-web/conn'
}
export const prod = { 
    service_base_url : 'http://'+window.location.hostname+":"+window.location.port,
    ws_url :'ws://'+window.location.hostname+":"+window.location.port+'/qnav-web/conn'
}