import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomLegendComponent } from '../custom-legend/custom-legend.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UiCommonModule } from '@omnia/ui-common';
import {MatDialog,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';

import { QnavLineChartComponent } from './qnav-line-chart.component';

describe('QnavLineChartComponent', () => {
  let component: QnavLineChartComponent;
  let fixture: ComponentFixture<QnavLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QnavLineChartComponent ,CustomLegendComponent],
      imports: [
        MatDialogModule,
        UiCommonModule,
        MatChipsModule,
        MatIconModule,
        NgxChartsModule,
        HttpClientTestingModule
      ],
      providers: [ CustomLegendComponent,MatDialog,{
        provide: MatDialogRef,
        useValue: {}
      },
      {
        provide: MAT_DIALOG_DATA,
        useValue: {}
      } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QnavLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
