import { MatIconModule, MatButtonModule, MatCheckboxModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DynamicModule } from 'ng-dynamic-component';
import { NumberRoundUpPipe } from '../pipe/number-roundup.pipe';
import { PercentFormatPipe } from '../pipe/percent-format.pipe';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { CommonDataTableComponent } from './common-data-table.component';
import { By } from '@angular/platform-browser';
//import { CommonDataTableComponentgetSortIcon } from './common-data-table.component';

fdescribe('CommonDataTableComponent', () => {
  let component: CommonDataTableComponent;
  let fixture: ComponentFixture<CommonDataTableComponent>;
  let debugElement: DebugElement;
  let htmlElement: HTMLElement;
  let dom;
  let button;
   
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonDataTableComponent,NumberRoundUpPipe,PercentFormatPipe  ],
      imports: [
         NgxDatatableModule, 
         DynamicModule ,
         MatMenuModule , MatIconModule, MatButtonModule , MatCheckboxModule],
       providers: [NumberRoundUpPipe,PercentFormatPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.isDataAvailable = true;
    component.headerSetting = true;
    dom = fixture.nativeElement;
    button = dom.querySelector('button');

  });

  it('should create function', () => {
    const x = component.showNews(1);
    expect(x).toBe(true);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not have the menu open', async () => {
    const menu = dom.parentNode.querySelector('.mat-menu-panel');
    expect(menu).toBeFalsy();
  });

  it('open the menu when clicking on the menu-panel button', async () => {
    button.click();
    const menu = dom.parentNode.querySelector('.mat-menu-panel');
    expect(menu).toBeTruthy();
  });

  it('should call togglePauseFlag method',()=>{  //description of the spec or test case
      spyOn(component, "togglePauseFlag");  //spies on the method/function to be called
      component.isDataTablePaused = false;   // intialization for satisfying ngif condition
      fixture.detectChanges();                  // to detect changes 
      let e1 = fixture.debugElement.query(By.css("button")); //intializing clickable button instance into e1
      e1.triggerEventHandler("click", null); //button gets triggered 
      fixture.detectChanges();    //changes detected after button clicked
      fixture.whenStable().then(() => {
        expect(component.togglePauseFlag).toHaveBeenCalled(); //outcome 
        
      });
  });



  it('change row to standard by clicking standard method',()=>{  
    spyOn(component, "getRowHeight");
    component.rowHeight = 40;   
    fixture.detectChanges();
    let e1 = fixture.debugElement.query(By.css("button")); 
    e1.triggerEventHandler("click", null); 
    fixture.detectChanges();    
    fixture.whenStable().then(() => {
      expect(component.getRowHeight).toHaveBeenCalled(); 
    });
});



it('should call toggleUn-PauseFlag method',()=>{  //description of the spec or test case
  spyOn(component, "togglePauseFlag");  //spies on the method/function to be called
  component.isDataTablePaused = true;   // intialization for satisfying ngif condition
  fixture.detectChanges();                  // to detect changes 
  let e1 = fixture.debugElement.query(By.css("button")); //intializing clickable button instance into e1
  e1.triggerEventHandler("click", null); //button gets triggered 
  fixture.detectChanges();    //changes detected after button clicked
  fixture.whenStable().then(() => {
    expect(component.togglePauseFlag).toHaveBeenCalled(); //outcome expected
  });
});


  it('change row to standard by clicking standard method',()=>{  
    spyOn(component, "getRowHeight");  
    component.rowHeight = 50;   
    fixture.detectChanges();                  
    let e1 = fixture.debugElement.query(By.css("button")); 
    e1.triggerEventHandler("click", null); 
    fixture.detectChanges();    
    fixture.whenStable().then(() => {
      expect(component.getRowHeight).toHaveBeenCalled(); 
    });
});







});
