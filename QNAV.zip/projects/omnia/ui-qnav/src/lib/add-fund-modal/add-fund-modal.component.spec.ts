import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';

import { AddFundModalComponent } from './add-fund-modal.component';

describe('AddFundModalComponent', () => {
  let component: AddFundModalComponent;
  let fixture: ComponentFixture<AddFundModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFundModalComponent ],
      providers:[ {
        provide: MatDialogRef,
        useValue: {}
      },
      {
        provide: MAT_DIALOG_DATA,
        useValue: {}
      }]


    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFundModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
