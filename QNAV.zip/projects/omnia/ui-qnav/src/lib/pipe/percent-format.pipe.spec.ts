import { PercentFormatPipe } from './percent-format.pipe';

describe('PercentFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new PercentFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
