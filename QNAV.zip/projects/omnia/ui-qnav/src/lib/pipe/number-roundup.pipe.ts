import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberRoundUp'
})
export class NumberRoundUpPipe implements PipeTransform {

  transform(value: any, maxFractionDigits: number): any {
    return Math.round(10**maxFractionDigits*value)/10**maxFractionDigits;
  }

}
