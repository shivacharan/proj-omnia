export const defaultFundList = [

  {
    "name": "",
    "series": [
      {
        "name": "09:30:00",
        "value": 0.0,
        "nav": "0.0",
        "marketval": "0.0"
      }
    ]
  }
];

export const ticksValue = [
    new Date().setHours(9, 30, 0), 
    new Date().setHours(10, 30, 0),
    new Date().setHours(11, 30, 0),
    new Date().setHours(12, 30, 0),
    new Date().setHours(13, 30, 0),
    new Date().setHours(14, 30, 0),
    new Date().setHours(15, 30, 0),
    new Date().setHours(16, 30, 0)
    ];
    
