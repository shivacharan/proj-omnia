import { Injectable } from '@angular/core';
import { ShareInfoBeweenComponentsService } from '../services/share-info-beween-components.service';
import _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class CommonUtilsService {
  startTime: Date = new Date();
  endTime: Date = new Date();
  timeDivision: Date = new Date();
  liveTime: Date = new Date();
  isAfterMarketClose: boolean = false;
  constructor(private shareInforBewteenComponents: ShareInfoBeweenComponentsService
  ) {
    this.startTime.setHours(9, 30, 0, 0);
    this.endTime.setHours(16, 30, 0, 0);
    this.timeDivision.setHours(15, 30, 0, 0);
    let instance = setInterval(() => {
      if (new Date() < this.endTime) {
        this.liveTime = new Date()
      } else {
        this.liveTime = this.endTime;
        clearInterval(instance);
      }
    }, 1000);
    this.isAfterMarketClose = this.isAfterMarketColse(this.liveTime);
  }
  isAfterMarketColse(time: Date): boolean {
    if ( time <= this.endTime) {
      return false;
    }
    return true;
  }
  isBeforeMarketOpen(time: Date): boolean {
    if ( time >= this.startTime) {
      return false;
    }
    return true;
  }

  isValidTime(time: Date): boolean {

    if (time >= this.startTime && time <= this.endTime) {
      return true;
    }
    return false;
  }

  public isBeyondDivision(time: Date): boolean {
    if (time >= this.timeDivision) {
      return true;
    }
    return false;
  }

  public getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  
  public getColorForFund(fundid: String) {
    this.resetColorForFund(fundid);
    for (let item of this.shareInforBewteenComponents.colorSchema) {
      if (item['fundid'] === undefined) {
        item['fundid'] = fundid;
        return item['color'];
      }
    }
    return this.getRandomColor();

  }
  public resetColorForFund(fundid: String) {
    for (let item of this.shareInforBewteenComponents.colorSchema) {
      if (item['fundid'] === fundid) {
        item['fundid'] = undefined;
      }
    }
  }

  public updateFundStatus(fundid: String, isChecked: boolean) {
    const index = this.shareInforBewteenComponents.getFundList().findIndex(element => element.fundID === fundid);
    if (isChecked === this.shareInforBewteenComponents.getFundList()[index]['checked']) {
      return;
    }
    this.shareInforBewteenComponents.getFundList()[index]['checked'] = isChecked;
    //remove the color for the fund as well
    if (isChecked === false) {
      this.resetColorForFund(fundid);
    } else {
      this.getColorForFund(fundid);
    }

  }

  public formatTime(time: Date): string {
    let t = new Date(time);
    let second = '00';
    if (t.getSeconds() <= 20) {
      second = '00';
    } else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
      second = '20';
    } else {
      second = '40';
    }
    return ("0" + t.getHours()).slice(-2) + ':' + ("0" + t.getMinutes()).slice(-2) + ':' + second;
  }
  public formatDateTime(time): Date {
    let t = new Date(time);
    let second = '00';
    if (t.getSeconds() <= 20) {
      t.setSeconds(0);
      t.setMilliseconds(0);
    } else if (t.getSeconds() > 20 && t.getSeconds() <= 40) {
      t.setSeconds(20);
      t.setMilliseconds(0);
    } else {
      t.setSeconds(40);
      t.setMilliseconds(0);
    }
    return t;
  }
  //rest component shared information if login user/authorized token changed
  public validateUser() {
    if(this.shareInforBewteenComponents.accessToken) {
      if(sessionStorage.getItem('access_token') === this.shareInforBewteenComponents.accessToken) {
        return true;
      }
    }
    this.shareInforBewteenComponents.reset();
    this.shareInforBewteenComponents.accessToken = sessionStorage.getItem('access_token');
    return false;
  }

  public extractFundLevelData(data) {
    const fundLevelData = (data as any[]).map(d => {
          const rowTemp = {
              //fundid: d.fundid,
              fundid: d.fundid,
              maskedId: d.maskedId,
              name: d.name,
              classID: "A",
              child: "parent",
            };
            const multiClassData = d.classLevelTrialData;
            const row = Object.assign(rowTemp, multiClassData.A);
            return row;
          });
    return fundLevelData;
  }

  public extractClassLevelData(data) {
    const classLevelData = [];
    (data as any[]).forEach(d => {
           const rowTemp = {
            //fundid: d.fundid,
            fundid: d.fundid,
            maskedId: d.maskedId,
            name: d.name,
            child: "child",
          };
          const multiClassData = d.classLevelTrialData;
          for(let key in multiClassData) {
            if (key !== "A") {
              const childRow = Object.assign(rowTemp, multiClassData[key], {classID: key});
              classLevelData.push(_.cloneDeep(childRow));
            }
          }
          
        });
        return classLevelData.reverse();
  }

  public extractWSData(data,childOrNot) {
    let returnData = [];
    const temp = {
      cusip: data.cusip,
      exchangeRate: data.exchangeRate,
      //fundid: data.fundid,
      fundid: data.fundid,
      longShortIndicator: data.longShortIndicator,
      mv: data.mv,
      mvChange: data.mvChange,
      navImpact: data.navImpact,
      price: data.price,
      priceChangePercent: data.priceChangePercent,
      sodMv: data.sodMv,
      sodPrice: data.sodPrice,
      updatetime: data.updatetime
    }
    if (childOrNot) {
        for (let key in data) {
        if (Number(key)) {
          const row = Object.assign(temp, data[key], {classID: key});
          returnData.push(_.cloneDeep(row));
        }
      }
    } else {
      returnData = data["A"];
      returnData =  Object.assign(temp, returnData, {classID: "A"});
    }
    return returnData;
  }

  public sortColumnByProp(rows, childRows, expandCollapseIconMap, prop, ascFlag) {
    const pRows = [];
    rows.forEach(item => {
      if (item.classID === "A") pRows.push(item);
      if (childRows.length === 0) pRows.push(item);
    });
    ascFlag ? pRows.sort(this.sortCompareAsc(prop)) : pRows.sort(this.sortCompareDesc(prop));
    childRows.forEach(item => {
      const fundid = item.fundid;
      expandCollapseIconMap.forEach(expandItem => {
        if (expandItem.fundid === fundid && expandItem.expand) {
          const index = pRows.findIndex(pitem => {return pitem.fundid === fundid});
          pRows.splice(index + 1, 0, item)
        }
      })
    });
    return pRows;
  }

  private sortCompareAsc(prop) {
    return function (obj1, obj2) {
      let v1 = obj1[prop];
      let v2  = obj2[prop];
      if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
        v1 = Number(v1);
        v2 = Number(v2);
      }

      if (v1 === undefined || v1 < v2) {
        return -1
      } else if (v2 === undefined ||  v1 > v2) {
        return 1;
      } else {
        return 0
      }
    }
  }

  private sortCompareDesc(prop) {
    return function (obj1, obj2) {
      let v1 = obj1[prop];
      let v2  = obj2[prop];
      if (!isNaN(Number(v1)) && !isNaN(Number(v2))) {
        v1 = Number(v1);
        v2 = Number(v2);
      }
      if (v1 === undefined || v1 < v2 ) {
        return 1
      } else if (v2 === undefined || v1 > v2) {
        return -1;
      } else {
        return 0
      }
    }
  }

}
