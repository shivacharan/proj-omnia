export class QnavChart {
    name: string;
    customColor: string;
    series: Array<{
        name: string,
        value: number,
        nav: string,
        marketval: string
    }>;
}
