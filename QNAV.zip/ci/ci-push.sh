#!/usr/bin/env bash

set -e

fly -t ci-ui login -c https://ci.io.lab -u ui -p ui -n ui

fly -t ci-ui sp --non-interactive -c ui-qnav.yml -p qnav-ui -l config.yml

fly -t ci-ui unpause-pipeline --pipeline=qnav-ui
